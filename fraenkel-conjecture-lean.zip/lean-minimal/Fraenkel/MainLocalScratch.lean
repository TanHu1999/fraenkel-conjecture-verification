import Fraenkel.Beatty.OneThird
import Fraenkel.External.Tijdeman2000
import Fraenkel.External.BaratVarju2003
import Fraenkel.Words.Periodic
import Fraenkel.Beatty.RigidExtension

namespace Fraenkel

 def TestBiInfiniteBeattyPartition {m : ℕ} (α β : Fin m → ℝ) : Prop :=
  ∀ z : ℤ, ∃! i : Fin m,
    z ∈ biInfiniteBeattySequence (α i) (β i)

 theorem makeRationalPartitionTest
    {m : ℕ} (hm : 3 ≤ m) (α β : Fin m → ℝ)
    (hα : ∀ i, 1 < α i)
    (hdistinct : Function.Injective α)
    (hpartition : TestBiInfiniteBeattyPartition α β) :
    ∃ P : RationalBeattyPartition m,
      ∀ i, (P.moduli i : ℝ) = α i := by
  classical
  let hpart : BeattyPartition α β := ⟨hα, hpartition⟩
  choose μ hμ using rationalityOfBiInfiniteBeattyPartitionModuli α β hm hpart hdistinct
  let P : RationalBeattyPartition m :=
    { nonempty := by omega
      moduli := μ
      shifts := β
      modulus_gt_one := by
        intro i
        have hi := hα i
        have hmi := hμ i
        exact_mod_cast (show (1 : ℝ) < (μ i : ℝ) from by simpa [hmi] using hi)
      partition := by
        intro z
        obtain ⟨i, hi, hu⟩ := hpartition z
        refine ⟨i, ?_, ?_⟩
        · simpa only [hμ i] using hi
        · intro j hj
          apply hu j
          simpa only [hμ j] using hj }
  refine ⟨P, ?_⟩
  intro i
  exact hμ i

theorem leastPositiveBeattyIndexTest (α β : ℝ) (hα : 1 < α) :
    ∃ n₀ : ℤ, 0 < beattyTerm α β n₀ ∧
      ∀ n : ℤ, 0 < beattyTerm α β n → n₀ ≤ n := by
  have hαpos : 0 < α := lt_trans zero_lt_one hα
  obtain ⟨N, hN⟩ := exists_nat_gt ((β - 1) / α)
  have hNmul : β - 1 < (N : ℝ) * α := by
    exact (div_lt_iff₀ hαpos).mp hN
  have hbound : ∀ n : ℤ, 0 < beattyTerm α β n → -(N : ℤ) ≤ n := by
    intro n hn
    by_contra hnot
    have hnlt : n < -(N : ℤ) := by omega
    have harg : (n : ℝ) * α + β < 1 := by
      have hnR : (n : ℝ) ≤ (-(N : ℤ) - 1 : ℤ) := by
        exact_mod_cast (show n ≤ -(N : ℤ) - 1 by omega)
      push_cast at hnR
      nlinarith
    have hfloor : beattyTerm α β n ≤ 0 := by
      apply (Int.floor_le_iff).2
      simpa using harg
    omega
  obtain ⟨N', hN'⟩ := exists_nat_gt ((1 - β) / α)
  have hN'mul : 1 - β < (N' : ℝ) * α := by
    exact (div_lt_iff₀ hαpos).mp hN'
  have hpositive : 0 < beattyTerm α β (N' : ℤ) := by
    apply (Int.floor_pos).2
    push_cast
    nlinarith
  exact Int.exists_least_of_bdd ⟨-(N : ℤ), hbound⟩
    ⟨(N' : ℤ), hpositive⟩

theorem positiveTailSet_eqTest (α β : ℝ) (hα : 1 < α)
    (n₀ : ℤ) (hn₀ : 0 < beattyTerm α β n₀)
    (hmin : ∀ n : ℤ, 0 < beattyTerm α β n → n₀ ≤ n) :
    External.Graham1973.oneSidedBeattySequence α
        (β + ((n₀ - 1 : ℤ) : ℝ) * α) =
      {z : ℤ | ∃ n : ℤ, n₀ ≤ n ∧ beattyTerm α β n = z} := by
  ext z
  constructor
  · rintro ⟨n, hn, hz⟩
    refine ⟨n + n₀ - 1, ?_, ?_⟩
    · omega
    · change beattyTerm α
        (β + ((n₀ - 1 : ℤ) : ℝ) * α) n = z at hz
      change beattyTerm α β (n + n₀ - 1) = z
      simp only [beattyTerm] at hz ⊢
      convert hz using 1 <;> push_cast <;> ring
  · rintro ⟨n, hn, rfl⟩
    refine ⟨n - n₀ + 1, ?_, ?_⟩
    · omega
    · change beattyTerm α
        (β + ((n₀ - 1 : ℤ) : ℝ) * α) (n - n₀ + 1) =
          beattyTerm α β n
      simp only [beattyTerm]
      push_cast
      congr 1
      ring

theorem positiveTailReindexTest {m : ℕ} (α β : Fin m → ℝ)
    (hα : ∀ i, 1 < α i)
    (hpartition : TestBiInfiniteBeattyPartition α β) :
    ∃ β' : Fin m → ℝ,
      External.Tijdeman2000.PositiveBeattyPartition α β' := by
  classical
  choose n₀ hn₀ hmin using fun i => leastPositiveBeattyIndexTest (α i) (β i) (hα i)
  let β' : Fin m → ℝ := fun i =>
    β i + ((n₀ i - 1 : ℤ) : ℝ) * α i
  refine ⟨β', ?_⟩
  constructor
  · intro z
    constructor
    · intro hzpos
      obtain ⟨i, hi, hu⟩ := hpartition z
      obtain ⟨n, hn⟩ := hi
      have hn' : beattyTerm (α i) (β i) n = z := by
        simpa [beattyTerm] using hn
      have hnt : n₀ i ≤ n := by
        apply hmin i n
        rw [hn']
        exact hzpos
      have htail := positiveTailSet_eqTest (α i) (β i) (hα i)
        (n₀ i) (hn₀ i) (hmin i)
      have hzset : z ∈ {w : ℤ | ∃ t : ℤ,
          n₀ i ≤ t ∧ beattyTerm (α i) (β i) t = w} := by
        exact ⟨n, hnt, hn⟩
      have : z ∈ External.Graham1973.oneSidedBeattySequence (α i) (β' i) := by
        rw [show β' i = β i + ((n₀ i - 1 : ℤ) : ℝ) * α i by rfl]
        rw [htail]
        exact hzset
      exact ⟨i, this⟩
    · rintro ⟨i, hi⟩
      have htail := positiveTailSet_eqTest (α i) (β i) (hα i)
        (n₀ i) (hn₀ i) (hmin i)
      rw [show β' i = β i + ((n₀ i - 1 : ℤ) : ℝ) * α i by rfl,
        htail] at hi
      obtain ⟨n, hnt, hnz⟩ := hi
      have hmono := (beattyTerm_strictMono (α i) (β i) (hα i)).monotone hnt
      have hpos := hn₀ i
      calc
        0 < beattyTerm (α i) (β i) (n₀ i) := hpos
        _ ≤ beattyTerm (α i) (β i) n := hmono
        _ = z := hnz
  · intro z i j hi hj
    have htaili := positiveTailSet_eqTest (α i) (β i) (hα i)
      (n₀ i) (hn₀ i) (hmin i)
    have htailj := positiveTailSet_eqTest (α j) (β j) (hα j)
      (n₀ j) (hn₀ j) (hmin j)
    have hi' : z ∈ biInfiniteBeattySequence (α i) (β i) := by
      obtain ⟨n, hn, hnz⟩ := by
        rw [show β' i = β i + ((n₀ i - 1 : ℤ) : ℝ) * α i by rfl,
          htaili] at hi
        exact hi
      exact ⟨n, hnz⟩
    have hj' : z ∈ biInfiniteBeattySequence (α j) (β j) := by
      obtain ⟨n, hn, hnz⟩ := by
        rw [show β' j = β j + ((n₀ j - 1 : ℤ) : ℝ) * α j by rfl,
          htailj] at hj
        exact hj
      exact ⟨n, hnz⟩
    obtain ⟨k, hk, huk⟩ := hpartition z
    exact (huk i hi').trans (huk j hj').symm

/-- The recorded one-sided results, applied to the positive tails. -/
theorem knownCasesThroughSevenTest
    {m : ℕ} (hm : 3 ≤ m) (hm7 : m ≤ 7) (α β : Fin m → ℝ)
    (hα : ∀ i, 1 < α i) (hdistinct : Function.Injective α)
    (hpartition : TestBiInfiniteBeattyPartition α β) :
    Set.range α = Set.range (fun j : Fin m =>
      ((2 : ℝ) ^ m - 1) / (2 : ℝ) ^ j.val) := by
  obtain ⟨β', hβ'⟩ := positiveTailReindexTest α β hα hpartition
  by_cases hm6 : m ≤ 6
  · exact External.Tijdeman2000.fraenkelConjectureForSixSequences
      hm hm6 α β' hα hdistinct hβ'
  · have hm_eq : m = 7 := by omega
    subst m
    exact External.BaratVarju2003.fraenkelConjectureForSevenSequences
      α β' hα hdistinct hβ'

end Fraenkel
