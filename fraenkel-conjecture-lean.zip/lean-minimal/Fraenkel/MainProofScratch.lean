import Fraenkel.MainLocalScratch
import Fraenkel.Words.CompressedPeriodScratch

open scoped BigOperators Classical

namespace Fraenkel

 theorem selectCriticalLetterScratch
    {m : ℕ} (hm : 3 ≤ m) (α β : Fin m → ℝ)
    (hα : ∀ i, 1 < α i)
    (hdistinct : Function.Injective α)
    (hpartition : TestBiInfiniteBeattyPartition α β) :
    ∃ (P : RationalBeattyPartition m) (q : ℤ) (p r : Fin m → ℤ) (a : Fin m),
      PrimitiveRationalBeattyPartition P q p r ∧
      (∀ i, (P.moduli i : ℝ) = α i) ∧
      (p a = maximumNumerator P p) ∧
      (P.moduli a : ℝ) ≤ 3 := by
  obtain ⟨P, hPα⟩ := makeRationalPartitionTest hm α β hα hdistinct hpartition
  obtain ⟨q₀, p₀, r₀, hpres₀⟩ := commonDenominatorPresentation_exists P
  obtain ⟨hmods, hsets, hprim, hinj⟩ :=
    primitiveNormalizationPreservesRationalBeattySets P q₀ p₀ r₀ hpres₀
  have hPα' : ∀ i, (P.moduli i : ℝ) = α i := hPα
  have hPinj : Function.Injective P.moduli := by
    intro i j hij
    apply hdistinct
    have hcast : (P.moduli i : ℝ) = (P.moduli j : ℝ) :=
      congrArg (fun x : ℚ => (x : ℝ)) hij
    exact (hPα i).symm.trans (hcast.trans (hPα j))
  let q := commonDenominatorGcd q₀ p₀
  let p : Fin m → ℤ := fun i => p₀ i / q
  let r := r₀
  have hprim' : PrimitiveRationalBeattyPartition P (q₀ / q) p r := by
    simpa [q, p, r] using hprim
  have hinj' : Function.Injective p := hinj hPinj
  have hthird := oneThirdTheorem P (q₀ / q) p r hprim' hPinj
  let S : Finset ℤ := Finset.univ.image p
  have hSne : S.Nonempty := by
    refine ⟨p ⟨0, P.nonempty⟩, ?_⟩
    exact Finset.mem_image.mpr ⟨⟨0, P.nonempty⟩, Finset.mem_univ _, rfl⟩
  obtain ⟨a, haS, hap⟩ := Finset.mem_image.mp (Finset.max'_mem S hSne)
  have hpa : p a = maximumNumerator P p := by
    simpa [maximumNumerator, S] using hap
  have hpa_pos : 0 < p a := hprim'.2.1 a |>.1
  have hq_pos : 0 < q₀ / q := hprim'.1.q_pos
  have hratio_le : ((q₀ / q : ℤ) : ℝ) / (p a : ℝ) ≤ 3 := by
    have hthird' : ((q₀ / q : ℤ) : ℝ) / 3 ≤ (p a : ℝ) := by
      simpa [hpa] using hthird
    have hpR : 0 < (p a : ℝ) := by exact_mod_cast hpa_pos
    have hqR : 0 < ((q₀ / q : ℤ) : ℝ) := by exact_mod_cast hq_pos
    have hrel : (((q₀ / q : ℤ) : ℝ) / (p a : ℝ)) * (p a : ℝ) =
        ((q₀ / q : ℤ) : ℝ) := by
      field_simp
    nlinarith
  refine ⟨P, q₀ / q, p, r, a, hprim', hPα', hpa, ?_⟩
  have hratio_eq : ((q₀ / q : ℤ) : ℝ) / (p a : ℝ) = (P.moduli a : ℝ) := by
    simpa [p, q] using (hmods a).1.trans (hmods a).2
  rw [← hratio_eq]
  exact hratio_le

theorem prepareCriticalDeletionScratch
    {m : ℕ} (hm : 3 ≤ m) (α β : Fin m → ℝ)
    (hα : ∀ i, 1 < α i)
    (hdistinct : Function.Injective α)
    (hpartition : TestBiInfiniteBeattyPartition α β) :
    ∃ (P : RationalBeattyPartition m) (q : ℤ) (p r : Fin m → ℤ) (a : Fin m),
      PrimitiveRationalBeattyPartition P q p r ∧
      (∀ i, (P.moduli i : ℝ) = α i) ∧
      p a = maximumNumerator P p ∧
      Function.Injective p ∧
      (P.moduli a : ℝ) ≤ 3 ∧
      ∃ (W : ℤ → Fin m) (W' : ℤ → DeletedAlphabet m a),
        W = beattyPartitionCodingWord (fun i => (P.moduli i : ℝ)) P.shifts
          ⟨fun i => by
            change (1 : ℝ) < (P.moduli i : ℝ)
            exact_mod_cast P.modulus_gt_one i, P.partition⟩ ∧
        IsCompressedDeletion W a W' ∧ BalancedWord W' ∧
        Function.Periodic W' (q - p a) ∧
        ∀ b : DeletedAlphabet m a, ∀ z : ℤ,
          wordIntervalCount W' b z (z + (q - p a)) = p b.val := by
  obtain ⟨P, q, p, r, a, hprim, hPα, hpa, haRate⟩ :=
    selectCriticalLetterScratch hm α β hα hdistinct hpartition
  have hp_inj : Function.Injective p := by
    intro i j hij
    apply hdistinct
    rw [← hPα i, ← hPα j, ← hprim.1.modulus_eq i, ← hprim.1.modulus_eq j, hij]
  let αP : Fin m → ℝ := fun i => (P.moduli i : ℝ)
  let βP : Fin m → ℝ := P.shifts
  have hpartP : BeattyPartition αP βP := by
    refine ⟨?_, ?_⟩
    · intro i
      change (1 : ℝ) < (P.moduli i : ℝ)
      exact_mod_cast P.modulus_gt_one i
    · exact P.partition
  let W : ℤ → Fin m := beattyPartitionCodingWord αP βP hpartP
  obtain ⟨W', hdel, hbal'⟩ := deletionAtRateAtMostThree αP βP hpartP a (by
    simpa [αP] using haRate)
  obtain ⟨e, he⟩ := hdel
  have hWper : Function.Periodic W q := by
    intro z
    have hi := (beattyPartitionCodingWord_spec αP βP hpartP z (W z)).mp rfl
    have hsetper (i : Fin m) (t : ℤ) :
        t + q ∈ biInfiniteBeattySequence (αP i) (βP i) ↔
          t ∈ biInfiniteBeattySequence (αP i) (βP i) := by
      have hperiod := (periodDensityAndModulus (p i) q (r i)
        (hprim.1.numerator_bounds i).1 (hprim.1.numerator_bounds i).2).1
      have hset : biInfiniteBeattySequence (αP i) (βP i) =
          integerTranslatedRationalBeattySet (p i) q (r i) := by
        simpa [αP, βP] using hprim.1.set_eq i
      rw [hset]
      exact integerIndicator_period_mem_iffScratch _ q hperiod t
    exact (beattyPartitionCodingWord_spec αP βP hpartP (z + q) (W z)).mpr
      ((hsetper (W z) z).mpr hi)
  have hWcount (i : Fin m) (z : ℤ) :
      wordIntervalCount W i z (z + q) = p i := by
    have hcount := codingWordIntervalCount_eq_integerBlockCountScratch
      αP βP hpartP i z (z + q) (by linarith [hprim.1.q_pos])
    have hperiodcount :=
      (commonDenominator_period_count P q p r hprim.1 i).2 z
    have hsub : z + q - z = q := by ring
    rw [hsub] at hcount
    rw [hcount]
    have hset : biInfiniteBeattySequence (αP i) (βP i) =
        integerTranslatedRationalBeattySet (p i) q (r i) := by
      simpa [αP, βP] using hprim.1.set_eq i
    have hperiodcount' : integerBlockCount
        (biInfiniteBeattySequence (αP i) (βP i)) z q.toNat = (p i).toNat := by
      simpa [αP, βP] using hperiodcount
    rw [hperiodcount']
    have hqnat : q.toNat = q.toNat := rfl
    have hcast : ((p i).toNat : ℤ) = p i := by
      rw [Int.toNat_of_nonneg (hprim.1.numerator_bounds i).1.le]
    rw [hcast]
  have hretcount : ∀ z : ℤ,
      (((Finset.Ico z (z + q)).filter (fun t => W t ≠ a)).card : ℤ) = q - p a := by
    exact retainedCountFromDeletedCountScratch W a q (p a) hprim.1.q_pos.le
      (fun z => hWcount a z)
  have hshift : ∀ j : ℤ, (e j).val + q = (e (j + (q - p a))).val := by
    intro j
    exact (retainedEnumerationShiftScratch W a e q (p a)
      hprim.1.q_pos (hprim.2.1 a).1 (hprim.2.1 a).2 hWper hretcount j).symm
  have hW'per : Function.Periodic W' (q - p a) := by
    exact compressedWordPeriodicScratch W a W' e he q (p a) hWper hshift
  have hW'count (b : DeletedAlphabet m a) (z : ℤ) :
      wordIntervalCount W' b z (z + (q - p a)) = p b.val := by
    have hcomp := compressedIntervalCountScratch W a W' e he b z
      (z + (q - p a))
    rw [hcomp]
    have hcount := hWcount b.val (e z).val
    rw [hshift z] at hcount
    exact hcount
  have hdel' : IsCompressedDeletion W a W' := ⟨e, he⟩
  refine ⟨P, q, p, r, a, hprim, hPα, hpa, hp_inj, haRate, W, W', rfl, hdel', hbal', hW'per,
    hW'count⟩

theorem compressedRationalDataScratch
    {m : ℕ} (hm : 3 ≤ m) (α β : Fin m → ℝ)
    (hα : ∀ i, 1 < α i)
    (hdistinct : Function.Injective α)
    (hpartition : TestBiInfiniteBeattyPartition α β) :
    ∃ (P : RationalBeattyPartition m) (q : ℤ) (p r : Fin m → ℤ) (a : Fin m),
      PrimitiveRationalBeattyPartition P q p r ∧
      (∀ i, (P.moduli i : ℝ) = α i) ∧
      p a = maximumNumerator P p ∧ Function.Injective p ∧
      (P.moduli a : ℝ) ≤ 3 ∧
      ∃ αD βD : DeletedAlphabet m a → ℝ,
        (∀ b, 1 < αD b) ∧ Function.Injective αD ∧
        (∀ b, αD b = ((q - p a : ℤ) : ℝ) / (p b.val : ℝ)) ∧
        (∀ z : ℤ, ∃! b, z ∈ biInfiniteBeattySequence (αD b) (βD b)) := by
  obtain ⟨P, q, p, r, a, hprim, hPα, hpa, hp_inj, haRate,
      W, W', hWdef, hdel, hbal', hW'per, hW'count⟩ :=
    prepareCriticalDeletionScratch hm α β hα hdistinct hpartition
  classical
  letI : Fintype (DeletedAlphabet m a) :=
    Fintype.subtype (Finset.univ.filter (fun i : Fin m => i ≠ a)) (by simp)
  obtain ⟨e, he⟩ := hdel
  let k : ℤ := q - p a
  have hk : 0 < k := by
    dsimp [k]
    exact sub_pos.mpr (hprim.2.1 a).2
  let X : DeletedAlphabet m a → Set ℤ := fun b => {z : ℤ | W' z = b}
  have hW'surj : ∀ b : DeletedAlphabet m a, ∃ z : ℤ, W' z = b := by
    intro b
    obtain ⟨z, hz⟩ := beattyPartitionCodingWord_surjective
      (fun i => (P.moduli i : ℝ)) P.shifts
      ⟨fun i => by
        change (1 : ℝ) < (P.moduli i : ℝ)
        exact_mod_cast P.modulus_gt_one i, P.partition⟩ b.val
    have hret : (beattyPartitionCodingWord
        (fun i => (P.moduli i : ℝ)) P.shifts
        ⟨fun i => by
          change (1 : ℝ) < (P.moduli i : ℝ)
          exact_mod_cast P.modulus_gt_one i, P.partition⟩ z) ≠ a := by
      simpa [hWdef, hz] using b.property
    let rz : RetainedPositions W a := ⟨z, by simpa [hWdef] using hret⟩
    obtain ⟨j, hj⟩ := e.surjective rz
    refine ⟨j, ?_⟩
    rw [he j]
    apply Subtype.ext
    simpa [rz, hj, hWdef, hz]
  have hXnonempty (b : DeletedAlphabet m a) : (X b).Nonempty := by
    obtain ⟨z, hz⟩ := hW'surj b
    exact ⟨z, hz⟩
  have hcardDel : Fintype.card (DeletedAlphabet m a) = m - 1 := by
    simp [DeletedAlphabet, Fintype.card_subtype_compl]
  letI : Nontrivial (DeletedAlphabet m a) :=
    Fintype.one_lt_card_iff_nontrivial.mp (by rw [hcardDel]; omega)
  have hXproper (b : DeletedAlphabet m a) : (X b)ᶜ.Nonempty := by
    obtain ⟨c, hcb⟩ := exists_ne b
    obtain ⟨z, hzc⟩ := hW'surj c
    refine ⟨z, (Set.mem_compl_iff (X b) z).2 ?_⟩
    intro hzb
    exact hcb (by simpa [X] using hzc.symm.trans hzb)
  have hXpb (b : DeletedAlphabet m a) : PeriodicBalancedSubset (X b) := by
    refine ⟨k, hk, ?_, ?_⟩
    · intro z
      have hz := congrArg (fun c : DeletedAlphabet m a => decide (c = b)) (hW'per z)
      simpa [binarySubsetWord, X] using hz
    · simpa [X] using binarySubsetBalancedOfBalancedWordScratch W' b hbal'
  choose pb qb rb hpb hpbq hXeq using fun b =>
    periodicBalancedSubsetsAreRationalBeattySets (X b) (hXpb b)
      (hXnonempty b) (hXproper b)
  let αD : DeletedAlphabet m a → ℝ := fun b => (qb b : ℝ) / (pb b : ℝ)
  let βD : DeletedAlphabet m a → ℝ := fun b => (rb b : ℝ)
  have hαD (b : DeletedAlphabet m a) : 1 < αD b := by
    dsimp [αD]
    apply (lt_div_iff₀ (by exact_mod_cast (hpb b))).2
    norm_num
    exact_mod_cast (hpbq b)
  have hcountD (b : DeletedAlphabet m a) (z : ℤ) :
      wordIntervalCount W' b z (z + qb b) = pb b := by
    have hqb : 0 < qb b := lt_trans (hpb b) (hpbq b)
    have hc := wordIntervalCount_eq_integerBlockCount_of_memScratch W' b (X b)
      (by intro t; rfl) z (z + qb b) (by linarith)
    have hpcount := (periodDensityAndModulus (pb b) (qb b) (rb b)
      (hpb b) (hpbq b)).2.1 z
    have hsetcount : integerBlockCount (X b) z (qb b).toNat = (pb b).toNat := by
      rw [hXeq b]
      exact hpcount
    have hsub : z + qb b - z = qb b := by ring
    rw [hsub] at hc
    rw [hc, hsetcount]
    rw [Int.toNat_of_nonneg (hpb b).le]
  have hprod (b : DeletedAlphabet m a) : qb b * p b.val = k * pb b := by
    have hqb : 0 < qb b := lt_trans (hpb b) (hpbq b)
    have hmulK := wordIntervalCount_mul_periodScratch W' b k (p b.val) hk
      (hW'count b) 0 (qb b).toNat
    have hmulQ := wordIntervalCount_mul_periodScratch W' b (qb b) (pb b) hqb
      (fun t => hcountD b t) 0 k.toNat
    have hqnat : ((qb b).toNat : ℤ) = qb b := by
      rw [Int.toNat_of_nonneg hqb.le]
    have hknat : (k.toNat : ℤ) = k := by
      rw [Int.toNat_of_nonneg hk.le]
    rw [hqnat] at hmulK
    rw [hknat] at hmulQ
    have hend : (0 : ℤ) + qb b * k = 0 + k * qb b := by ring
    rw [hend] at hmulK
    exact hmulK.symm.trans (by simpa [mul_comm] using hmulQ)
  have hratio (b : DeletedAlphabet m a) :
      αD b = (k : ℝ) / (p b.val : ℝ) := by
    dsimp [αD]
    apply (div_eq_div_iff (by exact_mod_cast (ne_of_gt (hpb b)))
      (by exact_mod_cast (ne_of_gt (hprim.2.1 b.val).1))).2
    exact_mod_cast hprod b
  have hαDinj : Function.Injective αD := by
    intro b c hbc
    have hratioeq : (k : ℝ) / (p b.val : ℝ) = (k : ℝ) / (p c.val : ℝ) :=
      (hratio b).symm.trans (hbc.trans (hratio c))
    have hcross : (k : ℝ) * (p c.val : ℝ) =
        (k : ℝ) * (p b.val : ℝ) :=
      (div_eq_div_iff (by exact_mod_cast (ne_of_gt (hprim.2.1 b.val).1))
        (by exact_mod_cast (ne_of_gt (hprim.2.1 c.val).1))).mp hratioeq
    have hpvalR : (p c.val : ℝ) = p b.val := by
      exact mul_left_cancel₀ (show (k : ℝ) ≠ 0 by exact_mod_cast (ne_of_gt hk)) hcross
    have hpval : p b.val = p c.val := by
      exact_mod_cast hpvalR.symm
    have hbcval : b.val = c.val := hp_inj hpval
    exact Subtype.ext hbcval
  have hpartD : ∀ z : ℤ, ∃! b : DeletedAlphabet m a,
      z ∈ biInfiniteBeattySequence (αD b) (βD b) := by
    intro z
    let b₀ := W' z
    have hbmem : z ∈ X b₀ := by rfl
    have hbset : z ∈ integerTranslatedRationalBeattySet (pb b₀) (qb b₀) (rb b₀) := by
      rw [← hXeq b₀]
      exact hbmem
    refine ⟨b₀, ?_, ?_⟩
    · simpa [αD, βD, integerTranslatedRationalBeattySet] using hbset
    · intro c hc
      have hcset : z ∈ X c := by
        rw [hXeq c]
        simpa [αD, βD, integerTranslatedRationalBeattySet] using hc
      have hbc : b₀ = c := by
        apply Subtype.ext
        simpa [X, b₀] using congrArg Subtype.val hcset
      exact hbc.symm
  refine ⟨P, q, p, r, a, hprim, hPα, hpa, hp_inj, haRate,
    αD, βD, hαD, hαDinj, ?_, hpartD⟩
  intro b
  simpa [k] using hratio b

theorem oneThirdStrongScratch
    {m : ℕ} (hm : 3 ≤ m) (α β : Fin m → ℝ)
    (hα : ∀ i, 1 < α i)
    (hdistinct : Function.Injective α)
    (hpartition : TestBiInfiniteBeattyPartition α β) :
    Set.range α = Set.range (fun j : Fin m =>
      ((2 : ℝ) ^ m - 1) / (2 : ℝ) ^ j.val) := by
  have hmain : ∀ n : ℕ, 3 ≤ n →
      ∀ (α β : Fin n → ℝ),
        (∀ i, 1 < α i) → Function.Injective α →
        TestBiInfiniteBeattyPartition α β →
        Set.range α = Set.range (fun j : Fin n =>
          ((2 : ℝ) ^ n - 1) / (2 : ℝ) ^ j.val) := by
    intro n
    induction n using Nat.strong_induction_on with
    | h n ih =>
      intro hn α β hα hαinj hpart
      by_cases hn7 : n ≤ 7
      · exact knownCasesThroughSevenTest hn hn7 α β hα hαinj hpart
      · obtain ⟨P, q, p, r, a, hprim, hPα, hpa, hp_inj, haRate,
            αD, βD, hαD, hαDinj, hDdensity, hDpart⟩ :=
          compressedRationalDataScratch hn α β hα hαinj hpart
        letI : Fintype (DeletedAlphabet n a) :=
          Fintype.subtype (Finset.univ.filter (fun i : Fin n => i ≠ a)) (by simp)
        have hcardDel : Fintype.card (DeletedAlphabet n a) = n - 1 := by
          simp [DeletedAlphabet, Fintype.card_subtype_compl]
        let e₀ : DeletedAlphabet n a ≃ Fin (Fintype.card (DeletedAlphabet n a)) :=
          Fintype.equivFin (DeletedAlphabet n a)
        let e : DeletedAlphabet n a ≃ Fin (n - 1) := e₀.trans (finCongr hcardDel)
        let αF : Fin (n - 1) → ℝ := fun j => αD (e.symm j)
        let βF : Fin (n - 1) → ℝ := fun j => βD (e.symm j)
        have hαF : ∀ j, 1 < αF j := by
          intro j
          exact hαD (e.symm j)
        have hαFinj : Function.Injective αF := by
          intro i j hij
          apply e.symm.injective
          apply hαDinj
          simpa [αF] using hij
        have hpartF : TestBiInfiniteBeattyPartition αF βF := by
          intro z
          obtain ⟨b, hb, hbu⟩ := hDpart z
          refine ⟨e b, ?_, ?_⟩
          · simpa [αF, βF] using hb
          · intro j hj
            apply e.symm.injective
            simpa using hbu (e.symm j) (by simpa [αF, βF] using hj)
        have hsmall : 3 ≤ n - 1 := by omega
        have hrangeF := ih (n - 1) (by omega) hsmall αF βF hαF hαFinj hpartF
        let M : ℤ := (2 : ℤ) ^ (n - 2)
        let D : ℤ := 2 * M - 1
        have hM2 : 2 ≤ M := by
          dsimp [M]
          have he : 1 ≤ n - 2 := by omega
          have hpw := pow_le_pow_right₀ (a := (2 : ℤ)) (by norm_num) he
          simpa using hpw
        have hDpos : 0 < D := by dsimp [D]; omega
        have hpow : ((2 : ℝ) ^ (n - 1) - 1) = (D : ℝ) := by
          have he : n - 1 = (n - 2) + 1 := by omega
          dsimp [D, M]
          rw [he, pow_succ]
          push_cast
          ring
        have htarget : Set.range (fun j : Fin (n - 1) =>
            ((2 : ℝ) ^ (n - 1) - 1) / (2 : ℝ) ^ j.val) =
            Set.range (fun j : Fin (n - 1) =>
              (D : ℝ) / (2 : ℝ) ^ j.val) := by
          apply congrArg Set.range
          funext j
          rw [hpow]
        have hαFrange : Set.range αF = Set.range αD := by
          ext x
          constructor
          · rintro ⟨j, rfl⟩
            exact ⟨e.symm j, by simp [αF]⟩
          · rintro ⟨b, rfl⟩
            exact ⟨e b, by simp [αF]⟩
        have hDtarget : Set.range αD = Set.range (fun j : Fin (n - 1) =>
            (D : ℝ) / (2 : ℝ) ^ j.val) :=
          hαFrange.symm.trans (hrangeF.trans htarget)
        have hpowpos (j : Fin (n - 1)) :
            0 < ((2 : ℤ) ^ j.val) := by positivity
        have hcross (b : DeletedAlphabet n a) (j : Fin (n - 1))
            (hEq : αD b = (D : ℝ) / (2 : ℝ) ^ j.val) :
            D * p b.val = (q - p a) * (2 : ℤ) ^ j.val := by
          have hreal : ((q - p a : ℤ) : ℝ) / (p b.val : ℝ) =
              (D : ℝ) / (2 : ℝ) ^ j.val :=
            (hDdensity b).symm.trans hEq
          have hcrossR := (div_eq_div_iff
            (by exact_mod_cast (ne_of_gt (hprim.2.1 b.val).1))
            (by exact_mod_cast (ne_of_gt (hpowpos j)))).mp hreal
          exact_mod_cast hcrossR.symm
        let hbasej : Fin (n - 1) := ⟨0, by omega⟩
        have hbaseMem : (D : ℝ) / (2 : ℝ) ^ hbasej.val ∈ Set.range αD := by
          rw [hDtarget]
          exact ⟨hbasej, rfl⟩
        obtain ⟨b₀, hb₀⟩ := hbaseMem
        have hbaseCross := hcross b₀ hbasej hb₀
        let h : ℤ := p b₀.val
        have hkrel : q - p a = D * h := by
          dsimp [h]
          simpa [hbasej] using hbaseCross.symm
        have hpos : 0 < h := by dsimp [h]; exact hprim.2.1 b₀.val |>.1
        have hvalue (b : DeletedAlphabet n a) (j : Fin (n - 1))
            (hEq : αD b = (D : ℝ) / (2 : ℝ) ^ j.val) :
            p b.val = h * (2 : ℤ) ^ j.val := by
          have hc := hcross b j hEq
          rw [hkrel] at hc
          have hcancel : D * p b.val = D * (h * (2 : ℤ) ^ j.val) := by
            calc
              D * p b.val = D * h * (2 : ℤ) ^ j.val := hc
              _ = D * (h * (2 : ℤ) ^ j.val) := by ring
          exact mul_left_cancel₀ (ne_of_gt hDpos) hcancel
        have hsurv (i : Fin n) (hia : i ≠ a) :
            ∃ j : Fin (n - 1), p i = h * (2 : ℤ) ^ j.val := by
          let b : DeletedAlphabet n a := ⟨i, hia⟩
          have hmem : αD b ∈ Set.range (fun j : Fin (n - 1) =>
              (D : ℝ) / (2 : ℝ) ^ j.val) := by
            rw [← hDtarget]
            exact ⟨b, rfl⟩
          obtain ⟨j, hj⟩ := hmem
          exact ⟨j, hvalue b j hj.symm⟩
        have hexists (j : Fin (n - 1)) :
            ∃ i : Fin n, i ≠ a ∧ p i = h * (2 : ℤ) ^ j.val := by
          have hmem : (D : ℝ) / (2 : ℝ) ^ j.val ∈ Set.range αD := by
            rw [hDtarget]
            exact ⟨j, rfl⟩
          obtain ⟨b, hb⟩ := hmem
          refine ⟨b.val, b.property, hvalue b j hb⟩
        let jM : Fin (n - 1) := ⟨n - 2, by omega⟩
        obtain ⟨iM, hiM, hiMp⟩ := hexists jM
        have hiMpM : p iM = M * h := by
          simpa [jM, M, mul_comm] using hiMp
        have hqrel : q = p a + D * h := by
          linarith [hkrel]
        have hgcd : Int.gcd (p a) h = 1 := by
          apply (Int.gcd_eq_one_iff).2
          intro c hcpa hch
          have hcq : c ∣ q := by
            rw [hqrel]
            exact dvd_add hcpa (dvd_mul_of_dvd_right hch D)
          have hcp (i : Fin n) : c ∣ p i := by
            by_cases hi : i = a
            · simpa [hi] using hcpa
            · obtain ⟨j, hpj⟩ := hsurv i hi
              rw [hpj]
              exact dvd_mul_of_dvd_left hch _
          have hcd : c ∣ commonDenominatorGcd q p := by
            unfold commonDenominatorGcd
            apply Finset.dvd_gcd
            intro x hx
            cases x with
            | none => simpa using hcq
            | some i => exact hcp i
          rw [hprim.2.2.2] at hcd
          exact hcd
        have hqle : q ≤ 3 * p a := by
          have hratioa : (q : ℝ) / (p a : ℝ) ≤ 3 := by
            calc
              (q : ℝ) / (p a : ℝ) = (P.moduli a : ℝ) := hprim.1.modulus_eq a
              _ ≤ 3 := haRate
          have hpR : 0 < (p a : ℝ) := by exact_mod_cast (hprim.2.1 a).1
          have hqleR := (div_le_iff₀ hpR).mp hratioa
          exact_mod_cast hqleR
        have hineq : 2 * p a ≥ D * h := by
          linarith [hqrel, hqle]
        have hne : p a ≠ M * h := by
          intro heq
          have hpEq : p a = p iM := by
            rw [hiMpM, heq]
          have hai : a = iM := hp_inj hpEq
          exact hiM hai.symm
        have hMrep : ∃ t : ℕ, M = (2 : ℤ) ^ t ∧ 2 ≤ M :=
          ⟨n - 2, by rfl, hM2⟩
        have hdisj : SomeDisjointRationalBeattyTranslations (p a) (M * h) q := by
          refine ⟨r a, r iM, Set.disjoint_left.mpr ?_⟩
          intro z hza hzi
          have hzi' : z ∈ integerTranslatedRationalBeattySet (p iM) q (r iM) := by
            rw [hiMpM]
            exact hzi
          have hza' : z ∈ biInfiniteBeattySequence (P.moduli a : ℝ) (P.shifts a) := by
            rw [hprim.1.set_eq a]
            exact hza
          have hzi'' : z ∈ biInfiniteBeattySequence (P.moduli iM : ℝ) (P.shifts iM) := by
            rw [hprim.1.set_eq iM]
            exact hzi'
          obtain ⟨i, hz, hu⟩ := P.partition z
          have hai : a = i := hu a hza'
          have hMi : iM = i := hu iM hzi''
          exact hiM (hMi.trans hai.symm)
        have hRigid := rigidBinaryExtension M (p a) h q hMrep
          (hprim.2.1 a).1 hpos hprim.1.q_pos hqrel hgcd hineq hne hdisj
        have hpFinal : p a = 2 * M := congrArg (fun t => t.1) hRigid
        have hhFinal : h = 1 := congrArg (fun t => t.2.1) hRigid
        have hqFinal : q = 4 * M - 1 := congrArg (fun t => t.2.2) hRigid
        have hMtop : 2 * M = (2 : ℤ) ^ (n - 1) := by
          dsimp [M]
          have he : n - 1 = (n - 2) + 1 := by omega
          rw [he, pow_succ]
          ring
        have hpRange : Set.range p = Set.range (fun j : Fin n => (2 : ℤ) ^ j.val) := by
          ext x
          constructor
          · rintro ⟨i, rfl⟩
            by_cases hi : i = a
            · refine ⟨⟨n - 1, by omega⟩, ?_⟩
              rw [hi, hpFinal, hMtop]
            · obtain ⟨j, hpj⟩ := hsurv i hi
              refine ⟨⟨j.val, by omega⟩, ?_⟩
              rw [hpj, hhFinal]
              simp
          · rintro ⟨j, rfl⟩
            by_cases hj : j.val = n - 1
            · refine ⟨a, ?_⟩
              rw [hpFinal, hMtop]
              congr 1
              exact hj.symm
            · let j' : Fin (n - 1) := ⟨j.val, by omega⟩
              obtain ⟨i, hi, hpi⟩ := hexists j'
              refine ⟨i, ?_⟩
              rw [hpi, hhFinal]
              simp [j']
        have hqTarget : q = (2 : ℤ) ^ n - 1 := by
          have hpow4 : (2 : ℤ) ^ n = 4 * M := by
            have he : n = (n - 2) + 2 := by omega
            rw [he, pow_add]
            dsimp [M]
            norm_num
            ring
          rw [hqFinal, hpow4]
        have hbin := (fraenkelConjecture_iff_binaryPrimitiveData P q p r hprim).2
          ⟨hqTarget, hpRange⟩
        calc
          Set.range α = Set.range (fun i : Fin n => (P.moduli i : ℝ)) := by
            ext x
            constructor
            · rintro ⟨i, rfl⟩
              exact ⟨i, hPα i⟩
            · rintro ⟨i, rfl⟩
              exact ⟨i, (hPα i).symm⟩
          _ = Set.range (fun j : Fin n =>
              ((2 : ℝ) ^ n - 1) / (2 : ℝ) ^ j.val) := hbin
  exact hmain m hm α β hα hdistinct hpartition

end Fraenkel
