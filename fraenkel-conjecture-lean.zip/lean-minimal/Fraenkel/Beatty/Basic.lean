import Mathlib.Data.Real.Archimedean

/-!
# Beatty sets

The package's two foundational Beatty-set definitions. The functions are total
Lean definitions; the characterization theorems record the package's intended
domains (`1 < α` and `0 < p < q`). All divisions take place in `ℝ`, not in `ℤ`.
The indexing set is `ℤ` in both definitions, not `ℕ`.
-/

namespace Fraenkel

/-- The bi-infinite Beatty set `S(α, β)`. Its package domain is `1 < α`. -/
-- zpi: def-bi-infinite-beatty-sequence
noncomputable def biInfiniteBeattySequence (α β : ℝ) : Set ℤ :=
  Set.range fun n : ℤ => ⌊(n : ℝ) * α + β⌋

/-- The defining formula on the domain specified in the entry. -/
-- zpi: def-bi-infinite-beatty-sequence
theorem biInfiniteBeattySequence_spec (α β : ℝ) (_hα : 1 < α) :
    biInfiniteBeattySequence α β =
      {z : ℤ | ∃ n : ℤ, ⌊(n : ℝ) * α + β⌋ = z} :=
  rfl

/-- The rational specialization `B^q_{p,r}`, with integer shift `r`.
Its package domain is `0 < p < q`. -/
-- zpi: def-integer-translated-rational-beatty-set
noncomputable def integerTranslatedRationalBeattySet (p q r : ℤ) : Set ℤ :=
  biInfiniteBeattySequence ((q : ℝ) / (p : ℝ)) (r : ℝ)

/-- The entry's formula, including real rather than integer division. -/
-- zpi: def-integer-translated-rational-beatty-set
theorem integerTranslatedRationalBeattySet_spec (p q r : ℤ)
    (_hp : 0 < p) (_hpq : p < q) :
    integerTranslatedRationalBeattySet p q r =
      {z : ℤ | ∃ n : ℤ, ⌊(n : ℝ) * (q : ℝ) / (p : ℝ) + (r : ℝ)⌋ = z} := by
  simp only [integerTranslatedRationalBeattySet, biInfiniteBeattySequence,
    mul_div_assoc, Set.range]

/-- Support lemma: the two notations refer to the same rational Beatty set. -/
-- zpi: def-integer-translated-rational-beatty-set
theorem integerTranslatedRationalBeattySet_eq_biInfiniteBeattySequence (p q r : ℤ) :
    integerTranslatedRationalBeattySet p q r =
      biInfiniteBeattySequence ((q : ℝ) / (p : ℝ)) (r : ℝ) :=
  rfl

end Fraenkel
