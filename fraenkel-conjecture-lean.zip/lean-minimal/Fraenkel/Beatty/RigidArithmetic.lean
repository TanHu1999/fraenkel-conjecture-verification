import Fraenkel.Beatty.Normalization

namespace Fraenkel

/-- The polynomial gap used to rule out a proper power-of-two divisor. -/
-- zpi: lem-rigid-binary-extension
theorem rigidProperDivisorGap (d e : ℤ) (hd : 2 ≤ d) (he : 2 ≤ e) :
    2 * d * (2 * d * e - 1 - e) <
      (2 * d * e - 1) * (d - 1) * (2 * e - 1) := by
  let E := e - 2
  let Y := d - 2
  have hE : 0 ≤ E := by dsimp [E]; omega
  have hY : 0 ≤ Y := by dsimp [Y]; omega
  have hid : (2 * d * e - 1) * (d - 1) * (2 * e - 1) -
      2 * d * (2 * d * e - 1 - e) =
      (4 * E ^ 2 + 10 * E + 4) * Y ^ 2 +
      (12 * E ^ 2 + 26 * E + 7) * Y + (8 * E ^ 2 + 14 * E + 1) := by
    dsimp [E, Y]
    ring
  have hpos : 0 < (4 * E ^ 2 + 10 * E + 4) * Y ^ 2 +
      (12 * E ^ 2 + 26 * E + 7) * Y + (8 * E ^ 2 + 14 * E + 1) := by
    positivity
  linarith only [hid, hpos]

/-- The strict inequality contradiction for a proper divisor. -/
-- zpi: lem-rigid-binary-extension
theorem rigidNoProperDivisor (c d e u h a : ℤ)
    (hc : 0 < c) (hd : 2 ≤ d) (he : 2 ≤ e) (hh : 0 < h)
    (hca : c * a = 2 * d * e - 1)
    (hbound : (2 * d * e - 1) * h ≤ 2 * c * d * u)
    (hnecessary : (d - 1) * u * (2 * e * h - 1) ≤ h * (a - e)) : False := by
  have hc1 : 1 ≤ c := by omega
  have hh1 : 1 ≤ h := by omega
  have hd0 : 0 < d := by omega
  have he0 : 0 < e := by omega
  have hD : 0 < 2 * d * e - 1 := by nlinarith
  have hF : 0 ≤ (d - 1) * (2 * e * h - 1) := by
    have : 0 ≤ 2 * e * h - 1 := by nlinarith
    exact mul_nonneg (by omega) this
  have hfirst := mul_le_mul_of_nonneg_right hbound hF
  have hsecond := mul_le_mul_of_nonneg_left hnecessary
    (show 0 ≤ 2 * c * d by positivity)
  have hprod : (2 * d * e - 1) * (d - 1) * (2 * e * h - 1) * h ≤
      2 * d * (2 * d * e - 1 - c * e) * h := by
    calc
      _ = ((2 * d * e - 1) * h) * ((d - 1) * (2 * e * h - 1)) := by ring
      _ ≤ (2 * c * d * u) * ((d - 1) * (2 * e * h - 1)) := hfirst
      _ = (2 * c * d) * ((d - 1) * u * (2 * e * h - 1)) := by ring
      _ ≤ (2 * c * d) * (h * (a - e)) := hsecond
      _ = 2 * d * (c * a - c * e) * h := by ring
      _ = _ := by rw [hca]
  have hcancel := (mul_le_mul_iff_left₀ hh).mp (by
    simpa only [mul_comm _ h] using hprod)
  have hsmall : (2 * d * e - 1) * (d - 1) * (2 * e - 1) ≤
      (2 * d * e - 1) * (d - 1) * (2 * e * h - 1) := by
    apply mul_le_mul_of_nonneg_left
    · nlinarith only [mul_le_mul_of_nonneg_left hh1 (show 0 ≤ 2 * e by omega)]
    · exact mul_nonneg (by omega) (by omega)
  have hright : 2 * d * (2 * d * e - 1 - c * e) ≤
      2 * d * (2 * d * e - 1 - e) := by
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    nlinarith only [mul_le_mul_of_nonneg_right hc1 he0.le]
  have hcancel' :
      (2 * d * e - 1) * (d - 1) * (2 * e * h - 1) ≤
        2 * d * (2 * d * e - 1 - c * e) := by
    simpa [mul_comm] using hcancel
  exact (not_le_of_gt (rigidProperDivisorGap d e hd he))
    (hsmall.trans (hcancel'.trans hright))

/-- The $d=1$ branch of the rigid arithmetic argument. -/
-- zpi: lem-rigid-binary-extension
theorem rigidNoDOne (m u h k l : ℤ)
    (hm : 2 ≤ m) (hu : 0 < u) (hh : 0 < h)
    (hk : 1 ≤ k) (hl : 1 ≤ l)
    (heq : k * u + l * m * h = u + (2 * m - 1) * h)
    (hineq : (2 * m - 1) * h ≤ 2 * u) : False := by
  have hgt : (m - 1) * h < u := by nlinarith only [hineq, hh]
  have hlterm : m * h ≤ l * m * h := by
    have hlm : m ≤ l * m := by
      have := mul_le_mul_of_nonneg_right hl (by nlinarith only [hm, hh])
      nlinarith only [this]
    have := mul_le_mul_of_nonneg_right hlm hh.le
    nlinarith only [this]
  have hupper : (k - 1) * u ≤ (m - 1) * h := by
    nlinarith only [heq, hlterm]
  have hknot : ¬ 2 ≤ k := by
    intro hk2
    have hku : u ≤ (k - 1) * u := by
      have := mul_le_mul_of_nonneg_right (show (1 : ℤ) ≤ k - 1 by omega) hu.le
      nlinarith only [this]
    linarith only [hgt, hupper, hku]
  have hk1 : k = 1 := by omega
  have heq' : l * m * h = (2 * m - 1) * h := by
    rw [hk1] at heq
    nlinarith only [heq]
  have hlCases : l = 1 ∨ 2 ≤ l := by omega
  rcases hlCases with rfl | hl2
  · have hmlt : m < 2 * m - 1 := by omega
    have hmlth := mul_lt_mul_of_pos_right hmlt hh
    have heq'' : m * h = (2 * m - 1) * h := by simpa using heq'
    exact (ne_of_lt hmlth) heq''
  · have hlm2 : 2 * m ≤ l * m := by
      have := mul_le_mul_of_nonneg_right hl2 (by nlinarith only [hm, hh])
      nlinarith only [this]
    have hlterm2 : 2 * m * h ≤ l * m * h := by
      have := mul_le_mul_of_nonneg_right hlm2 hh.le
      nlinarith only [this]
    have hmlt : 2 * m > 2 * m - 1 := by omega
    have hmlth := mul_lt_mul_of_pos_right hmlt hh
    linarith only [heq', hlterm2, hmlth]

/-- The $c>1$ contradiction when the divisor is all of $M$. -/
-- zpi: lem-rigid-binary-extension
theorem rigidFinalCOne (c d u h a : ℤ)
    (hc : 3 ≤ c) (hd : 2 ≤ d) (hu : 0 < u) (hh : 0 < h)
    (hca : c * a = 2 * d - 1)
    (hnecessary : (d - 1) * u * (2 * h - 1) ≤ h * (a - 1)) : False := by
  have hposd : 0 < d := by omega
  have hposa : 0 < a := by
    have : 0 < 2 * d - 1 := by nlinarith
    nlinarith [hca]
  have hca3 : 3 * a ≤ 2 * d - 1 := by
    have := mul_le_mul_of_nonneg_right hc (show 0 ≤ a by omega)
    nlinarith only [this, hca]
  have hleft1 : (d - 1) * h ≤ (d - 1) * u * (2 * h - 1) := by
    have hu1 : 1 ≤ u := by omega
    have hh1 : 1 ≤ h := by omega
    have ha : 0 ≤ d - 1 := by omega
    have hfac : 0 ≤ 2 * h - 1 := by omega
    have hA : (d - 1) * h ≤ (d - 1) * (2 * h - 1) := by
      apply mul_le_mul_of_nonneg_left (by omega) ha
    have hB : (d - 1) * (2 * h - 1) ≤
        (d - 1) * u * (2 * h - 1) := by
      have hu' := mul_le_mul_of_nonneg_right hu1 hfac
      have := mul_le_mul_of_nonneg_left hu' ha
      nlinarith only [this]
    exact hA.trans hB
  have ha_lt : a - 1 < d - 1 := by
    nlinarith only [hca3, hd]
  have hleft2 : h * (a - 1) < h * (d - 1) :=
    mul_lt_mul_of_pos_left ha_lt hh
  have hleft2' : h * (a - 1) < (d - 1) * h := by
    simpa [mul_comm] using hleft2
  exact (not_lt_of_ge hleft1) (lt_of_le_of_lt hnecessary hleft2')

/-- The final shape forced after $d=M$ and $c=1$. -/
-- zpi: lem-rigid-binary-extension
theorem rigidFinalShape (d u h : ℤ)
    (hd : 2 ≤ d) (hu : 0 < u) (hh : 0 < h)
    (hne : u ≠ h)
    (hineq : (2 * d - 1) * h ≤ 2 * d * u)
    (hnecessary : (d - 1) * u * (2 * h - 1) ≤ h * (2 * d - 2)) :
    h = 1 ∧ u = 2 := by
  have hd1 : 0 < d - 1 := by omega
  have hcancel : u * (2 * h - 1) ≤ 2 * h := by
    have hmul : (d - 1) * (u * (2 * h - 1)) ≤
        (d - 1) * (2 * h) := by
      calc
        (d - 1) * (u * (2 * h - 1)) =
            (d - 1) * u * (2 * h - 1) := by ring
        _ ≤ h * (2 * d - 2) := hnecessary
        _ = (d - 1) * (2 * h) := by ring
    apply (mul_le_mul_iff_left₀ hd1).mp
    simpa [mul_assoc, mul_left_comm, mul_comm] using hmul
  have hnot2 : ¬ 2 ≤ h := by
    intro h2
    have hu1 : 1 ≤ u := by omega
    have hif : u = 1 := by
      by_contra hu2
      have hu2' : 2 ≤ u := by omega
      have hlow : 2 * h < u * (2 * h - 1) := by
        have hfac : 0 < 2 * h - 1 := by omega
        have hu' := mul_le_mul_of_nonneg_right hu2' (le_of_lt hfac)
        have hbase : 2 * h < 2 * (2 * h - 1) := by nlinarith only [h2]
        exact lt_of_lt_of_le hbase (by simpa [mul_comm] using hu')
      exact (not_lt_of_ge hcancel) hlow
    rw [hif] at hineq
    have : (2 * d - 1) * h > 2 * d := by nlinarith only [h2, hd]
    linarith only [hineq, this]
  have hh1 : h = 1 := by omega
  have hu_le2 : u ≤ 2 := by
    rw [hh1] at hcancel
    nlinarith only [hcancel]
  have hu1 : 1 ≤ u := by omega
  have hu2 : u = 2 := by
    by_contra hu2ne
    have : u = 1 := by omega
    apply hne
    rw [hh1, this]
  exact ⟨hh1, hu2⟩

/-- Integer division by a positive divisor, transported from naturals. -/
private theorem rigidNatDivisorCastToIntDiv (z : ℤ) (d : ℕ)
    (hz : 0 ≤ z) (hd : 0 < d) (hdiv : d ∣ z.toNat) :
    ((z.toNat / d : ℕ) : ℤ) = z / (d : ℤ) := by
  have hz' : (z.toNat : ℤ) = z := Int.toNat_of_nonneg hz
  have hdnz : (d : ℤ) ≠ 0 := by exact_mod_cast (ne_of_gt hd)
  symm
  apply Int.ediv_eq_of_eq_mul_right hdnz
  have hmul := Nat.mul_div_cancel' hdiv
  have hmulR : (d : ℤ) * ((z.toNat / d : ℕ) : ℤ) = (z.toNat : ℤ) := by
    exact_mod_cast hmul
  rw [hz'] at hmulR
  exact hmulR.symm

end Fraenkel
