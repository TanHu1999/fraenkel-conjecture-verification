import Fraenkel.Beatty.Basic
import Fraenkel.External.Graham1973
import Fraenkel.External.Paparella2013
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Tactic

/-! Rationality and normalization of Beatty partitions. -/

open Filter
open scoped BigOperators Topology

namespace Fraenkel

/-- Support notion: the indexed sets partition all integers, with one part per
index. This does not impose distinct moduli; results require them explicitly. -/
-- zpi: lem-rationality-of-bi-infinite-beatty-partition-moduli
def BeattyPartition {m : ℕ} (α β : Fin m → ℝ) : Prop :=
  (∀ i, 1 < α i) ∧ ∀ z : ℤ, ∃! i : Fin m, z ∈ biInfiniteBeattySequence (α i) (β i)

/-- Above a common finite cutoff, discarding nonpositive Beatty indices loses no
terms. This is the tail restriction/reindexing step in the package's proof. -/
-- zpi: lem-rationality-of-bi-infinite-beatty-partition-moduli
theorem beattyPartition_eventualCover {m : ℕ} (α β : Fin m → ℝ)
    (hpart : BeattyPartition α β) : External.Graham1973.EventualCoveringFamily α β := by
  obtain ⟨B, hB⟩ := (Set.finite_range β).bddAbove
  obtain ⟨N, hN⟩ := exists_int_gt B
  refine ⟨N, ?_⟩
  intro z hz
  have htail (i : Fin m) :
      z ∈ biInfiniteBeattySequence (α i) (β i) ↔
        z ∈ External.Graham1973.oneSidedBeattySequence (α i) (β i) := by
    constructor
    · rintro ⟨n, hn⟩
      change ⌊(n : ℝ) * α i + β i⌋ = z at hn
      refine ⟨n, ?_, hn⟩
      by_contra hnpos
      have hnle : (n : ℝ) ≤ 0 := by exact_mod_cast (show n ≤ 0 by omega)
      have hα : 0 ≤ α i := le_of_lt (lt_trans zero_lt_one (hpart.1 i))
      have hβ : β i ≤ B := hB (Set.mem_range_self i)
      have hf := Int.floor_le ((n : ℝ) * α i + β i)
      rw [hn] at hf
      have hz' : (N : ℝ) ≤ (z : ℝ) := by exact_mod_cast hz
      nlinarith [mul_nonpos_of_nonpos_of_nonneg hnle hα]
    · rintro ⟨n, _, hn⟩
      exact ⟨n, hn⟩
  obtain ⟨i, hi, hu⟩ := hpart.2 z
  exact ⟨i, (htail i).mp hi, fun j hj => hu j ((htail j).mpr hj)⟩

/-- The full local rationality result, obtained from Graham's ECF borrowing. -/
-- zpi: lem-rationality-of-bi-infinite-beatty-partition-moduli
theorem rationalityOfBiInfiniteBeattyPartitionModuli {m : ℕ} (α β : Fin m → ℝ)
    (hm : 3 ≤ m) (hpart : BeattyPartition α β) (hdistinct : Function.Injective α) :
    ∀ i, ∃ a : ℚ, (a : ℝ) = α i := by
  intro i
  by_contra hirr
  have hi : Irrational (α i) := hirr
  obtain ⟨j, k, hjk, heq⟩ := External.Graham1973.irrationalEventualCoverHasRepeatedModuli
    α β hm (fun j => lt_trans zero_lt_one (hpart.1 j))
    (beattyPartition_eventualCover α β hpart) ⟨i, hi⟩
  exact hjk (hdistinct heq)

/-- Adding a number below one residue-cell width does not cross the next integer. -/
-- zpi: lem-real-shift-normalization-for-rational-beatty-sets
theorem floor_rational_add_small (N p : ℤ) (hp : 0 < p) (δ : ℝ)
    (hδ : 0 ≤ δ) (hδp : δ < 1 / (p : ℝ)) :
    ⌊(N : ℝ) / (p : ℝ) + δ⌋ = ⌊(N : ℝ) / (p : ℝ)⌋ := by
  have hpR : 0 < (p : ℝ) := by exact_mod_cast hp
  have hrem0 : 0 ≤ N % p := Int.emod_nonneg N (by omega)
  have hrem1 : N % p ≤ p - 1 := by have := Int.emod_lt_of_pos N hp; omega
  have hquot : (N : ℝ) / (p : ℝ) = ((N / p : ℤ) : ℝ) + ((N % p : ℤ) : ℝ) / (p : ℝ) := by
    apply (div_eq_iff hpR.ne').mpr
    have h := congrArg (fun z : ℤ => (z : ℝ)) (Int.mul_ediv_add_emod N p)
    push_cast at h
    field_simp
    nlinarith [h]
  have H (e : ℝ) (he : 0 ≤ e) (hep : e < 1 / (p : ℝ)) :
      ⌊(N : ℝ) / (p : ℝ) + e⌋ = N / p := by
    apply Int.floor_eq_iff.mpr
    rw [hquot]
    have hr0 : 0 ≤ ((N % p : ℤ) : ℝ) := by exact_mod_cast hrem0
    have hr1 : ((N % p : ℤ) : ℝ) ≤ (p : ℝ) - 1 := by exact_mod_cast hrem1
    have hrdiv : 0 ≤ ((N % p : ℤ) : ℝ) / (p : ℝ) := by positivity
    have hep' := (lt_div_iff₀ hpR).mp hep
    have hcancel := div_mul_cancel₀ (((N % p : ℤ) : ℝ)) hpR.ne'
    have hrlt : ((N % p : ℤ) : ℝ) / (p : ℝ) + e < 1 :=
      (mul_lt_mul_iff_of_pos_right hpR).mp (by nlinarith)
    constructor <;> linarith
  calc
    _ = N / p := H δ hδ hδp
    _ = _ := by simpa using (H 0 le_rfl (by positivity)).symm

/-- The source proof's coprime residue reindexing, with the modulus-one case
handled separately because Paparella's definition requires modulus greater than one. -/
-- zpi: lem-real-shift-normalization-for-rational-beatty-sets
theorem realShiftNormalization (p q : ℤ) (hp : 0 < p) (_hpq : p < q)
    (hcop : Int.gcd p q = 1) (β : ℝ) :
    ∃ r : ℤ, biInfiniteBeattySequence ((q : ℝ) / (p : ℝ)) β =
      integerTranslatedRationalBeattySet p q r := by
  let h : ℤ := ⌊(p : ℝ) * β⌋
  have hpR : 0 < (p : ℝ) := by exact_mod_cast hp
  have hj : ∃ j : ℤ, (j * q) % p = h % p := by
    by_cases hp1 : p = 1
    · exact ⟨0, by simp [hp1]⟩
    obtain ⟨j, _, _, hj⟩ := External.Paparella2013.coprimeMul_residue_exists
      p q h (by omega) (by simpa [Int.gcd_comm] using hcop)
    exact ⟨j, by simpa [mul_comm] using hj⟩
  obtain ⟨j, hj⟩ := hj
  have hdvd : p ∣ j * q - h := by
    apply Int.dvd_of_emod_eq_zero
    rw [Int.sub_emod, hj, sub_self]
    simp
  obtain ⟨t, ht⟩ := hdvd
  have hqt : j * q = h + t * p := by nlinarith [ht]
  have hqtR : (j : ℝ) * (q : ℝ) = (h : ℝ) + (t : ℝ) * (p : ℝ) := by exact_mod_cast hqt
  let δ : ℝ := β - (h : ℝ) / (p : ℝ)
  have hf : (h : ℝ) ≤ (p : ℝ) * β := Int.floor_le _
  have hfu : (p : ℝ) * β < (h : ℝ) + 1 := Int.lt_floor_add_one _
  have hδ : 0 ≤ δ := by
    dsimp [δ]
    rw [sub_nonneg, div_le_iff₀ hpR]
    nlinarith
  have hδp : δ < 1 / (p : ℝ) := by
    apply (lt_div_iff₀ hpR).mpr
    dsimp [δ]
    rw [sub_mul, div_mul_cancel₀ _ hpR.ne']
    nlinarith
  refine ⟨-t, ?_⟩
  have hshift (n : ℤ) :
      ⌊((n - j : ℤ) : ℝ) * ((q : ℝ) / (p : ℝ)) + β⌋ =
        ⌊(n : ℝ) * ((q : ℝ) / (p : ℝ)) + ((-t : ℤ) : ℝ)⌋ := by
    have harg : ((n - j : ℤ) : ℝ) * ((q : ℝ) / (p : ℝ)) + β =
        ((n * q - t * p : ℤ) : ℝ) / (p : ℝ) + δ := by
      dsimp [δ]
      push_cast
      field_simp
      nlinarith [hqtR]
    have harg' : (n : ℝ) * ((q : ℝ) / (p : ℝ)) + ((-t : ℤ) : ℝ) =
        ((n * q - t * p : ℤ) : ℝ) / (p : ℝ) := by
      push_cast
      field_simp
      ring
    rw [harg, harg']
    exact floor_rational_add_small _ p hp δ hδ hδp
  ext z
  change (∃ n : ℤ, ⌊(n : ℝ) * ((q : ℝ) / (p : ℝ)) + β⌋ = z) ↔
    ∃ n : ℤ, ⌊(n : ℝ) * ((q : ℝ) / (p : ℝ)) + ((-t : ℤ) : ℝ)⌋ = z
  constructor
  · rintro ⟨n, hn⟩
    refine ⟨n + j, ?_⟩
    have hh := hshift (n + j)
    simp only [add_sub_cancel_right] at hh
    exact hh.symm.trans hn
  · rintro ⟨n, hn⟩
    exact ⟨n - j, (hshift n).trans hn⟩

/-- An indexed term; unlike a Beatty set, this remembers the index. -/
-- zpi: prop-period-density-and-modulus-of-rational-beatty-set
noncomputable def beattyTerm (α β : ℝ) (n : ℤ) : ℤ := ⌊(n : ℝ) * α + β⌋

/-- Number of occupied integer positions in `[z,z+N)`. -/
-- zpi: prop-period-density-and-modulus-of-rational-beatty-set
noncomputable def integerBlockCount (S : Set ℤ) (z : ℤ) (N : ℕ) : ℕ := by
  classical
  exact ((Finset.Ico z (z + (N : ℤ))).filter (fun t => t ∈ S)).card

/-- The indicator used for periodicity and counting. -/
-- zpi: prop-period-density-and-modulus-of-rational-beatty-set
noncomputable def integerIndicator (S : Set ℤ) (z : ℤ) : ℝ := by
  classical
  exact if z ∈ S then 1 else 0

/-- Distinct Beatty indices yield distinct positions. -/
-- zpi: prop-period-density-and-modulus-of-rational-beatty-set
theorem beattyTerm_strictMono (α β : ℝ) (hα : 1 < α) : StrictMono (beattyTerm α β) := by
  apply strictMono_int_of_lt_succ
  intro n
  have hh : ((n : ℝ) * α + β) + 1 ≤ ((n + 1 : ℤ) : ℝ) * α + β := by
    push_cast
    linarith
  have hf := Int.floor_mono hh
  rw [Int.floor_add_one] at hf
  change ⌊(n : ℝ) * α + β⌋ < ⌊((n + 1 : ℤ) : ℝ) * α + β⌋
  omega

/-- Occupied positions and their indices are in bijection. This makes the
source proof's period-counting argument explicit for every finite interval. -/
-- zpi: prop-period-density-and-modulus-of-rational-beatty-set
theorem beattyBlockCount_eq_ceil (α β : ℝ) (hα : 1 < α) (z : ℤ) (N : ℕ) :
    integerBlockCount (biInfiniteBeattySequence α β) z N =
      (⌈(((z : ℝ) + (N : ℝ)) - β) / α⌉ - ⌈((z : ℝ) - β) / α⌉).toNat := by
  classical
  have hαpos : 0 < α := lt_trans zero_lt_one hα
  let L : ℤ := ⌈((z : ℝ) - β) / α⌉
  let U : ℤ := ⌈(((z : ℝ) + (N : ℝ)) - β) / α⌉
  have hb (n : ℤ) : n ∈ Finset.Ico L U ↔
      beattyTerm α β n ∈ Finset.Ico z (z + (N : ℤ)) := by
    simp only [Finset.mem_Ico, L, U, Int.ceil_le, Int.lt_ceil,
      beattyTerm, Int.le_floor, Int.floor_lt, Int.cast_add, Int.cast_natCast]
    rw [div_le_iff₀ hαpos, lt_div_iff₀ hαpos]
    constructor <;> intro hh <;> constructor <;> linarith [hh.1, hh.2]
  have heq : (Finset.Ico L U).image (beattyTerm α β) =
      (Finset.Ico z (z + (N : ℤ))).filter (fun t => t ∈ biInfiniteBeattySequence α β) := by
    ext t
    constructor
    · intro ht
      obtain ⟨n, hn, rfl⟩ := Finset.mem_image.mp ht
      exact Finset.mem_filter.mpr ⟨(hb n).mp hn, ⟨n, rfl⟩⟩
    · intro ht
      obtain ⟨ht, n, hn⟩ := Finset.mem_filter.mp ht
      change beattyTerm α β n = t at hn
      exact Finset.mem_image.mpr ⟨n, (hb n).mpr (hn ▸ ht), hn⟩
  rw [integerBlockCount, ← heq, Finset.card_image_of_injective _
    (beattyTerm_strictMono α β hα).injective, Int.card_Ico]

/-- A bounded floor error vanishes after division by the growing index. -/
-- zpi: prop-period-density-and-modulus-of-rational-beatty-set
theorem floor_linear_div_tendsto (a b : ℝ) :
    Tendsto (fun n : ℕ => (⌊a * (n : ℝ) + b⌋ : ℝ) / (n : ℝ)) atTop (𝓝 a) := by
  have hlo : Tendsto (fun n : ℕ => a + (b - 1) / (n : ℝ)) atTop (𝓝 a) := by
    simpa using (tendsto_const_div_atTop_nhds_zero_nat (b - 1)).const_add a
  have hhi : Tendsto (fun n : ℕ => a + b / (n : ℝ)) atTop (𝓝 a) := by
    simpa using (tendsto_const_div_atTop_nhds_zero_nat b).const_add a
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' hlo hhi
  · filter_upwards [eventually_ge_atTop 1] with n hn
    have hnR : 0 < (n : ℝ) := by exact_mod_cast (show 0 < n by omega)
    have hf := Int.lt_floor_add_one (a * (n : ℝ) + b)
    apply (le_div_iff₀ hnR).mpr
    field_simp
    linarith
  · filter_upwards [eventually_ge_atTop 1] with n hn
    have hnR : 0 < (n : ℝ) := by exact_mod_cast (show 0 < n by omega)
    have hf := Int.floor_le (a * (n : ℝ) + b)
    apply (div_le_iff₀ hnR).mpr
    field_simp
    linarith

-- zpi: prop-period-density-and-modulus-of-rational-beatty-set
theorem ceil_linear_div_tendsto (a b : ℝ) :
    Tendsto (fun n : ℕ => (⌈a * (n : ℝ) + b⌉ : ℝ) / (n : ℝ)) atTop (𝓝 a) := by
  have h := (floor_linear_div_tendsto (-a) (-b)).neg
  simpa only [neg_mul, ← neg_add, Int.floor_neg, Int.cast_neg, neg_div, neg_neg] using h

/-- Density is independent of the starting position for a Beatty set. -/
-- zpi: prop-period-density-and-modulus-of-rational-beatty-set
theorem beattyBlockDensity (α β : ℝ) (hα : 1 < α) (z : ℤ) :
    Tendsto (fun N : ℕ => (integerBlockCount (biInfiniteBeattySequence α β) z N : ℝ) /
      (N : ℝ)) atTop (𝓝 (1 / α)) := by
  have hαpos : 0 < α := lt_trans zero_lt_one hα
  have hcount (N : ℕ) :
      (integerBlockCount (biInfiniteBeattySequence α β) z N : ℝ) =
        (⌈(1 / α) * (N : ℝ) + ((z : ℝ) - β) / α⌉ : ℝ) -
          (⌈((z : ℝ) - β) / α⌉ : ℝ) := by
    rw [beattyBlockCount_eq_ceil α β hα]
    have hle : ⌈((z : ℝ) - β) / α⌉ ≤ ⌈(((z : ℝ) + (N : ℝ)) - β) / α⌉ := by
      apply Int.ceil_mono
      apply div_le_div_of_nonneg_right _ hαpos.le
      have : (0 : ℝ) ≤ N := by positivity
      linarith
    have ht : ((⌈(((z : ℝ) + (N : ℝ)) - β) / α⌉ -
        ⌈((z : ℝ) - β) / α⌉).toNat : ℝ) =
        ((⌈(((z : ℝ) + (N : ℝ)) - β) / α⌉ - ⌈((z : ℝ) - β) / α⌉ : ℤ) : ℝ) := by
      exact_mod_cast (Int.toNat_of_nonneg (sub_nonneg.mpr hle))
    have harg : (((z : ℝ) + (N : ℝ)) - β) / α =
        (1 / α) * (N : ℝ) + ((z : ℝ) - β) / α := by ring
    rw [ht, Int.cast_sub, harg]
  have h := (ceil_linear_div_tendsto (1 / α) (((z : ℝ) - β) / α)).sub
    (tendsto_const_div_atTop_nhds_zero_nat (⌈((z : ℝ) - β) / α⌉ : ℝ))
  simpa only [sub_zero, hcount, sub_div] using h

/-- Average spacing is the actual limit of differences along the increasing
enumeration, not a renamed reciprocal-density assertion. -/
-- zpi: prop-period-density-and-modulus-of-rational-beatty-set
theorem beattyAverageSpacing (α β : ℝ) (k : ℤ) :
    Tendsto (fun n : ℕ => ((beattyTerm α β (k + (n : ℤ)) - beattyTerm α β k : ℤ) : ℝ) /
      (n : ℝ)) atTop (𝓝 α) := by
  have h := (floor_linear_div_tendsto α ((k : ℝ) * α + β)).sub
    (tendsto_const_div_atTop_nhds_zero_nat (beattyTerm α β k : ℝ))
  simp only [sub_zero] at h
  convert h using 1
  funext n
  have he : ((k + (n : ℤ) : ℤ) : ℝ) * α + β = α * (n : ℝ) + ((k : ℝ) * α + β) := by
    push_cast
    ring
  simp only [beattyTerm, Int.cast_sub, sub_div, he]

/-- Advancing the index by `p` advances the occupied position by `q`. -/
-- zpi: prop-period-density-and-modulus-of-rational-beatty-set
theorem rationalBeatty_index_period (p q r n : ℤ) (hp : 0 < p) :
    beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n + p) =
      beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) n + q := by
  have hpR : (p : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hp)
  unfold beattyTerm
  have hh : ((n + p : ℤ) : ℝ) * ((q : ℝ) / (p : ℝ)) + (r : ℝ) =
      (n : ℝ) * ((q : ℝ) / (p : ℝ)) + (r : ℝ) + (q : ℝ) := by
    push_cast
    field_simp
    ring
  rw [hh, Int.floor_add_intCast]

/-- The full period, finite-block count, density, and average-spacing result. -/
-- zpi: prop-period-density-and-modulus-of-rational-beatty-set
theorem periodDensityAndModulus (p q r : ℤ) (hp : 0 < p) (hpq : p < q) :
    Function.Periodic (integerIndicator (integerTranslatedRationalBeattySet p q r)) q ∧
    (∀ z : ℤ, integerBlockCount (integerTranslatedRationalBeattySet p q r) z q.toNat = p.toNat) ∧
    (∀ z : ℤ, Tendsto (fun N : ℕ =>
      (integerBlockCount (integerTranslatedRationalBeattySet p q r) z N : ℝ) / (N : ℝ))
      atTop (𝓝 ((p : ℝ) / (q : ℝ)))) ∧
    (∀ k : ℤ, Tendsto (fun n : ℕ =>
      ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (k + (n : ℤ)) -
        beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) k : ℤ) : ℝ) / (n : ℝ))
      atTop (𝓝 ((q : ℝ) / (p : ℝ)))) := by
  classical
  have hpR : 0 < (p : ℝ) := by exact_mod_cast hp
  have hq : 0 < q := lt_trans hp hpq
  have hα : 1 < (q : ℝ) / (p : ℝ) := by rw [lt_div_iff₀ hpR, one_mul]; exact_mod_cast hpq
  refine ⟨?_, ?_, ?_, beattyAverageSpacing _ _⟩
  · intro z
    have hm : z + q ∈ integerTranslatedRationalBeattySet p q r ↔
        z ∈ integerTranslatedRationalBeattySet p q r := by
      constructor
      · rintro ⟨n, hn⟩
        change beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) n = z + q at hn
        refine ⟨n - p, ?_⟩
        have hh := rationalBeatty_index_period p q r (n - p) hp
        simp only [sub_add_cancel] at hh
        change beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n - p) = z
        omega
      · rintro ⟨n, hn⟩
        refine ⟨n + p, ?_⟩
        change beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n + p) = z + q
        rw [rationalBeatty_index_period p q r n hp]
        exact congrArg (fun t : ℤ => t + q) hn
    simp only [integerIndicator, hm]
  · intro z
    rw [integerTranslatedRationalBeattySet, beattyBlockCount_eq_ceil _ _ hα]
    have hshift : (((z : ℝ) + (q.toNat : ℝ)) - (r : ℝ)) / ((q : ℝ) / (p : ℝ)) =
        ((z : ℝ) - (r : ℝ)) / ((q : ℝ) / (p : ℝ)) + (p : ℝ) := by
      have hqCast : (q.toNat : ℝ) = (q : ℝ) := by exact_mod_cast (Int.toNat_of_nonneg hq.le)
      rw [hqCast]
      have hqR : (q : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hq)
      field_simp
      ring
    rw [hshift, Int.ceil_add_intCast]
    congr 1
    omega
  · intro z
    simpa [integerTranslatedRationalBeattySet, one_div_div] using
      beattyBlockDensity ((q : ℝ) / (p : ℝ)) (r : ℝ) hα z

/-- Rational moduli greater than one, with real shifts, partitioning all integers.
These are precisely the assumptions in the common-denominator definition. -/
-- zpi: def-common-denominator-data-of-rational-beatty-partition
structure RationalBeattyPartition (m : ℕ) where
  nonempty : 0 < m
  moduli : Fin m → ℚ
  shifts : Fin m → ℝ
  modulus_gt_one : ∀ i, 1 < moduli i
  partition : ∀ z : ℤ, ∃! i : Fin m,
    z ∈ biInfiniteBeattySequence (moduli i : ℝ) (shifts i)

/-- The selected numerical presentation, without assuming primitivity or a
sum-of-numerators identity. The reduced-data characterization below proves
that these conditions are exactly the source's common-multiple construction. -/
-- zpi: def-common-denominator-data-of-rational-beatty-partition
structure CommonDenominatorPresentation {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p r : Fin m → ℤ) : Prop where
  q_pos : 0 < q
  numerator_bounds : ∀ i, 0 < p i ∧ p i < q
  modulus_eq : ∀ i, (q : ℝ) / (p i : ℝ) = (P.moduli i : ℝ)
  set_eq : ∀ i, biInfiniteBeattySequence (P.moduli i : ℝ) (P.shifts i) =
    integerTranslatedRationalBeattySet (p i) q (r i)

-- zpi: def-common-denominator-data-of-rational-beatty-partition
theorem commonDenominatorPresentation_spec {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p r : Fin m → ℤ) :
    CommonDenominatorPresentation P q p r ↔
      0 < q ∧ (∀ i, 0 < p i ∧ p i < q) ∧
      (∀ i, (q : ℝ) / (p i : ℝ) = (P.moduli i : ℝ)) ∧
      (∀ i, biInfiniteBeattySequence (P.moduli i : ℝ) (P.shifts i) =
        integerTranslatedRationalBeattySet (p i) q (r i)) :=
  ⟨fun h => ⟨h.q_pos, h.numerator_bounds, h.modulus_eq, h.set_eq⟩,
    fun ⟨hq, hp, hm, hs⟩ => ⟨hq, hp, hm, hs⟩⟩

/-- The reduced positive integers used in the source construction always exist. -/
-- zpi: def-common-denominator-data-of-rational-beatty-partition
theorem rationalModulus_reduced (α : ℚ) (hα : 1 < α) :
    ∃ a b : ℤ, 0 < a ∧ a < b ∧ Int.gcd a b = 1 ∧ (α : ℝ) = (b : ℝ) / (a : ℝ) := by
  refine ⟨(α.den : ℤ), α.num, ?_, ?_, ?_, ?_⟩
  · exact_mod_cast α.den_pos
  · have hαR : (1 : ℝ) < (α : ℝ) := by exact_mod_cast hα
    rw [Rat.cast_def] at hαR
    have hden : (0 : ℝ) < α.den := by exact_mod_cast α.den_pos
    have hh := (lt_div_iff₀ hden).mp hαR
    simp only [one_mul] at hh
    exact_mod_cast hh
  · simpa [Int.gcd_def, Nat.gcd_comm] using α.reduced.gcd_eq_one
  · simp [Rat.cast_def]

/-- Construct a presentation for any positive common multiple of the reduced
modulus numerators. This includes the actual real-shift normalization step. -/
-- zpi: def-common-denominator-data-of-rational-beatty-partition
theorem commonDenominatorPresentation_of_reduced {m : ℕ} (P : RationalBeattyPartition m)
    (a b : Fin m → ℤ) (ha : ∀ i, 0 < a i) (hab : ∀ i, a i < b i)
    (hcop : ∀ i, Int.gcd (a i) (b i) = 1)
    (hα : ∀ i, (P.moduli i : ℝ) = (b i : ℝ) / (a i : ℝ))
    (q : ℤ) (hq : 0 < q) (hdiv : ∀ i, b i ∣ q) :
    ∃ r : Fin m → ℤ, CommonDenominatorPresentation P q (fun i => q / b i * a i) r := by
  classical
  choose r hr using fun i => realShiftNormalization (a i) (b i) (ha i) (hab i)
    (hcop i) (P.shifts i)
  have hc (i) : 0 < q / b i := Int.ediv_pos_of_pos_of_dvd hq (by linarith [ha i, hab i]) (hdiv i)
  have hqmul (i) : q / b i * b i = q := Int.ediv_mul_cancel (hdiv i)
  have hratio (i) : (q : ℝ) / ((q / b i * a i : ℤ) : ℝ) = (b i : ℝ) / (a i : ℝ) := by
    have haR : (a i : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt (ha i))
    have hcR : ((q / b i : ℤ) : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt (hc i))
    have hqR : (q : ℝ) = ((q / b i : ℤ) : ℝ) * (b i : ℝ) := by exact_mod_cast (hqmul i).symm
    rw [Int.cast_mul, hqR]
    field_simp
  refine ⟨r, ⟨hq, ?_, ?_, ?_⟩⟩
  · intro i
    refine ⟨mul_pos (hc i) (ha i), ?_⟩
    calc
      _ < q / b i * b i := mul_lt_mul_of_pos_left (hab i) (hc i)
      _ = q := hqmul i
  · intro i
    exact (hratio i).trans (hα i).symm
  · intro i
    rw [hα i, hr i]
    simp only [integerTranslatedRationalBeattySet, hratio i]

/-- Every rational Beatty partition has a selected presentation. The product
of the finitely many positive reduced numerators is one allowed denominator. -/
-- zpi: def-common-denominator-data-of-rational-beatty-partition
theorem commonDenominatorPresentation_exists {m : ℕ} (P : RationalBeattyPartition m) :
    ∃ q : ℤ, ∃ p r : Fin m → ℤ, CommonDenominatorPresentation P q p r := by
  classical
  choose a b ha hab hcop hα using fun i => rationalModulus_reduced (P.moduli i) (P.modulus_gt_one i)
  let q : ℤ := ∏ i, b i
  have hq : 0 < q := Finset.prod_pos fun i _ => lt_trans (ha i) (hab i)
  have hdiv (i) : b i ∣ q := Finset.dvd_prod_of_mem b (Finset.mem_univ i)
  obtain ⟨r, hr⟩ := commonDenominatorPresentation_of_reduced P a b ha hab hcop hα q hq hdiv
  exact ⟨q, (fun i => q / b i * a i), r, hr⟩

/-- Conversely, every presentation is obtained by the source's reduced-data
construction. Thus the presentation structure has not changed its notion. -/
-- zpi: def-common-denominator-data-of-rational-beatty-partition
theorem commonDenominatorPresentation_reduced_data {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p r : Fin m → ℤ) (h : CommonDenominatorPresentation P q p r)
    (a b : Fin m → ℤ) (ha : ∀ i, 0 < a i) (hab : ∀ i, a i < b i)
    (hcop : ∀ i, Int.gcd (a i) (b i) = 1)
    (hα : ∀ i, (P.moduli i : ℝ) = (b i : ℝ) / (a i : ℝ)) :
    ∀ i, b i ∣ q ∧ 0 < q / b i ∧ p i = q / b i * a i := by
  intro i
  have haR : (a i : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt (ha i))
  have hpR : (p i : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt (h.numerator_bounds i).1)
  have heq := (div_eq_div_iff hpR haR).mp ((h.modulus_eq i).trans (hα i))
  have heqZ : q * a i = b i * p i := by exact_mod_cast heq
  have hdiv : b i ∣ q := Int.dvd_of_dvd_mul_left_of_gcd_one
    (show b i ∣ q * a i by rw [heqZ]; exact dvd_mul_right _ _)
    (by simpa [Int.gcd_comm] using hcop i)
  have hbpos : 0 < b i := lt_trans (ha i) (hab i)
  refine ⟨hdiv, Int.ediv_pos_of_pos_of_dvd h.q_pos hbpos.le hdiv, ?_⟩
  apply mul_right_cancel₀ hbpos.ne'
  calc
    p i * b i = q * a i := by nlinarith [heqZ]
    _ = (q / b i * b i) * a i := by rw [Int.ediv_mul_cancel hdiv]
    _ = (q / b i * a i) * b i := by ring

/-- Counting all parts in a finite integer interval counts every position once. -/
-- zpi: def-common-denominator-data-of-rational-beatty-partition
theorem partition_blockCounts_sum {m : ℕ} (P : RationalBeattyPartition m) (z : ℤ) (N : ℕ) :
    (∑ i, integerBlockCount (biInfiniteBeattySequence (P.moduli i : ℝ) (P.shifts i)) z N) = N := by
  classical
  have hcount (i : Fin m) :
      integerBlockCount (biInfiniteBeattySequence (P.moduli i : ℝ) (P.shifts i)) z N =
        ∑ t ∈ Finset.Ico z (z + (N : ℤ)),
          if t ∈ biInfiniteBeattySequence (P.moduli i : ℝ) (P.shifts i) then (1 : ℕ) else 0 := by
    simp [integerBlockCount]
  simp_rw [hcount]
  rw [Finset.sum_comm]
  have hone (t : ℤ) : (∑ i : Fin m,
      if t ∈ biInfiniteBeattySequence (P.moduli i : ℝ) (P.shifts i) then 1 else 0) = (1 : ℕ) := by
    obtain ⟨i, hi, hu⟩ := P.partition t
    rw [Finset.sum_eq_single i]
    · simp [hi]
    · intro j _ hji
      apply if_neg
      intro hj
      exact hji (hu j hj)
    · simp
  simp only [hone, Finset.sum_const, smul_eq_mul, mul_one]
  simp [Int.card_Ico]

/-- The periodicity and per-period counts asserted in the common-denominator
entry are consequences of the represented sets, not presentation fields. -/
-- zpi: def-common-denominator-data-of-rational-beatty-partition
theorem commonDenominator_period_count {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p r : Fin m → ℤ) (h : CommonDenominatorPresentation P q p r) :
    ∀ i, Function.Periodic
        (integerIndicator (biInfiniteBeattySequence (P.moduli i : ℝ) (P.shifts i))) q ∧
      ∀ z : ℤ, integerBlockCount
        (biInfiniteBeattySequence (P.moduli i : ℝ) (P.shifts i)) z q.toNat = (p i).toNat := by
  intro i
  rw [h.set_eq i]
  have hp := periodDensityAndModulus (p i) q (r i) (h.numerator_bounds i).1
    (h.numerator_bounds i).2
  exact ⟨hp.1, hp.2.1⟩

/-- The sum identity is proved from partition/counting, never stored as an
extra assumption in the presentation structure. -/
-- zpi: def-common-denominator-data-of-rational-beatty-partition
theorem commonDenominator_sum {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p r : Fin m → ℤ) (h : CommonDenominatorPresentation P q p r) :
    ∑ i, p i = q := by
  have hc (i) : integerBlockCount (biInfiniteBeattySequence (P.moduli i : ℝ) (P.shifts i))
      0 q.toNat = (p i).toNat :=
    (commonDenominator_period_count P q p r h i).2 0
  have hs := partition_blockCounts_sum P 0 q.toNat
  simp only [hc] at hs
  have hsZ := congrArg (fun n : ℕ => (n : ℤ)) hs
  simpa only [Nat.cast_sum, Int.toNat_of_nonneg h.q_pos.le,
    Int.toNat_of_nonneg (h.numerator_bounds _).1.le] using hsZ

/-- The density claims embedded in the common-denominator definition. -/
-- zpi: def-common-denominator-data-of-rational-beatty-partition
theorem commonDenominator_densities {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p r : Fin m → ℤ) (h : CommonDenominatorPresentation P q p r) :
    (∀ i, 1 / (P.moduli i : ℝ) = (p i : ℝ) / (q : ℝ)) ∧
    (∀ i, ∀ z : ℤ, Tendsto (fun N : ℕ =>
      (integerBlockCount (biInfiniteBeattySequence (P.moduli i : ℝ) (P.shifts i)) z N : ℝ) /
      (N : ℝ)) atTop (𝓝 ((p i : ℝ) / (q : ℝ)))) ∧
    (∑ i, (p i : ℝ) / (q : ℝ)) = 1 := by
  refine ⟨?_, ?_, ?_⟩
  · intro i
    rw [← h.modulus_eq i, one_div_div]
  · intro i z
    rw [h.set_eq i]
    exact (periodDensityAndModulus (p i) q (r i) (h.numerator_bounds i).1
      (h.numerator_bounds i).2).2.2.1 z
  · rw [← Finset.sum_div, ← Int.cast_sum, commonDenominator_sum P q p r h]
    exact div_self (by exact_mod_cast (ne_of_gt h.q_pos))

/-- Positive common scaling changes neither the sets nor the recorded shifts. -/
-- zpi: def-common-denominator-data-of-rational-beatty-partition
theorem commonDenominator_scale {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p r : Fin m → ℤ) (h : CommonDenominatorPresentation P q p r)
    (k : ℤ) (hk : 0 < k) :
    CommonDenominatorPresentation P (k * q) (fun i => k * p i) r := by
  have hkR : (k : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hk)
  have heq (i) : ((k * q : ℤ) : ℝ) / ((k * p i : ℤ) : ℝ) = (q : ℝ) / (p i : ℝ) := by
    simp only [Int.cast_mul, mul_div_mul_left _ _ hkR]
  refine ⟨mul_pos hk h.q_pos, ?_, ?_, ?_⟩
  · intro i
    exact ⟨mul_pos hk (h.numerator_bounds i).1,
      mul_lt_mul_of_pos_left (h.numerator_bounds i).2 hk⟩
  · intro i
    exact (heq i).trans (h.modulus_eq i)
  · intro i
    rw [h.set_eq i]
    simp only [integerTranslatedRationalBeattySet, heq i]

/-- The nonnegative gcd of `q` and all `pᵢ`, including `q` even for empty index
families. `Option.none` is the denominator slot, `some i` a numerator slot. -/
-- zpi: def-primitive-rational-beatty-partition
def commonDenominatorGcd {m : ℕ} (q : ℤ) (p : Fin m → ℤ) : ℤ :=
  Finset.univ.gcd (fun i : Option (Fin m) => i.elim q p)

/-- Primitivity of the selected data, not a property of an arbitrary rescaling. -/
-- zpi: def-primitive-rational-beatty-partition
def PrimitiveRationalBeattyPartition {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p r : Fin m → ℤ) : Prop :=
  CommonDenominatorPresentation P q p r ∧
    (∀ i, 0 < p i ∧ p i < q) ∧ (∑ i, p i) = q ∧ commonDenominatorGcd q p = 1

-- zpi: def-primitive-rational-beatty-partition
theorem primitiveRationalBeattyPartition_spec {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p r : Fin m → ℤ) (h : CommonDenominatorPresentation P q p r) :
    PrimitiveRationalBeattyPartition P q p r ↔
      (∀ i, 0 < p i ∧ p i < q) ∧ (∑ i, p i) = q ∧ commonDenominatorGcd q p = 1 := by
  simp only [PrimitiveRationalBeattyPartition, h, true_and]

/-- The selected gcd is positive and divides every component. -/
-- zpi: prop-primitive-normalization-preserves-rational-beatty-sets
theorem commonDenominatorGcd_pos_and_dvd {m : ℕ} (q : ℤ) (p : Fin m → ℤ) (hq : 0 < q) :
    0 < commonDenominatorGcd q p ∧ commonDenominatorGcd q p ∣ q ∧
      ∀ i, commonDenominatorGcd q p ∣ p i := by
  have hdq : commonDenominatorGcd q p ∣ q :=
    Finset.gcd_dvd (f := fun i : Option (Fin m) => i.elim q p) (Finset.mem_univ none)
  have hdp (i : Fin m) : commonDenominatorGcd q p ∣ p i :=
    Finset.gcd_dvd (f := fun j : Option (Fin m) => j.elim q p) (Finset.mem_univ (some i))
  have hd0 : 0 ≤ commonDenominatorGcd q p := Finset.Int.finsetGcd_nonneg
  have hdne : commonDenominatorGcd q p ≠ 0 := by
    intro hz
    rw [hz, zero_dvd_iff] at hdq
    omega
  exact ⟨by omega, hdq, hdp⟩

/-- Exact gcd division preserves each modulus and set, keeps every `rᵢ`, and
produces primitive selected data. No distinctness is assumed unless it is
needed for the final distinct-numerator assertion. -/
-- zpi: prop-primitive-normalization-preserves-rational-beatty-sets
theorem primitiveNormalizationPreservesRationalBeattySets {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p r : Fin m → ℤ) (h : CommonDenominatorPresentation P q p r) :
    let d := commonDenominatorGcd q p
    let q' := q / d
    let p' := fun i => p i / d
    (∀ i, (q' : ℝ) / (p' i : ℝ) = (q : ℝ) / (p i : ℝ) ∧
      (q : ℝ) / (p i : ℝ) = (P.moduli i : ℝ)) ∧
    (∀ i, integerTranslatedRationalBeattySet (p' i) q' (r i) =
      integerTranslatedRationalBeattySet (p i) q (r i)) ∧
    PrimitiveRationalBeattyPartition P q' p' r ∧
    (Function.Injective P.moduli → Function.Injective p') := by
  let d := commonDenominatorGcd q p
  obtain ⟨hdpos, hdq, hdp⟩ := commonDenominatorGcd_pos_and_dvd q p h.q_pos
  change 0 < d at hdpos
  change d ∣ q at hdq
  change ∀ i, d ∣ p i at hdp
  have hdR : (d : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hdpos)
  have hqpos : 0 < q / d := Int.ediv_pos_of_pos_of_dvd h.q_pos hdpos.le hdq
  have hbounds (i) : 0 < p i / d ∧ p i / d < q / d := by
    refine ⟨Int.ediv_pos_of_pos_of_dvd (h.numerator_bounds i).1 hdpos.le (hdp i), ?_⟩
    apply (mul_lt_mul_iff_of_pos_right hdpos).mp
    rw [Int.ediv_mul_cancel (hdp i), Int.ediv_mul_cancel hdq]
    exact (h.numerator_bounds i).2
  have hratio (i) : ((q / d : ℤ) : ℝ) / ((p i / d : ℤ) : ℝ) = (q : ℝ) / (p i : ℝ) := by
    rw [Int.cast_div_charZero hdq, Int.cast_div_charZero (hdp i)]
    field_simp
  have hs (i) : integerTranslatedRationalBeattySet (p i / d) (q / d) (r i) =
      integerTranslatedRationalBeattySet (p i) q (r i) := by
    simp only [integerTranslatedRationalBeattySet, hratio i]
  have hpres : CommonDenominatorPresentation P (q / d) (fun i => p i / d) r := by
    refine ⟨hqpos, hbounds, fun i => (hratio i).trans (h.modulus_eq i), ?_⟩
    intro i
    exact (h.set_eq i).trans (hs i).symm
  have hgcd : commonDenominatorGcd (q / d) (fun i => p i / d) = 1 := by
    have hg := Finset.gcd_div_eq_one (s := Finset.univ)
      (f := fun j : Option (Fin m) => j.elim q p) (i := none)
      (Finset.mem_univ none) h.q_pos.ne'
    convert hg using 1
    apply Finset.gcd_congr rfl
    intro j _
    cases j <;> rfl
  refine ⟨fun i => ⟨hratio i, h.modulus_eq i⟩, hs,
    ⟨hpres, hbounds, commonDenominator_sum P _ _ r hpres, hgcd⟩, ?_⟩
  intro hinj i j hij
  change p i / d = p j / d at hij
  apply hinj
  have hm : (P.moduli i : ℝ) = (P.moduli j : ℝ) := by
    rw [← hpres.modulus_eq i, ← hpres.modulus_eq j, hij]
  exact_mod_cast hm

/-- The complete equivalence, for every rational partition with primitive data;
there is no added distinctness hypothesis or restriction to `m ≥ 3`. -/
-- zpi: prop-fraenkel-conjecture-equivalent-to-binary-primitive-data
theorem fraenkelConjecture_iff_binaryPrimitiveData {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p r : Fin m → ℤ) (h : PrimitiveRationalBeattyPartition P q p r) :
    Set.range (fun i => (P.moduli i : ℝ)) =
      Set.range (fun j : Fin m => ((2 : ℝ) ^ m - 1) / (2 : ℝ) ^ j.val) ↔
    q = (2 : ℤ) ^ m - 1 ∧ Set.range p = Set.range (fun j : Fin m => (2 : ℤ) ^ j.val) := by
  have hc := h.1
  constructor
  · intro hset
    let D : ℤ := (2 : ℤ) ^ m - 1
    have hDmem : (D : ℝ) ∈ Set.range (fun j : Fin m => ((2 : ℝ) ^ m - 1) / (2 : ℝ) ^ j.val) :=
      ⟨⟨0, P.nonempty⟩, by simp [D]⟩
    rw [← hset] at hDmem
    obtain ⟨i₀, hi₀⟩ := hDmem
    let c : ℤ := p i₀
    have hcpos : 0 < c := (hc.numerator_bounds i₀).1
    have hcR : (c : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hcpos)
    have hqeq : q = D * c := by
      have hh := (div_eq_iff hcR).mp ((hc.modulus_eq i₀).trans hi₀)
      exact_mod_cast hh
    have hDne : D ≠ 0 := by
      intro hz
      rw [hz, zero_mul] at hqeq
      linarith [hc.q_pos]
    have hnum (i : Fin m) (j : Fin m)
        (hij : (P.moduli i : ℝ) = ((2 : ℝ) ^ m - 1) / (2 : ℝ) ^ j.val) :
        p i = c * (2 : ℤ) ^ j.val := by
      have hpR : (p i : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt (hc.numerator_bounds i).1)
      have hpow : (2 : ℝ) ^ j.val ≠ 0 := by positivity
      have heq := (div_eq_div_iff hpR hpow).mp ((hc.modulus_eq i).trans hij)
      have heqZ : q * (2 : ℤ) ^ j.val = D * p i := by
        dsimp [D]
        exact_mod_cast heq
      apply mul_left_cancel₀ hDne
      calc
        D * p i = q * (2 : ℤ) ^ j.val := heqZ.symm
        _ = D * (c * (2 : ℤ) ^ j.val) := by rw [hqeq]; ring
    have hsurj (i : Fin m) : ∃ j : Fin m, p i = c * (2 : ℤ) ^ j.val := by
      have hi : (P.moduli i : ℝ) ∈ Set.range (fun j : Fin m =>
          ((2 : ℝ) ^ m - 1) / (2 : ℝ) ^ j.val) := hset ▸ Set.mem_range_self i
      obtain ⟨j, hj⟩ := hi
      exact ⟨j, hnum i j hj.symm⟩
    have hcd : c ∣ commonDenominatorGcd q p := by
      apply Finset.dvd_gcd
      intro j _
      cases j with
      | none => exact ⟨D, by simpa [mul_comm] using hqeq⟩
      | some i =>
        obtain ⟨j, hj⟩ := hsurj i
        exact ⟨(2 : ℤ) ^ j.val, hj⟩
    rw [h.2.2.2] at hcd
    have hc1 : c = 1 := Int.eq_one_of_dvd_one hcpos.le hcd
    refine ⟨by simpa [hc1, D] using hqeq, ?_⟩
    apply Set.Subset.antisymm
    · rintro x ⟨i, rfl⟩
      obtain ⟨j, hj⟩ := hsurj i
      exact ⟨j, by simpa [hc1] using hj.symm⟩
    · rintro x ⟨j, rfl⟩
      have hj : ((2 : ℝ) ^ m - 1) / (2 : ℝ) ^ j.val ∈
          Set.range (fun i => (P.moduli i : ℝ)) := hset.symm ▸ Set.mem_range_self j
      obtain ⟨i, hi⟩ := hj
      exact ⟨i, by simpa [hc1] using hnum i j hi⟩
  · rintro ⟨hq, hp⟩
    apply Set.Subset.antisymm
    · rintro x ⟨i, rfl⟩
      have hi : p i ∈ Set.range (fun j : Fin m => (2 : ℤ) ^ j.val) := hp ▸ Set.mem_range_self i
      obtain ⟨j, hj⟩ := hi
      refine ⟨j, ?_⟩
      change ((2 : ℝ) ^ m - 1) / (2 : ℝ) ^ j.val = (P.moduli i : ℝ)
      change (2 : ℤ) ^ j.val = p i at hj
      rw [← hc.modulus_eq i, hq, ← hj]
      push_cast
      rfl
    · rintro x ⟨j, rfl⟩
      have hj : (2 : ℤ) ^ j.val ∈ Set.range p := hp.symm ▸ Set.mem_range_self j
      obtain ⟨i, hi⟩ := hj
      refine ⟨i, ?_⟩
      change (P.moduli i : ℝ) = ((2 : ℝ) ^ m - 1) / (2 : ℝ) ^ j.val
      rw [← hc.modulus_eq i, hq, hi]
      push_cast
      rfl

end Fraenkel
