import Fraenkel.Beatty.Normalization
import Fraenkel.Beatty.RigidArithmetic
import Fraenkel.External.Simpson2004

set_option maxHeartbeats 1000000

namespace Fraenkel

/-- The tuple of reduced parameters attached to `(p,s,q)`. Integer division is
used for the displayed quotients; on the theorem's positive domain the gcds
are positive divisors, so these are the ordinary reduced quotients. -/
-- zpi: def-morikawa-simpson-reduced-parameters
structure MorikawaSimpsonReducedParameters where
  gp : ℤ
  gs : ℤ
  A : ℤ
  x : ℤ
  B : ℤ
  y : ℤ
  d : ℤ
  u : ℤ
  v : ℤ

/-- The Morikawa--Simpson reduced parameters from the package definition. -/
-- zpi: def-morikawa-simpson-reduced-parameters
noncomputable def morikawaSimpsonReducedParameters (p s q : ℤ) :
    MorikawaSimpsonReducedParameters := by
  let gp : ℤ := Int.gcd p q
  let gs : ℤ := Int.gcd s q
  let A : ℤ := q / gp
  let x : ℤ := p / gp
  let B : ℤ := q / gs
  let y : ℤ := s / gs
  let d : ℤ := Int.gcd x y
  let u : ℤ := x / d
  let v : ℤ := y / d
  exact ⟨gp, gs, A, x, B, y, d, u, v⟩

-- zpi: def-morikawa-simpson-reduced-parameters
theorem morikawaSimpsonReducedParameters_spec (p s q : ℤ) :
    let R := morikawaSimpsonReducedParameters p s q
    R.gp = (Int.gcd p q : ℤ) ∧ R.gs = (Int.gcd s q : ℤ) ∧
      R.A = q / R.gp ∧ R.x = p / R.gp ∧
      R.B = q / R.gs ∧ R.y = s / R.gs ∧
      R.d = (Int.gcd R.x R.y : ℤ) ∧ R.u = R.x / R.d ∧ R.v = R.y / R.d := by
  simp [morikawaSimpsonReducedParameters]

/-- Some integer translates of the two rational Beatty sets are disjoint. -/
-- zpi: thm-morikawa-simpson-disjointness-criterion
def SomeDisjointRationalBeattyTranslations (p s q : ℤ) : Prop :=
  ∃ r₁ r₂ : ℤ,
    Disjoint (integerTranslatedRationalBeattySet p q r₁)
      (integerTranslatedRationalBeattySet s q r₂)

/-- Convert the gcd of nonnegative integer arguments to the corresponding
natural-number gcd after `toNat`. -/
private theorem intGcdCastToNat (x y : ℤ) (hx : 0 ≤ x) (hy : 0 ≤ y) :
    (Nat.gcd x.toNat y.toNat : ℤ) = Int.gcd x y := by
  have hx' : (x.toNat : ℤ) = x := Int.toNat_of_nonneg hx
  have hy' : (y.toNat : ℤ) = y := Int.toNat_of_nonneg hy
  have hg := Int.gcd_eq_natAbs (a := x) (b := y)
  have hxn : x.natAbs = x.toNat := by
    apply Int.natCast_inj.mp
    rw [Int.natAbs_of_nonneg hx, hx']
  have hyn : y.natAbs = y.toNat := by
    apply Int.natCast_inj.mp
    rw [Int.natAbs_of_nonneg hy, hy']
  rw [hxn, hyn] at hg
  exact_mod_cast hg.symm

/-- Convert a positive integer quotient by a gcd to the corresponding natural
quotient. -/
private theorem natDivCastToIntDiv (x y : ℤ) (hx : 0 < x) (hy : 0 < y) :
    ((x.toNat / Nat.gcd x.toNat y.toNat : ℕ) : ℤ) =
      x / (Int.gcd x y : ℤ) := by
  have hx' : (x.toNat : ℤ) = x := Int.toNat_of_nonneg hx.le
  have hgcast : (Nat.gcd x.toNat y.toNat : ℤ) = Int.gcd x y :=
    intGcdCastToNat x y hx.le hy.le
  have hgdvd : Nat.gcd x.toNat y.toNat ∣ x.toNat := Nat.gcd_dvd_left _ _
  have hgnz : (Nat.gcd x.toNat y.toNat : ℤ) ≠ 0 := by
    have hgpos : 0 < Nat.gcd x.toNat y.toNat := by
      have hxnat : 0 < x.toNat := by
        have hxnatR : (0 : ℤ) < (x.toNat : ℤ) := by simpa [hx'] using hx
        exact_mod_cast hxnatR
      exact Nat.gcd_pos_of_pos_left _ hxnat
    exact_mod_cast (ne_of_gt hgpos)
  symm
  rw [← hgcast]
  apply Int.ediv_eq_of_eq_mul_right hgnz
  have hmul := Nat.mul_div_cancel' hgdvd
  have hmulR : (Nat.gcd x.toNat y.toNat : ℤ) *
      ((x.toNat / Nat.gcd x.toNat y.toNat : ℕ) : ℤ) = (x.toNat : ℤ) := by
    exact_mod_cast hmul
  rw [hx'] at hmulR
  exact hmulR.symm

/-- Integer division by a positive natural divisor, transported from naturals. -/
private theorem rigidNatDivisorCastToIntDiv (z : ℤ) (d : ℕ)
    (hz : 0 ≤ z) (hd : 0 < d) (hdiv : d ∣ z.toNat) :
    ((z.toNat / d : ℕ) : ℤ) = z / (d : ℤ) := by
  have hz' : (z.toNat : ℤ) = z := Int.toNat_of_nonneg hz
  have hdnz : (d : ℤ) ≠ 0 := by exact_mod_cast (ne_of_gt hd)
  symm
  apply Int.ediv_eq_of_eq_mul_right hdnz
  have hmul := Nat.mul_div_cancel' hdiv
  have hmulR : (d : ℤ) * ((z.toNat / d : ℕ) : ℤ) = (z.toNat : ℤ) := by
    exact_mod_cast hmul
  rw [hz'] at hmulR
  exact hmulR.symm

/-- Morikawa--Simpson's integer-translate disjointness criterion. The
reduced-parameter translation from Simpson's real-shift statement, including
real-shift normalization, is proved below. -/
-- zpi: thm-morikawa-simpson-disjointness-criterion
theorem morikawaSimpsonDisjointnessCriterion (p s q : ℤ)
    (hp : 0 < p) (hs : 0 < s) (hpq : p < q) (hsq : s < q) :
    SomeDisjointRationalBeattyTranslations p s q ↔
      let R := morikawaSimpsonReducedParameters p s q
      ∃ k l : ℕ, 0 < k ∧ 0 < l ∧
        (k : ℤ) * R.u + (l : ℤ) * R.v =
          (Int.gcd R.A R.B : ℤ) - 2 * R.u * R.v * (R.d - 1) := by
  let R := morikawaSimpsonReducedParameters p s q
  change SomeDisjointRationalBeattyTranslations p s q ↔
      ∃ k l : ℕ, 0 < k ∧ 0 < l ∧
        (k : ℤ) * R.u + (l : ℤ) * R.v =
          (Int.gcd R.A R.B : ℤ) - 2 * R.u * R.v * (R.d - 1)
  have hgp : 0 < R.gp := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact_mod_cast ((Int.gcd_pos_iff).2 (Or.inl (ne_of_gt hp)))
  have hgs : 0 < R.gs := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact_mod_cast ((Int.gcd_pos_iff).2 (Or.inl (ne_of_gt hs)))
  have hA : 0 < R.A := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.ediv_pos_of_pos_of_dvd (lt_trans hp hpq) hgp.le (Int.gcd_dvd_right p q)
  have hx : 0 < R.x := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.ediv_pos_of_pos_of_dvd hp hgp.le (Int.gcd_dvd_left p q)
  have hB : 0 < R.B := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.ediv_pos_of_pos_of_dvd (lt_trans hs hsq) hgs.le (Int.gcd_dvd_right s q)
  have hy : 0 < R.y := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.ediv_pos_of_pos_of_dvd hs hgs.le (Int.gcd_dvd_left s q)
  have hPg : R.x * R.gp = p := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.ediv_mul_cancel (Int.gcd_dvd_left p q)
  have hQg : R.A * R.gp = q := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.ediv_mul_cancel (Int.gcd_dvd_right p q)
  have hSg : R.y * R.gs = s := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.ediv_mul_cancel (Int.gcd_dvd_left s q)
  have hTg : R.B * R.gs = q := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.ediv_mul_cancel (Int.gcd_dvd_right s q)
  have hAx : R.x < R.A := by
    apply (Int.ediv_lt_iff_lt_mul hgp).2
    rw [hQg]
    exact hpq
  have hBy : R.y < R.B := by
    apply (Int.ediv_lt_iff_lt_mul hgs).2
    rw [hTg]
    exact hsq
  have hcopx : Int.gcd R.x R.A = 1 := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.gcd_div_gcd_div_gcd ((Int.gcd_pos_iff).2 (Or.inl (ne_of_gt hp)))
  have hcopy : Int.gcd R.y R.B = 1 := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.gcd_div_gcd_div_gcd ((Int.gcd_pos_iff).2 (Or.inl (ne_of_gt hs)))
  have hdn : 0 < R.d := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact_mod_cast ((Int.gcd_pos_iff).2 (Or.inl (ne_of_gt hx)))
  have hu : 0 < R.u := by
    dsimp [R, morikawaSimpsonReducedParameters] at *
    exact Int.ediv_pos_of_pos_of_dvd hx hdn.le (Int.gcd_dvd_left _ _)
  have hv : 0 < R.v := by
    dsimp [R, morikawaSimpsonReducedParameters] at *
    exact Int.ediv_pos_of_pos_of_dvd hy hdn.le (Int.gcd_dvd_right _ _)
  have hRateP : (R.A : ℝ) / (R.x : ℝ) = (q : ℝ) / (p : ℝ) := by
    rw [← hQg, ← hPg]
    push_cast
    field_simp
  have hRateS : (R.B : ℝ) / (R.y : ℝ) = (q : ℝ) / (s : ℝ) := by
    rw [← hTg, ← hSg]
    push_cast
    field_simp
  have hAcast : (R.A.toNat : ℝ) = (R.A : ℝ) := by
    have hh : (R.A.toNat : ℤ) = R.A := Int.toNat_of_nonneg hA.le
    exact_mod_cast hh
  have hxcast : (R.x.toNat : ℝ) = (R.x : ℝ) := by
    have hh : (R.x.toNat : ℤ) = R.x := Int.toNat_of_nonneg hx.le
    exact_mod_cast hh
  have hBcast : (R.B.toNat : ℝ) = (R.B : ℝ) := by
    have hh : (R.B.toNat : ℤ) = R.B := Int.toNat_of_nonneg hB.le
    exact_mod_cast hh
  have hycast : (R.y.toNat : ℝ) = (R.y : ℝ) := by
    have hh : (R.y.toNat : ℤ) = R.y := Int.toNat_of_nonneg hy.le
    exact_mod_cast hh
  have hSeqP (β : ℝ) :
      External.Simpson2004.rationalBeattySequence R.A.toNat R.x.toNat β =
        biInfiniteBeattySequence ((q : ℝ) / (p : ℝ)) β := by
    rw [External.Simpson2004.rationalBeattySequence, hAcast, hxcast, hRateP]
  have hSeqS (β : ℝ) :
      External.Simpson2004.rationalBeattySequence R.B.toNat R.y.toNat β =
        biInfiniteBeattySequence ((q : ℝ) / (s : ℝ)) β := by
    rw [External.Simpson2004.rationalBeattySequence, hBcast, hycast, hRateS]
  have hnormP (β : ℝ) :
      ∃ r : ℤ,
        biInfiniteBeattySequence ((q : ℝ) / (p : ℝ)) β =
          integerTranslatedRationalBeattySet p q r := by
    obtain ⟨r, hr⟩ := realShiftNormalization R.x R.A hx hAx hcopx β
    refine ⟨r, ?_⟩
    calc
      biInfiniteBeattySequence ((q : ℝ) / (p : ℝ)) β =
          biInfiniteBeattySequence ((R.A : ℝ) / (R.x : ℝ)) β := by rw [hRateP]
      _ = integerTranslatedRationalBeattySet R.x R.A r := hr
      _ = integerTranslatedRationalBeattySet p q r := by
        rw [integerTranslatedRationalBeattySet, integerTranslatedRationalBeattySet]
        rw [hRateP]
  have hnormS (β : ℝ) :
      ∃ r : ℤ,
        biInfiniteBeattySequence ((q : ℝ) / (s : ℝ)) β =
          integerTranslatedRationalBeattySet s q r := by
    obtain ⟨r, hr⟩ := realShiftNormalization R.y R.B hy hBy hcopy β
    refine ⟨r, ?_⟩
    calc
      biInfiniteBeattySequence ((q : ℝ) / (s : ℝ)) β =
          biInfiniteBeattySequence ((R.B : ℝ) / (R.y : ℝ)) β := by rw [hRateS]
      _ = integerTranslatedRationalBeattySet R.y R.B r := hr
      _ = integerTranslatedRationalBeattySet s q r := by
        rw [integerTranslatedRationalBeattySet, integerTranslatedRationalBeattySet]
        rw [hRateS]
  have hleft : SomeDisjointRationalBeattyTranslations p s q ↔
      ∃ β₁ β₂ : ℝ,
        Disjoint
          (External.Simpson2004.rationalBeattySequence R.A.toNat R.x.toNat β₁)
          (External.Simpson2004.rationalBeattySequence R.B.toNat R.y.toNat β₂) := by
    constructor
    · rintro ⟨r₁, r₂, hd⟩
      refine ⟨(r₁ : ℝ), (r₂ : ℝ), ?_⟩
      rw [hSeqP, hSeqS]
      simpa [integerTranslatedRationalBeattySet] using hd
    · rintro ⟨β₁, β₂, hd⟩
      obtain ⟨r₁, hr₁⟩ := hnormP β₁
      obtain ⟨r₂, hr₂⟩ := hnormS β₂
      refine ⟨r₁, r₂, ?_⟩
      rw [← hr₁, ← hr₂]
      rw [← hSeqP, ← hSeqS]
      exact hd
  let a₁ : ℕ := R.A.toNat
  let b₁ : ℕ := R.x.toNat
  let a₂ : ℕ := R.B.toNat
  let b₂ : ℕ := R.y.toNat
  have ha₁ : 0 < a₁ := by
    dsimp [a₁]
    have hh : (R.A.toNat : ℤ) = R.A := Int.toNat_of_nonneg hA.le
    have hz : (0 : ℤ) < (R.A.toNat : ℤ) := by simpa [hh] using hA
    exact_mod_cast hz
  have hb₁ : 0 < b₁ := by
    dsimp [b₁]
    have hh : (R.x.toNat : ℤ) = R.x := Int.toNat_of_nonneg hx.le
    have hz : (0 : ℤ) < (R.x.toNat : ℤ) := by simpa [hh] using hx
    exact_mod_cast hz
  have ha₂ : 0 < a₂ := by
    dsimp [a₂]
    have hh : (R.B.toNat : ℤ) = R.B := Int.toNat_of_nonneg hB.le
    have hz : (0 : ℤ) < (R.B.toNat : ℤ) := by simpa [hh] using hB
    exact_mod_cast hz
  have hb₂ : 0 < b₂ := by
    dsimp [b₂]
    have hh : (R.y.toNat : ℤ) = R.y := Int.toNat_of_nonneg hy.le
    have hz : (0 : ℤ) < (R.y.toNat : ℤ) := by simpa [hh] using hy
    exact_mod_cast hz
  have hcop₁ : Nat.gcd a₁ b₁ = 1 := by
    have hh := intGcdCastToNat R.A R.x hA.le hx.le
    have hh' : (Nat.gcd R.A.toNat R.x.toNat : ℤ) = Int.gcd R.x R.A := by
      simpa [Int.gcd_comm] using hh
    rw [hcopx] at hh'
    exact_mod_cast (by simpa [a₁, b₁] using hh')
  have hcop₂ : Nat.gcd a₂ b₂ = 1 := by
    have hh := intGcdCastToNat R.B R.y hB.le hy.le
    have hh' : (Nat.gcd R.B.toNat R.y.toNat : ℤ) = Int.gcd R.y R.B := by
      simpa [Int.gcd_comm] using hh
    rw [hcopy] at hh'
    exact_mod_cast (by simpa [a₂, b₂] using hh')
  have hgdCast : (Nat.gcd b₁ b₂ : ℤ) = R.d := by
    have hh := intGcdCastToNat R.x R.y hx.le hy.le
    calc
      (Nat.gcd b₁ b₂ : ℤ) = (Int.gcd R.x R.y : ℤ) := by simpa [b₁, b₂] using hh
      _ = R.d := by rfl
  have hgaCast : (Nat.gcd a₁ a₂ : ℤ) = (Int.gcd R.A R.B : ℤ) := by
    have hh := intGcdCastToNat R.A R.B hA.le hB.le
    simpa [a₁, a₂] using hh
  have huCast :
      ((b₁ / Nat.gcd b₁ b₂ : ℕ) : ℤ) = R.u := by
    dsimp [b₁, b₂]
    calc
      ((R.x.toNat / Nat.gcd R.x.toNat R.y.toNat : ℕ) : ℤ) =
          R.x / (Int.gcd R.x R.y : ℤ) :=
        natDivCastToIntDiv R.x R.y hx hy
      _ = R.u := by rfl
  have hvCast :
      ((b₂ / Nat.gcd b₁ b₂ : ℕ) : ℤ) = R.v := by
    dsimp [b₁, b₂]
    calc
      ((R.y.toNat / Nat.gcd R.x.toNat R.y.toNat : ℕ) : ℤ) =
          R.y / (Int.gcd R.y R.x : ℤ) := by
            simpa only [Nat.gcd_comm] using natDivCastToIntDiv R.y R.x hy hx
      _ = R.y / (Int.gcd R.x R.y : ℤ) := by rw [Int.gcd_comm]
      _ = R.v := by rfl
  let U : ℕ := b₁ / Nat.gcd b₁ b₂
  let V : ℕ := b₂ / Nat.gcd b₁ b₂
  let G : ℕ := Nat.gcd a₁ a₂
  let D : ℕ := Nat.gcd b₁ b₂
  let H : ℕ := 2 * U * V * (D - 1)
  have hUcast : (U : ℤ) = R.u := by simpa [U] using huCast
  have hVcast : (V : ℤ) = R.v := by simpa [V] using hvCast
  have hDcast : (D : ℤ) = R.d := by simpa [D] using hgdCast
  have hGcast : (G : ℤ) = (Int.gcd R.A R.B : ℤ) := by
    simpa [G] using hgaCast
  have hU : 0 < U := by
    have hz : (0 : ℤ) < (U : ℤ) := by rw [hUcast]; exact hu
    exact_mod_cast hz
  have hV : 0 < V := by
    have hz : (0 : ℤ) < (V : ℤ) := by rw [hVcast]; exact hv
    exact_mod_cast hz
  have hD : 0 < D := by
    dsimp [D]
    exact Nat.gcd_pos_of_pos_left _ hb₁
  have hHexpand : (H : ℤ) =
      2 * (U : ℤ) * (V : ℤ) * ((D - 1 : ℕ) : ℤ) := by
    rfl
  have hHcast : (H : ℤ) = 2 * R.u * R.v * (R.d - 1) := by
    rw [hHexpand, hUcast, hVcast, Nat.cast_sub (by omega), hDcast]
    norm_num
  have hEquation :
      (∃ x y : ℕ, 0 < x ∧ 0 < y ∧ x * U + y * V = G - H) ↔
        ∃ k l : ℕ, 0 < k ∧ 0 < l ∧
          (k : ℤ) * R.u + (l : ℤ) * R.v =
            (Int.gcd R.A R.B : ℤ) - 2 * R.u * R.v * (R.d - 1) := by
    by_cases hsub : H ≤ G
    · have hsubcast : ((G - H : ℕ) : ℤ) = (G : ℤ) - (H : ℤ) := by
        rw [Nat.cast_sub hsub]
      constructor
      · rintro ⟨k, l, hk, hl, he⟩
        refine ⟨k, l, hk, hl, ?_⟩
        have he' := congrArg (fun n : ℕ => (n : ℤ)) he
        push_cast at he'
        rw [hUcast, hVcast, hsubcast, hGcast, hHcast] at he'
        exact he'
      · rintro ⟨k, l, hk, hl, he⟩
        refine ⟨k, l, hk, hl, ?_⟩
        have he' := he
        rw [← hGcast, ← hHcast, ← hUcast, ← hVcast, ← hsubcast] at he'
        exact_mod_cast he'
    · have hGle : G ≤ H := by omega
      have hzero : G - H = 0 := Nat.sub_eq_zero_of_le hGle
      constructor
      · rintro ⟨k, l, hk, hl, he⟩
        have hkp : 0 < k * U := Nat.mul_pos hk hU
        have hlp : 0 < l * V := Nat.mul_pos hl hV
        rw [hzero] at he
        omega
      · rintro ⟨k, l, hk, hl, he⟩
        have hkp : (0 : ℤ) < (k : ℤ) * R.u :=
          mul_pos (by exact_mod_cast hk) hu
        have hlp : (0 : ℤ) < (l : ℤ) * R.v :=
          mul_pos (by exact_mod_cast hl) hv
        have hGH : (G : ℤ) ≤ (H : ℤ) := by exact_mod_cast hGle
        rw [hGcast, hHcast] at hGH
        linarith
  have hSimpson := External.Simpson2004.disjointRationalBeattyCriterion
    a₁ b₁ a₂ b₂ ha₁ hb₁ hcop₁ ha₂ hb₂ hcop₂
  calc
    SomeDisjointRationalBeattyTranslations p s q ↔
        ∃ β₁ β₂ : ℝ,
          Disjoint
            (External.Simpson2004.rationalBeattySequence a₁ b₁ β₁)
            (External.Simpson2004.rationalBeattySequence a₂ b₂ β₂) := by
      simpa [a₁, b₁, a₂, b₂] using hleft
    _ ↔ ∃ x y : ℕ, 0 < x ∧ 0 < y ∧ x * U + y * V = G - H := by
      simpa [U, V, G, D, H] using hSimpson
    _ ↔ ∃ k l : ℕ, 0 < k ∧ 0 < l ∧
        (k : ℤ) * R.u + (l : ℤ) * R.v =
          (Int.gcd R.A R.B : ℤ) - 2 * R.u * R.v * (R.d - 1) := hEquation

/-- The rigid binary extension lemma. -/
-- zpi: lem-rigid-binary-extension
theorem rigidBinaryExtension (M p h q : ℤ)
    (hM : ∃ n : ℕ, M = (2 : ℤ) ^ n ∧ 2 ≤ M)
    (hp : 0 < p) (hh : 0 < h) (hq : 0 < q)
    (hrel : q = p + (2 * M - 1) * h)
    (hcop : Int.gcd p h = 1)
    (hineq : 2 * p ≥ (2 * M - 1) * h)
    (hne : p ≠ M * h)
    (hdisj : SomeDisjointRationalBeattyTranslations p (M * h) q) :
    (p, h, q) = (2 * M, 1, 4 * M - 1) := by
  obtain ⟨n, hMn, hM2⟩ := hM
  have hMpos : 0 < M := lt_of_lt_of_le (by omega : (0 : ℤ) < 2) hM2
  have hM1 : 1 < M := by omega
  have hqrel : q = p + (2 * M - 1) * h := hrel
  have hqpos : 0 < q := hq
  have hMh : 0 < M * h := mul_pos hMpos hh
  have hpq : p < q := by
    rw [hrel]
    nlinarith
  have hMq : M * h < q := by
    rw [hrel]
    nlinarith
  have hcrit := (morikawaSimpsonDisjointnessCriterion p (M * h) q
    hp hMh hpq hMq).1 hdisj
  obtain ⟨k, l, hk, hl, hEq⟩ := hcrit
  have hcopHQ : Int.gcd h q = 1 := by
    apply (Int.gcd_eq_one_iff).2
    intro c hc_h hc_q
    have hcDh : c ∣ (2 * M - 1) * h := dvd_mul_of_dvd_right hc_h _
    have hc_p : c ∣ p := by
      have hp_expr : p = q - (2 * M - 1) * h := by linarith [hrel]
      rw [hp_expr]
      exact dvd_sub hc_q hcDh
    exact (Int.gcd_eq_one_iff).1 hcop c hc_p hc_h
  let pN : ℕ := p.natAbs
  let hN : ℕ := h.natAbs
  let qN : ℕ := q.natAbs
  let MN : ℕ := M.natAbs
  have hpNcast : (pN : ℤ) = p := by
    dsimp [pN]
    exact Int.natAbs_of_nonneg hp.le
  have hhNcast : (hN : ℤ) = h := by
    dsimp [hN]
    exact Int.natAbs_of_nonneg hh.le
  have hqNcast : (qN : ℤ) = q := by
    dsimp [qN]
    exact Int.natAbs_of_nonneg hq.le
  have hMNcast : (MN : ℤ) = M := by
    dsimp [MN]
    exact Int.natAbs_of_nonneg hMpos.le
  have hcopHQNat : Nat.Coprime hN qN := by
    apply Nat.coprime_iff_gcd_eq_one.mpr
    have hg := Int.gcd_eq_natAbs (a := h) (b := q)
    rw [hcopHQ] at hg
    simpa [hN, qN] using hg.symm
  have hcopPHNat : Nat.Coprime pN hN := by
    apply Nat.coprime_iff_gcd_eq_one.mpr
    have hg := Int.gcd_eq_natAbs (a := p) (b := h)
    rw [hcop] at hg
    simpa [pN, hN] using hg.symm
  let cN : ℕ := Int.gcd p q
  let tN : ℕ := Int.gcd (M * h) q
  have htpos0 : 0 < tN := by
    dsimp [tN]
    exact (Int.gcd_pos_iff).2 (Or.inl (ne_of_gt hMh))
  have hcPInt : (cN : ℤ) ∣ p := by
    dsimp [cN]
    exact Int.gcd_dvd_left p q
  have hcQInt : (cN : ℤ) ∣ q := by
    dsimp [cN]
    exact Int.gcd_dvd_right p q
  have hcPN : cN ∣ pN := by
    have hnat := (Int.natAbs_dvd_natAbs (a := (cN : ℤ)) (b := p)).2 hcPInt
    simpa [cN, pN] using hnat
  have hcQN : cN ∣ qN := by
    have hnat := (Int.natAbs_dvd_natAbs (a := (cN : ℤ)) (b := q)).2 hcQInt
    simpa [cN, qN] using hnat
  have hcopCHNat : Nat.Coprime cN hN :=
    Nat.Coprime.of_dvd_left hcPN hcopPHNat
  let DN : ℕ := 2 * MN - 1
  have hDNcast : (DN : ℤ) = 2 * M - 1 := by
    dsimp [DN]
    rw [Nat.cast_sub (by omega), Nat.cast_mul, hMNcast]
    norm_num
  have hqNrel : qN = pN + DN * hN := by
    have hz : (qN : ℤ) = (pN + DN * hN : ℕ) := by
      rw [Nat.cast_add, Nat.cast_mul, hqNcast, hpNcast, hDNcast, hhNcast]
      exact hrel
    exact_mod_cast hz
  have hcDN : cN ∣ DN := by
    have hdiff : cN ∣ qN - pN := Nat.dvd_sub hcQN hcPN
    have hprod : cN ∣ DN * hN := by simpa [hqNrel] using hdiff
    exact hcopCHNat.dvd_of_dvd_mul_right hprod
  have hcpos : 0 < cN := by
    dsimp [cN]
    exact (Int.gcd_pos_iff).2 (Or.inl (ne_of_gt hp))
  have hcne2 : cN ≠ 2 := by
    intro hc2
    rw [hc2] at hcDN
    obtain ⟨z, hz⟩ := hcDN
    dsimp [DN] at hz
    omega
  have hc3_of_gt1 (hc1 : 1 < cN) : 3 ≤ cN := by omega
  have hMpow : MN = 2 ^ n := by
    have hz : (MN : ℤ) = ((2 ^ n : ℕ) : ℤ) := by
      rw [hMNcast, hMn]
      norm_num
    exact_mod_cast hz
  have ht_eq : tN = Int.gcd M q := by
    have hgt := Int.gcd_eq_natAbs (a := M * h) (b := q)
    rw [Int.natAbs_mul] at hgt
    have hcancel := hcopHQNat.gcd_mul_right_cancel MN
    calc
      tN = (MN * hN).gcd qN := by simpa [tN, MN, hN, qN] using hgt
      _ = MN.gcd qN := hcancel
      _ = Int.gcd M q := by
        have hgm := Int.gcd_eq_natAbs (a := M) (b := q)
        simpa [MN, qN] using hgm.symm
  have htMInt : (tN : ℤ) ∣ M := by
    rw [ht_eq]
    exact Int.gcd_dvd_left M q
  have htMN : tN ∣ MN := by
    have hnat := (Int.natAbs_dvd_natAbs (a := (tN : ℤ)) (b := M)).2 htMInt
    simpa [MN] using hnat
  have hMN2 : 2 ≤ MN := by
    have hz : (2 : ℤ) ≤ (MN : ℤ) := by rw [hMNcast]; exact hM2
    exact_mod_cast hz
  have hnpos : 0 < n := by
    by_contra hn0
    have hnzero : n = 0 := by omega
    rw [hnzero] at hMn
    norm_num at hMn
    omega
  have hMeven : 2 ∣ M := by
    rw [hMn]
    exact dvd_pow_self (2 : ℤ) (by omega)
  have hcNotEven : ¬ Even cN := by
    intro hceven
    have h2c : 2 ∣ cN := even_iff_two_dvd.mp hceven
    have h2D : 2 ∣ DN := dvd_trans h2c hcDN
    obtain ⟨z, hz⟩ := h2D
    dsimp [DN] at hz
    omega
  have hcOdd : Odd cN := (Nat.not_even_iff_odd).1 hcNotEven
  have htPow : ∃ j ≤ n, tN = 2 ^ j := by
    have hpowdiv : tN ∣ 2 ^ n := by simpa [hMpow] using htMN
    exact (Nat.dvd_prime_pow Nat.prime_two).1 hpowdiv
  obtain ⟨j, hjn, htPowEq⟩ := htPow
  have hcopCT : Nat.Coprime cN tN := by
    rw [htPowEq]
    exact (Nat.coprime_two_right.mpr hcOdd).pow_right j
  have ht_even_of_gt1 (ht1 : 1 < tN) : 2 ∣ tN := by
    have hpowdiv : tN ∣ 2 ^ n := by simpa [hMpow] using htMN
    obtain ⟨j, hj, hjt⟩ := (Nat.dvd_prime_pow Nat.prime_two).1 hpowdiv
    have hjpos : 0 < j := by
      by_contra hj0
      have : j = 0 := by omega
      rw [this] at hjt
      omega
    rw [hjt]
    exact dvd_pow_self 2 (by omega)
  have htQInt : (tN : ℤ) ∣ q := by
    dsimp [tN]
    exact Int.gcd_dvd_right (M * h) q
  have htQN : tN ∣ qN := by
    have hnat := (Int.natAbs_dvd_natAbs (a := (tN : ℤ)) (b := q)).2 htQInt
    simpa [qN] using hnat
  have hctQ : cN * tN ∣ qN :=
    hcopCT.mul_dvd_of_dvd_of_dvd hcQN htQN
  let rN : ℕ := qN / (cN * tN)
  have hctr : cN * tN * rN = qN := by
    dsimp [rN]
    exact Nat.mul_div_cancel' hctQ
  have hqC : qN / cN = tN * rN := by
    calc
      qN / cN = (cN * tN * rN) / cN := by rw [hctr]
      _ = tN * rN := by
        rw [show cN * tN * rN = cN * (tN * rN) by ring]
        exact Nat.mul_div_cancel_left _ (by omega : 0 < cN)
  have hqT : qN / tN = cN * rN := by
    calc
      qN / tN = (cN * tN * rN) / tN := by rw [hctr]
      _ = cN * rN := by
        rw [show cN * tN * rN = tN * (cN * rN) by ring]
        exact Nat.mul_div_cancel_left _ htpos0
  have hqGcd : Nat.gcd (qN / cN) (qN / tN) = rN := by
    rw [hqC, hqT, Nat.gcd_mul_right]
    rw [hcopCT.symm.gcd_eq_one]
    simp
  have hphDiv_of_t_gt1 (ht1 : 1 < tN) : 2 ∣ p - h := by
    have htwoQNat : 2 ∣ qN := dvd_trans (ht_even_of_gt1 ht1) htQN
    have htwoQInt : (2 : ℤ) ∣ q := by
      have hnat : (2 : ℤ) ∣ (qN : ℤ) := by exact_mod_cast htwoQNat
      simpa [hqNcast] using hnat
    have htwoMh : (2 : ℤ) ∣ 2 * M * h := by
      refine ⟨M * h, ?_⟩
      ring
    have hsub : (2 : ℤ) ∣ q - 2 * M * h := dvd_sub htwoQInt htwoMh
    have heq : p - h = q - 2 * M * h := by rw [hrel]; ring
    rw [heq]
    exact hsub
  have hpNotEven_of_t_gt1 (ht1 : 1 < tN) : ¬ (2 : ℤ) ∣ p := by
    intro hp2
    have hh2 : (2 : ℤ) ∣ h := by
      have hsub : (2 : ℤ) ∣ p - (p - h) := dvd_sub hp2 (hphDiv_of_t_gt1 ht1)
      convert hsub using 1; ring
    have htwoG : 2 ∣ Int.gcd p h := Int.dvd_gcd hp2 hh2
    rw [hcop] at htwoG
    omega
  let xN : ℕ := pN / cN
  let eN : ℕ := MN / tN
  let yN : ℕ := eN * hN
  have hcMul : cN * xN = pN := by
    dsimp [xN]
    exact Nat.mul_div_cancel' hcPN
  have htMul : tN * eN = MN := by
    dsimp [eN]
    exact Nat.mul_div_cancel' htMN
  have hcposN : 0 < cN := hcpos
  have htposN : 0 < tN := by
    dsimp [tN]
    exact (Int.gcd_pos_iff).2 (Or.inl (ne_of_gt hMh))
  have hpNpos : 0 < pN := by
    have hz : (0 : ℤ) < (pN : ℤ) := by simpa [hpNcast] using hp
    exact_mod_cast hz
  have hMNpos : 0 < MN := by
    have hz : (0 : ℤ) < (MN : ℤ) := by simpa [hMNcast] using hMpos
    exact_mod_cast hz
  have hxNpos : 0 < xN := by
    apply Nat.div_pos
    · exact Nat.le_of_dvd hpNpos hcPN
    · exact hcposN
  have heNpos : 0 < eN := by
    apply Nat.div_pos
    · exact Nat.le_of_dvd hMNpos htMN
    · exact htposN
  have hpOddN_of_t_gt1 (ht1 : 1 < tN) : Odd pN := by
    apply (Nat.not_even_iff_odd).1
    intro hpeven
    have hp2N : 2 ∣ pN := even_iff_two_dvd.mp hpeven
    have hp2 : (2 : ℤ) ∣ p := by
      have hz : (2 : ℤ) ∣ (pN : ℤ) := by exact_mod_cast hp2N
      simpa [hpNcast] using hz
    exact hpNotEven_of_t_gt1 ht1 hp2
  have hpCopMN_of_t_gt1 (ht1 : 1 < tN) : Nat.Coprime pN MN := by
    rw [hMpow]
    exact (Nat.coprime_two_right.mpr (hpOddN_of_t_gt1 ht1)).pow_right n
  have hxCopHN : Nat.Coprime xN hN :=
    Nat.Coprime.of_dvd_left (by
      rw [← hcMul]
      exact ⟨cN, by ring⟩) hcopPHNat
  have hxCopEN_of_t_gt1 (ht1 : 1 < tN) : Nat.Coprime xN eN := by
    have heMN : eN ∣ MN := by
      rw [← htMul]
      exact ⟨tN, by ring⟩
    have hxCopMN : Nat.Coprime xN MN :=
      Nat.Coprime.of_dvd_left (by
        rw [← hcMul]
        exact ⟨cN, by ring⟩) (hpCopMN_of_t_gt1 ht1)
    exact Nat.Coprime.of_dvd_right heMN hxCopMN
  have hxCopY_of_t_gt1 (ht1 : 1 < tN) : Nat.Coprime xN yN := by
    dsimp [yN]
    exact (hxCopEN_of_t_gt1 ht1).mul_right hxCopHN
  have hdN_of_t_gt1 (ht1 : 1 < tN) : Nat.gcd xN yN = 1 :=
    (hxCopY_of_t_gt1 ht1).gcd_eq_one
  let R := morikawaSimpsonReducedParameters p (M * h) q
  have hgp : 0 < R.gp := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact_mod_cast ((Int.gcd_pos_iff).2 (Or.inl (ne_of_gt hp)))
  have hgs : 0 < R.gs := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact_mod_cast ((Int.gcd_pos_iff).2 (Or.inl (ne_of_gt hMh)))
  have hA : 0 < R.A := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.ediv_pos_of_pos_of_dvd hq hgp.le (Int.gcd_dvd_right p q)
  have hx : 0 < R.x := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.ediv_pos_of_pos_of_dvd hp hgp.le (Int.gcd_dvd_left p q)
  have hB : 0 < R.B := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.ediv_pos_of_pos_of_dvd hq hgs.le (Int.gcd_dvd_right (M * h) q)
  have hy : 0 < R.y := by
    dsimp [R, morikawaSimpsonReducedParameters]
    exact Int.ediv_pos_of_pos_of_dvd hMh hgs.le (Int.gcd_dvd_left (M * h) q)
  have hEqR :
      (k : ℤ) * R.u + (l : ℤ) * R.v =
        (Int.gcd R.A R.B : ℤ) - 2 * R.u * R.v * (R.d - 1) := by
    simpa [R] using hEq
  have hpToNat : p.toNat = pN := by
    apply Int.natCast_inj.mp
    rw [Int.toNat_of_nonneg hp.le, hpNcast]
  have hqToNat : q.toNat = qN := by
    apply Int.natCast_inj.mp
    rw [Int.toNat_of_nonneg hq.le, hqNcast]
  have hRxCast : (xN : ℤ) = R.x := by
    have hnat := natDivCastToIntDiv p q hp hq
    simpa [xN, cN, R, morikawaSimpsonReducedParameters, hpToNat, hqToNat] using hnat
  have hFullMul : ((MN * hN : ℕ) : ℤ) = M * h := by
    rw [Nat.cast_mul, hMNcast, hhNcast]
  have hMtoNat : M.toNat = MN := by
    apply Int.natCast_inj.mp
    rw [Int.toNat_of_nonneg hMpos.le, hMNcast]
  have hhtoNat : h.toNat = hN := by
    apply Int.natCast_inj.mp
    rw [Int.toNat_of_nonneg hh.le, hhNcast]
  have hFullToNat : (M * h).toNat = MN * hN := by
    rw [Int.toNat_mul hMpos.le hh.le, hMtoNat, hhtoNat]
  have htNat : tN = (MN * hN).gcd qN := by
    have hgt := Int.gcd_eq_natAbs (a := M * h) (b := q)
    rw [Int.natAbs_mul] at hgt
    simpa [tN, MN, hN, qN] using hgt
  have hFullGcd : (M * h).toNat.gcd q.toNat = tN := by
    rw [hFullToNat, hqToNat]
    exact htNat.symm
  have hRyCast : (yN : ℤ) = R.y := by
    have hnat := natDivCastToIntDiv (M * h) q hMh hq
    have hquot : (M * h).toNat / tN = yN := by
      rw [hFullToNat]
      dsimp [yN, eN]
      simpa [Nat.mul_comm] using Nat.mul_div_assoc hN htMN
    rw [hFullGcd, hquot] at hnat
    simpa [R, morikawaSimpsonReducedParameters, tN] using hnat
  have hRxToNat : R.x.toNat = xN := by
    apply Int.natCast_inj.mp
    rw [Int.toNat_of_nonneg hx.le, hRxCast]
  have hRyToNat : R.y.toNat = yN := by
    apply Int.natCast_inj.mp
    rw [Int.toNat_of_nonneg hy.le, hRyCast]
  have hRdCast : (Nat.gcd xN yN : ℤ) = R.d := by
    have hg := intGcdCastToNat R.x R.y hx.le hy.le
    calc
      (Nat.gcd xN yN : ℤ) = (Int.gcd R.x R.y : ℤ) := by
        simpa [hRxToNat, hRyToNat] using hg
      _ = R.d := by rfl
  have hUCastR :
      ((xN / Nat.gcd xN yN : ℕ) : ℤ) = R.u := by
    have hnat := natDivCastToIntDiv R.x R.y hx hy
    rw [hRxToNat, hRyToNat] at hnat
    calc
      ((xN / Nat.gcd xN yN : ℕ) : ℤ) =
          R.x / (Int.gcd R.x R.y : ℤ) := hnat
      _ = R.u := by rfl
  have hVCastR :
      ((yN / Nat.gcd xN yN : ℕ) : ℤ) = R.v := by
    have hnat := natDivCastToIntDiv R.y R.x hy hx
    rw [hRyToNat, hRxToNat] at hnat
    calc
      ((yN / Nat.gcd xN yN : ℕ) : ℤ) =
          R.y / (Int.gcd R.y R.x : ℤ) := by
            simpa only [Nat.gcd_comm] using hnat
      _ = R.y / (Int.gcd R.x R.y : ℤ) := by rw [Int.gcd_comm]
      _ = R.v := by rfl
  have hqpgcd : Nat.gcd qN pN = cN := by
    apply Int.natCast_inj.mp
    have hg := intGcdCastToNat q p hq.le hp.le
    simpa [cN, hpToNat, hqToNat, Int.gcd_comm] using hg
  have hqfullgcd : Nat.gcd qN (MN * hN) = tN := by
    rw [← hFullToNat, ← hqToNat]
    simpa [Nat.gcd_comm] using hFullGcd
  have hRACast : (qN / cN : ℤ) = R.A := by
    have hnat := natDivCastToIntDiv q p hq hp
    rw [hpToNat, hqToNat, hqpgcd] at hnat
    simpa [cN, R, morikawaSimpsonReducedParameters, Int.gcd_comm] using hnat
  have hRBCast : (qN / tN : ℤ) = R.B := by
    have hnat := natDivCastToIntDiv q (M * h) hq hMh
    rw [hqToNat, hFullToNat, hqfullgcd] at hnat
    simpa [tN, R, morikawaSimpsonReducedParameters, Int.gcd_comm] using hnat
  have hRAToNat : R.A.toNat = qN / cN := by
    apply Int.natCast_inj.mp
    rw [Int.toNat_of_nonneg hA.le]
    exact (rigidNatDivisorCastToIntDiv qN cN (by positivity) hcpos hcQN).trans hRACast |>.symm
  have hRBToNat : R.B.toNat = qN / tN := by
    apply Int.natCast_inj.mp
    rw [Int.toNat_of_nonneg hB.le]
    exact (rigidNatDivisorCastToIntDiv qN tN (by positivity) htpos0 htQN).trans hRBCast |>.symm
  have hGABCast :
      (Nat.gcd (qN / cN) (qN / tN) : ℤ) = (Int.gcd R.A R.B : ℤ) := by
    have hg := intGcdCastToNat R.A R.B hA.le hB.le
    simpa [hRAToNat, hRBToNat] using hg
  have hGABr : (rN : ℤ) = (Int.gcd R.A R.B : ℤ) := by
    calc
      (rN : ℤ) = (Nat.gcd (qN / cN) (qN / tN) : ℤ) := by
        rw [hqGcd]
      _ = (Int.gcd R.A R.B : ℤ) := hGABCast
  have ht_one : tN = 1 := by
    by_contra htne
    have ht1 : 1 < tN := by omega
    have hdOne : R.d = 1 := by
      have hd := hRdCast
      rw [hdN_of_t_gt1 ht1] at hd
      omega
    have huOne : R.u = (xN : ℤ) := by
      have hu' := hUCastR
      rw [hdN_of_t_gt1 ht1] at hu'
      norm_num at hu'
      exact hu'.symm
    have hvOne : R.v = (yN : ℤ) := by
      have hv' := hVCastR
      rw [hdN_of_t_gt1 ht1] at hv'
      norm_num at hv'
      exact hv'.symm
    rw [huOne, hvOne, hdOne, ← hGABr] at hEqR
    norm_num at hEqR
    have hEqSimple :
        (k : ℤ) * (xN : ℤ) + (l : ℤ) * (yN : ℤ) = (rN : ℤ) := hEqR
    have hcMulZ : (cN : ℤ) * (xN : ℤ) = (pN : ℤ) := by
      exact_mod_cast hcMul
    have htMulZ : (tN : ℤ) * (eN : ℤ) = (MN : ℤ) := by
      exact_mod_cast htMul
    have hEqMul := congrArg (fun z : ℤ => z * (cN : ℤ) * (tN : ℤ)) hEqSimple
    have hEqMul' :
        (k : ℤ) * (xN : ℤ) * (cN : ℤ) * (tN : ℤ) +
            (l : ℤ) * (eN : ℤ) * (hN : ℤ) * (tN : ℤ) * (cN : ℤ) =
          (rN : ℤ) * (cN : ℤ) * (tN : ℤ) := by
      calc
        _ = ((k : ℤ) * (xN : ℤ) + (l : ℤ) * (yN : ℤ)) *
            (cN : ℤ) * (tN : ℤ) := by
              rw [show yN = eN * hN by rfl]
              push_cast
              ring
        _ = _ := hEqMul
    have hEqTarget :
        (k : ℤ) * (pN : ℤ) * (tN : ℤ) +
            (l : ℤ) * (MN : ℤ) * (hN : ℤ) * (cN : ℤ) = (qN : ℤ) := by
      calc
        _ = (k : ℤ) * (xN : ℤ) * (cN : ℤ) * (tN : ℤ) +
            (l : ℤ) * (eN : ℤ) * (hN : ℤ) * (tN : ℤ) * (cN : ℤ) := by
              rw [← hcMulZ, ← htMulZ]
              ring_nf
        _ = (rN : ℤ) * (cN : ℤ) * (tN : ℤ) := hEqMul'
        _ = (qN : ℤ) := by
          have hctrZ := congrArg (fun z : ℕ => (z : ℤ)) hctr
          push_cast at hctrZ
          calc
            _ = (cN : ℤ) * (tN : ℤ) * (rN : ℤ) := by ring
            _ = (qN : ℤ) := hctrZ
    have hEqInt :
        (k : ℤ) * p * (tN : ℤ) +
            (l : ℤ) * M * h * (cN : ℤ) = q := by
      have he := hEqTarget
      push_cast at he
      rw [hpNcast, hMNcast, hhNcast, hqNcast] at he
      exact he
    have hk1 : (1 : ℤ) ≤ (k : ℤ) := by exact_mod_cast (show 1 ≤ k by omega)
    have hl1 : (1 : ℤ) ≤ (l : ℤ) := by exact_mod_cast (show 1 ≤ l by omega)
    have hkp : p * (tN : ℤ) ≤ (k : ℤ) * p * (tN : ℤ) := by
      have hkp0 : p ≤ (k : ℤ) * p := by
        calc
          p = 1 * p := by ring
          _ ≤ (k : ℤ) * p := mul_le_mul_of_nonneg_right hk1 hp.le
      exact mul_le_mul_of_nonneg_right hkp0 (by positivity)
    have hlc : M * h * (cN : ℤ) ≤ (l : ℤ) * M * h * (cN : ℤ) := by
      have hl0 : M * h ≤ (l : ℤ) * M * h := by
        have hl0' : M * h ≤ (l : ℤ) * (M * h) := by
          calc
            M * h = 1 * (M * h) := by ring
            _ ≤ (l : ℤ) * (M * h) := mul_le_mul_of_nonneg_right hl1 hMh.le
        simpa [mul_assoc] using hl0'
      exact mul_le_mul_of_nonneg_right hl0 (by positivity)
    have hLower :
        p * (tN : ℤ) + M * h * (cN : ℤ) ≤
          (k : ℤ) * p * (tN : ℤ) + (l : ℤ) * M * h * (cN : ℤ) :=
      add_le_add hkp hlc
    have hcCases : cN = 1 ∨ 3 ≤ cN := by omega
    rcases hcCases with hc1 | hc3
    · have hEqInt1 := hEqInt
      have hLower1 := hLower
      simp [hc1] at hEqInt1 hLower1
      have hbase : q < p * (tN : ℤ) + M * h := by
        have ht2 : (2 : ℤ) ≤ (tN : ℤ) := by exact_mod_cast (show 2 ≤ tN by omega)
        have hpt : 2 * p ≤ p * (tN : ℤ) := by
          have hpt' := mul_le_mul_of_nonneg_left ht2 hp.le
          simpa [mul_comm] using hpt'
        have hpMh : (M - 1) * h < p := by
          have htmp : 2 * (M - 1) * h < 2 * p := by
            nlinarith only [hineq, hh]
          nlinarith only [htmp]
        nlinarith only [hpt, hpMh, hrel]
      have hle : p * (tN : ℤ) + M * h ≤ q := by
        calc
          p * (tN : ℤ) + M * h ≤
              (k : ℤ) * p * (tN : ℤ) + (l : ℤ) * M * h := hLower1
          _ = q := hEqInt1
      exact (not_lt_of_ge hle) hbase
    · have hbase : q < p * (tN : ℤ) + M * h * (cN : ℤ) := by
        have ht2 : (2 : ℤ) ≤ (tN : ℤ) := by exact_mod_cast (show 2 ≤ tN by omega)
        have hc3z : (3 : ℤ) ≤ (cN : ℤ) := by exact_mod_cast hc3
        have hpt : 2 * p ≤ p * (tN : ℤ) := by
          have hpt' := mul_le_mul_of_nonneg_left ht2 hp.le
          simpa [mul_comm] using hpt'
        have hmhc : 3 * (M * h) ≤ M * h * (cN : ℤ) := by
          have hmhc' := mul_le_mul_of_nonneg_left hc3z hMh.le
          simpa [mul_assoc, mul_comm, mul_left_comm] using hmhc'
        have hqbase : q < 2 * p + 3 * (M * h) := by
          nlinarith only [hrel, hp, hh, hMh]
        have hbase' : 2 * p + 3 * (M * h) ≤
            p * (tN : ℤ) + M * h * (cN : ℤ) := by
          have hsum := add_le_add hpt hmhc
          simpa [mul_assoc, mul_comm, mul_left_comm, add_assoc, add_comm, add_left_comm] using hsum
        exact lt_of_lt_of_le hqbase hbase'
      have hle : p * (tN : ℤ) + M * h * (cN : ℤ) ≤ q := by
        calc
          p * (tN : ℤ) + M * h * (cN : ℤ) ≤
              (k : ℤ) * p * (tN : ℤ) + (l : ℤ) * M * h * (cN : ℤ) := hLower
          _ = q := hEqInt
      exact (not_lt_of_ge hle) hbase
  let d0 : ℕ := Nat.gcd xN yN
  let u0 : ℕ := xN / d0
  let v0 : ℕ := yN / d0
  let g0 : ℕ := qN / cN
  have hd0pos : 0 < d0 := by
    dsimp [d0]
    exact Nat.gcd_pos_of_pos_left _ hxNpos
  have hxd0 : d0 * u0 = xN := by
    dsimp [u0, d0]
    exact Nat.mul_div_cancel' (Nat.gcd_dvd_left _ _)
  have hyd0 : d0 * v0 = yN := by
    dsimp [v0, d0]
    exact Nat.mul_div_cancel' (Nat.gcd_dvd_right _ _)
  have hgd0 : (d0 : ℤ) = R.d := by simpa [d0] using hRdCast
  have hgu0 : (u0 : ℤ) = R.u := by simpa [u0, d0] using hUCastR
  have hgv0 : (v0 : ℤ) = R.v := by simpa [v0, d0] using hVCastR
  have hgr0 : (g0 : ℤ) = (rN : ℤ) := by
    dsimp [g0]
    simp [rN, ht_one]
  have hEqNat :
      k * u0 + l * v0 = g0 - 2 * u0 * v0 * (d0 - 1) := by
    have he := hEqR
    rw [← hgu0, ← hgv0, ← hgd0, ← hGABr] at he
    have hr : rN = g0 := by
      dsimp [rN, g0]
      rw [ht_one]
      simp
    rw [hr] at he
    have hcastsub : ((d0 - 1 : ℕ) : ℤ) = (d0 : ℤ) - 1 := by
      rw [Nat.cast_sub (by omega : 1 ≤ d0)]
      norm_num
    have he' := he
    rw [← hcastsub] at he'
    have htermI' :
        (0 : ℤ) ≤ (g0 : ℤ) -
          2 * (u0 : ℤ) * (v0 : ℤ) * ((d0 - 1 : ℕ) : ℤ) := by
      rw [← he']
      positivity
    have htermI :
        (0 : ℤ) ≤ (g0 : ℤ) -
          (2 * u0 * v0 * (d0 - 1) : ℕ) := by
      simpa only [Nat.cast_mul, Nat.cast_ofNat] using htermI'
    have htermN : 2 * u0 * v0 * (d0 - 1) ≤ g0 := by
      apply (Int.ofNat_le).mp
      linarith only [htermI]
    exact_mod_cast he'
  have heN_one : eN = MN := by
    dsimp [eN]
    rw [ht_one]
    simp
  have hyN_one : yN = MN * hN := by
    dsimp [yN]
    rw [heN_one]
  have hd0_mul_h : d0 ∣ MN * hN := by
    rw [← hyN_one]
    exact Nat.gcd_dvd_right _ _
  have hcopd0h : Nat.Coprime d0 hN := by
    exact Nat.Coprime.of_dvd_left (Nat.gcd_dvd_left _ _) hxCopHN
  have hd0MN : d0 ∣ MN := hcopd0h.dvd_of_dvd_mul_right hd0_mul_h
  obtain ⟨r0, hr0n, hd0pow⟩ :=
    (Nat.dvd_prime_pow Nat.prime_two).1 (by simpa [hMpow] using hd0MN)
  let m0 : ℕ := MN / d0
  have hdm0 : d0 * m0 = MN := by
    dsimp [m0]
    exact Nat.mul_div_cancel' hd0MN
  have hv0_mh : v0 = m0 * hN := by
    apply Nat.eq_of_mul_eq_mul_left hd0pos
    calc
      d0 * v0 = yN := hyd0
      _ = MN * hN := hyN_one
      _ = d0 * (m0 * hN) := by
        rw [← hdm0]
        ring
  let a0 : ℕ := DN / cN
  have hca0 : cN * a0 = DN := by
    dsimp [a0]
    exact Nat.mul_div_cancel' hcDN
  have hDNform : DN = 2 * d0 * m0 - 1 := by
    dsimp [DN]
    rw [← hdm0]
    ring_nf
  have hcg0 : cN * g0 = qN := by
    dsimp [g0]
    exact Nat.mul_div_cancel' hcQN
  have hpN_expand : pN = cN * d0 * u0 := by
    calc
      pN = cN * xN := hcMul.symm
      _ = cN * (d0 * u0) := by
        exact (congrArg (fun z => cN * z) hxd0).symm
      _ = cN * d0 * u0 := by ring
  have hqN_expand : qN = cN * d0 * u0 + (2 * d0 * m0 - 1) * hN := by
    calc
      qN = pN + DN * hN := hqNrel
      _ = cN * d0 * u0 + DN * hN := by rw [hpN_expand]
      _ = cN * d0 * u0 + (2 * d0 * m0 - 1) * hN := by rw [hDNform]
  have hDformCa : 2 * d0 * m0 - 1 = cN * a0 := by
    rw [← hDNform, hca0]
  have hg0_expand : g0 = d0 * u0 + a0 * hN := by
    apply Nat.eq_of_mul_eq_mul_left hcpos
    calc
      cN * g0 = qN := hcg0
      _ = cN * d0 * u0 + (2 * d0 * m0 - 1) * hN := hqN_expand
      _ = cN * (d0 * u0 + a0 * hN) := by rw [hDformCa]; ring
  have hyNpos : 0 < yN := by
    have hz : (0 : ℤ) < (yN : ℤ) := by rw [hRyCast]; exact hy
    exact_mod_cast hz
  have hv0pos : 0 < v0 := by
    apply Nat.pos_of_mul_pos_left
    rw [hyd0]
    exact hyNpos
  have hu0pos : 0 < u0 := by
    apply Nat.pos_of_mul_pos_left
    rw [hxd0]
    exact hxNpos
  have htermN0 : 2 * u0 * v0 * (d0 - 1) ≤ g0 := by
    by_contra hnot
    have hgt : g0 < 2 * u0 * v0 * (d0 - 1) := lt_of_not_ge hnot
    have hz : g0 - 2 * u0 * v0 * (d0 - 1) = 0 :=
      Nat.sub_eq_zero_of_le hgt.le
    have hpos : 0 < k * u0 + l * v0 := by
      exact Nat.add_pos_left (Nat.mul_pos hk (by positivity)) _
    rw [hz] at hEqNat
    omega
  have hEqAdd :
      g0 = 2 * u0 * v0 * (d0 - 1) + (k * u0 + l * v0) :=
    (Nat.sub_eq_iff_eq_add' htermN0).mp hEqNat.symm
  have hEqVars :
      k * u0 + l * (m0 * hN) + 2 * u0 * (m0 * hN) * (d0 - 1) =
        d0 * u0 + a0 * hN := by
    rw [hg0_expand, hv0_mh] at hEqAdd
    calc
      _ = 2 * u0 * (m0 * hN) * (d0 - 1) + (k * u0 + l * (m0 * hN)) := by
        ac_rfl
      _ = d0 * u0 + a0 * hN := hEqAdd.symm
  have hineqN : DN * hN ≤ 2 * pN := by
    have hz : (DN * hN : ℤ) ≤ (2 * pN : ℕ) := by
      push_cast
      rw [hDNcast, hhNcast, hpNcast]
      exact hineq
    exact_mod_cast hz
  have hineqVars : (2 * d0 * m0 - 1) * hN ≤ 2 * cN * d0 * u0 := by
    rw [hDNform, hpN_expand] at hineqN
    simpa [mul_assoc] using hineqN
  have hcaI : (cN : ℤ) * (a0 : ℤ) =
      2 * (d0 : ℤ) * (m0 : ℤ) - 1 := by
    have hsub : ((2 * d0 * m0 - 1 : ℕ) : ℤ) =
        2 * (d0 : ℤ) * (m0 : ℤ) - 1 := by
      rw [Nat.cast_sub (by omega : 1 ≤ 2 * d0 * m0)]
      norm_num
    calc
      (cN : ℤ) * (a0 : ℤ) = (cN * a0 : ℕ) := by norm_num
      _ = (2 * d0 * m0 - 1 : ℕ) := hDformCa ▸ rfl
      _ = _ := hsub
  have hboundA : a0 * hN ≤ 2 * d0 * u0 := by
    apply Nat.le_of_mul_le_mul_left (c := cN)
    · calc
        cN * (a0 * hN) = (cN * a0) * hN := by ring
        _ = (2 * d0 * m0 - 1) * hN := by rw [hca0, hDNform]
        _ ≤ 2 * cN * d0 * u0 := hineqVars
        _ = cN * (2 * d0 * u0) := by ring
    · exact hcpos
  have hbaseNat :
      u0 + m0 * hN + 2 * u0 * (m0 * hN) * (d0 - 1) ≤
        d0 * u0 + a0 * hN := by
    have hu_le : u0 ≤ k * u0 := by
      calc u0 = 1 * u0 := by ring
        _ ≤ k * u0 := Nat.mul_le_mul_right u0 (by omega)
    have hv_le : m0 * hN ≤ l * (m0 * hN) := by
      calc m0 * hN = 1 * (m0 * hN) := by ring
        _ ≤ l * (m0 * hN) := Nat.mul_le_mul_right _ (by omega)
    calc
      _ ≤ k * u0 + l * (m0 * hN) + 2 * u0 * (m0 * hN) * (d0 - 1) := by omega
      _ = _ := hEqVars
  have hnecessaryI :
      ((d0 : ℤ) - 1) * (u0 : ℤ) *
          (2 * (m0 : ℤ) * (hN : ℤ) - 1) ≤
        (hN : ℤ) * ((a0 : ℤ) - (m0 : ℤ)) := by
    have hbaseI :
        (u0 : ℤ) + (m0 : ℤ) * (hN : ℤ) +
            2 * (u0 : ℤ) * ((m0 : ℤ) * (hN : ℤ)) * ((d0 - 1 : ℕ) : ℤ) ≤
          (d0 : ℤ) * (u0 : ℤ) + (a0 : ℤ) * (hN : ℤ) := by
      exact_mod_cast hbaseNat
    have hdsubI : ((d0 - 1 : ℕ) : ℤ) = (d0 : ℤ) - 1 := by
      rw [Nat.cast_sub (by omega : 1 ≤ d0)]
      norm_num
    rw [hdsubI] at hbaseI
    nlinarith only [hbaseI]
  have hNpos : 0 < hN := by
    have hz : (0 : ℤ) < (hN : ℤ) := by rw [hhNcast]; exact hh
    exact_mod_cast hz
  have hm0pos : 0 < m0 := by
    apply Nat.pos_of_mul_pos_left
    rw [hdm0]
    exact hMNpos
  have ha0pos : 0 < a0 := by
    apply Nat.pos_of_mul_pos_left
    rw [hca0]
    dsimp [DN]
    omega
  have hdm_cases : d0 = 1 ∨ 2 ≤ d0 := by omega
  rcases hdm_cases with hd1 | hd2
  · have hmaI : (m0 : ℤ) ≤ (a0 : ℤ) := by
      have hnI : (0 : ℤ) < (hN : ℤ) := by exact_mod_cast hNpos
      have hi := hnecessaryI
      rw [hd1] at hi
      norm_num at hi
      nlinarith only [hi, hnI]
    have hma : m0 ≤ a0 := by exact_mod_cast hmaI
    have hcaD1 : cN * a0 = 2 * m0 - 1 := by
      calc
        cN * a0 = DN := hca0
        _ = 2 * m0 - 1 := by rw [hDNform, hd1]
    have hcnot2 : ¬ 2 ≤ cN := by
      intro hc2
      have hc3 : 3 ≤ cN := by omega
      have h3a : 3 * a0 ≤ cN * a0 := Nat.mul_le_mul_right a0 hc3
      rw [hcaD1] at h3a
      have h3m : 3 * m0 ≤ 3 * a0 := Nat.mul_le_mul_left 3 hma
      omega
    have hc1 : cN = 1 := by omega
    have haD1 : a0 = 2 * m0 - 1 := by
      have := hcaD1
      simp [hc1] at this
      exact this
    have hm2 : 2 ≤ m0 := by
      have hdm := hdm0
      rw [hd1] at hdm
      omega
    have hEqD1 := hEqVars
    simp [hd1, haD1] at hEqD1
    have hineqD1 := hineqVars
    simp [hd1, hc1] at hineqD1
    have hsubm : ((2 * m0 - 1 : ℕ) : ℤ) = 2 * (m0 : ℤ) - 1 := by
      rw [Nat.cast_sub (by omega : 1 ≤ 2 * m0)]
      norm_num
    have hEqD1I :
        (k : ℤ) * (u0 : ℤ) + (l : ℤ) * (m0 : ℤ) * (hN : ℤ) =
          (u0 : ℤ) + (2 * (m0 : ℤ) - 1) * (hN : ℤ) := by
      have hz : ((k * u0 + l * (m0 * hN) : ℕ) : ℤ) =
          ((u0 + (2 * m0 - 1) * hN : ℕ) : ℤ) := by
        exact_mod_cast hEqD1
      push_cast at hz
      rw [hsubm] at hz
      simpa [mul_assoc] using hz
    have hineqD1I :
        (2 * (m0 : ℤ) - 1) * (hN : ℤ) ≤ 2 * (u0 : ℤ) := by
      have hz : (((2 * m0 - 1) * hN : ℕ) : ℤ) ≤ ((2 * u0 : ℕ) : ℤ) := by
        exact_mod_cast hineqD1
      push_cast at hz
      rw [hsubm] at hz
      simpa using hz
    have hfalse : False := by
      apply rigidNoDOne (m := (m0 : ℤ)) (u := (u0 : ℤ))
        (h := (hN : ℤ)) (k := (k : ℤ)) (l := (l : ℤ))
      · exact_mod_cast hm2
      · exact_mod_cast hu0pos
      · exact_mod_cast hNpos
      · exact_mod_cast hk
      · exact_mod_cast hl
      · exact hEqD1I
      · exact hineqD1I
    exact hfalse.elim
  · have hm_cases : m0 = 1 ∨ 2 ≤ m0 := by omega
    rcases hm_cases with hm1 | hm2
    · have hdm_eq : d0 = MN := by
        have hdm := hdm0
        rw [hm1] at hdm
        simpa using hdm
      have hcaFinal :
          (cN : ℤ) * (a0 : ℤ) = 2 * (d0 : ℤ) - 1 := by
        simpa [hm1] using hcaI
      have hnecessaryFinalI :
          ((d0 : ℤ) - 1) * (u0 : ℤ) * (2 * (hN : ℤ) - 1) ≤
            (hN : ℤ) * ((a0 : ℤ) - 1) := by
        simpa [hm1] using hnecessaryI
      have hc1 : cN = 1 := by
        by_contra hcne
        have hc3 : 3 ≤ cN := by omega
        have hfalse : False := by
          apply rigidFinalCOne (c := (cN : ℤ)) (d := (d0 : ℤ))
            (u := (u0 : ℤ)) (h := (hN : ℤ)) (a := (a0 : ℤ))
          · exact_mod_cast hc3
          · exact_mod_cast hd2
          · exact_mod_cast hu0pos
          · exact_mod_cast hNpos
          · exact hcaFinal
          · exact hnecessaryFinalI
        exact hfalse.elim
      have haFinal : a0 = 2 * d0 - 1 := by
        calc
          a0 = DN := by simpa [hc1] using hca0
          _ = 2 * d0 - 1 := by rw [hDNform, hm1]; simp
      have haFinalI : (a0 : ℤ) = 2 * (d0 : ℤ) - 1 := by
        have h := hcaFinal
        rw [hc1] at h
        norm_num at h
        exact h
      have hnecessaryShape :
          ((d0 : ℤ) - 1) * (u0 : ℤ) * (2 * (hN : ℤ) - 1) ≤
            (hN : ℤ) * (2 * (d0 : ℤ) - 2) := by
        have htmp := hnecessaryFinalI
        rw [haFinalI] at htmp
        convert htmp using 1; ring
      have hineqFinalN := hineqVars
      simp [hm1, hc1] at hineqFinalN
      have hsubd : ((2 * d0 - 1 : ℕ) : ℤ) =
          2 * (d0 : ℤ) - 1 := by
        rw [Nat.cast_sub (by omega : 1 ≤ 2 * d0)]
        norm_num
      have hineqFinalI :
          (2 * (d0 : ℤ) - 1) * (hN : ℤ) ≤
            2 * (d0 : ℤ) * (u0 : ℤ) := by
        have hz : (((2 * d0 - 1) * hN : ℕ) : ℤ) ≤
            ((2 * d0 * u0 : ℕ) : ℤ) := by
          exact_mod_cast hineqFinalN
        push_cast at hz
        rw [hsubd] at hz
        simpa [mul_assoc] using hz
      have hne_u_h : (u0 : ℤ) ≠ (hN : ℤ) := by
        intro huh
        have huhN : u0 = hN := by exact_mod_cast huh
        have hpEqN : pN = MN * hN := by
          rw [hpN_expand, hc1, hdm_eq, huhN]
          simp
        have hpEqI : p = M * h := by
          have hz := congrArg (fun z : ℕ => (z : ℤ)) hpEqN
          push_cast at hz
          rw [hpNcast, hMNcast, hhNcast] at hz
          exact hz
        exact hne hpEqI
      have hshape := rigidFinalShape (d := (d0 : ℤ)) (u := (u0 : ℤ))
        (h := (hN : ℤ))
        (by exact_mod_cast hd2)
        (by exact_mod_cast hu0pos)
        (by exact_mod_cast hNpos)
        hne_u_h hineqFinalI hnecessaryShape
      have hhFinal : hN = 1 := by exact_mod_cast hshape.1
      have huFinal : u0 = 2 := by exact_mod_cast hshape.2
      have hpFinal : p = 2 * M := by
        have hpEqN : pN = 2 * MN := by
          calc
            pN = cN * d0 * u0 := hpN_expand
            _ = 2 * MN := by rw [hc1, huFinal, hdm_eq]; ring
        have hz := congrArg (fun z : ℕ => (z : ℤ)) hpEqN
        push_cast at hz
        rw [hpNcast, hMNcast] at hz
        exact hz
      have hhFinalI : h = 1 := by
        have hz := congrArg (fun z : ℕ => (z : ℤ)) hhFinal
        push_cast at hz
        rw [hhNcast] at hz
        exact hz
      have hqFinal : q = 4 * M - 1 := by
        rw [hrel, hpFinal, hhFinalI]
        ring
      exact Prod.ext hpFinal (Prod.ext hhFinalI hqFinal)
    · have hboundI :
          (2 * (d0 : ℤ) * (m0 : ℤ) - 1) * (hN : ℤ) ≤
            2 * (cN : ℤ) * (d0 : ℤ) * (u0 : ℤ) := by
        have hboundI0 :
            (((2 * d0 * m0 - 1) * hN : ℕ) : ℤ) ≤
              ((2 * cN * d0 * u0 : ℕ) : ℤ) := by
          exact_mod_cast hineqVars
        have hsub : ((2 * d0 * m0 - 1 : ℕ) : ℤ) =
            2 * (d0 : ℤ) * (m0 : ℤ) - 1 := by
          rw [Nat.cast_sub (by omega : 1 ≤ 2 * d0 * m0)]
          norm_num
        rw [Nat.cast_mul, hsub] at hboundI0
        simpa [Nat.cast_mul] using hboundI0
      have hnecessaryI' :
          ((d0 : ℤ) - 1) * (u0 : ℤ) *
              (2 * (m0 : ℤ) * (hN : ℤ) - 1) ≤
            (hN : ℤ) * ((a0 : ℤ) - (m0 : ℤ)) := hnecessaryI
      have hfalse : False := by
        apply rigidNoProperDivisor (c := (cN : ℤ)) (d := (d0 : ℤ))
          (e := (m0 : ℤ)) (u := (u0 : ℤ)) (h := (hN : ℤ)) (a := (a0 : ℤ))
        · exact_mod_cast hcpos
        · exact_mod_cast hd2
        · exact_mod_cast hm2
        · exact_mod_cast hNpos
        · exact hcaI
        · exact hboundI
        · exact hnecessaryI'
      exact hfalse.elim

end Fraenkel
