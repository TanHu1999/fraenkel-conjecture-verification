import Fraenkel.Analytic.Rigidity
import Fraenkel.Fourier.MinimumLayer

namespace Fraenkel

/-- The maximum selected numerator. -/
-- zpi: thm-one-third-theorem
noncomputable def maximumNumerator {m : ℕ}
    (P : RationalBeattyPartition m) (p : Fin m → ℤ) : ℤ :=
  (Finset.univ.image p).max'
    (Finset.image_nonempty.mpr
      ⟨(⟨0, P.nonempty⟩ : Fin m), Finset.mem_univ _⟩)

/-- One-third theorem: a primitive rational Beatty partition with distinct
moduli has a numerator at least one third of its common denominator. -/
-- zpi: thm-one-third-theorem
theorem oneThirdTheorem
    {m : ℕ} (P : RationalBeattyPartition m) (q : ℤ)
    (p r : Fin m → ℤ)
    (hprim : PrimitiveRationalBeattyPartition P q p r)
    (hdistinct : Function.Injective P.moduli) :
    (q : ℝ) / 3 ≤ (maximumNumerator P p : ℝ) := by
  by_contra hnot
  have hmax_lt : (maximumNumerator P p : ℝ) < (q : ℝ) / 3 :=
    lt_of_not_ge hnot
  have hsub : ∀ i, 3 * p i < q := by
    intro i
    have hple : p i ≤ maximumNumerator P p := by
      unfold maximumNumerator
      apply Finset.le_max'
      exact Finset.mem_image.mpr ⟨i, Finset.mem_univ _, rfl⟩
    have hpleR : (p i : ℝ) ≤ (maximumNumerator P p : ℝ) := by
      exact_mod_cast hple
    have hltR : (3 : ℝ) * (p i : ℝ) < (q : ℝ) := by
      nlinarith
    exact_mod_cast hltR
  let Q : ℤ := minimumLayerModulus P q p
  let A : Finset ℤ := minimumGCDLayer P q p
  have hAne : A.Nonempty := by
    dsimp [A, minimumGCDLayer]
    have hI : (Finset.univ.image (fun i : Fin m => layerGcd q p i)).Nonempty := by
      exact Finset.image_nonempty.mpr
        ⟨(⟨0, P.nonempty⟩ : Fin m), Finset.mem_univ _⟩
    have hgmem : minimumLayerGcd P q p ∈
        Finset.univ.image (fun i : Fin m => layerGcd q p i) := by
      exact Finset.min'_mem _ hI
    obtain ⟨i, hi, higeq⟩ := Finset.mem_image.mp hgmem
    refine ⟨p i / minimumLayerGcd P q p, ?_⟩
    exact Finset.mem_image.mpr ⟨i,
      Finset.mem_filter.mpr ⟨Finset.mem_univ _, higeq⟩, rfl⟩
  have hlayer :
      UnitRepresentatives Q A ∧
        (∀ a ∈ A, 3 * a < Q) ∧
        (∑ a ∈ A, a) ≤ Q ∧
        (∀ a ∈ A, 1 ≤ inverseSineRowMass Q A a) := by
    simpa [Q, A] using
      (minimumGCDFourierLayer P q p r hprim hdistinct hsub)
  let s : ℤ := A.min' hAne
  have hs_mem : s ∈ A := by
    exact Finset.min'_mem A hAne
  have hs_min : ∀ a ∈ A, s ≤ a := by
    intro a ha
    exact Finset.min'_le A a ha
  have hQ : 4 ≤ Q := by
    have hs_pos : 0 < s := hlayer.1.1 s hs_mem |>.1
    have hs_upper := hlayer.2.1 s hs_mem
    omega
  let D : MinimumRowSlackData :=
    { Q := Q
      A := A
      hQ := hQ
      hA := hlayer.1
      hA_upper := hlayer.2.1
      hA_sum := hlayer.2.2.1
      s := s
      hs_mem := hs_mem
      hs_min := hs_min }
  obtain ⟨a, haA, hdef⟩ := subcriticalInverseSineRigidity D
  have hdef' : inverseSineRowMass Q A a < 1 := by
    simpa [D] using hdef
  have hpass : 1 ≤ inverseSineRowMass Q A a := hlayer.2.2.2 a haA
  exact (not_lt_of_ge hpass) hdef'

end Fraenkel
