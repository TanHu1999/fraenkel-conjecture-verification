import Mathlib.Data.Real.Archimedean
import Mathlib.NumberTheory.Real.Irrational

/-! Graham's one-sided objects and rationality borrowing. They are kept distinct
from the package's bi-infinite Beatty sets. Positive indices are integers `n > 0`.
-/

namespace Fraenkel.External.Graham1973

/-- Graham's one-sided Beatty set, on its intended domain `0 < α`. -/
-- zpi: external/def-one-sided-beatty-sequence
noncomputable def oneSidedBeattySequence (α β : ℝ) : Set ℤ :=
  {z | ∃ n : ℤ, 0 < n ∧ ⌊(n : ℝ) * α + β⌋ = z}

-- zpi: external/def-one-sided-beatty-sequence
theorem oneSidedBeattySequence_spec (α β : ℝ) (_hα : 0 < α) :
    oneSidedBeattySequence α β =
      {z : ℤ | ∃ n : ℤ, 0 < n ∧ ⌊(n : ℝ) * α + β⌋ = z} :=
  rfl

/-- Every sufficiently large integer is in exactly one member of the family. -/
-- zpi: external/def-eventual-covering-family
def EventualCoveringFamily {m : ℕ} (α β : Fin m → ℝ) : Prop :=
  ∃ N : ℤ, ∀ z : ℤ, N ≤ z → ∃! i : Fin m, z ∈ oneSidedBeattySequence (α i) (β i)

-- zpi: external/def-eventual-covering-family
theorem eventualCoveringFamily_spec {m : ℕ} (α β : Fin m → ℝ)
    (_hα : ∀ i, 0 < α i) :
    EventualCoveringFamily α β ↔
      ∃ N : ℤ, ∀ z : ℤ, N ≤ z → ∃! i : Fin m, z ∈ oneSidedBeattySequence (α i) (β i) :=
  Iff.rfl

/-- Source: R. L. Graham, *Covering the Positive Integers by Disjoint Sets of
 the Form {[n alpha + beta] n = 1, 2, ...}*, J. Combin. Theory A 15 (1973),
 354--358, Corollary. Recorded in the package as the irrational ECF formulation,
 not silently replaced by the local bi-infinite rationality conclusion. -/
-- zpi: external/thm-rationality-of-distinct-exact-beatty-covers
axiom irrationalEventualCoverHasRepeatedModuli {m : ℕ} (α β : Fin m → ℝ)
    (hm : 3 ≤ m) (hα : ∀ i, 0 < α i) (hcover : EventualCoveringFamily α β)
    (hirr : ∃ i, Irrational (α i)) :
    ∃ i j : Fin m, i ≠ j ∧ α i = α j

end Fraenkel.External.Graham1973
