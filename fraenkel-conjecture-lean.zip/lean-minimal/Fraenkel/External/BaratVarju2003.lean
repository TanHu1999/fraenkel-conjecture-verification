import Fraenkel.External.Tijdeman2000

namespace Fraenkel.External.BaratVarju2003

/-- The one-sided positive-integer partition condition used by the source. -/
-- zpi: external/thm-fraenkel-conjecture-for-seven-sequences
def PositiveBeattyPartition (α β : Fin 7 → ℝ) : Prop :=
  (∀ z : ℤ, 0 < z ↔ ∃ i : Fin 7,
    z ∈ Fraenkel.External.Graham1973.oneSidedBeattySequence (α i) (β i)) ∧
  (∀ z : ℤ, ∀ i j : Fin 7,
    z ∈ Fraenkel.External.Graham1973.oneSidedBeattySequence (α i) (β i) →
    z ∈ Fraenkel.External.Graham1973.oneSidedBeattySequence (α j) (β j) →
    i = j)

/-- Janos Barat and Peter P. Varju, *Partitioning the Positive Integers to
Seven Beatty Sequences*, Indagationes Mathematicae 14 (2003), 149--161. -/
-- zpi: external/thm-fraenkel-conjecture-for-seven-sequences
axiom fraenkelConjectureForSevenSequences
    (α β : Fin 7 → ℝ)
    (hα : ∀ i, 1 < α i)
    (hdistinct : Function.Injective α)
    (hpartition : PositiveBeattyPartition α β) :
    Set.range α =
      Set.range (fun j : Fin 7 =>
        ((2 : ℝ) ^ 7 - 1) / (2 : ℝ) ^ j.val)

end Fraenkel.External.BaratVarju2003
