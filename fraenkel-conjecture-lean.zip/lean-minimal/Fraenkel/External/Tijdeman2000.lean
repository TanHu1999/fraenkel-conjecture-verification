import Fraenkel.External.Graham1973

namespace Fraenkel.External.Tijdeman2000

/-- A one-sided partition of the positive integers, in the source formulation. -/
-- zpi: external/thm-fraenkel-conjecture-for-six-sequences
def PositiveBeattyPartition {m : ℕ} (α β : Fin m → ℝ) : Prop :=
  (∀ z : ℤ, 0 < z ↔ ∃ i : Fin m,
    z ∈ Fraenkel.External.Graham1973.oneSidedBeattySequence (α i) (β i)) ∧
  (∀ z : ℤ, ∀ i j : Fin m,
    z ∈ Fraenkel.External.Graham1973.oneSidedBeattySequence (α i) (β i) →
    z ∈ Fraenkel.External.Graham1973.oneSidedBeattySequence (α j) (β j) →
    i = j)

/-- R. Tijdeman, *Fraenkel's Conjecture for Six Sequences*, Discrete
Mathematics 222 (2000), 223--234. The borrowed statement retains the source's
one-sided positive-integer formulation for every `3 ≤ m ≤ 6`. -/
-- zpi: external/thm-fraenkel-conjecture-for-six-sequences
axiom fraenkelConjectureForSixSequences
    {m : ℕ} (hm : 3 ≤ m) (hm6 : m ≤ 6)
    (α β : Fin m → ℝ)
    (hα : ∀ i, 1 < α i)
    (hdistinct : Function.Injective α)
    (hpartition : PositiveBeattyPartition α β) :
    Set.range α =
      Set.range (fun j : Fin m =>
        ((2 : ℝ) ^ m - 1) / (2 : ℝ) ^ j.val)

end Fraenkel.External.Tijdeman2000
