import Mathlib.Data.Finset.Card
import Mathlib.Data.Int.Interval
import Mathlib.Data.Int.GCD
import Mathlib.Tactic

namespace Fraenkel.External.Paparella2013

/-- An integer modulus greater than one and exactly `h` distinct integers whose
residues are pairwise distinct. A `Finset` records distinct integers, not a list
that might repeat the same integer. -/
-- zpi: external/def-complete-residue-system
def CompleteResidueSystem (h : ℤ) (R : Finset ℤ) : Prop :=
  1 < h ∧ R.card = h.toNat ∧ Set.InjOn (fun a : ℤ => a % h) (R : Set ℤ)

-- zpi: external/def-complete-residue-system
theorem completeResidueSystem_spec (h : ℤ) (R : Finset ℤ)
    (hh : 1 < h) (hcard : R.card = h.toNat) :
    CompleteResidueSystem h R ↔ Set.InjOn (fun a : ℤ => a % h) (R : Set ℤ) := by
  simp [CompleteResidueSystem, hh, hcard]

/-- The equivalence with surjectivity asserted in the definition entry. -/
-- zpi: external/def-complete-residue-system
theorem completeResidueSystem_iff_surjective (h : ℤ) (R : Finset ℤ)
    (hh : 1 < h) (hcard : R.card = h.toNat) :
    CompleteResidueSystem h R ↔
      Set.SurjOn (fun a : ℤ => a % h) (R : Set ℤ) (Finset.Ico 0 h : Set ℤ) := by
  rw [completeResidueSystem_spec h R hh hcard]
  have hm : Set.MapsTo (fun a : ℤ => a % h) (R : Set ℤ) (Finset.Ico 0 h : Set ℤ) := by
    intro a _
    exact Finset.mem_Ico.mpr ⟨Int.emod_nonneg a (by omega), Int.emod_lt_of_pos a (by omega)⟩
  have hc : (Finset.Ico (0 : ℤ) h).card = R.card := by simp [Int.card_Ico, hcard]
  exact ⟨fun hi => Finset.surjOn_of_injOn_of_card_le _ hm hi hc.le,
    fun hs => Finset.injOn_of_surjOn_of_card_le _ hm hs hc.ge⟩

/-- The standard residues form a complete residue system. -/
-- zpi: external/def-complete-residue-system
theorem standardResidues_complete (h : ℤ) (hh : 1 < h) :
    CompleteResidueSystem h (Finset.Ico 0 h) := by
  refine ⟨hh, by simp [Int.card_Ico], ?_⟩
  intro a ha b hb hab
  have ha' := Finset.mem_Ico.mp ha
  have hb' := Finset.mem_Ico.mp hb
  simpa [Int.emod_eq_of_lt ha'.1 ha'.2, Int.emod_eq_of_lt hb'.1 hb'.2] using hab

/-- Source: Pietro Paparella, *Complete Residue Systems: A Primer and an
Application*, Advances in Algebra 6(1) (2013), Theorem 4. This records the full
if-and-only-if, including arbitrary integer multipliers. -/
-- zpi: external/thm-coprime-multiplication-preserves-complete-residue-systems
axiom coprimeMultiplicationPreservesCompleteResidueSystems
    (h p : ℤ) (R : Finset ℤ) (hR : CompleteResidueSystem h R) :
    CompleteResidueSystem h (R.image (fun a => p * a)) ↔ Int.gcd p h = 1

/-- The residue-reindexing consequence used by the package's normalization proof. -/
-- zpi: external/thm-coprime-multiplication-preserves-complete-residue-systems
theorem coprimeMul_residue_exists (h p x : ℤ) (hh : 1 < h) (hcop : Int.gcd p h = 1) :
    ∃ j : ℤ, 0 ≤ j ∧ j < h ∧ (p * j) % h = x % h := by
  have hR := (coprimeMultiplicationPreservesCompleteResidueSystems h p
    (Finset.Ico 0 h) (standardResidues_complete h hh)).mpr hcop
  have hs := (completeResidueSystem_iff_surjective h _ hh hR.2.1).mp hR
  have hx : x % h ∈ (Finset.Ico 0 h : Set ℤ) :=
    Finset.mem_Ico.mpr ⟨Int.emod_nonneg x (by omega), Int.emod_lt_of_pos x (by omega)⟩
  obtain ⟨a, ha, heq⟩ := hs hx
  obtain ⟨j, hj, rfl⟩ := Finset.mem_image.mp ha
  exact ⟨j, (Finset.mem_Ico.mp hj).1, (Finset.mem_Ico.mp hj).2, heq⟩

end Fraenkel.External.Paparella2013
