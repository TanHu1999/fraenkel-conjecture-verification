import Fraenkel.Beatty.Basic
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Data.ZMod.Basic

namespace Fraenkel.External.GrahamObryant2005

open scoped BigOperators Classical

/-- The period multiplicity of the source multiset
`{⌊n q/p+r⌋ : n ∈ ℤ}` on canonical residues. The `p>0` and `q>1`
hypotheses belong to the borrowed theorem; the definition is total. -/
-- zpi: external/thm-fourier-transform-of-rational-beatty-set
noncomputable def rationalBeattyPeriodMultiplicity
    (p q r : ℤ) (x : ZMod q.natAbs) : ℕ :=
  (Finset.univ : Finset (Fin p.natAbs)).filter
    (fun n =>
      ((⌊(n.val : ℝ) * (q : ℝ) / (p : ℝ) + (r : ℝ)⌋ : ℤ) :
        ZMod q.natAbs) = x) |>.card

/-- The source's Fourier transform, on canonical representatives. -/
-- zpi: external/thm-fourier-transform-of-rational-beatty-set
noncomputable def rationalBeattyFourierTransform
    (p q r : ℤ) (j : ZMod q.natAbs) : ℂ :=
  ∑ x : Fin q.natAbs,
    (rationalBeattyPeriodMultiplicity p q r
      ((x.val : ℕ) : ZMod q.natAbs) : ℂ) *
      Complex.exp
        (-2 * Complex.ofReal Real.pi * Complex.I *
          (Complex.ofReal ((j.val * x.val : ℕ) : ℝ) /
            Complex.ofReal (q : ℝ)))

/-- `ω^k = exp(2π i k/q)` in the source formula. -/
-- zpi: external/thm-fourier-transform-of-rational-beatty-set
noncomputable def rationalBeattyOmegaPower (q k : ℤ) : ℂ :=
  Complex.exp (2 * Complex.ofReal Real.pi * Complex.I *
    (Complex.ofReal k / Complex.ofReal q))

/-- R. L. Graham and K. O'Bryant, *A Discrete Fourier Kernel and Fraenkel's
Tiling Conjecture*, Acta Arithmetica 118 (2005), Theorem 1.1. This records the
source's full multiset domain `p>0`, `q>1`, rather than adding `p<q`. -/
-- zpi: external/thm-fourier-transform-of-rational-beatty-set
axiom fourierTransformOfRationalBeattySet
    (p q r barp : ℤ) (hp : 0 < p) (hq : 1 < q)
    (hbar : q ∣ p * barp - (Int.gcd p q : ℤ)) :
    rationalBeattyFourierTransform p q r 0 = (p : ℂ) ∧
      (∀ j : ZMod q.natAbs, 0 < j.val →
        rationalBeattyFourierTransform p q r j =
          if (Int.gcd p q : ℤ) ∣ (j.val : ℤ) then
            (Int.gcd p q : ℂ) *
              (1 - rationalBeattyOmegaPower q (j.val : ℤ)) /
              (1 - rationalBeattyOmegaPower q ((j.val : ℤ) * barp)) *
              rationalBeattyOmegaPower q (-((j.val : ℤ) * r))
          else 0) ∧
      (∀ j : ZMod q.natAbs, 0 < j.val →
        ‖rationalBeattyFourierTransform p q r j‖ =
          if (Int.gcd p q : ℤ) ∣ (j.val : ℤ) then
            ‖(Int.gcd p q : ℂ) *
              (Real.sin (Real.pi * (j.val : ℝ) / (q : ℝ)) /
                Real.sin (Real.pi *
                  (((j.val : ℤ) * barp : ℤ) : ℝ) / (q : ℝ)))‖
          else 0)

end Fraenkel.External.GrahamObryant2005
