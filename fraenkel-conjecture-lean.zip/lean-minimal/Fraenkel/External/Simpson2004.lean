import Fraenkel.Beatty.Basic
import Mathlib.Data.Int.GCD

namespace Fraenkel.External.Simpson2004

/-- Source notation for a reduced rational Beatty modulus. -/
-- zpi: external/thm-disjointness-criterion-for-two-rational-beatty-sequences
noncomputable def rationalBeattySequence (a b : ℕ) (β : ℝ) : Set ℤ :=
  biInfiniteBeattySequence ((a : ℝ) / (b : ℝ)) β

/-- Jamie Simpson, *Disjoint Beatty Sequences*, Integers 4 (2004), Theorem 8.
The source uses real shifts and reduced positive rational moduli. The right side
uses the source's `gcd` and residual denominator notation explicitly. -/
-- zpi: external/thm-disjointness-criterion-for-two-rational-beatty-sequences
axiom disjointRationalBeattyCriterion
    (a₁ b₁ a₂ b₂ : ℕ)
    (ha₁ : 0 < a₁) (hb₁ : 0 < b₁) (hc₁ : Nat.gcd a₁ b₁ = 1)
    (ha₂ : 0 < a₂) (hb₂ : 0 < b₂) (hc₂ : Nat.gcd a₂ b₂ = 1) :
    (∃ β₁ β₂ : ℝ, Disjoint (rationalBeattySequence a₁ b₁ β₁)
      (rationalBeattySequence a₂ b₂ β₂)) ↔
      ∃ x y : ℕ, 0 < x ∧ 0 < y ∧
        x * (b₁ / Nat.gcd b₁ b₂) + y * (b₂ / Nat.gcd b₁ b₂) =
          Nat.gcd a₁ a₂ -
            2 * (b₁ / Nat.gcd b₁ b₂) * (b₂ / Nat.gcd b₁ b₂) *
              (Nat.gcd b₁ b₂ - 1)

end Fraenkel.External.Simpson2004
