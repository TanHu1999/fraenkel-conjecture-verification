import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Basic

/-! Borrowings recorded by the package, not newly proved results. -/

open Filter
open scoped Topology

namespace Fraenkel.External.NistDlmf

/-- The punctured complex small-angle limit.
Source: NIST DLMF, Equation 4.17.1, as recorded by the external entry. -/
-- zpi: external/lem-sine-small-angle-limit
axiom sineSmallAngleLimit :
  Tendsto (fun z : ℂ => Complex.sin z / z) (𝓝[≠] (0 : ℂ)) (𝓝 (1 : ℂ))

/-- Euler's sine product, over positive integer indices.
Source: NIST DLMF, Equation 4.22.1, as recorded by the external entry. -/
-- zpi: external/thm-euler-product-for-sine
axiom eulerProductForSine (z : ℂ) :
  Complex.sin z = z * ∏' m : ℕ,
    (1 - z ^ 2 / (((m : ℂ) + 1) ^ 2 * (Real.pi : ℂ) ^ 2))

end Fraenkel.External.NistDlmf
