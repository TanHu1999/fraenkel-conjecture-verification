import Mathlib.Data.Real.Archimedean
import Mathlib.Data.Int.Interval

namespace Fraenkel.External.StonyBrook

/-- The finite set of integers in a real half-open interval. The membership
lemma below ensures that the counting axiom concerns the actual interval. -/
-- zpi: external/lem-integer-count-in-half-open-interval
noncomputable def integersInHalfOpenInterval (a b : ℝ) : Finset ℤ :=
  Finset.Ico ⌈a⌉ ⌈b⌉

-- zpi: external/lem-integer-count-in-half-open-interval
theorem mem_integersInHalfOpenInterval (a b : ℝ) (z : ℤ) :
    z ∈ integersInHalfOpenInterval a b ↔ a ≤ (z : ℝ) ∧ (z : ℝ) < b := by
  simp only [integersInHalfOpenInterval, Finset.mem_Ico, Int.ceil_le, Int.lt_ceil]

/-- Source: Stony Brook University, CSE 547 Discrete Mathematics, Lecture 11,
*Integers in the Intervals*. Both endpoints are real, with the right endpoint
excluded. The cardinal is cast to integers before the ceiling subtraction. -/
-- zpi: external/lem-integer-count-in-half-open-interval
axiom integerCountInHalfOpenInterval (a b : ℝ) (hab : a ≤ b) :
  ((integersInHalfOpenInterval a b).card : ℤ) = ⌈b⌉ - ⌈a⌉

end Fraenkel.External.StonyBrook
