import Mathlib.Data.Real.Archimedean

namespace Fraenkel.External.Algebrica

/-- Source: Algebrica, *Floor and Ceiling Functions*, translation and sum rules.
The two possible values are integer floors/ceilings of the real increment. -/
-- zpi: external/lem-floor-difference-is-floor-or-ceiling
axiom floorDifference (x y : ℝ) :
  ⌊x + y⌋ - ⌊x⌋ = ⌊y⌋ ∨ ⌊x + y⌋ - ⌊x⌋ = ⌈y⌉

end Fraenkel.External.Algebrica
