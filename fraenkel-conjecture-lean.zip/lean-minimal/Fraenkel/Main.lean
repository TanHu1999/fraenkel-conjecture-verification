import Fraenkel.Beatty.OneThird
import Fraenkel.External.Tijdeman2000
import Fraenkel.External.BaratVarju2003
import Fraenkel.MainProofScratch

namespace Fraenkel

/-- A bi-infinite Beatty partition of the integers. -/
-- zpi: prop-one-third-theorem-and-known-cases-imply-fraenkel-conjecture
def BiInfiniteBeattyPartition {m : ℕ} (α β : Fin m → ℝ) : Prop :=
  ∀ z : ℤ, ∃! i : Fin m,
    z ∈ biInfiniteBeattySequence (α i) (β i)

/-- The target set of moduli in the binary Fraenkel family. -/
-- zpi: prop-one-third-theorem-and-known-cases-imply-fraenkel-conjecture
def FraenkelModuli (m : ℕ) : Set ℝ :=
  Set.range (fun j : Fin m => ((2 : ℝ) ^ m - 1) / (2 : ℝ) ^ j.val)

/-- The one-third theorem plus the recorded cases through seven sequences. -/
-- zpi: prop-one-third-theorem-and-known-cases-imply-fraenkel-conjecture
theorem oneThirdTheoremAndKnownCases
    {m : ℕ} (hm : 3 ≤ m) (α β : Fin m → ℝ)
    (hα : ∀ i, 1 < α i)
    (hdistinct : Function.Injective α)
    (hpartition : BiInfiniteBeattyPartition α β) :
    Set.range α = FraenkelModuli m := by
  have hpart' : TestBiInfiniteBeattyPartition α β := by
    simpa [BiInfiniteBeattyPartition, TestBiInfiniteBeattyPartition] using hpartition
  simpa [FraenkelModuli] using
    (oneThirdStrongScratch hm α β hα hdistinct hpart')

/-- Fraenkel's conjecture in the package's bi-infinite formulation. -/
-- zpi: thm-fraenkel-conjecture
theorem fraenkelConjecture
    {m : ℕ} (hm : 3 ≤ m) (α β : Fin m → ℝ)
    (hα : ∀ i, 1 < α i)
    (hdistinct : Function.Injective α)
    (hpartition : BiInfiniteBeattyPartition α β) :
    Set.range α = FraenkelModuli m := by
  exact oneThirdTheoremAndKnownCases hm α β hα hdistinct hpartition

end Fraenkel
