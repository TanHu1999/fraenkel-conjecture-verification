import Mathlib.RingTheory.RootsOfUnity.Complex
import Fraenkel.Fourier.Basic
import Fraenkel.Analytic.Kernel
import Fraenkel.External.GrahamObryant2005

namespace Fraenkel

open scoped BigOperators Classical

set_option maxHeartbeats 1000000

/-- Gcd data and the retained minimum-gcd layer of a primitive rational Beatty
partition. -/
-- zpi: def-minimum-gcd-layer-data
structure MinimumGCDFourierLayerData {m : ℕ} where
  P : RationalBeattyPartition m
  q : ℤ
  p : Fin m → ℤ
  r : Fin m → ℤ
  primitive : PrimitiveRationalBeattyPartition P q p r

/-- The gcd attached to one numerator. -/
-- zpi: def-minimum-gcd-layer-data
def layerGcd {m : ℕ} (q : ℤ) (p : Fin m → ℤ) (i : Fin m) : ℤ :=
  Int.gcd (p i) q

/-- The minimum gcd `g`. -/
-- zpi: def-minimum-gcd-layer-data
noncomputable def minimumLayerGcd {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p : Fin m → ℤ) : ℤ :=
  (Finset.univ.image (fun i : Fin m => layerGcd q p i)).min'
    (Finset.image_nonempty.mpr
      ⟨(⟨0, P.nonempty⟩ : Fin m), Finset.mem_univ _⟩)

/-- The reduced denominator `Q=q/g`. -/
-- zpi: def-minimum-gcd-layer-data
noncomputable def minimumLayerModulus {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p : Fin m → ℤ) : ℤ :=
  q / minimumLayerGcd P q p

/-- The retained indices on the minimum gcd layer. -/
-- zpi: def-minimum-gcd-layer-data
noncomputable def minimumLayerIndices {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p : Fin m → ℤ) : Finset (Fin m) :=
  Finset.univ.filter
    (fun i => layerGcd q p i = minimumLayerGcd P q p)

/-- The minimum layer `A={a_i}` with `p_i=g a_i`. -/
-- zpi: def-minimum-gcd-layer-data
noncomputable def minimumGCDLayer {m : ℕ} (P : RationalBeattyPartition m)
    (q : ℤ) (p : Fin m → ℤ) : Finset ℤ :=
  (minimumLayerIndices P q p).image
    (fun i => p i / minimumLayerGcd P q p)

/-- The cyclic root of unity `exp(2π i k/q)`. -/
-- zpi: prop-fourier-transform-of-rational-beatty-period-indicator
noncomputable def cyclicFourierOmegaPower (q k : ℤ) : ℂ :=
  Complex.exp (2 * Complex.ofReal Real.pi * Complex.I *
    (Complex.ofReal k / Complex.ofReal q))

/-- Fourier transform of one rational Beatty period indicator. -/
-- zpi: prop-fourier-transform-of-rational-beatty-period-indicator
private theorem probe_gcd_divisibility (p q : ℤ) (hp : 0 < p) (hq : 0 < q) (hpq : p < q)
    (u : ℤ) (hu : 1 ≤ u) (huQ : u < q / Int.gcd p q)
    (hu_inv : (p / Int.gcd p q) * u % (q / Int.gcd p q) = 1) :
    q ∣ p * u - (Int.gcd p q : ℤ) := by
  let g : ℤ := Int.gcd p q
  have hgpos : 0 < g := by
    dsimp [g]
    exact_mod_cast Int.gcd_pos_of_ne_zero_left q (ne_of_gt hp)
  have hgp : g ∣ p := by
    dsimp [g]
    exact Int.gcd_dvd_left p q
  have hgq : g ∣ q := by
    dsimp [g]
    exact Int.gcd_dvd_right p q
  have hQpos : 0 < q / g := Int.ediv_pos_of_pos_of_dvd hq hgpos.le hgq
  have hQdvd : q / g ∣ (p / g) * u - 1 := by
    apply Int.dvd_of_emod_eq_zero
    rw [Int.sub_emod, hu_inv]
    simp
  change q ∣ p * u - g
  rcases hQdvd with ⟨k, hk⟩
  refine ⟨k, ?_⟩
  have hp_eq : p = g * (p / g) := by
    exact (Int.mul_ediv_cancel' hgp).symm
  have hq_eq : q = g * (q / g) := by
    exact (Int.mul_ediv_cancel' hgq).symm
  rw [hp_eq, hq_eq]
  calc
    g * (p / g) * u - g = g * (p / g * u - 1) := by ring
    _ = g * (q / g * k) := by rw [hk]
    _ = g * (q / g) * k := by ring


private theorem probe_order_layer_equiv (p q : ℤ) (hp : 0 < p) (hpq : p < q) (hq : 0 < q)
    (j : ZMod q.natAbs) (hj : 0 < j.val) :
    (Int.gcd p q : ℤ) ∣ (j.val : ℤ) ↔
      orderOf (cyclicFourierOmegaPower q (j.val : ℤ)) ∣
        (q / Int.gcd p q).natAbs := by
  let g : ℤ := Int.gcd p q
  have hgpos : 0 < g := by
    dsimp [g]
    exact_mod_cast Int.gcd_pos_of_ne_zero_left q (ne_of_gt hp)
  have hgp : g ∣ p := by
    dsimp [g]
    exact Int.gcd_dvd_left p q
  have hgq : g ∣ q := by
    dsimp [g]
    exact Int.gcd_dvd_right p q
  have hQpos : 0 < q / g := Int.ediv_pos_of_pos_of_dvd hq hgpos.le hgq
  have hq_eq : q = g * (q / g) := (Int.mul_ediv_cancel' hgq).symm
  have hQnat : ((q / g).natAbs : ℤ) = q / g := Int.natAbs_of_nonneg hQpos.le
  have hQcastC : ((q / g).natAbs : ℂ) = ((q / g : ℤ) : ℂ) := by
    have hQnatR := congrArg (fun z : ℤ => (z : ℝ)) hQnat
    simpa only [Complex.ofReal_natCast, Complex.ofReal_intCast] using
      congrArg Complex.ofReal hQnatR
  have hQne : q / g ≠ 0 := ne_of_gt hQpos
  rw [orderOf_dvd_iff_pow_eq_one]
  constructor
  · intro hgj
    change g ∣ (j.val : ℤ) at hgj
    obtain ⟨k, hk⟩ := hgj
    have hkC : (j.val : ℂ) = (g : ℂ) * (k : ℂ) := by
      exact_mod_cast hk
    rw [cyclicFourierOmegaPower, ← Complex.exp_nat_mul]
    rw [hQcastC]
    convert Complex.exp_int_mul_two_pi_mul_I k using 1
    push_cast
    rw [hkC]
    have hqC : (q : ℂ) = (g : ℂ) * ((q / g : ℤ) : ℂ) := by
      exact_mod_cast hq_eq
    have hQComplex : ((q / g : ℤ) : ℂ) ≠ 0 := by
      exact_mod_cast hQne
    congr 1
    rw [hqC]
    field_simp [hgpos.ne', hQComplex]
  · intro hpow
    rw [cyclicFourierOmegaPower, ← Complex.exp_nat_mul] at hpow
    rw [hQcastC] at hpow
    obtain ⟨n, hn⟩ := (Complex.exp_eq_one_iff).mp hpow
    have him := congrArg Complex.im hn
    norm_num at him
    have hqR : 0 < (q : ℝ) := by exact_mod_cast hq
    have hqRne : (q : ℝ) ≠ 0 := ne_of_gt hqR
    have hQR : 0 < ((q / g : ℤ) : ℝ) := by exact_mod_cast hQpos
    have hQRne : ((q / g : ℤ) : ℝ) ≠ 0 := by exact_mod_cast hQne
    have hjR : 0 < (j.val : ℝ) := by exact_mod_cast hj
    field_simp [hqRne, hQRne] at him
    have hq_eqR : (q : ℝ) = (g : ℝ) * ((q / g : ℤ) : ℝ) := by
      exact_mod_cast hq_eq
    have him' : (j.val : ℝ) = (g : ℝ) * (n : ℝ) := by
      apply (mul_left_cancel₀ hQRne)
      calc
        ((q / g : ℤ) : ℝ) * (j.val : ℝ) = (q : ℝ) * (n : ℝ) := him
        _ = ((g : ℝ) * ((q / g : ℤ) : ℝ)) * (n : ℝ) := by rw [← hq_eqR]
        _ = ((q / g : ℤ) : ℝ) * ((g : ℝ) * (n : ℝ)) := by ring
    have hjn : (j.val : ℤ) = g * n := by
      exact_mod_cast him'
    change g ∣ (j.val : ℤ)
    exact ⟨n, hjn⟩


private theorem probe_beatty_residue_characterization (p q r : ℤ) (hp : 0 < p) (hpq : p < q) (hq : 0 < q) (z : ℤ) :
    z ∈ integerTranslatedRationalBeattySet p q r ↔
      ∃ n : Fin p.natAbs,
        ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n.val : ℤ) : ℤ) :
          ZMod q.natAbs) = (z : ZMod q.natAbs) := by
  classical
  have hpNat : 0 < p.natAbs := Int.natAbs_pos.mpr (ne_of_gt hp)
  have hqNat : 0 < q.natAbs := Int.natAbs_pos.mpr (ne_of_gt hq)
  letI : NeZero p.natAbs := ⟨Nat.ne_of_gt hpNat⟩
  letI : NeZero q.natAbs := ⟨Nat.ne_of_gt hqNat⟩
  have hpZ : (p.natAbs : ℤ) = p := Int.natAbs_of_nonneg hp.le
  have hqZ : (q.natAbs : ℤ) = q := Int.natAbs_of_nonneg hq.le
  have hpR : 0 < (p : ℝ) := by exact_mod_cast hp
  have hα : 1 < (q : ℝ) / (p : ℝ) := by
    rw [lt_div_iff₀ hpR]
    simpa using hpq
  let a : Fin p.natAbs → ℤ := fun n =>
    beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n.val : ℤ)
  have ha_floor (n : Fin p.natAbs) :
      (⌊(n.val : ℝ) * (q : ℝ) / (p : ℝ) + (r : ℝ)⌋ : ℤ) = a n := by
    dsimp [a, beattyTerm]
    congr 1
    push_cast
    ring
  have hper_res : Function.Periodic (fun n : ℤ =>
      ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) n : ℤ) : ZMod q.natAbs)) p := by
    intro n
    change ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n + p) : ℤ) : ZMod q.natAbs) =
      ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) n : ℤ) : ZMod q.natAbs)
    rw [rationalBeatty_index_period p q r n hp]
    rw [Int.cast_add]
    have hqzero : (q : ZMod q.natAbs) = 0 := by
      rw [ZMod.intCast_zmod_eq_zero_iff_dvd]
      exact Int.natAbs_dvd_self
    simp [hqzero]
  have hreindex (n : ℤ) :
      ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) n : ℤ) : ZMod q.natAbs) =
        ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n % p) : ℤ) : ZMod q.natAbs) := by
    have hval := hper_res.int_mul (n / p) (n % p)
    simpa [Int.emod_add_mul_ediv, mul_comm] using hval
  have hset_per : Function.Periodic
      (integerIndicator (integerTranslatedRationalBeattySet p q r)) q :=
    (periodDensityAndModulus p q r hp hpq).1
  have hset_shift (x k : ℤ) :
      integerIndicator (integerTranslatedRationalBeattySet p q r) (x + k * q) =
        integerIndicator (integerTranslatedRationalBeattySet p q r) x := by
    have h := hset_per.int_mul k x
    simpa [mul_comm] using h
  have hset_shift_mem (x k : ℤ) :
      x ∈ integerTranslatedRationalBeattySet p q r ↔
        x + k * q ∈ integerTranslatedRationalBeattySet p q r := by
    by_cases hx : x ∈ integerTranslatedRationalBeattySet p q r
    · constructor
      · intro _
        by_contra hright
        have hone : integerIndicator (integerTranslatedRationalBeattySet p q r) x = 1 := by
          simp [integerIndicator, hx]
        have hzero : integerIndicator (integerTranslatedRationalBeattySet p q r) (x + k * q) = 0 := by
          simp [integerIndicator, hright]
        linarith [hset_shift x k]
      · intro _
        exact hx
    · constructor
      · intro hmem
        exact (hx hmem).elim
      · intro hright
        by_contra hmem
        have hzero : integerIndicator (integerTranslatedRationalBeattySet p q r) x = 0 := by
          simp [integerIndicator, hx]
        have hone : integerIndicator (integerTranslatedRationalBeattySet p q r) (x + k * q) = 1 := by
          simp [integerIndicator, hright]
        linarith [hset_shift x k]
  constructor
  · rintro ⟨n, hn⟩
    change beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) n = z at hn
    let rem : ℤ := n % p
    have hrem0 : 0 ≤ rem := by
      dsimp [rem]
      exact Int.emod_nonneg _ (ne_of_gt hp)
    have hrem_lt : rem < p := by
      dsimp [rem]
      exact Int.emod_lt_of_pos _ hp
    have hrem_lt_nat : rem.toNat < p.natAbs := by
      apply (Int.toNat_lt hrem0).2
      rw [hpZ]
      exact hrem_lt
    let n0 : Fin p.natAbs := ⟨rem.toNat, hrem_lt_nat⟩
    have hn0 : (n0.val : ℤ) = rem := by
      dsimp [n0]
      exact Int.toNat_of_nonneg hrem0
    refine ⟨n0, ?_⟩
    have hres := hreindex n
    calc
      ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n0.val : ℤ) : ℤ) : ZMod q.natAbs) =
          ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n % p) : ℤ) : ZMod q.natAbs) := by
            rw [hn0]
      _ = ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) n : ℤ) : ZMod q.natAbs) := hres.symm
      _ = (z : ZMod q.natAbs) := by rw [hn]
  · rintro ⟨n, hn⟩
    let an : ℤ := beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n.val : ℤ)
    have han_mem : an ∈ integerTranslatedRationalBeattySet p q r := by
      change ∃ k : ℤ, beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) k = an
      exact ⟨n.val, rfl⟩
    have hcast : (an : ZMod q.natAbs) = (z : ZMod q.natAbs) := by
      simpa [an] using hn
    have hmodNat : Int.ModEq (q.natAbs : ℤ) an z :=
      (ZMod.intCast_eq_intCast_iff an z q.natAbs).mp hcast
    rw [hqZ] at hmodNat
    obtain ⟨k, hk⟩ := (Int.modEq_iff_dvd.mp hmodNat)
    have hzform : z = an + k * q := by
      nlinarith [hk]
    rw [hzform]
    exact (hset_shift_mem an k).mp han_mem


private theorem probe_beatty_period_residue_injective (p q r : ℤ) (hp : 0 < p) (hpq : p < q) (hq : 0 < q) :
    Function.Injective (fun n : Fin p.natAbs =>
      ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n.val : ℤ) : ℤ) : ZMod q.natAbs)) := by
  classical
  have hpNat : 0 < p.natAbs := Int.natAbs_pos.mpr (ne_of_gt hp)
  have hqNat : 0 < q.natAbs := Int.natAbs_pos.mpr (ne_of_gt hq)
  letI : NeZero p.natAbs := ⟨Nat.ne_of_gt hpNat⟩
  letI : NeZero q.natAbs := ⟨Nat.ne_of_gt hqNat⟩
  have hpZ : (p.natAbs : ℤ) = p := Int.natAbs_of_nonneg hp.le
  have hqZ : (q.natAbs : ℤ) = q := Int.natAbs_of_nonneg hq.le
  have hpR : 0 < (p : ℝ) := by exact_mod_cast hp
  have hα : 1 < (q : ℝ) / (p : ℝ) := by
    rw [lt_div_iff₀ hpR]
    simpa using hpq
  have hstrict : StrictMono (beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ)) :=
    beattyTerm_strictMono _ _ hα
  intro n₁ n₂ hres
  have hn₁_nonneg : (0 : ℤ) ≤ n₁.val := by omega
  have hn₂_nonneg : (0 : ℤ) ≤ n₂.val := by omega
  have hn₁_lt : (n₁.val : ℤ) < p := by
    calc
      (n₁.val : ℤ) < (p.natAbs : ℤ) := by exact_mod_cast n₁.isLt
      _ = p := hpZ
  have hn₂_lt : (n₂.val : ℤ) < p := by
    calc
      (n₂.val : ℤ) < (p.natAbs : ℤ) := by exact_mod_cast n₂.isLt
      _ = p := hpZ
  let b₁ : ℤ := beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n₁.val : ℤ)
  let b₂ : ℤ := beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n₂.val : ℤ)
  have hbase : b₁ ≤ b₂ ∨ b₂ ≤ b₁ := le_total b₁ b₂
  have hlow (n : Fin p.natAbs) :
      beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (0 : ℤ) ≤
        beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n.val : ℤ) := by
    apply hstrict.monotone
    omega
  have hupp (n : Fin p.natAbs) :
      beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n.val : ℤ) <
        beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) p := by
    have hnlt : (n.val : ℤ) < p := by
      calc
        (n.val : ℤ) < (p.natAbs : ℤ) := by exact_mod_cast n.isLt
        _ = p := hpZ
    exact hstrict hnlt
  have hperiod_p :
      beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) p =
        beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) 0 + q := by
    simpa using rationalBeatty_index_period p q r 0 hp
  have hb₁_low : beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) 0 ≤ b₁ := by
    simpa [b₁] using hlow n₁
  have hb₂_low : beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) 0 ≤ b₂ := by
    simpa [b₂] using hlow n₂
  have hb₁_up : b₁ < beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) 0 + q := by
    have h := hupp n₁
    rw [hperiod_p] at h
    simpa [b₁] using h
  have hb₂_up : b₂ < beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) 0 + q := by
    have h := hupp n₂
    rw [hperiod_p] at h
    simpa [b₂] using h
  have hdiff_lt : b₁ - b₂ < q := by
    nlinarith [hb₁_up, hb₂_low]
  have hdiff_gt : -q < b₁ - b₂ := by
    nlinarith [hb₂_up, hb₁_low]
  have hmod : Int.ModEq q b₁ b₂ := by
    have hcast := hres
    change (b₁ : ZMod q.natAbs) = (b₂ : ZMod q.natAbs) at hcast
    have hm : Int.ModEq (q.natAbs : ℤ) b₁ b₂ :=
      (ZMod.intCast_eq_intCast_iff b₁ b₂ q.natAbs).mp hcast
    rw [hqZ] at hm
    exact hm
  obtain ⟨k, hk⟩ := (Int.modEq_iff_dvd.mp hmod)
  have hzero : b₁ - b₂ = 0 := by
    by_contra hne
    have hkne : k ≠ 0 := by
      intro hk0
      apply hne
      rw [hk0] at hk
      nlinarith [hk]
    have hkpos : 0 < k ∨ k < 0 := by omega
    rcases hkpos with hkpos | hkneg
    · have hqk : q ≤ q * k := by nlinarith
      nlinarith [hk, hdiff_lt, hq]
    · have hqk : q * k ≤ -q := by nlinarith
      nlinarith [hk, hdiff_gt, hq]
  have hb_eq : b₁ = b₂ := by omega
  have hn_eq_int : (n₁.val : ℤ) = n₂.val := by
    apply (hstrict.injective)
    simpa [b₁, b₂] using hb_eq
  apply Fin.ext
  exact_mod_cast hn_eq_int


private theorem probe_period_multiplicity_eq_indicator (p q r : ℤ)
    (hp : 0 < p) (hpq : p < q) (hq : 0 < q)
    (t : ZMod q.natAbs) :
    External.GrahamObryant2005.rationalBeattyPeriodMultiplicity p q r t =
      (periodBeattyIndicator p q r hp hpq hq t).val := by
  classical
  have hpNat : 0 < p.natAbs := Int.natAbs_pos.mpr (ne_of_gt hp)
  have hqNat : 0 < q.natAbs := Int.natAbs_pos.mpr (ne_of_gt hq)
  letI : NeZero p.natAbs := ⟨Nat.ne_of_gt hpNat⟩
  letI : NeZero q.natAbs := ⟨Nat.ne_of_gt hqNat⟩
  let f : Fin p.natAbs → ZMod q.natAbs := fun n =>
    ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n.val : ℤ) : ℤ) : ZMod q.natAbs)
  have hfloor (n : Fin p.natAbs) :
      ((⌊(n.val : ℝ) * (q : ℝ) / (p : ℝ) + (r : ℝ)⌋ : ℤ) : ZMod q.natAbs) = f n := by
    have hreal : (n.val : ℝ) * (q : ℝ) / (p : ℝ) + (r : ℝ) =
        (n.val : ℝ) * ((q : ℝ) / (p : ℝ)) + (r : ℝ) := by ring
    rw [hreal]
    rfl
  let F : Finset (Fin p.natAbs) := Finset.univ.filter (fun n => f n = t)
  have hF_eq :
      (External.GrahamObryant2005.rationalBeattyPeriodMultiplicity p q r t) = F.card := by
    unfold External.GrahamObryant2005.rationalBeattyPeriodMultiplicity
    congr 1
    ext n
    simp only [F, Finset.mem_filter, Finset.mem_univ, true_and]
    rw [hfloor]
  have hchar := probe_beatty_residue_characterization p q r hp hpq hq (t.val : ℤ)
  have htval : ((t.val : ℕ) : ZMod q.natAbs) = t := by
    simpa using (ZMod.natCast_val t)
  have htvalZ : ((t.val : ℤ) : ZMod q.natAbs) = t := by
    simpa using htval
  have hFcard : F.card =
      if (t.val : ℤ) ∈ integerTranslatedRationalBeattySet p q r then 1 else 0 := by
    by_cases hmem : (t.val : ℤ) ∈ integerTranslatedRationalBeattySet p q r
    · obtain ⟨n₀, hn₀⟩ := hchar.mp hmem
      have hnt : f n₀ = t := by
        change ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n₀.val : ℤ) : ℤ) :
          ZMod q.natAbs) = t
        calc
          _ = ((t.val : ℤ) : ZMod q.natAbs) := hn₀
          _ = t := htvalZ
      have hfilter : F = {n₀} := by
        ext n
        simp only [F, Finset.mem_filter, Finset.mem_univ, true_and,
          Finset.mem_singleton]
        constructor
        · intro hn
          apply probe_beatty_period_residue_injective p q r hp hpq hq
          simpa [f] using hn.trans hnt.symm
        · intro hn
          subst n
          exact hnt
      rw [hfilter]
      have hmem_cast : t.cast ∈ integerTranslatedRationalBeattySet p q r := by
        rw [ZMod.cast_eq_val t]
        exact hmem
      simp [hmem_cast]
    · have hempty : F = ∅ := by
        ext n
        simp [F]
        intro hn
        apply hmem
        apply hchar.mpr
        refine ⟨n, ?_⟩
        change ((beattyTerm ((q : ℝ) / (p : ℝ)) (r : ℝ) (n.val : ℤ) : ℤ) :
          ZMod q.natAbs) = ((t.val : ℤ) : ZMod q.natAbs)
        calc
          _ = f n := rfl
          _ = t := hn
          _ = ((t.val : ℤ) : ZMod q.natAbs) := htvalZ.symm
      rw [hempty]
      simp only [Finset.card_empty]
      rw [if_neg hmem]
  rw [hF_eq, hFcard]
  rw [periodBeattyIndicator_spec]
  split <;> rfl


private theorem probe_discrete_fourier_eq_external (p q r : ℤ)
    (hp : 0 < p) (hpq : p < q) (hq : 0 < q)
    (j : ZMod q.natAbs) :
    discreteFourierTransform q hq
        (fun t => Complex.ofReal
          ((periodBeattyIndicator p q r hp hpq hq t).val : ℝ)) j =
      External.GrahamObryant2005.rationalBeattyFourierTransform p q r j := by
  classical
  unfold discreteFourierTransform
    External.GrahamObryant2005.rationalBeattyFourierTransform
  apply Finset.sum_congr rfl
  intro x hx
  rw [probe_period_multiplicity_eq_indicator p q r hp hpq hq
    ((x.val : ℕ) : ZMod q.natAbs)]
  rfl


private theorem probe_exp_div_eq_one_iff (a Q : ℤ) (hQ : 0 < Q) :
    Complex.exp (2 * Complex.ofReal Real.pi * Complex.I *
      (Complex.ofReal a / Complex.ofReal Q)) = 1 ↔ Q ∣ a := by
  have hQR : 0 < (Q : ℝ) := by exact_mod_cast hQ
  have hQRne : (Q : ℝ) ≠ 0 := ne_of_gt hQR
  constructor
  · intro h
    obtain ⟨n, hn⟩ := (Complex.exp_eq_one_iff).mp h
    have him := congrArg Complex.im hn
    norm_num at him
    field_simp [hQRne] at him
    have ha : (a : ℝ) = (Q : ℝ) * (n : ℝ) := by
      nlinarith [him]
    exact ⟨n, by exact_mod_cast ha⟩
  · rintro ⟨n, hn⟩
    rw [hn]
    have hQComplex : (Q : ℂ) ≠ 0 := by exact_mod_cast (ne_of_gt hQ)
    convert Complex.exp_int_mul_two_pi_mul_I n using 1
    push_cast
    field_simp [hQComplex]


private theorem probe_cyclic_omega_pow (q j u : ℤ) (hq : 0 < q) (hu : 0 ≤ u) :
    (cyclicFourierOmegaPower q j) ^ u.natAbs =
      cyclicFourierOmegaPower q (j * u) := by
  have hqC : (q : ℂ) ≠ 0 := by exact_mod_cast (ne_of_gt hq)
  have huZ : (u.natAbs : ℤ) = u := Int.natAbs_of_nonneg hu
  have huC : (u.natAbs : ℂ) = (u : ℂ) := by
    have huR := congrArg (fun z : ℤ => (z : ℝ)) huZ
    simpa only [Complex.ofReal_natCast, Complex.ofReal_intCast] using
      congrArg Complex.ofReal huR
  rw [cyclicFourierOmegaPower, ← Complex.exp_nat_mul]
  rw [cyclicFourierOmegaPower]
  congr 1
  push_cast
  field_simp [hqC]
  rw [huC]
  ring


private theorem probe_geometric_sum_formula (u : ℤ) (hu : 0 < u) (z : ℂ) (hz : z ≠ 1) :
    geometricSumPolynomial u.natAbs (by
      apply Int.natAbs_pos.mpr
      omega) z = (z ^ u.natAbs - 1) / (z - 1) := by
  unfold geometricSumPolynomial
  exact geom_sum_eq hz u.natAbs


private theorem probe_active_denominator_nonzero (p q r : ℤ)
    (hp : 0 < p) (hpq : p < q) (hq : 0 < q)
    (j : ZMod q.natAbs) (hj : 0 < j.val)
    (u : ℤ) (hu : 1 ≤ u) (huQ : u < q / Int.gcd p q)
    (hu_inv : (p / Int.gcd p q) * u % (q / Int.gcd p q) = 1)
    (hgj : (Int.gcd p q : ℤ) ∣ (j.val : ℤ)) :
    cyclicFourierOmegaPower q ((j.val : ℤ) * u) ≠ 1 ∧
      geometricSumPolynomial u.natAbs (by
        apply Int.natAbs_pos.mpr
        omega) (cyclicFourierOmegaPower q (j.val : ℤ)) ≠ 0 := by
  classical
  let g : ℤ := Int.gcd p q
  let Q : ℤ := q / g
  have hgpos : 0 < g := by
    dsimp [g]
    exact_mod_cast Int.gcd_pos_of_ne_zero_left q (ne_of_gt hp)
  have hgq : g ∣ q := by
    dsimp [g]
    exact Int.gcd_dvd_right p q
  have hQpos : 0 < Q := by
    dsimp [Q]
    exact Int.ediv_pos_of_pos_of_dvd hq hgpos.le hgq
  have hq_eq : q = g * Q := by
    dsimp [Q]
    exact (Int.mul_ediv_cancel' hgq).symm
  have hqC : (q : ℂ) = (g : ℂ) * (Q : ℂ) := by
    exact_mod_cast hq_eq
  have hQComplex : (Q : ℂ) ≠ 0 := by exact_mod_cast (ne_of_gt hQpos)
  have hqNat : 0 < q.natAbs := Int.natAbs_pos.mpr (ne_of_gt hq)
  letI : NeZero q.natAbs := ⟨Nat.ne_of_gt hqNat⟩
  have hQdvd : Q ∣ (p / g) * u - 1 := by
    dsimp [Q, g]
    apply Int.dvd_of_emod_eq_zero
    rw [Int.sub_emod, hu_inv]
    simp
  have hcancel (x : ℤ) (hx : Q ∣ x * u) : Q ∣ x := by
    rcases hx with ⟨l, hl⟩
    rcases hQdvd with ⟨m, hm⟩
    refine ⟨l * (p / g) - x * m, ?_⟩
    calc
      x = (x * u) * (p / g) - x * ((p / g) * u - 1) := by ring
      _ = (Q * l) * (p / g) - x * (Q * m) := by rw [hl, hm]
      _ = Q * (l * (p / g) - x * m) := by ring
  have hgj' : g ∣ (j.val : ℤ) := by
    simpa [g] using hgj
  obtain ⟨k, hk⟩ := hgj'
  have hjltq : (j.val : ℤ) < q := by
    calc
      (j.val : ℤ) < (q.natAbs : ℤ) := by exact_mod_cast (ZMod.val_lt j)
      _ = q := Int.natAbs_of_nonneg hq.le
  have hkpos : 0 < k := by
    nlinarith [hgpos, hj]
  have hkltQ : k < Q := by
    have hmul : g * k < g * Q := by
      calc
        g * k = (j.val : ℤ) := hk.symm
        _ < q := hjltq
        _ = g * Q := hq_eq
    exact (Int.mul_lt_mul_left hgpos).mp hmul
  have hku_not : ¬ Q ∣ k * u := by
    intro hku
    obtain ⟨l, hl⟩ := hcancel k hku
    have hlpos : 0 < l := by nlinarith [hQpos, hkpos]
    nlinarith [hkltQ, hQpos, hl]
  have hkC : (j.val : ℂ) = (g : ℂ) * (k : ℂ) := by
    exact_mod_cast hk
  have hcycle_formula :
      cyclicFourierOmegaPower q ((j.val : ℤ) * u) =
        Complex.exp (2 * Complex.ofReal Real.pi * Complex.I *
          (Complex.ofReal ((k * u : ℤ) : ℝ) / Complex.ofReal (Q : ℝ))) := by
    unfold cyclicFourierOmegaPower
    congr 1
    push_cast
    rw [hkC, hqC]
    field_simp [hgpos.ne', hQComplex]
  have hden : cyclicFourierOmegaPower q ((j.val : ℤ) * u) ≠ 1 := by
    intro h
    rw [hcycle_formula] at h
    exact hku_not ((probe_exp_div_eq_one_iff (k * u) Q hQpos).mp h)
  refine ⟨hden, ?_⟩
  intro hJ
  have hz : cyclicFourierOmegaPower q (j.val : ℤ) ≠ 1 := by
    intro hz
    have hqj : q ∣ (j.val : ℤ) := by
      have hformula : cyclicFourierOmegaPower q (j.val : ℤ) =
          Complex.exp (2 * Complex.ofReal Real.pi * Complex.I *
            (Complex.ofReal (j.val : ℤ) / Complex.ofReal q)) := rfl
      rw [hformula] at hz
      exact (probe_exp_div_eq_one_iff (j.val : ℤ) q hq).mp hz
    obtain ⟨l, hl⟩ := hqj
    have hlpos : 0 < l := by nlinarith [hj, hq, hl]
    nlinarith [hjltq, hq, hl]
  have hupos : 0 < u := by omega
  have hu0 : 0 ≤ u := by omega
  have hgeom := probe_geometric_sum_formula u hupos
    (cyclicFourierOmegaPower q (j.val : ℤ)) hz
  have hpow := probe_cyclic_omega_pow q (j.val : ℤ) u hq hu0
  rw [hpow] at hgeom
  rw [hJ] at hgeom
  have : cyclicFourierOmegaPower q ((j.val : ℤ) * u) = 1 := by
    have hquot :
        (cyclicFourierOmegaPower q ((j.val : ℤ) * u) - 1) /
          (cyclicFourierOmegaPower q (j.val : ℤ) - 1) = 0 := by
      simpa using hgeom.symm
    rcases (div_eq_zero_iff.mp hquot) with hnum | hdenom
    · exact (hden (sub_eq_zero.mp hnum)).elim
    · exact False.elim (hz (sub_eq_zero.mp hdenom))
  exact hden this


private theorem probe_fourier_geometric_formula
    (p q r : ℤ) (hp : 0 < p) (hpq : p < q) (hq : 0 < q)
    (j : ZMod q.natAbs) (hj : 0 < j.val)
    (u : ℤ) (hu : 1 ≤ u) (huQ : u < q / Int.gcd p q)
    (hu_inv : (p / Int.gcd p q) * u % (q / Int.gcd p q) = 1)
    (hgj : (Int.gcd p q : ℤ) ∣ (j.val : ℤ)) :
    ((Int.gcd p q : ℤ) : ℂ) *
        (1 - cyclicFourierOmegaPower q (j.val : ℤ)) /
          (1 - cyclicFourierOmegaPower q ((j.val : ℤ) * u)) *
        cyclicFourierOmegaPower q (-((j.val : ℤ) * r)) =
      ((Int.gcd p q : ℤ) : ℂ) *
        cyclicFourierOmegaPower q (-((j.val : ℤ) * r)) /
          geometricSumPolynomial u.natAbs (by
            apply Int.natAbs_pos.mpr
            omega) (cyclicFourierOmegaPower q (j.val : ℤ)) := by
  have hqNat : 0 < q.natAbs := Int.natAbs_pos.mpr (ne_of_gt hq)
  letI : NeZero q.natAbs := ⟨Nat.ne_of_gt hqNat⟩
  have hactive := probe_active_denominator_nonzero p q r hp hpq hq j hj u hu huQ hu_inv hgj
  have hden := hactive.1
  have hJ := hactive.2
  have hz : cyclicFourierOmegaPower q (j.val : ℤ) ≠ 1 := by
    intro hz
    have hqj : q ∣ (j.val : ℤ) := by
      have hformula : cyclicFourierOmegaPower q (j.val : ℤ) =
          Complex.exp (2 * Complex.ofReal Real.pi * Complex.I *
            (Complex.ofReal (j.val : ℤ) / Complex.ofReal q)) := rfl
      rw [hformula] at hz
      exact (probe_exp_div_eq_one_iff (j.val : ℤ) q hq).mp hz
    obtain ⟨l, hl⟩ := hqj
    have hjltq : (j.val : ℤ) < q := by
      calc
        (j.val : ℤ) < (q.natAbs : ℤ) := by exact_mod_cast (ZMod.val_lt j)
        _ = q := Int.natAbs_of_nonneg hq.le
    have hlpos : 0 < l := by nlinarith [hj, hq, hl]
    nlinarith [hjltq, hq, hl]
  have hupos : 0 < u := by omega
  have hgeom := probe_geometric_sum_formula u hupos
    (cyclicFourierOmegaPower q (j.val : ℤ)) hz
  have hpow := probe_cyclic_omega_pow q (j.val : ℤ) u hq (by omega)
  rw [hpow] at hgeom
  rw [hgeom]
  have hden' : 1 - cyclicFourierOmegaPower q ((j.val : ℤ) * u) ≠ 0 :=
    sub_ne_zero.mpr hden.symm
  have hden'' : cyclicFourierOmegaPower q ((j.val : ℤ) * u) - 1 ≠ 0 :=
    sub_ne_zero.mpr hden
  have hz' : cyclicFourierOmegaPower q (j.val : ℤ) - 1 ≠ 0 :=
    sub_ne_zero.mpr hz
  field_simp [hden', hden'', hz', hden, hz, hJ]
  ring

theorem fourierTransformOfRationalBeattyPeriodIndicator
    (p q r : ℤ) (hp : 0 < p) (hpq : p < q) (hq : 0 < q)
    (j : ZMod q.natAbs) (hj : 0 < j.val)
    (u : ℤ) (hu : 1 ≤ u) (huQ : u < q / Int.gcd p q)
    (hu_inv : (p / Int.gcd p q) * u % (q / Int.gcd p q) = 1) :
    q ∣ p * u - (Int.gcd p q : ℤ) ∧
      ((Int.gcd p q : ℤ) ∣ (j.val : ℤ) ↔
        orderOf (cyclicFourierOmegaPower q (j.val : ℤ)) ∣
          (q / Int.gcd p q).natAbs) ∧
      (discreteFourierTransform q hq
          (fun t => Complex.ofReal
            ((periodBeattyIndicator p q r hp hpq hq t).val : ℝ)) j =
        if (Int.gcd p q : ℤ) ∣ (j.val : ℤ) then
          ((Int.gcd p q : ℤ) : ℂ) *
            (1 - cyclicFourierOmegaPower q (j.val : ℤ)) /
            (1 - cyclicFourierOmegaPower q ((j.val : ℤ) * u)) *
            cyclicFourierOmegaPower q (-((j.val : ℤ) * r))
        else 0) ∧
      (discreteFourierTransform q hq
          (fun t => Complex.ofReal
            ((periodBeattyIndicator p q r hp hpq hq t).val : ℝ)) j =
        if orderOf (cyclicFourierOmegaPower q (j.val : ℤ)) ∣
            (q / Int.gcd p q).natAbs then
          ((Int.gcd p q : ℤ) : ℂ) *
            cyclicFourierOmegaPower q (-((j.val : ℤ) * r)) /
            geometricSumPolynomial u.natAbs (by
              apply Int.natAbs_pos.mpr
              omega) (cyclicFourierOmegaPower q (j.val : ℤ))
        else 0) ∧
      ((Int.gcd p q : ℤ) ∣ (j.val : ℤ) →
        geometricSumPolynomial u.natAbs (by
          apply Int.natAbs_pos.mpr
          omega) (cyclicFourierOmegaPower q (j.val : ℤ)) ≠ 0) := by
  classical
  have hqNat : 0 < q.natAbs := Int.natAbs_pos.mpr (ne_of_gt hq)
  letI : NeZero q.natAbs := ⟨Nat.ne_of_gt hqNat⟩
  have hdiv := probe_gcd_divisibility p q hp hq hpq u hu huQ hu_inv
  have hord := probe_order_layer_equiv p q hp hpq hq j hj
  have hDFT := probe_discrete_fourier_eq_external p q r hp hpq hq j
  have hq1 : 1 < q := by omega
  have hExt := External.GrahamObryant2005.fourierTransformOfRationalBeattySet
    p q r u hp hq1 hdiv
  have hthird :
      discreteFourierTransform q hq
          (fun t => Complex.ofReal
            ((periodBeattyIndicator p q r hp hpq hq t).val : ℝ)) j =
        if (Int.gcd p q : ℤ) ∣ (j.val : ℤ) then
          ((Int.gcd p q : ℤ) : ℂ) *
            (1 - cyclicFourierOmegaPower q (j.val : ℤ)) /
            (1 - cyclicFourierOmegaPower q ((j.val : ℤ) * u)) *
            cyclicFourierOmegaPower q (-((j.val : ℤ) * r))
        else 0 := by
    rw [hDFT]
    simpa [cyclicFourierOmegaPower,
      External.GrahamObryant2005.rationalBeattyOmegaPower] using hExt.2.1 j hj
  refine ⟨hdiv, hord, hthird, ?_, ?_⟩
  · by_cases hgj : (Int.gcd p q : ℤ) ∣ (j.val : ℤ)
    · have hgeom := probe_fourier_geometric_formula p q r hp hpq hq j hj u hu huQ
        hu_inv hgj
      rw [hthird, if_pos hgj, if_pos (hord.mp hgj)]
      exact hgeom
    · have horder : ¬ orderOf (cyclicFourierOmegaPower q (j.val : ℤ)) ∣
          (q / Int.gcd p q).natAbs := by
        intro ho
        exact hgj (hord.mpr ho)
      rw [hthird, if_neg hgj, if_neg horder]
  · intro hgj
    exact (probe_active_denominator_nonzero p q r hp hpq hq j hj u hu huQ
      hu_inv hgj).2


/-- The source partition condition for the rational Beatty sets. -/
-- zpi: prop-fourier-covering-identity-for-rational-beatty-partition
def rationalBeattySetsPartition
    {m : ℕ} (q : ℤ) (p r : Fin m → ℤ) : Prop :=
  ∀ z : ℤ, ∃! i : Fin m,
    z ∈ integerTranslatedRationalBeattySet (p i) q (r i)

/-- The indicator condition on one period. -/
-- zpi: prop-fourier-covering-identity-for-rational-beatty-partition
def periodIndicatorSumIsOne
    {m : ℕ} (q : ℤ) (p r : Fin m → ℤ)
    (hp : ∀ i, 0 < p i ∧ p i < q) (hq : 0 < q) : Prop :=
  ∀ t : ZMod q.natAbs,
    (∑ i : Fin m,
      (periodBeattyIndicator (p i) q (r i) (hp i).1 (hp i).2 hq t).val) = 1

/-- Fourier covering identity for a rational Beatty partition, including the
partition iff indicator characterization. -/
-- zpi: prop-fourier-covering-identity-for-rational-beatty-partition
theorem fourierCoveringIdentityForRationalBeattyPartition
    {m : ℕ} (q : ℤ) (p r : Fin m → ℤ)
    (hp : ∀ i, 0 < p i ∧ p i < q) (hq : 0 < q) :
    (rationalBeattySetsPartition q p r ↔
      periodIndicatorSumIsOne q p r hp hq) ∧
    (periodIndicatorSumIsOne q p r hp hq →
      (∑ i : Fin m,
        discreteFourierTransform q hq
          (fun t => Complex.ofReal
            ((periodBeattyIndicator (p i) q (r i) (hp i).1 (hp i).2 hq t).val : ℝ))
          (0 : ZMod q.natAbs)) = (q : ℂ) ∧
        (∀ j : ZMod q.natAbs, 0 < j.val →
          ∑ i : Fin m,
            discreteFourierTransform q hq
              (fun t => Complex.ofReal
                ((periodBeattyIndicator (p i) q (r i) (hp i).1 (hp i).2 hq t).val : ℝ)) j = 0)) := by
  classical
  have hqNat : 0 < q.natAbs := Int.natAbs_pos.mpr (ne_of_gt hq)
  letI : NeZero q.natAbs := ⟨Nat.ne_of_gt hqNat⟩
  have hmem_period (i : Fin m) (z : ℤ) :
      z ∈ integerTranslatedRationalBeattySet (p i) q (r i) ↔
        z % q ∈ integerTranslatedRationalBeattySet (p i) q (r i) := by
    let S : Set ℤ := integerTranslatedRationalBeattySet (p i) q (r i)
    have hper : Function.Periodic (integerIndicator S) q :=
      (periodDensityAndModulus (p i) q (r i) (hp i).1 (hp i).2).1
    have hz : z % q + (z / q) * q = z := by
      simpa [mul_comm] using Int.emod_add_mul_ediv z q
    have hval := hper.int_mul (z / q) (z % q)
    have hval' : integerIndicator S (z % q + (z / q) * q) =
        integerIndicator S (z % q) := by
      simpa [mul_comm] using hval
    rw [hz] at hval'
    change z ∈ S ↔ z % q ∈ S
    constructor
    · intro hzmem
      by_contra hrmem
      have hone : integerIndicator S z = 1 := by
        simp [integerIndicator, hzmem]
      have hzero : integerIndicator S (z % q) = 0 := by
        simp [integerIndicator, hrmem]
      linarith
    · intro hrmem
      by_contra hzmem
      have hone : integerIndicator S (z % q) = 1 := by
        simp [integerIndicator, hrmem]
      have hzero : integerIndicator S z = 0 := by
        simp [integerIndicator, hzmem]
      linarith
  have hterm (i : Fin m) (z : ℤ) :
      (periodBeattyIndicator (p i) q (r i) (hp i).1 (hp i).2 hq
        (z : ZMod q.natAbs)).val =
        if z ∈ integerTranslatedRationalBeattySet (p i) q (r i) then 1 else 0 := by
    rw [periodBeattyIndicator_spec]
    have hv : ((↑((z : ZMod q.natAbs).val) : ℤ)) = z % q := by
      rw [ZMod.val_intCast]
      simp [Int.natAbs_of_nonneg hq.le]
    rw [hv]
    by_cases hz : z ∈ integerTranslatedRationalBeattySet (p i) q (r i)
    · have hr : z % q ∈ integerTranslatedRationalBeattySet (p i) q (r i) :=
        (hmem_period i z).mp hz
      simp [hz, hr]
    · have hr : z % q ∉ integerTranslatedRationalBeattySet (p i) q (r i) := by
        intro hr
        exact hz ((hmem_period i z).mpr hr)
      simp [hz, hr]
  constructor
  · constructor
    · intro hpart t
      let z : ℤ := t.val
      have hex : ∃! i : Fin m,
          z ∈ integerTranslatedRationalBeattySet (p i) q (r i) := hpart z
      obtain ⟨i, hi, huniq⟩ := hex
      have hsum :
          (∑ j : Fin m,
            (periodBeattyIndicator (p j) q (r j) (hp j).1 (hp j).2 hq t).val) = 1 := by
        have hterm' (j : Fin m) :
            (periodBeattyIndicator (p j) q (r j) (hp j).1 (hp j).2 hq t).val =
              if z ∈ integerTranslatedRationalBeattySet (p j) q (r j) then 1 else 0 := by
          simpa [z] using hterm j z
        rw [Finset.sum_eq_single i]
        · rw [hterm', if_pos hi]
        · intro j hj hji
          rw [hterm', if_neg]
          intro hjmem
          exact hji (huniq j hjmem)
        · intro hnot
          exact False.elim (hnot (Finset.mem_univ i))
      exact hsum
    · intro hsum z
      let t : ZMod q.natAbs := (z : ZMod q.natAbs)
      have hsumz :
          (∑ j : Fin m,
            (periodBeattyIndicator (p j) q (r j) (hp j).1 (hp j).2 hq t).val) = 1 := hsum t
      have htermz (j : Fin m) :
          (periodBeattyIndicator (p j) q (r j) (hp j).1 (hp j).2 hq t).val =
            if z ∈ integerTranslatedRationalBeattySet (p j) q (r j) then 1 else 0 := by
        simpa [t] using hterm j z
      have hex : ∃ i : Fin m,
          z ∈ integerTranslatedRationalBeattySet (p i) q (r i) := by
        by_contra hnone
        have hzero : ∀ j : Fin m,
            (periodBeattyIndicator (p j) q (r j) (hp j).1 (hp j).2 hq t).val = 0 := by
          intro j
          rw [htermz, if_neg]
          exact fun hj => hnone ⟨j, hj⟩
        have : (∑ j : Fin m,
            (periodBeattyIndicator (p j) q (r j) (hp j).1 (hp j).2 hq t).val) = 0 := by
          exact Finset.sum_eq_zero (by intro j hj; exact hzero j)
        omega
      obtain ⟨i, hi⟩ := hex
      refine ⟨i, hi, ?_⟩
      intro j hj
      by_contra hne
      have hjmem := hj
      have hiVal :
          (periodBeattyIndicator (p i) q (r i) (hp i).1 (hp i).2 hq t).val = 1 := by
        rw [htermz, if_pos hi]
      have hjVal :
          (periodBeattyIndicator (p j) q (r j) (hp j).1 (hp j).2 hq t).val = 1 := by
        rw [htermz, if_pos hjmem]
      have hjerase : j ∈ (Finset.univ : Finset (Fin m)).erase i := by
        exact Finset.mem_erase.mpr ⟨hne, Finset.mem_univ _⟩
      have hrest :
          (periodBeattyIndicator (p j) q (r j) (hp j).1 (hp j).2 hq t).val ≤
            ∑ k ∈ (Finset.univ : Finset (Fin m)).erase i,
              (periodBeattyIndicator (p k) q (r k) (hp k).1 (hp k).2 hq t).val := by
        have hrest' := Finset.single_le_sum (s :=
            (Finset.univ : Finset (Fin m)).erase i)
          (f := fun k : Fin m =>
            (periodBeattyIndicator (p k) q (r k) (hp k).1 (hp k).2 hq t).val)
          (by intro k hk; exact Nat.zero_le _) hjerase
        simpa using hrest'
      have hsplit := Finset.sum_erase_add (Finset.univ : Finset (Fin m))
        (fun k : Fin m =>
          (periodBeattyIndicator (p k) q (r k) (hp k).1 (hp k).2 hq t).val)
        (Finset.mem_univ i)
      have hsplit' :
          (∑ k ∈ (Finset.univ : Finset (Fin m)).erase i,
            (periodBeattyIndicator (p k) q (r k) (hp k).1 (hp k).2 hq t).val) +
              (periodBeattyIndicator (p i) q (r i) (hp i).1 (hp i).2 hq t).val = 1 := by
        simpa [hsumz] using hsplit
      rw [hiVal] at hsplit'
      omega
  · intro hsum
    constructor
    · simp [discreteFourierTransform]
      rw [Finset.sum_comm]
      have hsum_y (y : Fin q.natAbs) :
          (∑ x : Fin m,
            (periodBeattyIndicator (p x) q (r x) (hp x).1 (hp x).2 hq
              ((y.val : ℕ) : ZMod q.natAbs)).val : ℂ) = 1 := by
        have hn := hsum ((y.val : ℕ) : ZMod q.natAbs)
        have hnC := congrArg (fun n : ℕ => (n : ℂ)) hn
        push_cast at hnC
        simpa using hnC
      simp_rw [hsum_y]
      simp
      all_goals omega
    · intro j hj
      simp only [discreteFourierTransform]
      rw [Finset.sum_comm]
      have hsum_y (y : Fin q.natAbs) :
          (∑ x : Fin m,
            Complex.ofReal (((periodBeattyIndicator (p x) q (r x)
              (hp x).1 (hp x).2 hq ((y.val : ℕ) : ZMod q.natAbs)).val : ℕ) : ℝ)) = 1 := by
        have hn := hsum ((y.val : ℕ) : ZMod q.natAbs)
        have hnC := congrArg (fun n : ℕ => (n : ℂ)) hn
        push_cast at hnC
        simpa using hnC
      simp_rw [← Finset.sum_mul]
      simp_rw [hsum_y]
      simp only [one_mul]
      let ζ : ℂ := Complex.exp (-2 * Complex.ofReal Real.pi * Complex.I *
        (Complex.ofReal (j.val : ℝ) / Complex.ofReal (q : ℝ)))
      have hexp (y : Fin q.natAbs) :
          Complex.exp (-2 * Complex.ofReal Real.pi * Complex.I *
            (Complex.ofReal ((j.val * y.val : ℕ) : ℝ) /
              Complex.ofReal (q : ℝ))) = ζ ^ y.val := by
        dsimp [ζ]
        rw [← Complex.exp_nat_mul]
        congr 1
        push_cast
        ring
      simp_rw [hexp]
      rw [Fin.sum_univ_eq_sum_range]
      have hζpow : ζ ^ q.natAbs = 1 := by
        rw [← Complex.exp_nat_mul]
        dsimp [ζ]
        have hqcastC : (q.natAbs : ℂ) = (q : ℂ) := by
          have hqcastR : (q.natAbs : ℝ) = (q : ℝ) := by
            have hqcastZ : (q.natAbs : ℤ) = q := Int.natAbs_of_nonneg hq.le
            have hqcastR0 := congrArg (fun z : ℤ => (z : ℝ)) hqcastZ
            simpa using hqcastR0
          simpa only [Complex.ofReal_natCast, Complex.ofReal_intCast] using
            congrArg Complex.ofReal hqcastR
        have hqC : (q : ℂ) ≠ 0 := by
          exact_mod_cast (ne_of_gt hq)
        rw [hqcastC]
        convert Complex.exp_int_mul_two_pi_mul_I (-(j.val : ℤ)) using 1
        push_cast
        field_simp [hqC]
      have hζne : ζ ≠ 1 := by
        intro hζ1
        have hexp_one : Complex.exp (-2 * Complex.ofReal Real.pi * Complex.I *
            (Complex.ofReal (j.val : ℝ) / Complex.ofReal (q : ℝ))) = 1 := by
          simpa [ζ] using hζ1
        obtain ⟨n, hn⟩ := (Complex.exp_eq_one_iff).mp hexp_one
        have him := congrArg Complex.im hn
        norm_num at him
        have hqR : 0 < (q : ℝ) := by exact_mod_cast hq
        have hqRne : (q : ℝ) ≠ 0 := ne_of_gt hqR
        have hjR : 0 < (j.val : ℝ) := by exact_mod_cast hj
        have hjltNat : j.val < q.natAbs := ZMod.val_lt j
        have hqcastR : (q.natAbs : ℝ) = (q : ℝ) := by
          have hqcastZ : (q.natAbs : ℤ) = q := Int.natAbs_of_nonneg hq.le
          have hqcastR0 := congrArg (fun z : ℤ => (z : ℝ)) hqcastZ
          simpa using hqcastR0
        have hjltR : (j.val : ℝ) < (q : ℝ) := by
          rw [← hqcastR]
          exact_mod_cast hjltNat
        field_simp [hqRne] at him
        rw [ZMod.cast_eq_val j] at him
        change -(j.val : ℝ) = (q : ℝ) * (n : ℝ) at him
        have hnneg : (n : ℝ) < 0 := by
          nlinarith [him, hjR, hqR]
        have hnnegZ : n < 0 := by exact_mod_cast hnneg
        have hnle : n ≤ -1 := by omega
        have hnleR : (n : ℝ) ≤ -1 := by exact_mod_cast hnle
        nlinarith [him, hjR, hjltR, hqR, hnleR]
      rw [geom_sum_eq hζne q.natAbs]
      rw [hζpow]
      ring

private theorem probe_sine_cyclic_abs (Q x : ℤ) (hQ : 2 ≤ Q) (hx : x % Q ≠ 0) :
    |Real.sin (Real.pi * (x : ℝ) / (Q : ℝ))| =
      Real.sin (Real.pi * (cyclicDistance Q x : ℝ) / (Q : ℝ)) := by
  have hQpos : 0 < Q := by omega
  have hr0 : 0 ≤ x % Q := Int.emod_nonneg x (by omega)
  have hrQ : x % Q < Q := Int.emod_lt_of_pos x hQpos
  have hr1 : 1 ≤ x % Q := by omega
  have hdecomp : x = (x / Q) * Q + x % Q :=
    (Int.ediv_mul_add_emod x Q).symm
  have hQreal : (Q : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hQpos)
  have hypos : 0 < Real.pi * ((x % Q : ℤ) : ℝ) / (Q : ℝ) := by
    positivity
  have hyrpi : Real.pi * ((x % Q : ℤ) : ℝ) / (Q : ℝ) < Real.pi := by
    apply (div_lt_iff₀ (show 0 < (Q : ℝ) by exact_mod_cast hQpos)).2
    have hp : 0 < Real.pi := Real.pi_pos
    exact (mul_lt_mul_of_pos_left (by exact_mod_cast hrQ) hp)
  have hsinpos : 0 < Real.sin
      (Real.pi * ((x % Q : ℤ) : ℝ) / (Q : ℝ)) :=
    Real.sin_pos_of_pos_of_lt_pi hypos hyrpi
  have hdecompR : (x : ℝ) = ((x / Q : ℤ) : ℝ) * (Q : ℝ) +
      ((x % Q : ℤ) : ℝ) := by
    exact_mod_cast hdecomp
  have hangle : Real.pi * (x : ℝ) / (Q : ℝ) =
      Real.pi * ((x % Q : ℤ) : ℝ) / (Q : ℝ) +
        ((x / Q : ℤ) : ℝ) * Real.pi := by
    rw [hdecompR]
    field_simp [hQreal]
    ring
  have habs : |Real.sin (Real.pi * (x : ℝ) / (Q : ℝ))| =
      Real.sin (Real.pi * ((x % Q : ℤ) : ℝ) / (Q : ℝ)) := by
    rw [hangle, Real.sin_add_int_mul_pi]
    have hsign : |((-1 : ℝ) ^ (x / Q))| = 1 := by simp
    rw [abs_mul, hsign, one_mul, abs_of_pos hsinpos]
  rw [habs]
  by_cases hcase : x % Q ≤ Q - x % Q
  · rw [show cyclicDistance Q x = x % Q by
      simp [cyclicDistance, min_eq_left (by omega : x % Q ≤ Q - x % Q)]]
  · have hcase' : Q - x % Q < x % Q := by
      have hlt := lt_of_not_ge hcase
      omega
    rw [show cyclicDistance Q x = Q - x % Q by
      simp [cyclicDistance, min_eq_right (le_of_lt hcase')]]
    have hsinref :
        Real.sin (Real.pi * ((Q - x % Q : ℤ) : ℝ) / (Q : ℝ)) =
          Real.sin (Real.pi * ((x % Q : ℤ) : ℝ) / (Q : ℝ)) := by
      have heq : Real.pi * ((Q - x % Q : ℤ) : ℝ) / (Q : ℝ) =
          Real.pi - Real.pi * ((x % Q : ℤ) : ℝ) / (Q : ℝ) := by
        push_cast
        field_simp [hQreal]
      rw [heq, Real.sin_pi_sub]
    exact hsinref.symm


private theorem probe_min_layer_first_three
    {m : ℕ} (P : RationalBeattyPartition m) (q : ℤ)
    (p r : Fin m → ℤ)
    (hprim : PrimitiveRationalBeattyPartition P q p r)
    (hdistinct : Function.Injective P.moduli)
    (hsub : ∀ i, 3 * p i < q) :
    let g := minimumLayerGcd P q p
    let Q := minimumLayerModulus P q p
    let A := minimumGCDLayer P q p
    UnitRepresentatives Q A ∧
      (∀ a ∈ A, 3 * a < Q) ∧
      (∑ a ∈ A, a) ≤ Q := by
  classical
  let g : ℤ := minimumLayerGcd P q p
  let Q : ℤ := minimumLayerModulus P q p
  let A : Finset ℤ := minimumGCDLayer P q p
  change UnitRepresentatives Q A ∧
      (∀ a ∈ A, 3 * a < Q) ∧
      (∑ a ∈ A, a) ≤ Q
  have hc := hprim.1
  have hp := hprim.2.1
  have hsum : (∑ i, p i) = q := hprim.2.2.1
  have hq : 0 < q := hc.q_pos
  have hI : (Finset.univ.image (fun i : Fin m => layerGcd q p i)).Nonempty := by
    exact Finset.image_nonempty.mpr ⟨⟨0, P.nonempty⟩, Finset.mem_univ _⟩
  have hgi_pos (i : Fin m) : 0 < layerGcd q p i := by
    unfold layerGcd
    exact_mod_cast Int.gcd_pos_of_ne_zero_left q (ne_of_gt (hp i).1)
  have hgm_pos : 0 < g := by
    dsimp [g, minimumLayerGcd]
    have hm := Finset.min'_mem
      (Finset.univ.image (fun i : Fin m => layerGcd q p i)) hI
    obtain ⟨i, hi, hieq⟩ := Finset.mem_image.mp hm
    rw [← hieq]
    exact hgi_pos i
  have hg_mem : g ∈ Finset.univ.image (fun i : Fin m => layerGcd q p i) := by
    dsimp [g, minimumLayerGcd]
    exact Finset.min'_mem _ hI
  obtain ⟨i0, hi0, hi0val⟩ := Finset.mem_image.mp hg_mem
  have hi0g : layerGcd q p i0 = g := hi0val
  have hgd_q : g ∣ q := by
    rw [← hi0g]
    exact Int.gcd_dvd_right (p i0) q
  have hQ_def : Q = q / g := by rfl
  have hQpos : 0 < Q := by
    rw [hQ_def]
    exact Int.ediv_pos_of_pos_of_dvd hq hgm_pos.le hgd_q
  have hQeq : q = g * Q := by
    rw [hQ_def]
    exact (Int.mul_ediv_cancel' hgd_q).symm
  have hIdef : A =
      (Finset.univ.filter (fun i : Fin m => layerGcd q p i = g)).image
        (fun i => p i / g) := by
    rfl
  have hmemI (i : Fin m) (hi : i ∈ Finset.univ.filter
      (fun i : Fin m => layerGcd q p i = g)) :
      layerGcd q p i = g := (Finset.mem_filter.mp hi).2
  have hgd_p (i : Fin m) (hi : i ∈ Finset.univ.filter
      (fun i : Fin m => layerGcd q p i = g)) : g ∣ p i := by
    rw [← hmemI i hi]
    exact Int.gcd_dvd_left (p i) q
  have hQge4 : 4 ≤ Q := by
    have hpi := hp i0
    have hsub0 := hsub i0
    have hgp : g ∣ p i0 := by
      rw [← hi0g]
      exact Int.gcd_dvd_left (p i0) q
    have ha_pos : 0 < p i0 / g := Int.ediv_pos_of_pos_of_dvd hpi.1 hgm_pos.le hgp
    have hlt : 3 * (p i0 / g) < Q := by
      have hmul : g * (3 * (p i0 / g)) = 3 * p i0 := by
        calc
          g * (3 * (p i0 / g)) = 3 * (g * (p i0 / g)) := by ring
          _ = 3 * p i0 := by
            rw [show g * (p i0 / g) = (p i0 / g) * g by ring,
              Int.ediv_mul_cancel hgp]
      apply (Int.mul_lt_mul_left hgm_pos).mp
      calc
        g * (3 * (p i0 / g)) = 3 * p i0 := hmul
        _ < q := hsub0
        _ = g * Q := hQeq
    omega
  have hA_mem (a : ℤ) (ha : a ∈ A) :
      ∃ i : Fin m, i ∈ Finset.univ.filter
        (fun i : Fin m => layerGcd q p i = g) ∧ p i / g = a := by
    rw [hIdef] at ha
    exact Finset.mem_image.mp ha
  have hA_pos (a : ℤ) (ha : a ∈ A) : 0 < a := by
    obtain ⟨i, hi, hia⟩ := hA_mem a ha
    rw [← hia]
    exact Int.ediv_pos_of_pos_of_dvd (hp i).1 hgm_pos.le (hgd_p i hi)
  have hA_upper (a : ℤ) (ha : a ∈ A) : 3 * a < Q := by
    obtain ⟨i, hi, hia⟩ := hA_mem a ha
    rw [← hia]
    have hmul : g * (3 * (p i / g)) = 3 * p i := by
      calc
        g * (3 * (p i / g)) = 3 * (g * (p i / g)) := by ring
        _ = 3 * p i := by
          rw [show g * (p i / g) = (p i / g) * g by ring,
            Int.ediv_mul_cancel (hgd_p i hi)]
    apply (Int.mul_lt_mul_left hgm_pos).mp
    calc
      g * (3 * (p i / g)) = 3 * p i := hmul
      _ < q := hsub i
      _ = g * Q := hQeq
  have hA_coprime (a : ℤ) (ha : a ∈ A) : Int.gcd a Q = 1 := by
    obtain ⟨i, hi, hia⟩ := hA_mem a ha
    rw [← hia, hQ_def]
    have hgcd : (Int.gcd (p i) q : ℤ) = g := by
      simpa [layerGcd] using hmemI i hi
    have h := Int.gcd_ediv (hgd_p i hi) hgd_q
    have hgnat : (g.natAbs : ℤ) = g := Int.natAbs_of_nonneg hgm_pos.le
    have hgcdNat : Int.gcd (p i) q = g.natAbs := by
      have hcast : ((Int.gcd (p i) q : ℕ) : ℤ) = (g.natAbs : ℤ) := by
        calc
          ((Int.gcd (p i) q : ℕ) : ℤ) = g := hgcd
          _ = (g.natAbs : ℤ) := hgnat.symm
      exact_mod_cast hcast
    rw [hgcdNat] at h
    have hgnatpos : 0 < g.natAbs := Int.natAbs_pos.mpr hgm_pos.ne'
    simpa [Nat.div_self hgnatpos] using h
  have hp_inj : Function.Injective p := by
    intro i j hij
    apply hdistinct
    have hm : (P.moduli i : ℝ) = (P.moduli j : ℝ) := by
      rw [← hc.modulus_eq i, ← hc.modulus_eq j, hij]
    exact_mod_cast hm
  have hf_injI (i j : Fin m)
      (hi : i ∈ Finset.univ.filter (fun i : Fin m => layerGcd q p i = g))
      (hj : j ∈ Finset.univ.filter (fun i : Fin m => layerGcd q p i = g))
      (hij : p i / g = p j / g) : i = j := by
    apply hp_inj
    calc
      p i = (p i / g) * g := (Int.ediv_mul_cancel (hgd_p i hi)).symm
      _ = (p j / g) * g := by rw [hij]
      _ = p j := Int.ediv_mul_cancel (hgd_p j hj)
  refine ⟨?_, hA_upper, ?_⟩
  · refine ⟨?_, ?_⟩
    · intro a ha
      exact ⟨hA_pos a ha, hA_coprime a ha⟩
    · intro a ha b hb hab
      have hapos := hA_pos a ha
      have hbpos := hA_pos b hb
      have haQ : a < Q := by nlinarith [hA_upper a ha]
      have hbQ : b < Q := by nlinarith [hA_upper b hb]
      have hamod : a % Q = a := Int.emod_eq_of_lt (by omega) haQ
      have hbmod : b % Q = b := Int.emod_eq_of_lt (by omega) hbQ
      change a % Q = b % Q at hab
      rw [hamod, hbmod] at hab
      exact hab
  · have hsumI : (∑ i ∈ (Finset.univ.filter
          (fun i : Fin m => layerGcd q p i = g)), p i) ≤ q := by
      have hle := Finset.sum_le_sum_of_subset_of_nonneg
        (s := Finset.univ.filter (fun i : Fin m => layerGcd q p i = g))
        (t := (Finset.univ : Finset (Fin m))) (f := p)
        (Finset.filter_subset _ _)
        (by
          intro i hi hnot
          exact (hp i).1.le)
      rw [hsum] at hle
      exact hle

    have hsumQuot : (∑ i ∈ (Finset.univ.filter
          (fun i : Fin m => layerGcd q p i = g)), p i / g) ≤ Q := by
      have hmul : g * (∑ i ∈ (Finset.univ.filter
          (fun i : Fin m => layerGcd q p i = g)), p i / g) =
          ∑ i ∈ (Finset.univ.filter
            (fun i : Fin m => layerGcd q p i = g)), p i := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro i hi
        calc
          g * (p i / g) = (p i / g) * g := by ring
          _ = p i := Int.ediv_mul_cancel (hgd_p i hi)
      have hqmul : g * Q = q := hQeq.symm
      nlinarith [hsumI, hmul, hqmul, hgm_pos]
    rw [hIdef]
    rw [Finset.sum_image]
    · exact hsumQuot
    · intro a ha b hb hab
      exact hf_injI a b ha hb hab


/-- The minimum-gcd Fourier layer has the subcritical representative bounds and
row inequalities. -/
-- zpi: prop-minimum-gcd-fourier-layer
theorem minimumGCDFourierLayer
    {m : ℕ} (P : RationalBeattyPartition m) (q : ℤ)
    (p r : Fin m → ℤ)
    (hprim : PrimitiveRationalBeattyPartition P q p r)
    (hdistinct : Function.Injective P.moduli)
    (hsub : ∀ i, 3 * p i < q) :
    let g := minimumLayerGcd P q p
    let Q := minimumLayerModulus P q p
    let A := minimumGCDLayer P q p
    UnitRepresentatives Q A ∧
      (∀ a ∈ A, 3 * a < Q) ∧
      (∑ a ∈ A, a) ≤ Q ∧
      (∀ a ∈ A, 1 ≤ inverseSineRowMass Q A a) := by
  classical
  let g : ℤ := minimumLayerGcd P q p
  let Q : ℤ := minimumLayerModulus P q p
  let A : Finset ℤ := minimumGCDLayer P q p
  change UnitRepresentatives Q A ∧
      (∀ a ∈ A, 3 * a < Q) ∧
      (∑ a ∈ A, a) ≤ Q ∧
      (∀ a ∈ A, 1 ≤ inverseSineRowMass Q A a)
  have harith := probe_min_layer_first_three P q p r hprim hdistinct hsub
  have hunit := harith.1
  have hupper := harith.2.1
  have hsumA := harith.2.2
  have hc := hprim.1
  have hp := hprim.2.1
  have hsum : (∑ i, p i) = q := hprim.2.2.1
  have hq : 0 < q := hc.q_pos
  have hI : (Finset.univ.image (fun i : Fin m => layerGcd q p i)).Nonempty := by
    exact Finset.image_nonempty.mpr ⟨⟨0, P.nonempty⟩, Finset.mem_univ _⟩
  have hgi_pos (i : Fin m) : 0 < layerGcd q p i := by
    unfold layerGcd
    exact_mod_cast Int.gcd_pos_of_ne_zero_left q (ne_of_gt (hp i).1)
  have hgm_pos : 0 < g := by
    dsimp [g, minimumLayerGcd]
    have hm := Finset.min'_mem
      (Finset.univ.image (fun i : Fin m => layerGcd q p i)) hI
    obtain ⟨i, hi, hieq⟩ := Finset.mem_image.mp hm
    rw [← hieq]
    exact hgi_pos i
  have hg_mem : g ∈ Finset.univ.image (fun i : Fin m => layerGcd q p i) := by
    dsimp [g, minimumLayerGcd]
    exact Finset.min'_mem _ hI
  obtain ⟨i0, hi0, hi0val⟩ := Finset.mem_image.mp hg_mem
  have hi0g : layerGcd q p i0 = g := hi0val
  have hgd_q : g ∣ q := by
    rw [← hi0g]
    exact Int.gcd_dvd_right (p i0) q
  have hQ_def : Q = q / g := by rfl
  have hQpos : 0 < Q := by
    rw [hQ_def]
    exact Int.ediv_pos_of_pos_of_dvd hq hgm_pos.le hgd_q
  have hQeq : q = g * Q := by
    rw [hQ_def]
    exact (Int.mul_ediv_cancel' hgd_q).symm
  have hIdef : A =
      (Finset.univ.filter (fun i : Fin m => layerGcd q p i = g)).image
        (fun i => p i / g) := by
    rfl
  have hA_mem (a : ℤ) (ha : a ∈ A) :
      ∃ i : Fin m, i ∈ Finset.univ.filter
        (fun i : Fin m => layerGcd q p i = g) ∧ p i / g = a := by
    rw [hIdef] at ha
    exact Finset.mem_image.mp ha
  have hmemI (i : Fin m) (hi : i ∈ Finset.univ.filter
      (fun i : Fin m => layerGcd q p i = g)) :
      layerGcd q p i = g := (Finset.mem_filter.mp hi).2
  have hgd_p (i : Fin m) (hi : i ∈ Finset.univ.filter
      (fun i : Fin m => layerGcd q p i = g)) : g ∣ p i := by
    rw [← hmemI i hi]
    exact Int.gcd_dvd_left (p i) q
  have hgi_ge (i : Fin m) : g ≤ layerGcd q p i := by
    dsimp [g, minimumLayerGcd]
    apply Finset.min'_le
    exact Finset.mem_image.mpr ⟨i, Finset.mem_univ _, rfl⟩
  have hQge4 : 4 ≤ Q := by
    have hAne : A.Nonempty := by
      dsimp [A, minimumGCDLayer]
      apply Finset.image_nonempty.mpr
      refine ⟨i0, ?_⟩
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hi0val⟩
    obtain ⟨a, ha⟩ := hAne
    have ha_pos := hunit.1 a ha |>.1
    have ha_upper := hupper a ha
    omega
  have hpart : rationalBeattySetsPartition q p r := by
    intro z
    obtain ⟨i, hi, huniq⟩ := P.partition z
    refine ⟨i, ?_, ?_⟩
    · simpa [hc.set_eq i] using hi
    · intro j hj
      apply huniq j
      simpa [hc.set_eq j] using hj
  have hind := (fourierCoveringIdentityForRationalBeattyPartition q p r hp hc.q_pos).1.1 hpart
  have hzero (j : ZMod q.natAbs) (hj : 0 < j.val) :
      ∑ i : Fin m,
        discreteFourierTransform q hc.q_pos
          (fun t => Complex.ofReal
            ((periodBeattyIndicator (p i) q (r i) (hp i).1 (hp i).2 hc.q_pos t).val : ℝ)) j = 0 :=
    (fourierCoveringIdentityForRationalBeattyPartition q p r hp hc.q_pos).2 hind |>.2 j hj
  have hdata (i : Fin m) :
      0 < p i ∧ p i < q ∧ 1 ≤ inverseMod (q / layerGcd q p i) (p i / layerGcd q p i) ∧
      inverseMod (q / layerGcd q p i) (p i / layerGcd q p i) < q / layerGcd q p i ∧
      (p i / layerGcd q p i) * inverseMod (q / layerGcd q p i) (p i / layerGcd q p i) %
          (q / layerGcd q p i) = 1 := by
    have hgi := hgi_pos i
    have hgp : layerGcd q p i ∣ p i := by
      exact Int.gcd_dvd_left (p i) q
    have hgq : layerGcd q p i ∣ q := by
      exact Int.gcd_dvd_right (p i) q
    have hQi : 0 < q / layerGcd q p i :=
      Int.ediv_pos_of_pos_of_dvd hq hgi.le hgq
    have hredpos : 0 < p i / layerGcd q p i :=
      Int.ediv_pos_of_pos_of_dvd (hp i).1 hgi.le hgp
    have hredlt : p i / layerGcd q p i < q / layerGcd q p i := by
      apply (Int.mul_lt_mul_left hgi).mp
      calc
        layerGcd q p i * (p i / layerGcd q p i) = p i := by
          rw [show layerGcd q p i * (p i / layerGcd q p i) =
            (p i / layerGcd q p i) * layerGcd q p i by ring,
            Int.ediv_mul_cancel hgp]
        _ < q := (hp i).2
        _ = layerGcd q p i * (q / layerGcd q p i) :=
          (Int.mul_ediv_cancel' hgq).symm
    have hcop : Int.gcd (p i / layerGcd q p i) (q / layerGcd q p i) = 1 := by
      have hh := Int.gcd_ediv hgp hgq
      have hgcdNat : Int.gcd (p i) q = (layerGcd q p i).natAbs := by
        simp [layerGcd, Int.natAbs_of_nonneg hgi.le]
      rw [hgcdNat] at hh
      simpa [Nat.div_self (Int.natAbs_pos.mpr hgi.ne')] using hh
    let u := inverseMod (q / layerGcd q p i) (p i / layerGcd q p i)
    have hu := inverseMod_spec (q / layerGcd q p i)
      (p i / layerGcd q p i) (by omega) hcop
    exact ⟨(hp i).1, (hp i).2, hu.1.1, hu.1.2, hu.2⟩
  have hfi (i : Fin m) (j : ZMod q.natAbs) (hj : 0 < j.val) :
      discreteFourierTransform q hc.q_pos
          (fun t => Complex.ofReal
            ((periodBeattyIndicator (p i) q (r i) (hp i).1 (hp i).2 hc.q_pos t).val : ℝ)) j =
        if (layerGcd q p i : ℤ) ∣ (j.val : ℤ) then
          ((layerGcd q p i : ℤ) : ℂ) *
            (1 - cyclicFourierOmegaPower q (j.val : ℤ)) /
            (1 - cyclicFourierOmegaPower q ((j.val : ℤ) *
              inverseMod (q / layerGcd q p i) (p i / layerGcd q p i))) *
            cyclicFourierOmegaPower q (-((j.val : ℤ) * r i)) else 0 := by
    have hd := hdata i
    have hf := fourierTransformOfRationalBeattyPeriodIndicator
      (p i) q (r i) (hp i).1 (hp i).2 hc.q_pos j hj
      (inverseMod (q / layerGcd q p i) (p i / layerGcd q p i))
      hd.2.2.1 hd.2.2.2.1 hd.2.2.2.2
    exact hf.2.2.1
  refine ⟨hunit, hupper, hsumA, ?_⟩
  intro a ha
  obtain ⟨ik, hik, hika⟩ := hA_mem a ha
  have hqNat : 0 < q.natAbs := Int.natAbs_pos.mpr hq.ne'
  letI : NeZero q.natAbs := ⟨Nat.ne_of_gt hqNat⟩
  let j : ZMod q.natAbs := (p ik : ZMod q.natAbs)
  have hjval : (j.val : ℤ) = p ik := by
    dsimp [j]
    rw [ZMod.val_intCast]
    rw [Int.natAbs_of_nonneg hq.le]
    have hpik0 : (0 : ℤ) ≤ p ik := (hp ik).1.le
    exact Int.emod_eq_of_lt hpik0 (hp ik).2
  have hjvalR : (j.val : ℝ) = (p ik : ℝ) := by exact_mod_cast hjval
  have hj : 0 < j.val := by
    have hpik : (0 : ℤ) < (j.val : ℤ) := by
      rw [hjval]
      exact (hp ik).1
    exact_mod_cast hpik
  have hlayer_iff (i : Fin m) :
      (layerGcd q p i : ℤ) ∣ (j.val : ℤ) ↔
        i ∈ Finset.univ.filter (fun i : Fin m => layerGcd q p i = g) := by
    rw [hjval]
    constructor
    · intro hd
      have hgiq : layerGcd q p i ∣ q := Int.gcd_dvd_right (p i) q
      have hgid : Int.gcd (p i) q ∣ Int.gcd (p ik) q := by
        apply Int.dvd_gcd
        · exact hd
        · exact hgiq
      have hgcdposZ : (0 : ℤ) < (Int.gcd (p ik) q : ℤ) := by
        simpa [layerGcd] using hgi_pos ik
      have hgcdpos : 0 < Int.gcd (p ik) q := by
        exact_mod_cast hgcdposZ
      have hgidle : Int.gcd (p i) q ≤ Int.gcd (p ik) q :=
        Nat.le_of_dvd (by exact_mod_cast hgcdpos) hgid
      have hleZ : (Int.gcd (p i) q : ℤ) ≤ (Int.gcd (p ik) q : ℤ) := by
        exact_mod_cast hgidle
      have hle : layerGcd q p i ≤ layerGcd q p ik := by
        simpa [layerGcd] using hleZ
      have hikg : layerGcd q p ik = g := hmemI ik hik
      have heq : layerGcd q p i = g := by
        apply le_antisymm
        · exact hle.trans_eq hikg
        · exact hgi_ge i
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, heq⟩
    · intro hi
      rw [hmemI i hi]
      exact hgd_p ik hik
  let I : Finset (Fin m) := Finset.univ.filter
    (fun i : Fin m => layerGcd q p i = g)
  let F : Fin m → ℂ := fun i =>
    discreteFourierTransform q hc.q_pos
      (fun t => Complex.ofReal
        ((periodBeattyIndicator (p i) q (r i) (hp i).1 (hp i).2 hc.q_pos t).val : ℝ)) j
  have hsumI : (∑ i ∈ I, F i) = 0 := by
    have hsumall : (∑ i : Fin m, F i) = 0 := by
      exact hzero j hj
    apply (Finset.sum_subset (Finset.filter_subset _ _) ?_).trans hsumall
    intro i hi hnot
    have hnotdiv : ¬ (layerGcd q p i : ℤ) ∣ (j.val : ℤ) := by
      intro hdiv
      exact hnot ((hlayer_iff i).mp hdiv)
    change F i = 0
    have hFi : F i =
        if (layerGcd q p i : ℤ) ∣ (j.val : ℤ) then
          ((layerGcd q p i : ℤ) : ℂ) *
            (1 - cyclicFourierOmegaPower q (j.val : ℤ)) /
            (1 - cyclicFourierOmegaPower q ((j.val : ℤ) *
              inverseMod (q / layerGcd q p i) (p i / layerGcd q p i))) *
            cyclicFourierOmegaPower q (-((j.val : ℤ) * r i)) else 0 := by
      dsimp [F]
      exact hfi i j hj
    rw [hFi, if_neg hnotdiv]
  have hikI : ik ∈ I := by
    dsimp [I]
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hmemI ik hik⟩
  have hsplit := Finset.sum_erase_add I F hikI
  have hsum_erase : (∑ i ∈ I.erase ik, F i) + F ik = 0 := by
    rw [hsumI] at hsplit
    exact hsplit
  have hnorm_le : ‖F ik‖ ≤ ∑ i ∈ I.erase ik, ‖F i‖ := by
    have hneg : F ik = - (∑ i ∈ I.erase ik, F i) :=
      eq_neg_of_add_eq_zero_right hsum_erase
    rw [hneg, norm_neg]
    exact norm_sum_le _ _
  have hposg : (0 : ℝ) < g := by exact_mod_cast hgm_pos
  have hposnum : 0 < Real.sin (Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ)) := by
    rw [hika]
    have hpa := hunit.1 a ha |>.1
    have ha1 : 1 ≤ a := by omega
    have ha_upper := hupper a ha
    have haQ : 2 * a ≤ Q := by omega
    have hh := kernelAngleBounds Q a (by omega) ha1 haQ
    exact Real.sin_pos_of_pos_of_lt_pi hh.2.2.1
      (lt_of_le_of_lt hh.2.2.2 (by linarith [Real.pi_pos]))
  have hcop_ak : Int.gcd (p ik / g) Q = 1 := by
    have ha := hunit.1 a ha |>.2
    simpa [hika] using ha
  have hprod_ne_unit (x u : ℤ) (hcop : Int.gcd x Q = 1)
      (hu1 : 1 ≤ u) (huQ : u < Q) : x * u % Q ≠ 0 := by
    intro hz
    have hQdvd : Q ∣ x * u := Int.dvd_of_emod_eq_zero hz
    have hbez := Int.gcd_eq_gcd_ab x Q
    rw [hcop] at hbez
    obtain ⟨t, ht⟩ := hQdvd
    have hQdvd_u : Q ∣ u := by
      refine ⟨Int.gcdA x Q * t + Int.gcdB x Q * u, ?_⟩
      calc
        u = 1 * u := by ring
        _ = (x * (Int.gcdA x Q) + Q * (Int.gcdB x Q)) * u := by
          rw [← hbez]
          norm_num
        _ = (x * u) * (Int.gcdA x Q) + Q * (Int.gcdB x Q) * u := by ring
        _ = (Q * t) * (Int.gcdA x Q) + Q * (Int.gcdB x Q) * u := by rw [ht]
        _ = Q * (Int.gcdA x Q * t + Int.gcdB x Q * u) := by ring
    obtain ⟨k, hk⟩ := hQdvd_u
    have hkpos : 0 < k := by nlinarith
    have hQle : Q ≤ u := by nlinarith
    omega
  have hnorm_layer (i : Fin m) (hi : i ∈ I) :
      ‖F i‖ = (g : ℝ) *
        (Real.sin (Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ)) /
          Real.sin (Real.pi *
            (cyclicDistance Q ((p ik / g) *
              inverseMod Q (p i / g)) : ℝ) / (Q : ℝ))) := by
    have hgi_eq : layerGcd q p i = g := by
      exact hmemI i hi
    have hgi_q : (Int.gcd (p i) q : ℤ) = g := by
      simpa [layerGcd] using hgi_eq
    have hdi := hdata i
    let ui : ℤ := inverseMod (q / layerGcd q p i) (p i / layerGcd q p i)
    have hUi : ui = inverseMod Q (p i / g) := by
      dsimp [ui]
      rw [hgi_eq, hQ_def]
    have hf := fourierTransformOfRationalBeattyPeriodIndicator
      (p i) q (r i) (hp i).1 (hp i).2 hc.q_pos j hj ui
      hdi.2.2.1 hdi.2.2.2.1 hdi.2.2.2.2
    have hbar := hf.1
    have hq1 : 1 < q := by omega
    have hExt := External.GrahamObryant2005.fourierTransformOfRationalBeattySet
      (p i) q (r i) ui (hp i).1 hq1 hbar
    have hnormExt := hExt.2.2 j hj
    have hbridge := probe_discrete_fourier_eq_external (p i) q (r i) (hp i).1 (hp i).2 hc.q_pos j
    have hdiv : (Int.gcd (p i) q : ℤ) ∣ (j.val : ℤ) := by
      simpa [layerGcd] using (hlayer_iff i).mpr hi
    have hpik_eq : p ik = g * (p ik / g) := by
      calc
        p ik = (p ik / g) * g := (Int.ediv_mul_cancel (hgd_p ik hik)).symm
        _ = g * (p ik / g) := by ring
    have hpi_eq : p i = g * (p i / g) := by
      calc
        p i = (p i / layerGcd q p i) * layerGcd q p i :=
          (Int.ediv_mul_cancel (Int.gcd_dvd_left (p i) q)).symm
        _ = (p i / g) * g := by rw [hgi_eq]
        _ = g * (p i / g) := by ring
    have hnumangle :
        Real.pi * (j.val : ℝ) / (q : ℝ) =
          Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ) := by
      rw [hjvalR, hpik_eq, hQeq]
      push_cast
      have hquot : g * (p ik / g) / g = p ik / g :=
        Int.mul_ediv_cancel_left _ hgm_pos.ne'
      rw [hquot]
      field_simp [hgm_pos.ne']
    have hdenangle :
        Real.pi * (((j.val : ℤ) * ui : ℤ) : ℝ) / (q : ℝ) =
          Real.pi * (((p ik / g) * inverseMod Q (p i / g) : ℤ) : ℝ) / (Q : ℝ) := by
      rw [hjval, hUi, hpik_eq, hQeq]
      push_cast
      have hquot : g * (p ik / g) / g = p ik / g :=
        Int.mul_ediv_cancel_left _ hgm_pos.ne'
      rw [hquot]
      field_simp [hgm_pos.ne']
    have hcop_a : Int.gcd (p ik / g) Q = 1 := by
      have ha := hunit.1 a ha |>.2
      simpa [hika] using ha
    have hprod_ne : ((p ik / g) * inverseMod Q (p i / g) : ℤ) % Q ≠ 0 := by
      have hcop_prod : (p ik / g) * inverseMod Q (p i / g) % Q ≠ 0 := by
        intro hz
        have hQdvd : Q ∣ (p ik / g) * inverseMod Q (p i / g) :=
          Int.dvd_of_emod_eq_zero hz
        have hbez := Int.gcd_eq_gcd_ab (p ik / g) Q
        rw [hcop_a] at hbez
        obtain ⟨t, ht⟩ := hQdvd
        have hQdvd_ui : Q ∣ inverseMod Q (p i / g) := by
          refine ⟨Int.gcdA (p ik / g) Q * t + Int.gcdB (p ik / g) Q *
            inverseMod Q (p i / g), ?_⟩
          calc
            inverseMod Q (p i / g) = 1 * inverseMod Q (p i / g) := by ring
            _ = ((p ik / g) * (p ik / g).gcdA Q +
                Q * (p ik / g).gcdB Q) * inverseMod Q (p i / g) := by
              rw [← hbez]
              norm_num
            _ = ((p ik / g) * inverseMod Q (p i / g)) *
                (p ik / g).gcdA Q +
                Q * (p ik / g).gcdB Q * inverseMod Q (p i / g) := by ring
            _ = (Q * t) * (p ik / g).gcdA Q +
                Q * (p ik / g).gcdB Q * inverseMod Q (p i / g) := by
              rw [ht]
            _ = Q * (Int.gcdA (p ik / g) Q * t +
                Int.gcdB (p ik / g) Q * inverseMod Q (p i / g)) := by ring
        have hui_lt : inverseMod Q (p i / g) < Q := by
          simpa [ui, hgi_eq, hQ_def] using hdi.2.2.2.1
        have hui_pos : 1 ≤ inverseMod Q (p i / g) := by
          simpa [ui, hgi_eq, hQ_def] using hdi.2.2.1
        obtain ⟨k, hk⟩ := hQdvd_ui
        have hkpos : 0 < k := by nlinarith
        have hQle : Q ≤ inverseMod Q (p i / g) := by nlinarith
        nlinarith
      exact hcop_prod
    have hsine := probe_sine_cyclic_abs Q
      ((p ik / g) * inverseMod Q (p i / g)) (by omega) hprod_ne
    have hnormcalc :
        ‖(Int.gcd (p i) q : ℂ) *
            (Real.sin (Real.pi * (j.val : ℝ) / (q : ℝ)) /
              Real.sin (Real.pi * (((j.val : ℤ) * ui : ℤ) : ℝ) / (q : ℝ)))‖ =
          (g : ℝ) *
            (Real.sin (Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ)) /
              Real.sin (Real.pi *
                (cyclicDistance Q ((p ik / g) * inverseMod Q (p i / g)) : ℝ) / (Q : ℝ))) := by
      have hgi_qC : (Int.gcd (p i) q : ℂ) = (g : ℂ) := by
        exact_mod_cast hgi_q
      rw [hgi_qC, hnumangle, hdenangle]
      simp only [norm_mul, norm_div, Complex.norm_real]
      have hg_norm : ‖(g : ℝ)‖ = (g : ℝ) := by
        rw [Real.norm_eq_abs, abs_of_pos hposg]
      have hnum_norm :
          ‖Real.sin (Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ))‖ =
            Real.sin (Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ)) := by
        rw [Real.norm_eq_abs, abs_of_pos hposnum]
      rw [Complex.norm_intCast, Real.norm_eq_abs, abs_of_pos hposg,
        abs_of_pos hposnum, Real.norm_eq_abs, hsine]
    calc
      ‖F i‖ = ‖External.GrahamObryant2005.rationalBeattyFourierTransform
          (p i) q (r i) j‖ := by
        simpa [F] using congrArg norm hbridge
      _ = ‖(Int.gcd (p i) q : ℂ) *
            (Real.sin (Real.pi * (j.val : ℝ) / (q : ℝ)) /
              Real.sin (Real.pi * (((j.val : ℤ) * ui : ℤ) : ℝ) / (q : ℝ)))‖ := by
        rw [hnormExt, if_pos hdiv]
      _ = (g : ℝ) *
            (Real.sin (Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ)) /
              Real.sin (Real.pi *
                (cyclicDistance Q ((p ik / g) * inverseMod Q (p i / g)) : ℝ) / (Q : ℝ))) := hnormcalc
  have hnorm_k : ‖F ik‖ = (g : ℝ) *
        (Real.sin (Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ)) /
          Real.sin (Real.pi /
            (Q : ℝ))) := by
    have hu := inverseMod_spec Q (p ik / g) (by omega) hcop_ak
    have hdist : cyclicDistance Q ((p ik / g) *
        inverseMod Q (p ik / g)) = 1 := by
      rw [cyclicDistance_spec Q
        ((p ik / g) * inverseMod Q (p ik / g)) 1 (by omega) (by omega) hu.2]
      omega
    have hk := hnorm_layer ik hikI
    rw [hdist] at hk
    convert hk using 1 <;> norm_num
  have hsin1 : 0 < Real.sin (Real.pi / (Q : ℝ)) := by
    have hh := kernelAngleBounds Q 1 (by omega) (by omega) (by omega)
    exact Real.sin_pos_of_pos_of_lt_pi hh.1 (by linarith [Real.pi_pos])
  have hnorm_k_pos : 0 < ‖F ik‖ := by
    rw [hnorm_k]
    positivity
  have hp_inj : Function.Injective p := by
    intro i j hij
    apply hdistinct
    have hm : (P.moduli i : ℝ) = (P.moduli j : ℝ) := by
      rw [← hc.modulus_eq i, ← hc.modulus_eq j, hij]
    exact_mod_cast hm
  have hphi_inj (i j : Fin m) (hi : i ∈ I) (hj : j ∈ I)
      (hij : p i / g = p j / g) : i = j := by
    apply hp_inj
    have hi' : i ∈ Finset.univ.filter
        (fun i : Fin m => layerGcd q p i = g) := by simpa [I] using hi
    have hj' : j ∈ Finset.univ.filter
        (fun i : Fin m => layerGcd q p i = g) := by simpa [I] using hj
    calc
      p i = (p i / g) * g := (Int.ediv_mul_cancel (hgd_p i hi')).symm
      _ = (p j / g) * g := by rw [hij]
      _ = p j := Int.ediv_mul_cancel (hgd_p j hj')
  have himage : (I.erase ik).image (fun i => p i / g) = A.erase a := by
    ext b
    constructor
    · intro hb
      obtain ⟨i, hi, hib⟩ := Finset.mem_image.mp hb
      have hiI : i ∈ I := (Finset.mem_erase.mp hi).2
      have hi' : i ∈ Finset.univ.filter
          (fun i : Fin m => layerGcd q p i = g) := by simpa [I] using hiI
      have hbA : b ∈ A := by
        rw [hIdef]
        exact Finset.mem_image.mpr ⟨i, hi', hib⟩
      have hba : b ≠ a := by
        intro hba
        have hphi : p i / g = p ik / g := by rw [hib, hba, hika]
        have hieq := hphi_inj i ik hiI hik hphi
        exact (Finset.mem_erase.mp hi).1 hieq
      exact Finset.mem_erase.mpr ⟨hba, hbA⟩
    · intro hb
      have hbA := (Finset.mem_erase.mp hb).2
      obtain ⟨i, hi', hib⟩ := hA_mem b hbA
      have hiI : i ∈ I := by simpa [I] using hi'
      have hine : i ≠ ik := by
        intro hieq
        apply (Finset.mem_erase.mp hb).1
        rw [← hib, hieq, hika]
      exact Finset.mem_image.mpr
        ⟨i, Finset.mem_erase.mpr ⟨hine, hiI⟩, hib⟩
  have hsum_map :
      (∑ i ∈ I.erase ik, (1 : ℝ) /
        Real.sin (Real.pi *
          (cyclicDistance Q ((p ik / g) * inverseMod Q (p i / g)) : ℝ) / (Q : ℝ))) =
      ∑ b ∈ A.erase a, (1 : ℝ) /
        Real.sin (Real.pi *
          (cyclicDistance Q (a * inverseMod Q b) : ℝ) / (Q : ℝ)) := by
    rw [← himage]
    rw [Finset.sum_image]
    · apply Finset.sum_congr rfl
      intro i hi
      rw [hika]
    · intro i hi j hj hij
      apply hphi_inj i j
      · exact Finset.mem_of_mem_erase hi
      · exact Finset.mem_of_mem_erase hj
      · exact hij
  have hnorm_sum :
      (∑ i ∈ I.erase ik, ‖F i‖) =
        (g : ℝ) * Real.sin (Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ)) *
          ∑ i ∈ I.erase ik, (1 : ℝ) /
            Real.sin (Real.pi *
              (cyclicDistance Q ((p ik / g) * inverseMod Q (p i / g)) : ℝ) / (Q : ℝ)) := by
    calc
      _ = ∑ i ∈ I.erase ik, (g : ℝ) *
          (Real.sin (Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ)) /
            Real.sin (Real.pi *
              (cyclicDistance Q ((p ik / g) * inverseMod Q (p i / g)) : ℝ) / (Q : ℝ))) := by
        apply Finset.sum_congr rfl
        intro i hi
        rw [hnorm_layer i (Finset.mem_of_mem_erase hi)]
      _ = _ := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro i hi
        ring
  have hineq := hnorm_le
  rw [hnorm_k, hnorm_sum] at hineq
  have hC : 0 < (g : ℝ) *
      Real.sin (Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ)) :=
    mul_pos hposg hposnum
  have hineq' :
      ((g : ℝ) * Real.sin (Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ))) *
          (1 / Real.sin (Real.pi / (Q : ℝ))) ≤
        ((g : ℝ) * Real.sin (Real.pi * ((p ik / g : ℤ) : ℝ) / (Q : ℝ))) *
          (∑ i ∈ I.erase ik, (1 : ℝ) /
            Real.sin (Real.pi *
              (cyclicDistance Q ((p ik / g) * inverseMod Q (p i / g)) : ℝ) / (Q : ℝ))) := by
    convert hineq using 1 <;> ring
  have hsum_inv :
      1 / Real.sin (Real.pi / (Q : ℝ)) ≤
        ∑ i ∈ I.erase ik, (1 : ℝ) /
          Real.sin (Real.pi *
            (cyclicDistance Q ((p ik / g) * inverseMod Q (p i / g)) : ℝ) / (Q : ℝ)) :=
    le_of_mul_le_mul_left hineq' hC
  have hmassI : 1 ≤ Real.sin (Real.pi / (Q : ℝ)) *
      ∑ i ∈ I.erase ik, (1 : ℝ) /
        Real.sin (Real.pi *
          (cyclicDistance Q ((p ik / g) * inverseMod Q (p i / g)) : ℝ) / (Q : ℝ)) := by
    have hh := (div_le_iff₀ hsin1).mp hsum_inv
    simpa [mul_comm] using hh
  have hmass : inverseSineRowMass Q A a =
      Real.sin (Real.pi / (Q : ℝ)) *
        ∑ i ∈ I.erase ik, (1 : ℝ) /
          Real.sin (Real.pi *
            (cyclicDistance Q ((p ik / g) * inverseMod Q (p i / g)) : ℝ) / (Q : ℝ)) := by
    unfold inverseSineRowMass
    calc
      (∑ b ∈ A.erase a, inverseSineKernel Q
          (cyclicDistance Q (a * inverseMod Q b))) =
          ∑ b ∈ A.erase a, Real.sin (Real.pi / (Q : ℝ)) /
            Real.sin (Real.pi *
              (cyclicDistance Q (a * inverseMod Q b) : ℝ) / (Q : ℝ)) := by
        rfl
      _ = Real.sin (Real.pi / (Q : ℝ)) *
          ∑ b ∈ A.erase a, (1 : ℝ) /
            Real.sin (Real.pi *
              (cyclicDistance Q (a * inverseMod Q b) : ℝ) / (Q : ℝ)) := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro b hb
        ring
      _ = _ := by rw [← hsum_map]
  rw [hmass]
  exact hmassI


end Fraenkel
