import Fraenkel.Beatty.Normalization
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Data.ZMod.Basic

namespace Fraenkel

open scoped BigOperators Classical

/-- The discrete Fourier transform on the cyclic quotient `ℤ/qℤ`, represented
by `ZMod q.natAbs` and the canonical representatives `0,...,q-1`. -/
-- zpi: def-discrete-fourier-transform-on-cyclic-group
noncomputable def discreteFourierTransform (q : ℤ) (_hq : 0 < q)
    (f : ZMod q.natAbs → ℂ) : ZMod q.natAbs → ℂ :=
  fun j =>
    ∑ t : Fin q.natAbs,
      f ((t.val : ℕ) : ZMod q.natAbs) *
        Complex.exp
          (-2 * Complex.ofReal Real.pi * Complex.I *
            (Complex.ofReal ((j.val * t.val : ℕ) : ℝ) /
              Complex.ofReal (q : ℝ)))

/-- The finite geometric-sum polynomial `J_u(z)=1+z+...+z^(u-1)`. -/
-- zpi: def-geometric-sum-polynomial
noncomputable def geometricSumPolynomial (u : ℕ) (_hu : 0 < u) (z : ℂ) : ℂ :=
  ∑ k ∈ Finset.range u, z ^ k

/-- The indicator of an integer-translated rational Beatty set on the canonical
representatives of one positive period. `Fin 2` is the explicit `{0,1}`
value type. -/
-- zpi: def-period-indicator-of-integer-translated-rational-beatty-set
noncomputable def periodBeattyIndicator (p q r : ℤ) (_hp : 0 < p)
    (_hpq : p < q) (_hq : 0 < q) : ZMod q.natAbs → Fin 2 := by
  classical
  exact fun t =>
    if (t.val : ℤ) ∈ integerTranslatedRationalBeattySet p q r then
      (1 : Fin 2)
    else
      (0 : Fin 2)

/-- Unfolding the period indicator. -/
-- zpi: def-period-indicator-of-integer-translated-rational-beatty-set
theorem periodBeattyIndicator_spec (p q r : ℤ) (hp : 0 < p)
    (hpq : p < q) (hq : 0 < q)
    (t : ZMod q.natAbs) :
    periodBeattyIndicator p q r hp hpq hq t =
      if (t.val : ℤ) ∈ integerTranslatedRationalBeattySet p q r then
        (1 : Fin 2)
      else
        (0 : Fin 2) := by
  classical
  rfl

end Fraenkel
