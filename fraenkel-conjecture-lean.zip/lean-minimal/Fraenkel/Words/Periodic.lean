import Fraenkel.Words.BalancedDeletion
import Fraenkel.External.Paparella2013

/-!
# Periodic balanced subsets

The package's binary-word convention is made explicit with `Bool`. The theorem
below keeps the nonempty/proper hypotheses explicit at the lemma site and
concludes an integer-translated rational Beatty set with the exact strict
numerator/denominator domain from its definition.
-/

open scoped BigOperators Classical

namespace Fraenkel

/-- The binary word of an integer subset. -/
-- zpi: def-periodic-balanced-subset-of-integers
noncomputable def binarySubsetWord (X : Set ℤ) : ℤ → Bool := by
  classical
  exact fun t => decide (t ∈ X)

/-- A subset is periodic balanced when its binary word is periodic and
balanced. Nonemptiness and properness are hypotheses of the downstream lemma,
not part of this definition. -/
-- zpi: def-periodic-balanced-subset-of-integers
def PeriodicBalancedSubset (X : Set ℤ) : Prop :=
  ∃ Q : ℤ, 0 < Q ∧ Function.Periodic (binarySubsetWord X) Q ∧
    BalancedWord (binarySubsetWord X)

-- zpi: def-periodic-balanced-subset-of-integers
theorem PeriodicBalancedSubset_spec (X : Set ℤ) :
    PeriodicBalancedSubset X ↔
      ∃ Q : ℤ, 0 < Q ∧ Function.Periodic (binarySubsetWord X) Q ∧
        BalancedWord (binarySubsetWord X) :=
  Iff.rfl

-- zpi: def-periodic-balanced-subset-of-integers
theorem binarySubsetWord_true_iff (X : Set ℤ) (t : ℤ) :
    binarySubsetWord X t = true ↔ t ∈ X := by
  simp [binarySubsetWord]

-- zpi: def-periodic-balanced-subset-of-integers
theorem binarySubsetWord_false_iff (X : Set ℤ) (t : ℤ) :
    binarySubsetWord X t = false ↔ t ∉ X := by
  simp [binarySubsetWord]

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_reduce (W : ℤ → Bool) (Q : ℤ)
    (hper : Function.Periodic W Q) (t : ℤ) : W t = W (t % Q) := by
  have hper' := (hper.int_mul (t / Q)) (t % Q)
  have hdecomp : t % Q + (t / Q) * Q = t := by
    simpa [mul_comm] using Int.emod_add_mul_ediv t Q
  calc
    W t = W (t % Q + (↑(t / Q) : ℤ) * Q) := by rw [hdecomp]
    _ = W (t % Q) := hper'

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_has_true_residue (X : Set ℤ) (Q : ℤ) (hQ : 0 < Q)
    (hper : Function.Periodic (binarySubsetWord X) Q) (hNonempty : X.Nonempty) :
    ∃ t ∈ Finset.Ico (0 : ℤ) Q, binarySubsetWord X t = true := by
  obtain ⟨x, hx⟩ := hNonempty
  refine ⟨x % Q, ?_, ?_⟩
  · exact Finset.mem_Ico.mpr ⟨Int.emod_nonneg x (by omega), Int.emod_lt_of_pos x hQ⟩
  · rw [← periodicWord_reduce (binarySubsetWord X) Q hper x]
    simpa [binarySubsetWord] using hx

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_has_false_residue (X : Set ℤ) (Q : ℤ) (hQ : 0 < Q)
    (hper : Function.Periodic (binarySubsetWord X) Q) (hProper : Xᶜ.Nonempty) :
    ∃ t ∈ Finset.Ico (0 : ℤ) Q, binarySubsetWord X t = false := by
  obtain ⟨x, hx⟩ := hProper
  refine ⟨x % Q, ?_, ?_⟩
  · exact Finset.mem_Ico.mpr ⟨Int.emod_nonneg x (by omega), Int.emod_lt_of_pos x hQ⟩
  · rw [← periodicWord_reduce (binarySubsetWord X) Q hper x]
    exact (binarySubsetWord_false_iff X x).2 ((Set.mem_compl_iff X x).1 hx)

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodCount_bounds (W : ℤ → Bool) (Q : ℤ) (hQ : 0 < Q)
    (hTrue : ∃ t ∈ Finset.Ico (0 : ℤ) Q, W t = true)
    (hFalse : ∃ t ∈ Finset.Ico (0 : ℤ) Q, W t = false) :
    0 < wordIntervalCount W true 0 Q ∧ wordIntervalCount W true 0 Q < Q := by
  let F : Finset ℤ := (Finset.Ico 0 Q).filter (fun t => W t = true)
  have hFpos : 0 < F.card := by
    obtain ⟨t, ht, hwt⟩ := hTrue
    have hmem : t ∈ F := Finset.mem_filter.mpr ⟨ht, hwt⟩
    exact Finset.card_pos.mpr ⟨t, hmem⟩
  have hFsubset : F ⊆ Finset.Ico (0 : ℤ) Q := Finset.filter_subset _ _
  have hFlt : F.card < (Finset.Ico (0 : ℤ) Q).card := by
    refine Finset.card_lt_card ⟨hFsubset, ?_⟩
    intro hsub
    obtain ⟨t, ht, hwt⟩ := hFalse
    have hmem : t ∈ F := hsub ht
    have htrue := (Finset.mem_filter.mp hmem).2
    simp [hwt] at htrue
  have hcount : wordIntervalCount W true 0 Q = (F.card : ℤ) := by
    unfold wordIntervalCount
    apply congrArg (fun s : Finset ℤ => (s.card : ℤ))
    ext t
    simp [F]
  rw [hcount]
  constructor
  · exact_mod_cast hFpos
  · have hI : (Finset.Ico (0 : ℤ) Q).card = Q.toNat := by simp [Int.card_Ico]
    have hQnat : (Q.toNat : ℤ) = Q := Int.toNat_of_nonneg hQ.le
    rw [hI] at hFlt
    rw [← hQnat]
    exact_mod_cast hFlt

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_period_count (W : ℤ → Bool) (Q : ℤ) (hQ : 0 < Q)
    (hper : Function.Periodic W Q) (u : ℤ) :
    wordIntervalCount W true u (u+Q) = wordIntervalCount W true 0 Q := by
  have hstep (t : ℤ) : wordIntervalCount W true (t+1) (t+1+Q) =
      wordIntervalCount W true t (t+Q) := by
    have hleft := wordIntervalCount_add W true t (t+1) (t+Q+1) (by omega) (by omega)
    have hright := wordIntervalCount_add W true t (t+Q) (t+Q+1) (by omega) (by omega)
    rw [wordIntervalCount_single] at hleft hright
    rw [hper t] at hright
    have hend : t+Q+1 = t+1+Q := by omega
    rw [hend] at hleft hright
    omega
  induction u using Int.induction_on with
  | zero => simp
  | succ n ih => rw [hstep]; exact ih
  | pred n ih =>
    have hs := hstep (-(n : ℤ)-1)
    simp only [sub_add_cancel] at hs
    exact hs.symm.trans ih

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_single_sum_count (W : ℤ → Bool) (a b : ℤ) :
    (∑ t ∈ Finset.Ico a b, (if W t = true then (1 : ℤ) else 0)) =
      wordIntervalCount W true a b := by
  rw [Finset.sum_boole]
  unfold wordIntervalCount
  apply congrArg (fun s : Finset ℤ => (s.card : ℤ))
  ext t
  simp

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_sum_shift (W : ℤ → Bool) (Q : ℤ) (n : ℕ) :
    (∑ t ∈ Finset.Ico (0 : ℤ) Q,
      (if W (t + (n : ℤ)) = true then (1 : ℤ) else 0)) =
      wordIntervalCount W true (n : ℤ) ((n : ℤ) + Q) := by
  have hsum :
      (∑ t ∈ Finset.Ico (0 : ℤ) Q,
        (if W (t + (n : ℤ)) = true then (1 : ℤ) else 0)) =
      ∑ z ∈ Finset.Ico (n : ℤ) ((n : ℤ) + Q),
        (if W z = true then (1 : ℤ) else 0) := by
    apply Finset.sum_bij (fun t _ => t + (n : ℤ))
    · intro t ht
      obtain ⟨ht0, htQ⟩ := Finset.mem_Ico.mp ht
      exact Finset.mem_Ico.mpr (by omega)
    · intro t₁ ht₁ t₂ ht₂ heq
      omega
    · intro z hz
      refine ⟨z - (n : ℤ), ?_, ?_⟩
      · obtain ⟨hz0, hzQ⟩ := Finset.mem_Ico.mp hz
        exact Finset.mem_Ico.mpr (by omega)
      · omega
    · intro t ht
      simp
  rw [← periodicWord_single_sum_count W (n : ℤ) ((n : ℤ) + Q)]
  exact hsum

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_factor_sum (W : ℤ → Bool) (Q : ℤ) (hQ : 0 < Q)
    (hper : Function.Periodic W Q) (P : ℤ)
    (hP : wordIntervalCount W true 0 Q = P) (n : ℕ) :
    (∑ t ∈ Finset.Ico (0 : ℤ) Q,
      wordIntervalCount W true t (t + (n : ℤ))) = (n : ℤ) * P := by
  induction n with
  | zero => simp [wordIntervalCount_empty]
  | succ n ih =>
    calc
      (∑ t ∈ Finset.Ico (0 : ℤ) Q,
          wordIntervalCount W true t (t + ((n + 1 : ℕ) : ℤ))) =
          ∑ t ∈ Finset.Ico (0 : ℤ) Q,
            (wordIntervalCount W true t (t + (n : ℤ)) +
              (if W (t + (n : ℤ)) = true then 1 else 0)) := by
                apply Finset.sum_congr rfl
                intro t ht
                have h := wordIntervalCount_add W true t (t + (n : ℤ))
                  (t + (n : ℤ) + 1) (by omega) (by omega)
                rw [wordIntervalCount_single] at h
                have hend : t + (n : ℤ) + 1 = t + ((n + 1 : ℕ) : ℤ) := by
                  push_cast
                  ring
                rw [hend] at h
                by_cases hw : W (t + (n : ℤ)) = true
                · simp [hw] at h ⊢
                  exact h
                · simp [hw] at h ⊢
                  exact h
      _ = (∑ t ∈ Finset.Ico (0 : ℤ) Q,
            wordIntervalCount W true t (t + (n : ℤ))) +
          (∑ t ∈ Finset.Ico (0 : ℤ) Q,
            (if W (t + (n : ℤ)) = true then 1 else 0)) := by
              rw [Finset.sum_add_distrib]
      _ = (n : ℤ) * P + wordIntervalCount W true (n : ℤ)
            ((n : ℤ) + Q) := by
              rw [ih, periodicWord_sum_shift W Q n]
      _ = (n + 1 : ℤ) * P := by
              rw [periodicWord_period_count W Q hQ hper (n : ℤ), hP]
              ring

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_factor_bounds (W : ℤ → Bool) (Q : ℤ) (hQ : 0 < Q)
    (hper : Function.Periodic W Q) (hbal : BalancedWord W) (P : ℤ)
    (hP : wordIntervalCount W true 0 Q = P) (n : ℕ)
    (t : ℤ) (ht : t ∈ Finset.Ico (0 : ℤ) Q) :
    ⌊(n : ℝ) * (P : ℝ) / (Q : ℝ)⌋ ≤
        wordIntervalCount W true t (t + (n : ℤ)) ∧
      wordIntervalCount W true t (t + (n : ℤ)) ≤
        ⌈(n : ℝ) * (P : ℝ) / (Q : ℝ)⌉ := by
  let s : Finset ℤ := Finset.Ico 0 Q
  let f : ℤ → ℤ := fun u => wordIntervalCount W true u (u + (n : ℤ))
  have hs : s.Nonempty := by
    dsimp [s]
    exact Finset.nonempty_Ico.mpr hQ
  obtain ⟨t₀, ht₀, hmin⟩ := Finset.exists_min_image s f hs
  let a : ℤ := f t₀
  have hmin' : ∀ u ∈ s, a ≤ f u := by
    intro u hu
    exact hmin u hu
  have hbal' : ∀ u ∈ s, |f u - a| ≤ 1 := by
    intro u hu
    have hh := hbal true u t₀ n
    simpa [f, a] using hh
  have hlo : ∀ u ∈ s, a ≤ f u := hmin'
  have hhi : ∀ u ∈ s, f u ≤ a + 1 := by
    intro u hu
    have hh := hbal' u hu
    rw [abs_le] at hh
    omega
  have hsum : ∑ u ∈ s, f u = (n : ℤ) * P := by
    simpa [s, f] using periodicWord_factor_sum W Q hQ hper P hP n
  have hcard : (s.card : ℤ) = Q := by
    dsimp [s]
    simp [Int.card_Ico, Int.toNat_of_nonneg hQ.le]
  have hsumR : ∑ u ∈ s, (f u : ℝ) = (n : ℝ) * (P : ℝ) := by
    have hh := congrArg (fun z : ℤ => (z : ℝ)) hsum
    simpa only [Int.cast_sum, Int.cast_mul, Int.cast_ofNat] using hh
  let x : ℝ := (n : ℝ) * (P : ℝ) / (Q : ℝ)
  have hQR : 0 < (Q : ℝ) := by exact_mod_cast hQ
  have havg : (∑ u ∈ s, (f u : ℝ)) = (Q : ℝ) * x := by
    rw [hsumR]
    dsimp [x]
    field_simp
  have hsum_lo : ∑ u ∈ s, (a : ℝ) ≤ ∑ u ∈ s, (f u : ℝ) := by
    apply Finset.sum_le_sum
    intro u hu
    exact_mod_cast hlo u hu
  have hsum_hi : ∑ u ∈ s, (f u : ℝ) ≤ ∑ u ∈ s, ((a : ℝ) + 1) := by
    apply Finset.sum_le_sum
    intro u hu
    exact_mod_cast hhi u hu
  have hcardR : (s.card : ℝ) = (Q : ℝ) := by
    exact_mod_cast hcard
  have hconst_lo : (∑ u ∈ s, (a : ℝ)) = (Q : ℝ) * (a : ℝ) := by
    rw [Finset.sum_const, nsmul_eq_mul, hcardR]
  have hconst_hi : (∑ u ∈ s, ((a : ℝ) + 1)) = (Q : ℝ) * ((a : ℝ) + 1) := by
    rw [Finset.sum_const, nsmul_eq_mul, hcardR]
  have hbounds : (a : ℝ) ≤ x ∧ x ≤ (a : ℝ) + 1 := by
    constructor
    · apply le_of_mul_le_mul_left _ hQR
      rw [← havg, ← hconst_lo]
      exact hsum_lo
    · apply le_of_mul_le_mul_left _ hQR
      rw [← havg, ← hconst_hi]
      exact hsum_hi
  have hstrict_hi : x < (a : ℝ) + 1 := by
    have hstrict_sum : (∑ u ∈ s, (f u : ℝ)) <
        ∑ u ∈ s, ((a : ℝ) + 1) := by
      apply Finset.sum_lt_sum
      · intro u hu
        exact_mod_cast hhi u hu
      · refine ⟨t₀, ht₀, ?_⟩
        dsimp [a, f]
        norm_num
    rw [havg, hconst_hi] at hstrict_sum
    exact lt_of_mul_lt_mul_left hstrict_sum hQR.le
  have hcase : x = (a : ℝ) ∨ (a : ℝ) < x := by
    rcases eq_or_lt_of_le hbounds.1 with hxa | hax
    · exact Or.inl hxa.symm
    · exact Or.inr hax
  rcases hcase with hxa | hax
  · have hall : ∀ u ∈ s, f u = a := by
      intro u hu
      apply le_antisymm
      · by_contra hne
        have hlt : a < f u := lt_of_not_ge hne
        have hstrict_sum : (∑ v ∈ s, (a : ℝ)) <
            ∑ v ∈ s, (f v : ℝ) := by
          apply Finset.sum_lt_sum
          · intro v hv
            exact_mod_cast hlo v hv
          · exact ⟨u, hu, by exact_mod_cast hlt⟩
        rw [hconst_lo, havg, hxa] at hstrict_sum
        linarith
      · exact hlo u hu
    have hta := hall t ht
    constructor
    · simpa [x, hxa] using hta.ge
    · simpa [x, hxa] using hta.le
  · have hfloor : ⌊x⌋ = a := by
      apply (Int.floor_eq_iff).2
      exact ⟨hbounds.1, hstrict_hi⟩
    have hceil_lower : a + 1 ≤ ⌈x⌉ := by
      have hcx := Int.le_ceil x
      have hlt : (a : ℝ) < (⌈x⌉ : ℝ) := lt_of_lt_of_le hax hcx
      have hlt' : a < ⌈x⌉ := by exact_mod_cast hlt
      omega
    have hceil_upper : ⌈x⌉ ≤ a + 1 := by
      apply (Int.ceil_le).2
      push_cast
      exact hbounds.2
    have hta := hmin' t ht
    have htatop := hhi t ht
    constructor
    · rw [hfloor]
      exact hta
    · exact le_trans htatop hceil_lower

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_interval_shift (W : ℤ → Bool) (Q : ℤ) (c : Bool)
    (hper : Function.Periodic W Q) (k u v : ℤ) :
    wordIntervalCount W c (u + k * Q) (v + k * Q) =
      wordIntervalCount W c u v := by
  have hperK := hper.int_mul k
  unfold wordIntervalCount
  apply congrArg (fun n : ℕ => (n : ℤ))
  apply Finset.card_bij (fun t _ => t - k * Q)
  · intro t ht
    have ht' : t ∈ Finset.Ico (u + k * Q) (v + k * Q) ∧ W t = c := by
      simpa only [Finset.mem_filter] using ht
    obtain ⟨htu, htv⟩ := Finset.mem_Ico.mp ht'.1
    simp only [Finset.mem_filter]
    refine ⟨Finset.mem_Ico.mpr (by omega), ?_⟩
    have hw := hperK (t - k * Q)
    have hwarg : (t - k * Q) + (↑k : ℤ) * Q = t := by ring
    have hw' : W t = W (t - k * Q) := by simpa [hwarg] using hw
    simpa using hw'.symm.trans ht'.2
  · intro t₁ ht₁ t₂ ht₂ heq
    omega
  · intro t ht
    have ht' : t ∈ Finset.Ico u v ∧ W t = c := by
      simpa only [Finset.mem_filter] using ht
    obtain ⟨htu, htv⟩ := Finset.mem_Ico.mp ht'.1
    refine ⟨t + k * Q, ?_, ?_⟩
    · simp only [Finset.mem_filter]
      refine ⟨Finset.mem_Ico.mpr (by omega), ?_⟩
      have hw := hperK t
      have hw' : W (t + k * Q) = W t := by simpa using hw
      simpa using hw'.trans ht'.2
    · ring

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_factor_bounds_all (W : ℤ → Bool) (Q : ℤ) (hQ : 0 < Q)
    (hper : Function.Periodic W Q) (hbal : BalancedWord W) (P : ℤ)
    (hP : wordIntervalCount W true 0 Q = P) (m : ℤ) (L : ℕ) :
    ⌊(L : ℝ) * (P : ℝ) / (Q : ℝ)⌋ ≤
        wordIntervalCount W true m (m + (L : ℤ)) ∧
      wordIntervalCount W true m (m + (L : ℤ)) ≤
        ⌈(L : ℝ) * (P : ℝ) / (Q : ℝ)⌉ := by
  let r : ℤ := m % Q
  have hr : r ∈ Finset.Ico (0 : ℤ) Q := by
    dsimp [r]
    exact Finset.mem_Ico.mpr ⟨Int.emod_nonneg m (by omega), Int.emod_lt_of_pos m hQ⟩
  have hres := periodicWord_factor_bounds W Q hQ hper hbal P hP L r hr
  have hshift := periodicWord_interval_shift W Q true hper (m / Q) r (r + (L : ℤ))
  have hm : r + (m / Q) * Q = m := by
    dsimp [r]
    simpa [mul_comm] using Int.emod_add_mul_ediv m Q
  have hend : (r + (L : ℤ)) + (m / Q) * Q = m + (L : ℤ) := by
    calc
      (r + (L : ℤ)) + (m / Q) * Q =
          (r + (m / Q) * Q) + (L : ℤ) := by ring
      _ = m + (L : ℤ) := by rw [hm]
  rw [← hshift] at hres
  rw [hm, hend] at hres
  exact hres

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private noncomputable def periodicWordCumulative (W : ℤ → Bool) (n : ℤ) : ℤ :=
  if 0 ≤ n then wordIntervalCount W true 0 n else -wordIntervalCount W true n 0

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_cumulative_sub (W : ℤ → Bool) (m n : ℤ) (hmn : m ≤ n) :
    periodicWordCumulative W n - periodicWordCumulative W m =
      wordIntervalCount W true m n := by
  by_cases hm : 0 ≤ m
  · by_cases hn : 0 ≤ n
    · simp [periodicWordCumulative, hm, hn]
      have h := wordIntervalCount_add W true 0 m n (by omega) hmn
      omega
    · omega
  · have hm' : m < 0 := lt_of_not_ge hm
    by_cases hn : 0 ≤ n
    · simp [periodicWordCumulative, hm, hn]
      have h := wordIntervalCount_add W true m 0 n (by omega) hn
      omega
    · have hn' : n < 0 := lt_of_not_ge hn
      simp [periodicWordCumulative, hm, hn]
      have h := wordIntervalCount_add W true m n 0 hmn (by omega)
      omega

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_cumulative_period (W : ℤ → Bool) (Q P : ℤ)
    (hQ : 0 < Q) (hper : Function.Periodic W Q)
    (hP : wordIntervalCount W true 0 Q = P) (n : ℤ) :
    periodicWordCumulative W (n + Q) = periodicWordCumulative W n + P := by
  have h := periodicWord_cumulative_sub W n (n + Q) (by omega)
  rw [periodicWord_period_count W Q hQ hper n, hP] at h
  omega

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private noncomputable def periodicWordDiscrepancy (W : ℤ → Bool) (Q P : ℤ) (n : ℤ) : ℝ :=
  (periodicWordCumulative W n : ℝ) - (n : ℝ) * (P : ℝ) / (Q : ℝ)

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_discrepancy_period (W : ℤ → Bool) (Q P : ℤ) (hQ : 0 < Q)
    (hF : ∀ n : ℤ, periodicWordCumulative W (n + Q) =
      periodicWordCumulative W n + P) (n : ℤ) :
    periodicWordDiscrepancy W Q P (n + Q) = periodicWordDiscrepancy W Q P n := by
  rw [periodicWordDiscrepancy, periodicWordDiscrepancy, hF]
  have hQR : (Q : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hQ)
  push_cast
  field_simp
  ring

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_discrepancy_diff_lt_one (W : ℤ → Bool) (Q P : ℤ)
    (hbound : ∀ (m : ℤ) (L : ℕ),
      ⌊(L : ℝ) * (P : ℝ) / (Q : ℝ)⌋ ≤
          wordIntervalCount W true m (m + (L : ℤ)) ∧
        wordIntervalCount W true m (m + (L : ℤ)) ≤
          ⌈(L : ℝ) * (P : ℝ) / (Q : ℝ)⌉)
    (m n : ℤ) (hmn : m < n) :
    |periodicWordDiscrepancy W Q P n - periodicWordDiscrepancy W Q P m| < 1 := by
  have hcount := periodicWord_cumulative_sub W m n hmn.le
  have hLnonneg : 0 ≤ n - m := by omega
  let L : ℕ := (n - m).toNat
  have hL : (L : ℤ) = n - m := by
    dsimp [L]
    exact Int.toNat_of_nonneg hLnonneg
  have hend : m + (L : ℤ) = n := by omega
  have hb := hbound m L
  have hLR : (L : ℝ) = (n - m : ℝ) := by exact_mod_cast hL
  rw [hend, hLR] at hb
  have hcountR :
      (periodicWordCumulative W n : ℝ) - (periodicWordCumulative W m : ℝ) =
        (wordIntervalCount W true m n : ℝ) := by
    have hh := congrArg (fun z : ℤ => (z : ℝ)) hcount
    simpa only [Int.cast_sub] using hh
  have hdiff : periodicWordDiscrepancy W Q P n - periodicWordDiscrepancy W Q P m =
      (wordIntervalCount W true m n : ℝ) -
        ((n - m : ℤ) : ℝ) * (P : ℝ) / (Q : ℝ) := by
    rw [periodicWordDiscrepancy, periodicWordDiscrepancy]
    rw [← hcountR]
    push_cast
    ring
  rw [abs_lt]
  rw [hdiff]
  have hlo : ((n - m : ℤ) : ℝ) * (P : ℝ) / (Q : ℝ) - 1 <
      (wordIntervalCount W true m n : ℝ) := by
    have hf := Int.lt_floor_add_one (((n - m : ℤ) : ℝ) * (P : ℝ) / (Q : ℝ))
    have hb' : (⌊((n - m : ℤ) : ℝ) * (P : ℝ) / (Q : ℝ)⌋ : ℝ) ≤
        (wordIntervalCount W true m n : ℝ) := by exact_mod_cast hb.1
    linarith
  have hhi : (wordIntervalCount W true m n : ℝ) <
      ((n - m : ℤ) : ℝ) * (P : ℝ) / (Q : ℝ) + 1 := by
    have hc := Int.ceil_lt_add_one (((n - m : ℤ) : ℝ) * (P : ℝ) / (Q : ℝ))
    have hb' : (wordIntervalCount W true m n : ℝ) ≤
        (⌈((n - m : ℤ) : ℝ) * (P : ℝ) / (Q : ℝ)⌉ : ℝ) := by exact_mod_cast hb.2
    linarith
  constructor <;> linarith

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_discrepancy_pair_lt (W : ℤ → Bool) (Q P : ℤ)
    (hbound : ∀ (m : ℤ) (L : ℕ),
      ⌊(L : ℝ) * (P : ℝ) / (Q : ℝ)⌋ ≤
          wordIntervalCount W true m (m + (L : ℤ)) ∧
        wordIntervalCount W true m (m + (L : ℤ)) ≤
          ⌈(L : ℝ) * (P : ℝ) / (Q : ℝ)⌉)
    (m n : ℤ) :
    |periodicWordDiscrepancy W Q P n - periodicWordDiscrepancy W Q P m| < 1 := by
  by_cases hmn : m < n
  · exact periodicWord_discrepancy_diff_lt_one W Q P hbound m n hmn
  · by_cases hnm : n < m
    · have hh := periodicWord_discrepancy_diff_lt_one W Q P hbound n m hnm
      simpa [abs_sub_comm] using hh
    · have heq : m = n := by omega
      subst n
      simp

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_floor_representation (W : ℤ → Bool) (Q P : ℤ)
    (hQ : 0 < Q)
    (hDperiod : ∀ n : ℤ, periodicWordDiscrepancy W Q P (n + Q) =
      periodicWordDiscrepancy W Q P n)
    (hbound : ∀ (m : ℤ) (L : ℕ),
      ⌊(L : ℝ) * (P : ℝ) / (Q : ℝ)⌋ ≤
          wordIntervalCount W true m (m + (L : ℤ)) ∧
        wordIntervalCount W true m (m + (L : ℤ)) ≤
          ⌈(L : ℝ) * (P : ℝ) / (Q : ℝ)⌉) :
    ∃ N : ℤ, ∀ n : ℤ,
      periodicWordCumulative W n = periodicWordCumulative W N +
        ⌊(n - N : ℤ) * (P : ℝ) / (Q : ℝ)⌋ := by
  let D : ℤ → ℝ := periodicWordDiscrepancy W Q P
  have hDper : Function.Periodic D Q := by
    intro n
    exact hDperiod n
  let s : Finset ℤ := Finset.Ico 0 Q
  have hs : s.Nonempty := by
    dsimp [s]
    exact Finset.nonempty_Ico.mpr hQ
  obtain ⟨N, hN, hmax⟩ := Finset.exists_max_image s D hs
  let C : ℝ := D N
  have hDle : ∀ n : ℤ, D n ≤ C := by
    intro n
    let r : ℤ := n % Q
    have hr : r ∈ s := by
      dsimp [s, r]
      exact Finset.mem_Ico.mpr ⟨Int.emod_nonneg n (by omega), Int.emod_lt_of_pos n hQ⟩
    have hred : D n = D r := by
      have hp := hDper.int_mul (n / Q) r
      have hdecomp : r + (n / Q) * Q = n := by
        dsimp [r]
        simpa [mul_comm] using Int.emod_add_mul_ediv n Q
      rw [← hdecomp]
      exact hp
    rw [hred]
    exact le_trans (hmax r hr) (by rfl)
  have hpair : ∀ m n : ℤ, |D n - D m| < 1 := by
    intro m n
    simpa [D] using periodicWord_discrepancy_pair_lt W Q P hbound m n
  have hgap : ∀ n : ℤ, 0 ≤ C - D n ∧ C - D n < 1 := by
    intro n
    have hle := hDle n
    have hp := hpair n N
    dsimp [C] at hp ⊢
    rw [abs_lt] at hp
    constructor <;> linarith
  have hfloor : ∀ n : ℤ,
      periodicWordCumulative W n =
        ⌊(n : ℝ) * (P : ℝ) / (Q : ℝ) + C⌋ := by
    intro n
    have harg : (n : ℝ) * (P : ℝ) / (Q : ℝ) + C =
        (periodicWordCumulative W n : ℝ) + (C - D n) := by
      dsimp [D, periodicWordDiscrepancy]
      ring
    symm
    apply (Int.floor_eq_iff).2
    rw [harg]
    have hg := hgap n
    constructor <;> linarith
  refine ⟨N, ?_⟩
  intro n
  rw [hfloor n]
  have hCN : C = (periodicWordCumulative W N : ℝ) -
      (N : ℝ) * (P : ℝ) / (Q : ℝ) := by
    rfl
  have harg : (n : ℝ) * (P : ℝ) / (Q : ℝ) + C =
      ((n - N : ℤ) : ℝ) * (P : ℝ) / (Q : ℝ) +
        (periodicWordCumulative W N : ℝ) := by
    rw [hCN]
    push_cast
    ring
  rw [harg, Int.floor_add_intCast]
  ring

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_jump_floor (W : ℤ → Bool) (F : ℤ → ℤ) (P Q N : ℤ)
    (hsub : ∀ n : ℤ, F (n+1) - F n = wordIntervalCount W true n (n+1))
    (hF : ∀ n : ℤ, F n = F N +
      ⌊(n - N : ℤ) * (P : ℝ) / (Q : ℝ)⌋) :
    ∀ n : ℤ, W n = true ↔
      ⌊(n + 1 - N : ℤ) * (P : ℝ) / (Q : ℝ)⌋ -
        ⌊(n - N : ℤ) * (P : ℝ) / (Q : ℝ)⌋ = 1 := by
  intro n
  have hc := hsub n
  rw [hF (n+1), hF n] at hc
  have hs := wordIntervalCount_single W true n
  by_cases hw : W n = true
  · simp [hw] at hs
    simp [hs] at hc
    have hc' :
        ⌊(n + 1 - N : ℤ) * (P : ℝ) / (Q : ℝ)⌋ -
            ⌊(n - N : ℤ) * (P : ℝ) / (Q : ℝ)⌋ = 1 := by
      simpa only [Int.cast_sub, Int.cast_add, Int.cast_one] using hc
    exact ⟨fun _ => hc', fun _ => hw⟩
  · simp [hw] at hs
    simp [hs] at hc
    have hc' :
        ⌊(n + 1 - N : ℤ) * (P : ℝ) / (Q : ℝ)⌋ -
            ⌊(n - N : ℤ) * (P : ℝ) / (Q : ℝ)⌋ = 0 := by
      simpa only [Int.cast_sub, Int.cast_add, Int.cast_one] using hc
    exact ⟨fun h => (hw h).elim, fun h => by omega⟩

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem floor_jump_interval_iff (x δ : ℝ) (hδ : δ < 1) :
    ⌊x + δ⌋ - ⌊x⌋ = 1 ↔
      ∃ l : ℤ, x < (l : ℝ) ∧ (l : ℝ) ≤ x + δ := by
  have hdiff_le : ⌊x + δ⌋ - ⌊x⌋ ≤ 1 := by
    have hx : x < (⌊x⌋ : ℝ) + 1 := Int.lt_floor_add_one x
    have hlt : x + δ < (⌊x⌋ : ℝ) + 2 := by linarith
    have hlt' : x + δ < ((⌊x⌋ + 2 : ℤ) : ℝ) := by
      push_cast
      exact hlt
    have hh : ⌊x + δ⌋ < ⌊x⌋ + 2 := (Int.floor_lt).2 hlt'
    omega
  constructor
  · intro h
    refine ⟨⌊x + δ⌋, ?_, Int.floor_le (x + δ)⟩
    have hh : ⌊x⌋ + 1 ≤ ⌊x + δ⌋ := by omega
    have hx : x < (⌊x⌋ : ℝ) + 1 := Int.lt_floor_add_one x
    exact lt_of_lt_of_le hx (by exact_mod_cast hh)
  · rintro ⟨l, hxl, hl⟩
    have hfloor_lt : ⌊x⌋ < l := (Int.floor_lt).2 hxl
    have hle_floor : l ≤ ⌊x + δ⌋ := (Int.le_floor).2 hl
    omega

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem integer_interval_iff_ceiling (n : ℤ) (y : ℝ) :
    (n : ℝ) < y ∧ y ≤ (n : ℝ) + 1 ↔ n = ⌈y⌉ - 1 := by
  constructor
  · intro h
    have h1 : n < ⌈y⌉ := (Int.lt_ceil).2 h.1
    have h2' : y ≤ ((n + 1 : ℤ) : ℝ) := by
      push_cast
      exact h.2
    have h2 : ⌈y⌉ ≤ n + 1 := (Int.ceil_le).2 h2'
    omega
  · intro h
    have h1 : n < ⌈y⌉ := by omega
    have h2 : ⌈y⌉ ≤ n + 1 := by omega
    have h2' : y ≤ (n : ℝ) + 1 := by
      simpa only [Int.cast_add, Int.cast_one] using (Int.ceil_le).1 h2
    exact ⟨(Int.lt_ceil).1 h1, h2'⟩

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem reducedPositiveRate (P Q : ℤ) (hP : 0 < P) (hPQ : P < Q) :
    ∃ p q : ℤ, 0 < p ∧ p < q ∧ Int.gcd p q = 1 ∧
      (P : ℝ) / (Q : ℝ) = (p : ℝ) / (q : ℝ) := by
  let g : ℤ := Int.gcd P Q
  have hg0 : 0 < g := by
    have hgNat : 0 < Int.gcd P Q :=
      (Int.gcd_pos_iff).2 (Or.inl (ne_of_gt hP))
    dsimp [g]
    exact_mod_cast hgNat
  have hgP : g ∣ P := by
    dsimp [g]
    exact Int.gcd_dvd_left P Q
  have hgQ : g ∣ Q := by
    dsimp [g]
    exact Int.gcd_dvd_right P Q
  let p : ℤ := P / g
  let q : ℤ := Q / g
  have hp : 0 < p := by
    dsimp [p]
    exact Int.ediv_pos_of_pos_of_dvd hP hg0.le hgP
  have hq : 0 < q := by
    dsimp [q]
    exact Int.ediv_pos_of_pos_of_dvd (lt_trans hP hPQ) hg0.le hgQ
  have hPg : p * g = P := by
    dsimp [p]
    exact Int.ediv_mul_cancel hgP
  have hQg : q * g = Q := by
    dsimp [q]
    exact Int.ediv_mul_cancel hgQ
  have hpq : p < q := by
    nlinarith
  have hcop : Int.gcd p q = 1 := by
    have h := Int.gcd_div hgP hgQ
    dsimp [g, p, q] at h ⊢
    rw [h]
    have hgNat : 0 < Int.gcd P Q :=
      (Int.gcd_pos_iff).2 (Or.inl (ne_of_gt hP))
    exact Nat.div_self hgNat
  have hrat : (P : ℝ) / (Q : ℝ) = (p : ℝ) / (q : ℝ) := by
    have hpR : (p : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hp)
    have hqR : (q : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hq)
    have hPR : (P : ℝ) = (p : ℝ) * (g : ℝ) := by exact_mod_cast hPg.symm
    have hQR : (Q : ℝ) = (q : ℝ) * (g : ℝ) := by exact_mod_cast hQg.symm
    rw [hPR, hQR]
    field_simp
  exact ⟨p, q, hp, hpq, hcop, hrat⟩

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_jump_positions (W : ℤ → Bool) (P Q p q N : ℤ)
    (hp : 0 < p) (hpq : p < q)
    (hrate : (P : ℝ) / (Q : ℝ) = (p : ℝ) / (q : ℝ))
    (hF : ∀ n : ℤ, periodicWordCumulative W n = periodicWordCumulative W N +
      ⌊(n - N : ℤ) * (P : ℝ) / (Q : ℝ)⌋) :
    ∀ n : ℤ, W n = true ↔
      ∃ l : ℤ, n = N - 1 + ⌈(l : ℝ) * (q : ℝ) / (p : ℝ)⌉ := by
  have hq : 0 < q := lt_trans hp hpq
  have hpR : 0 < (p : ℝ) := by exact_mod_cast hp
  have hqR : 0 < (q : ℝ) := by exact_mod_cast hq
  let δ : ℝ := (p : ℝ) / (q : ℝ)
  let α : ℝ := (q : ℝ) / (p : ℝ)
  have hδ0 : 0 < δ := by
    dsimp [δ]
    positivity
  have hδ1 : δ < 1 := by
    dsimp [δ]
    apply (div_lt_iff₀ hqR).2
    simpa using (show (p : ℝ) < (q : ℝ) by exact_mod_cast hpq)
  have hrecip : (1 / δ : ℝ) = α := by
    dsimp [δ, α]
    field_simp
  have hrewrite (z : ℤ) :
      (z : ℝ) * (P : ℝ) / (Q : ℝ) = (z : ℝ) * δ := by
    calc
      (z : ℝ) * (P : ℝ) / (Q : ℝ) = (z : ℝ) * ((P : ℝ) / (Q : ℝ)) := by ring
      _ = (z : ℝ) * δ := by rw [hrate]
  intro n
  have hj := (periodicWord_jump_floor W (fun z => periodicWordCumulative W z)
    P Q N (by
      intro z
      exact periodicWord_cumulative_sub W z (z + 1) (by omega)) hF n)
  rw [hrewrite (n + 1 - N), hrewrite (n - N)] at hj
  have harg : ((n + 1 - N : ℤ) : ℝ) * δ =
      ((n - N : ℤ) : ℝ) * δ + δ := by
    push_cast
    ring
  have hj' :
      ⌊((n - N : ℤ) : ℝ) * δ + δ⌋ -
          ⌊((n - N : ℤ) : ℝ) * δ⌋ = 1 ↔ W n = true := by
    constructor
    · intro h
      apply hj.mpr
      rw [harg]
      exact h
    · intro h
      have hh := hj.mp h
      rw [harg] at hh
      exact hh
  constructor
  · intro hwn
    have hjone :
        ⌊((n - N : ℤ) : ℝ) * δ + δ⌋ -
            ⌊((n - N : ℤ) : ℝ) * δ⌋ = 1 := hj'.2 hwn
    obtain ⟨l, hl1, hl2⟩ := (floor_jump_interval_iff
      (((n - N : ℤ) : ℝ) * δ) δ hδ1).1 hjone
    have hly1 : ((n - N : ℤ) : ℝ) < (l : ℝ) * α := by
      have hh : ((n - N : ℤ) : ℝ) < (l : ℝ) / δ :=
        (lt_div_iff₀ hδ0).2 (by simpa using hl1)
      rw [show (l : ℝ) / δ = (l : ℝ) * (1 / δ) by ring, hrecip] at hh
      exact hh
    have hly2 : (l : ℝ) * α ≤ ((n - N : ℤ) : ℝ) + 1 := by
      have hl2' : (l : ℝ) ≤ (((n - N : ℤ) : ℝ) + 1) * δ := by
        convert hl2 using 1
        ring
      have hh : (l : ℝ) / δ ≤ ((n - N : ℤ) : ℝ) + 1 :=
        (div_le_iff₀ hδ0).2 hl2'
      rw [show (l : ℝ) / δ = (l : ℝ) * (1 / δ) by ring, hrecip] at hh
      exact hh
    have hceil := (integer_interval_iff_ceiling (n - N) ((l : ℝ) * α)).1
      ⟨hly1, hly2⟩
    have hceil' : n - N = ⌈(l : ℝ) * (q : ℝ) / (p : ℝ)⌉ - 1 := by
      have heq : (l : ℝ) * α = (l : ℝ) * (q : ℝ) / (p : ℝ) := by
        dsimp [α]
        ring
      rw [heq] at hceil
      exact hceil
    refine ⟨l, ?_⟩
    omega
  · rintro ⟨l, hnl⟩
    have heq : (l : ℝ) * α = (l : ℝ) * (q : ℝ) / (p : ℝ) := by
      dsimp [α]
      ring
    have hnl' : n = N - 1 + ⌈(l : ℝ) * α⌉ := by
      rw [heq]
      exact hnl
    have hk : n - N = ⌈(l : ℝ) * α⌉ - 1 := by omega
    have hinterval := (integer_interval_iff_ceiling (n - N) ((l : ℝ) * α)).2 hk
    have hly1 : ((n - N : ℤ) : ℝ) < (l : ℝ) / δ := by
      rw [show (l : ℝ) / δ = (l : ℝ) * (1 / δ) by ring, hrecip]
      exact hinterval.1
    have hly2 : (l : ℝ) / δ ≤ ((n - N : ℤ) : ℝ) + 1 := by
      rw [show (l : ℝ) / δ = (l : ℝ) * (1 / δ) by ring, hrecip]
      exact hinterval.2
    have hl1 : ((n - N : ℤ) : ℝ) * δ < (l : ℝ) :=
      (lt_div_iff₀ hδ0).1 hly1
    have hl2' := (div_le_iff₀ hδ0).1 hly2
    have hl2 : (l : ℝ) ≤ ((n - N : ℤ) : ℝ) * δ + δ := by
      convert hl2' using 1
      ring
    have hjone := (floor_jump_interval_iff
      (((n - N : ℤ) : ℝ) * δ) δ hδ1).2 ⟨l, hl1, hl2⟩
    exact hj'.1 hjone

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem floor_shift_ceiling (p q j t l : ℤ) (hp : 0 < p)
    (hrel : j * q + 1 = t * p) :
    ⌊((l + j : ℤ) : ℝ) * (q : ℝ) / (p : ℝ)⌋ =
      ⌈(l : ℝ) * (q : ℝ) / (p : ℝ)⌉ + t - 1 := by
  have hpR : 0 < (p : ℝ) := by exact_mod_cast hp
  have hrelR : (j : ℝ) * (q : ℝ) + 1 = (t : ℝ) * (p : ℝ) := by
    exact_mod_cast hrel
  let A : ℤ := l * q
  have hquot : (A : ℝ) / (p : ℝ) =
      ((A / p : ℤ) : ℝ) + ((A % p : ℤ) : ℝ) / (p : ℝ) := by
    apply (div_eq_iff hpR.ne').mpr
    have h := congrArg (fun z : ℤ => (z : ℝ)) (Int.mul_ediv_add_emod A p)
    push_cast at h
    field_simp
    nlinarith [h]
  have hrem0 : 0 ≤ A % p := Int.emod_nonneg A (by omega)
  have hrem1 : A % p < p := Int.emod_lt_of_pos A hp
  have hz : (l + j) * q + 1 = l * q + t * p := by
    nlinarith [hrel]
  have hzR : ((l + j : ℤ) : ℝ) * (q : ℝ) + 1 =
      ((A : ℝ) + (t : ℝ) * (p : ℝ)) := by
    dsimp [A]
    have hh := congrArg (fun z : ℤ => (z : ℝ)) hz
    simpa only [Int.cast_add, Int.cast_mul, Int.cast_one] using hh
  have hshift : ((l + j : ℤ) : ℝ) * (q : ℝ) / (p : ℝ) =
      (A : ℝ) / (p : ℝ) + (t : ℝ) - 1 / (p : ℝ) := by
    field_simp
    nlinarith [hzR]
  have hfloor_aux :
      ⌊(A : ℝ) / (p : ℝ) - 1 / (p : ℝ)⌋ = A / p - if A % p = 0 then 1 else 0 := by
    by_cases hr : A % p = 0
    · simp only [hr, ite_true]
      rw [hquot]
      have hfloor : ⌊((A / p : ℤ) : ℝ) - 1 / (p : ℝ)⌋ = A / p - 1 := by
        apply (Int.floor_eq_iff).2
        have hp1 : (1 : ℝ) ≤ (p : ℝ) := by
          exact_mod_cast (show (1 : ℤ) ≤ p by omega)
        have hle : (1 : ℝ) / (p : ℝ) ≤ 1 := (div_le_iff₀ hpR).2 (by linarith)
        have hpos : 0 < (1 : ℝ) / (p : ℝ) := by positivity
        constructor <;> push_cast <;> linarith
      simpa [hr] using hfloor
    · have hrpos : 0 < A % p := lt_of_le_of_ne hrem0 (Ne.symm hr)
      simp only [hr, ite_false]
      rw [hquot]
      have hfloor : ⌊((A / p : ℤ) : ℝ) +
          ((A % p : ℤ) : ℝ) / (p : ℝ) - 1 / (p : ℝ)⌋ = A / p := by
        apply (Int.floor_eq_iff).2
        have hremR0 : (0 : ℝ) ≤ (A % p : ℤ) := by exact_mod_cast hrem0
        have hremR1 : ((A % p : ℤ) : ℝ) < (p : ℝ) := by exact_mod_cast hrem1
        have hremRpos : (0 : ℝ) < (A % p : ℤ) := by exact_mod_cast hrpos
        have hone : (1 : ℝ) ≤ (A % p : ℤ) := by
          exact_mod_cast (show (1 : ℤ) ≤ A % p by omega)
        have hlow : (0 : ℝ) ≤ ((A % p : ℤ) : ℝ) / (p : ℝ) - 1 / (p : ℝ) := by
          apply sub_nonneg.mpr
          exact (div_le_div_iff_of_pos_right hpR).2 hone
        have hremdiv : ((A % p : ℤ) : ℝ) / (p : ℝ) < 1 := by
          apply (div_lt_iff₀ hpR).2
          nlinarith
        have hhigh : ((A % p : ℤ) : ℝ) / (p : ℝ) - 1 / (p : ℝ) < 1 := by
          have hpos : 0 < (1 : ℝ) / (p : ℝ) := by positivity
          linarith
        constructor <;> linarith
      simpa using hfloor
  have hceil_aux :
      ⌈(A : ℝ) / (p : ℝ)⌉ = A / p + if A % p = 0 then 0 else 1 := by
    by_cases hr : A % p = 0
    · simp only [hr, ite_true]
      rw [hquot]
      have hceil : ⌈((A / p : ℤ) : ℝ) +
          ((A % p : ℤ) : ℝ) / (p : ℝ)⌉ = A / p := by
        apply (Int.ceil_eq_iff).2
        simp [hr]
      simpa using hceil
    · have hrpos : 0 < A % p := lt_of_le_of_ne hrem0 (Ne.symm hr)
      simp only [hr, ite_false]
      rw [hquot]
      have hceil : ⌈((A / p : ℤ) : ℝ) +
          ((A % p : ℤ) : ℝ) / (p : ℝ)⌉ = A / p + 1 := by
        apply (Int.ceil_eq_iff).2
        have hremR0 : (0 : ℝ) ≤ (A % p : ℤ) := by exact_mod_cast hrem0
        have hremR1 : ((A % p : ℤ) : ℝ) < (p : ℝ) := by exact_mod_cast hrem1
        have hremRpos : (0 : ℝ) < (A % p : ℤ) := by exact_mod_cast hrpos
        have hremdiv : ((A % p : ℤ) : ℝ) / (p : ℝ) < 1 := by
          apply (div_lt_iff₀ hpR).2
          nlinarith
        have hremposdiv : 0 < ((A % p : ℤ) : ℝ) / (p : ℝ) :=
          div_pos hremRpos hpR
        constructor
        · push_cast
          linarith
        · push_cast
          linarith
      simpa [hr] using hceil
  rw [hshift]
  rw [show (A : ℝ) / (p : ℝ) + (t : ℝ) - 1 / (p : ℝ) =
      ((A : ℝ) / (p : ℝ) - 1 / (p : ℝ)) + (t : ℝ) by ring]
  rw [Int.floor_add_intCast, hfloor_aux]
  have hAl : (A : ℝ) = (l : ℝ) * (q : ℝ) := by
    dsimp [A]
    push_cast
    ring
  have hceil_l : ⌈(l : ℝ) * (q : ℝ) / (p : ℝ)⌉ = ⌈(A : ℝ) / (p : ℝ)⌉ := by
    rw [hAl]
  rw [hceil_l, hceil_aux]
  dsimp [A]
  by_cases hr : (l * q) % p = 0 <;> simp [hr] <;> ring

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_choose_residue_shift (p q : ℤ) (hp : 0 < p)
    (hcop : Int.gcd p q = 1) :
    ∃ j t : ℤ, j * q + 1 = t * p := by
  by_cases hp1 : p = 1
  · exact ⟨0, 1, by simp [hp1]⟩
  obtain ⟨j, hj0, hjp, hjmod⟩ :=
    External.Paparella2013.coprimeMul_residue_exists p q (-1) (by omega)
      (by simpa [Int.gcd_comm] using hcop)
  have hmod : (j * q + 1) % p = 0 := by
    rw [Int.add_emod]
    have hmul : (j * q) % p = (-1 : ℤ) % p := by
      simpa [mul_comm] using hjmod
    rw [hmul]
    simp
  have hdvd : p ∣ j * q + 1 := Int.dvd_of_emod_eq_zero hmod
  obtain ⟨t, ht⟩ := hdvd
  refine ⟨j, t, ?_⟩
  nlinarith [ht]

-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
private theorem periodicWord_ceiling_set_eq_beatty (p q N t j : ℤ) (hp : 0 < p)
    (hrel : j * q + 1 = t * p) :
    Set.range (fun l : ℤ => N - 1 + ⌈(l : ℝ) * (q : ℝ) / (p : ℝ)⌉) =
      integerTranslatedRationalBeattySet p q (N-t) := by
  ext z
  change (∃ l : ℤ, N - 1 + ⌈(l : ℝ) * (q : ℝ)/(p : ℝ)⌉ = z) ↔
    ∃ k : ℤ, ⌊(k : ℝ) * ((q : ℝ)/(p : ℝ)) + ((N-t : ℤ) : ℝ)⌋ = z
  constructor
  · rintro ⟨l, rfl⟩
    let k : ℤ := l + j
    refine ⟨k, ?_⟩
    rw [Int.floor_add_intCast]
    have hs := floor_shift_ceiling p q j t l hp hrel
    have hfloor : ⌊(k : ℝ) * ((q : ℝ)/(p : ℝ))⌋ =
        ⌈(l : ℝ) * (q : ℝ)/(p : ℝ)⌉ + t - 1 := by
      dsimp [k]
      convert hs using 1
      ring_nf
    rw [hfloor]
    omega
  · rintro ⟨k, hk⟩
    let l : ℤ := k - j
    refine ⟨l, ?_⟩
    have hs := floor_shift_ceiling p q j t l hp hrel
    have hkl : l+j=k := by dsimp [l]; omega
    rw [show (k : ℝ) * ((q : ℝ)/(p : ℝ)) =
      ((l+j : ℤ) : ℝ) * (q : ℝ)/(p : ℝ) by rw [hkl]; ring] at hk
    rw [Int.floor_add_intCast] at hk
    rw [hs] at hk
    omega

/-- Every nonempty proper periodic balanced subset is an integer-translated
rational Beatty set. The proof reconstructs the cumulative mechanical word,
reduces its rational rate, and performs the complete-residue floor/ceiling
reindexing recorded in the package proof.
-/
-- zpi: lem-periodic-balanced-subsets-are-rational-beatty-sets
theorem periodicBalancedSubsetsAreRationalBeattySets (X : Set ℤ)
    (hX : PeriodicBalancedSubset X) (hNonempty : X.Nonempty)
    (hProper : Xᶜ.Nonempty) :
    ∃ p q r : ℤ, 0 < p ∧ p < q ∧
      X = integerTranslatedRationalBeattySet p q r := by
  obtain ⟨Q, hQ, hper, hbal⟩ := hX
  let W : ℤ → Bool := binarySubsetWord X
  have hperW : Function.Periodic W Q := by
    simpa [W] using hper
  have hbalW : BalancedWord W := by
    simpa [W] using hbal
  obtain ⟨t₁, ht₁, hwt₁⟩ := periodicWord_has_true_residue X Q hQ hper hNonempty
  obtain ⟨t₀, ht₀, hwt₀⟩ := periodicWord_has_false_residue X Q hQ hper hProper
  have htrueW : ∃ t ∈ Finset.Ico (0 : ℤ) Q, W t = true := by
    refine ⟨t₁, ht₁, ?_⟩
    simpa [W] using hwt₁
  have hfalseW : ∃ t ∈ Finset.Ico (0 : ℤ) Q, W t = false := by
    refine ⟨t₀, ht₀, ?_⟩
    simpa [W] using hwt₀
  have hPQ_count := periodCount_bounds W Q hQ htrueW hfalseW
  let P : ℤ := wordIntervalCount W true 0 Q
  have hP : wordIntervalCount W true 0 Q = P := by rfl
  have hPpos : 0 < P := by simpa [P] using hPQ_count.1
  have hPq : P < Q := by simpa [P] using hPQ_count.2
  have hbound : ∀ (m : ℤ) (L : ℕ),
      ⌊(L : ℝ) * (P : ℝ) / (Q : ℝ)⌋ ≤
          wordIntervalCount W true m (m + (L : ℤ)) ∧
        wordIntervalCount W true m (m + (L : ℤ)) ≤
          ⌈(L : ℝ) * (P : ℝ) / (Q : ℝ)⌉ := by
    intro m L
    exact periodicWord_factor_bounds_all W Q hQ hperW hbalW P hP m L
  have hFperiod : ∀ n : ℤ, periodicWordCumulative W (n + Q) =
      periodicWordCumulative W n + P := by
    intro n
    exact periodicWord_cumulative_period W Q P hQ hperW hP n
  have hDperiod : ∀ n : ℤ, periodicWordDiscrepancy W Q P (n + Q) =
      periodicWordDiscrepancy W Q P n := by
    intro n
    exact periodicWord_discrepancy_period W Q P hQ hFperiod n
  obtain ⟨N, hF⟩ := periodicWord_floor_representation W Q P hQ hDperiod hbound
  obtain ⟨p, q, hp, hpq, hcop, hrate⟩ := reducedPositiveRate P Q hPpos hPq
  obtain ⟨j, t, hrel⟩ := periodicWord_choose_residue_shift p q hp hcop
  have hjump := periodicWord_jump_positions W P Q p q N hp hpq hrate hF
  have hXceil : X = Set.range
      (fun l : ℤ => N - 1 + ⌈(l : ℝ) * (q : ℝ) / (p : ℝ)⌉) := by
    ext z
    constructor
    · intro hz
      have hw : W z = true := by
        simpa [W] using (binarySubsetWord_true_iff X z).2 hz
      obtain ⟨l, hl⟩ := (hjump z).1 hw
      exact ⟨l, hl.symm⟩
    · rintro ⟨l, hl⟩
      have hw : W z = true := (hjump z).2 ⟨l, hl.symm⟩
      exact (binarySubsetWord_true_iff X z).1 (by simpa [W] using hw)
  refine ⟨p, q, N - t, hp, hpq, ?_⟩
  calc
    X = Set.range (fun l : ℤ => N - 1 +
        ⌈(l : ℝ) * (q : ℝ) / (p : ℝ)⌉) := hXceil
    _ = integerTranslatedRationalBeattySet p q (N - t) :=
      periodicWord_ceiling_set_eq_beatty p q N t j hp hrel

end Fraenkel
