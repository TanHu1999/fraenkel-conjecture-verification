import Fraenkel.Words.Periodic

open scoped BigOperators Classical

namespace Fraenkel

/-- An order enumeration counts exactly its retained interval. -/
theorem retainedIntervalCountScratch {m : ℕ} (W : ℤ → Fin m) (a : Fin m)
    (e : ℤ ≃o RetainedPositions W a) (u v : ℤ) (huv : u ≤ v) :
    (((Finset.Ico (e u).val (e v).val).filter (fun t => W t ≠ a)).card : ℤ) =
      v - u := by
  classical
  have hcard : (Finset.Ico u v).card =
      ((Finset.Ico (e u).val (e v).val).filter (fun t => W t ≠ a)).card := by
    apply Finset.card_bij (fun j _ => (e j).val)
    · intro j hj
      obtain ⟨hju, hjv⟩ := Finset.mem_Ico.mp hj
      exact Finset.mem_filter.mpr
        ⟨Finset.mem_Ico.mpr ⟨e.monotone hju, e.strictMono hjv⟩, (e j).property⟩
    · intro i hi j hj hij
      exact e.injective (Subtype.ext hij)
    · intro t ht
      obtain ⟨htI, htret⟩ := Finset.mem_filter.mp ht
      obtain ⟨htu, htv⟩ := Finset.mem_Ico.mp htI
      let r : RetainedPositions W a := ⟨t, htret⟩
      refine ⟨e.symm r, Finset.mem_Ico.mpr ⟨?_, ?_⟩, ?_⟩
      · have : e u ≤ r := htu
        simpa using e.symm.monotone this
      · have : r < e v := htv
        simpa using e.symm.strictMono this
      · simp [r]
  rw [← hcard]
  simp [Int.card_Ico, Int.toNat_of_nonneg (sub_nonneg.mpr huv)]

/-- Counts of undeleted letters are preserved under order compression. -/
theorem compressedIntervalCountScratch {m : ℕ} (W : ℤ → Fin m) (a : Fin m)
    (W' : ℤ → DeletedAlphabet m a) (e : ℤ ≃o RetainedPositions W a)
    (he : ∀ j, W' j = ⟨W (e j).val, (e j).property⟩)
    (c : DeletedAlphabet m a) (u v : ℤ) :
    wordIntervalCount W' c u v = wordIntervalCount W c.val (e u).val (e v).val := by
  classical
  unfold wordIntervalCount
  apply congrArg (fun n : ℕ => (n : ℤ))
  apply Finset.card_bij (fun j _ => (e j).val)
  · intro j hj
    simp only [Finset.mem_filter] at hj ⊢
    obtain ⟨hjI, hjc⟩ := hj
    obtain ⟨hju, hjv⟩ := Finset.mem_Ico.mp hjI
    refine ⟨Finset.mem_Ico.mpr ⟨e.monotone hju, e.strictMono hjv⟩, ?_⟩
    change W (e j).val = c.val
    rw [he j] at hjc
    exact congrArg Subtype.val hjc
  · intro i hi j hj hij
    exact e.injective (Subtype.ext hij)
  · intro t ht
    simp only [Finset.mem_filter] at ht ⊢
    obtain ⟨htI, htc⟩ := ht
    obtain ⟨htu, htv⟩ := Finset.mem_Ico.mp htI
    have htret : W t ≠ a := fun hta => c.property (htc.symm.trans hta)
    let r : RetainedPositions W a := ⟨t, htret⟩
    refine ⟨e.symm r, ⟨Finset.mem_Ico.mpr ⟨?_, ?_⟩, ?_⟩, ?_⟩
    · have : e u ≤ r := htu
      simpa using e.symm.monotone this
    · have : r < e v := htv
      simpa using e.symm.strictMono this
    · apply Subtype.ext
      rw [he]
      simpa [r]
    · simp [r]

theorem retainedEnumerationShiftScratch {m : ℕ} (W : ℤ → Fin m) (a : Fin m)
    (e : ℤ ≃o RetainedPositions W a) (q p : ℤ)
    (hq : 0 < q) (hp : 0 < p) (hpq : p < q)
    (hper : Function.Periodic W q)
    (hcount : ∀ z : ℤ,
      (((Finset.Ico z (z + q)).filter (fun t => W t ≠ a)).card : ℤ) = q - p) :
    ∀ j : ℤ, (e (j + (q - p))).val = (e j).val + q := by
  intro j
  have hret : W ((e j).val + q) ≠ a := by
    intro hta
    apply (e j).property
    rw [← hper (e j).val]
    exact hta
  let r : RetainedPositions W a := ⟨(e j).val + q, hret⟩
  let j' : ℤ := e.symm r
  have hjle : j ≤ j' := by
    have her : e j ≤ r := by
      dsimp [r]
      exact_mod_cast (show (e j).val ≤ (e j).val + q by omega)
    simpa [j'] using e.symm.monotone her
  have henum := retainedIntervalCountScratch W a e j j' hjle
  have hrval : (e j').val = (e j).val + q := by
    simp [j', r]
  rw [hrval] at henum
  have hc := hcount (e j).val
  have hjdiff : j' - j = q - p := by
    linarith
  have hj'val : j' = j + (q - p) := by omega
  have heq : e (j + (q - p)) = r := by
    rw [← hj'val]
    simp [j']
  exact congrArg Subtype.val heq

theorem compressedWordPeriodicScratch {m : ℕ} (W : ℤ → Fin m) (a : Fin m)
    (W' : ℤ → DeletedAlphabet m a)
    (e : ℤ ≃o RetainedPositions W a)
    (he : ∀ j, W' j = ⟨W (e j).val, (e j).property⟩)
    (q p : ℤ) (hper : Function.Periodic W q)
    (hshift : ∀ j : ℤ, (e j).val + q = (e (j + (q - p))).val) :
    Function.Periodic W' (q - p) := by
  intro j
  rw [he (j + (q - p)), he j]
  apply Subtype.ext
  change W (e (j + (q - p))).val = W (e j).val
  rw [← hshift j, hper]

theorem retainedCountFromDeletedCountScratch {m : ℕ} (W : ℤ → Fin m) (a : Fin m)
    (q p : ℤ) (hq : 0 ≤ q)
    (hcount : ∀ z : ℤ, wordIntervalCount W a z (z + q) = p) :
    ∀ z : ℤ,
      (((Finset.Ico z (z + q)).filter (fun t => W t ≠ a)).card : ℤ) = q - p := by
  intro z
  let Feq := (Finset.Ico z (z + q)).filter (fun t => W t = a)
  let Fne := (Finset.Ico z (z + q)).filter (fun t => W t ≠ a)
  have heq : wordIntervalCount W a z (z + q) = (Feq.card : ℤ) := by
    unfold wordIntervalCount
    apply congrArg (fun s : Finset ℤ => (s.card : ℤ))
    ext t
    simp [Feq]
  have hFeq : Feq.card =
      ((Finset.Ico z (z + q)).filter (fun t : ℤ => W t = a)).card := by
    rfl
  have hFne : Fne.card =
      ((Finset.Ico z (z + q)).filter (fun t : ℤ => ¬ W t = a)).card := by
    rfl
  have hcard := Finset.card_filter_add_card_filter_not
    (s := Finset.Ico z (z + q)) (fun t : ℤ => W t = a)
  rw [Int.card_Ico] at hcard
  have hcardZ := congrArg (fun n : ℕ => (n : ℤ)) hcard
  have hqcast : ((z + q - z).toNat : ℤ) = q := by
    rw [Int.toNat_of_nonneg (by omega : 0 ≤ z + q - z)]
    omega
  have htotal : (Feq.card : ℤ) + (Fne.card : ℤ) = q := by
    rw [hFeq, hFne]
    push_cast at hcardZ
    rw [hqcast] at hcardZ
    convert hcardZ using 1 <;> omega
  rw [← heq, hcount z] at htotal
  unfold Fne at htotal
  linarith

theorem codingWordIntervalCount_eq_integerBlockCountScratch {m : ℕ}
    (α β : Fin m → ℝ) (hpart : BeattyPartition α β) (i : Fin m)
    (u v : ℤ) (huv : u ≤ v) :
    wordIntervalCount (beattyPartitionCodingWord α β hpart) i u v =
      integerBlockCount (biInfiniteBeattySequence (α i) (β i)) u
        (v - u).toNat := by
  have huv' : 0 ≤ v - u := by omega
  have hend : u + ((v - u).toNat : ℤ) = v := by
    rw [Int.toNat_of_nonneg huv']
    omega
  unfold wordIntervalCount integerBlockCount
  rw [hend]
  apply congrArg (fun s : Finset ℤ => (s.card : ℤ))
  ext t
  simp only [Finset.mem_filter, Finset.mem_Ico]
  constructor
  · rintro ⟨ht, hw⟩
    exact ⟨ht, (beattyPartitionCodingWord_spec α β hpart t i).mp hw⟩
  · rintro ⟨ht, hs⟩
    exact ⟨ht, (beattyPartitionCodingWord_spec α β hpart t i).mpr hs⟩

theorem wordIntervalCount_mul_periodScratch {A : Type*} (W : ℤ → A) (c : A)
    (k p : ℤ) (hk : 0 < k)
    (hcount : ∀ z : ℤ, wordIntervalCount W c z (z + k) = p) :
    ∀ z : ℤ, ∀ n : ℕ,
      wordIntervalCount W c z (z + (n : ℤ) * k) = (n : ℤ) * p := by
  intro z n
  induction n with
  | zero => simp [wordIntervalCount]
  | succ n ih =>
      have hn0 : 0 ≤ (n : ℤ) * k := mul_nonneg (by positivity) hk.le
      have hdiff : ((n + 1 : ℕ) : ℤ) * k - (n : ℤ) * k = k := by
        push_cast
        ring
      have hsplit := wordIntervalCount_add W c z
        (z + (n : ℤ) * k) (z + ((n + 1 : ℕ) : ℤ) * k)
        (by linarith) (by linarith [hdiff, hk.le])
      rw [hsplit, ih]
      have hstep := hcount (z + (n : ℤ) * k)
      have hend : z + (n : ℤ) * k + k =
          z + ((n + 1 : ℕ) : ℤ) * k := by
        push_cast
        ring
      rw [hend] at hstep
      rw [hstep]
      push_cast
      ring

theorem wordIntervalCount_eq_integerBlockCount_of_memScratch
    {A : Type*} (W : ℤ → A) (c : A) (X : Set ℤ)
    (hX : ∀ z : ℤ, W z = c ↔ z ∈ X)
    (u v : ℤ) (huv : u ≤ v) :
    wordIntervalCount W c u v = integerBlockCount X u (v - u).toNat := by
  have huv' : 0 ≤ v - u := by omega
  have hend : u + ((v - u).toNat : ℤ) = v := by
    rw [Int.toNat_of_nonneg huv']
    omega
  unfold wordIntervalCount integerBlockCount
  rw [hend]
  apply congrArg (fun s : Finset ℤ => (s.card : ℤ))
  ext t
  simp only [Finset.mem_filter, Finset.mem_Ico]
  constructor
  · rintro ⟨ht, hw⟩
    exact ⟨ht, (hX t).mp hw⟩
  · rintro ⟨ht, hs⟩
    exact ⟨ht, (hX t).mpr hs⟩

theorem integerIndicator_period_mem_iffScratch (X : Set ℤ) (q : ℤ)
    (hper : Function.Periodic (integerIndicator X) q) (z : ℤ) :
    z + q ∈ X ↔ z ∈ X := by
  have hz := hper z
  constructor
  · intro hplus
    by_contra hnot
    have hone : integerIndicator X (z + q) = 1 := by
      simp [integerIndicator, hplus]
    have hzero : integerIndicator X z = 0 := by
      simp [integerIndicator, hnot]
    linarith
  · intro hzmem
    by_contra hnot
    have hzero : integerIndicator X (z + q) = 0 := by
      simp [integerIndicator, hnot]
    have hone : integerIndicator X z = 1 := by
      simp [integerIndicator, hzmem]
    linarith

theorem binarySubsetBalancedOfBalancedWordScratch {A : Type*}
    (W : ℤ → A) (c : A) (hbal : BalancedWord W) :
    BalancedWord (binarySubsetWord {z : ℤ | W z = c}) := by
  let X : Set ℤ := {z : ℤ | W z = c}
  have htrue (u : ℤ) (n : ℕ) :
      wordIntervalCount (binarySubsetWord X) true u (u + n) =
        wordIntervalCount W c u (u + n) := by
    unfold wordIntervalCount
    apply congrArg (fun s : Finset ℤ => (s.card : ℤ))
    ext t
    simp [binarySubsetWord, X]
  have hfalse (u : ℤ) (n : ℕ) :
      wordIntervalCount (binarySubsetWord X) false u (u + n) =
        (n : ℤ) - wordIntervalCount W c u (u + n) := by
    let S := Finset.Ico u (u + (n : ℤ))
    have hcard := Finset.card_filter_add_card_filter_not
      (s := S) (fun t : ℤ => binarySubsetWord X t = true)
    have hcardZ := congrArg (fun k : ℕ => (k : ℤ)) hcard
    have hS : (S.card : ℤ) = n := by
      dsimp [S]
      rw [Int.card_Ico]
      simp
    have htrue' : wordIntervalCount (binarySubsetWord X) true u (u + n) =
        (S.filter (fun t : ℤ => binarySubsetWord X t = true)).card := by
      unfold wordIntervalCount
      apply congrArg (fun s : Finset ℤ => (s.card : ℤ))
      apply Finset.ext
      intro t
      simp [S]
    have hfalse' : wordIntervalCount (binarySubsetWord X) false u (u + n) =
        (S.filter (fun t : ℤ => binarySubsetWord X t = false)).card := by
      unfold wordIntervalCount
      apply congrArg (fun s : Finset ℤ => (s.card : ℤ))
      apply Finset.ext
      intro t
      simp [S]
    have hnot : S.filter (fun t : ℤ => ¬ binarySubsetWord X t = true) =
        S.filter (fun t : ℤ => binarySubsetWord X t = false) := by
      ext t
      simp
    rw [hnot] at hcardZ
    rw [hfalse']
    push_cast at hcardZ
    have hcardZ' :
        (S.filter (fun t : ℤ => binarySubsetWord X t = true)).card +
          (S.filter (fun t : ℤ => binarySubsetWord X t = false)).card = n := by
      rw [hS] at hcardZ
      exact_mod_cast hcardZ
    have hW : wordIntervalCount W c u (u + n) =
        (S.filter (fun t : ℤ => binarySubsetWord X t = true)).card := by
      exact (htrue u n).symm.trans htrue'
    linarith
  intro d u v n
  cases d with
  | false =>
      rw [hfalse u n, hfalse v n]
      have hb := hbal c u v n
      have hdiff : ((n : ℤ) - wordIntervalCount W c u (u + n)) -
          ((n : ℤ) - wordIntervalCount W c v (v + n)) =
          wordIntervalCount W c v (v + n) - wordIntervalCount W c u (u + n) := by
        ring
      rw [hdiff]
      simpa [abs_sub_comm] using hb
  | true =>
      rw [htrue u n, htrue v n]
      exact hbal c u v n

end Fraenkel
