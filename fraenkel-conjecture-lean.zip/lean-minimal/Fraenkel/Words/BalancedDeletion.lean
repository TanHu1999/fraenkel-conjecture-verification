import Fraenkel.Beatty.Normalization
import Fraenkel.External.Algebrica
import Fraenkel.External.StonyBrook
import Mathlib.Order.SuccPred.LinearLocallyFinite

/-!
# Balanced Beatty coding words and deletion

Finite words are functions on `Fin n`. A factor of a bi-infinite word is its
restriction to consecutive integer positions. Counts take values in `ℤ`, so
subtraction is ordinary integer subtraction, never truncated subtraction.
-/

open scoped BigOperators Classical

namespace Fraenkel

/-- Number of copies of a letter in a finite word. -/
-- zpi: def-balanced-bi-infinite-word
noncomputable def finiteWordCount {A : Type*} {n : ℕ} (Y : Fin n → A) (c : A) : ℤ := by
  classical
  exact ((Finset.univ.filter (fun i => Y i = c)).card : ℤ)

/-- The length-`n` factor starting at `u`. -/
-- zpi: def-balanced-bi-infinite-word
def wordFactor {A : Type*} (W : ℤ → A) (u : ℤ) (n : ℕ) : Fin n → A :=
  fun i => W (u + (i.val : ℤ))

/-- Count in the integer interval `[u,v)`. -/
-- zpi: def-balanced-bi-infinite-word
noncomputable def wordIntervalCount {A : Type*} (W : ℤ → A) (c : A) (u v : ℤ) : ℤ := by
  classical
  exact (((Finset.Ico u v).filter (fun t => W t = c)).card : ℤ)

-- zpi: def-balanced-bi-infinite-word
theorem wordFactor_count {A : Type*} (W : ℤ → A) (c : A) (u : ℤ) (n : ℕ) :
    finiteWordCount (wordFactor W u n) c = wordIntervalCount W c u (u + n) := by
  classical
  unfold finiteWordCount wordIntervalCount
  congr 1
  apply Finset.card_bij (fun i _ => u + (i.val : ℤ))
  · intro i hi
    have hc := (Finset.mem_filter.mp hi).2
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_Ico.mpr ?_, hc⟩
    have hn : (i.val : ℤ) < (n : ℤ) := by exact_mod_cast i.isLt
    constructor <;> omega
  · intro i _ j _ hij
    apply Fin.ext
    omega
  · intro t ht
    obtain ⟨ht, hc⟩ := Finset.mem_filter.mp ht
    obtain ⟨hlo, hhi⟩ := Finset.mem_Ico.mp ht
    let i : Fin n := ⟨(t - u).toNat, by omega⟩
    have hi : u + (i.val : ℤ) = t := by dsimp [i]; omega
    exact ⟨i, Finset.mem_filter.mpr ⟨Finset.mem_univ _, by simpa [wordFactor, hi] using hc⟩, hi⟩

/-- Balance for all letters and all equal-length finite factors. This total
predicate also makes sense on an infinite alphabet; the package uses finite ones. -/
-- zpi: def-balanced-bi-infinite-word
def BalancedWord {A : Type*} (W : ℤ → A) : Prop :=
  ∀ (c : A) (u v : ℤ) (n : ℕ),
    |wordIntervalCount W c u (u + n) - wordIntervalCount W c v (v + n)| ≤ 1

-- zpi: def-balanced-bi-infinite-word
theorem balancedWord_spec {A : Type*} [Finite A] (W : ℤ → A) :
    BalancedWord W ↔ ∀ (c : A) (u v : ℤ) (n : ℕ),
      |finiteWordCount (wordFactor W u n) c - finiteWordCount (wordFactor W v n) c| ≤ 1 := by
  simp only [BalancedWord, wordFactor_count]

/-- The unique letter whose part contains the given position. -/
-- zpi: def-beatty-partition-coding-word
noncomputable def beattyPartitionCodingWord {m : ℕ} (α β : Fin m → ℝ)
    (hpart : BeattyPartition α β) (z : ℤ) : Fin m :=
  (hpart.2 z).choose

-- zpi: def-beatty-partition-coding-word
theorem beattyPartitionCodingWord_spec {m : ℕ} (α β : Fin m → ℝ)
    (hpart : BeattyPartition α β) (z : ℤ) (i : Fin m) :
    beattyPartitionCodingWord α β hpart z = i ↔ z ∈ biInfiniteBeattySequence (α i) (β i) := by
  have hs := (hpart.2 z).choose_spec
  constructor
  · intro hi
    change (hpart.2 z).choose = i at hi
    simpa only [hi] using hs.1
  · intro hi
    exact (hs.2 i hi).symm

-- zpi: def-beatty-partition-coding-word
theorem beattyPartitionCodingWord_unique {m : ℕ} (α β : Fin m → ℝ)
    (hpart : BeattyPartition α β) (W : ℤ → Fin m)
    (hW : ∀ z i, W z = i ↔ z ∈ biInfiniteBeattySequence (α i) (β i)) :
    W = beattyPartitionCodingWord α β hpart := by
  funext z
  exact (beattyPartitionCodingWord_spec α β hpart z (W z)).mpr ((hW z (W z)).mp rfl) |>.symm

/-- Every part has its letter; no empty letter is silently introduced. -/
-- zpi: def-beatty-partition-coding-word
theorem beattyPartitionCodingWord_surjective {m : ℕ} (α β : Fin m → ℝ)
    (hpart : BeattyPartition α β) : Function.Surjective (beattyPartitionCodingWord α β hpart) := by
  intro i
  refine ⟨⌊β i⌋, (beattyPartitionCodingWord_spec α β hpart _ i).mpr ?_⟩
  exact ⟨0, by simp⟩

/-- Translation between the already-proved Beatty index count and the external
half-open-interval count. The former supplies the injective index correspondence. -/
-- zpi: prop-beatty-partition-coding-word-is-balanced
theorem codingWord_intervalCount {m : ℕ} (α β : Fin m → ℝ) (hpart : BeattyPartition α β)
    (i : Fin m) (u v : ℤ) (huv : u ≤ v) :
    wordIntervalCount (beattyPartitionCodingWord α β hpart) i u v =
      ⌈((v : ℝ) - β i) / α i⌉ - ⌈((u : ℝ) - β i) / α i⌉ := by
  classical
  have hα : 0 < α i := lt_trans zero_lt_one (hpart.1 i)
  let a := ((u : ℝ) - β i) / α i
  let b := ((v : ℝ) - β i) / α i
  have hab : a ≤ b := by
    apply div_le_div_of_nonneg_right _ hα.le
    have : (u : ℝ) ≤ (v : ℝ) := by exact_mod_cast huv
    linarith
  have heq : wordIntervalCount (beattyPartitionCodingWord α β hpart) i u v =
      (integerBlockCount (biInfiniteBeattySequence (α i) (β i)) u (v-u).toNat : ℤ) := by
    have hv : u + ((v-u).toNat : ℤ) = v := by omega
    simp only [wordIntervalCount, integerBlockCount, beattyPartitionCodingWord_spec, hv]
  rw [heq, beattyBlockCount_eq_ceil _ _ (hpart.1 i)]
  have hcast : ((v-u).toNat : ℝ) = (v : ℝ) - (u : ℝ) := by
    exact_mod_cast (Int.toNat_of_nonneg (sub_nonneg.mpr huv))
  rw [hcast]
  have hb : (u : ℝ) + ((v : ℝ) - (u : ℝ)) - β i = (v : ℝ) - β i := by ring
  rw [hb]
  have hcard := External.StonyBrook.integerCountInHalfOpenInterval a b hab
  simpa only [External.StonyBrook.integersInHalfOpenInterval, Int.card_Ico] using hcard

/-- The difference of ceilings is between the floor and ceiling of the interval length. -/
-- zpi: prop-beatty-partition-coding-word-is-balanced
theorem ceilDifference_bounds (x t : ℝ) :
    ⌊t⌋ ≤ ⌈x+t⌉ - ⌈x⌉ ∧ ⌈x+t⌉ - ⌈x⌉ ≤ ⌈t⌉ := by
  have hhi := Int.ceil_add_le x t
  have hlo := Int.ceil_mono (show x + (⌊t⌋ : ℝ) ≤ x + t by linarith [Int.floor_le t])
  rw [Int.ceil_add_intCast] at hlo
  omega

-- zpi: prop-beatty-partition-coding-word-is-balanced
theorem codingWord_count_bounds {m : ℕ} (α β : Fin m → ℝ) (hpart : BeattyPartition α β)
    (i : Fin m) (u : ℤ) (n : ℕ) :
    ⌊(n : ℝ) / α i⌋ ≤ wordIntervalCount (beattyPartitionCodingWord α β hpart) i u (u+n) ∧
    wordIntervalCount (beattyPartitionCodingWord α β hpart) i u (u+n) ≤ ⌈(n : ℝ) / α i⌉ := by
  rw [codingWord_intervalCount α β hpart i u (u+n) (by omega)]
  have heq : (((u+n : ℤ) : ℝ) - β i) / α i =
      ((u : ℝ) - β i) / α i + (n : ℝ) / α i := by push_cast; ring
  rw [heq]
  exact ceilDifference_bounds _ _

/-- Every Beatty partition coding word is balanced. -/
-- zpi: prop-beatty-partition-coding-word-is-balanced
theorem beattyPartitionCodingWord_balanced {m : ℕ} (α β : Fin m → ℝ)
    (hpart : BeattyPartition α β) : BalancedWord (beattyPartitionCodingWord α β hpart) := by
  intro i u v n
  have hu := codingWord_count_bounds α β hpart i u n
  have hv := codingWord_count_bounds α β hpart i v n
  have hd := Int.ceil_le_floor_add_one ((n : ℝ) / α i)
  rw [abs_le]
  omega

/-- The floor/ceiling gap relation stated in the deletion proof. -/
-- zpi: lem-deletion-at-rate-at-most-three
theorem beattyGap_floor_or_ceil (α β : ℝ) (j h : ℤ) :
    beattyTerm α β (j+h) - beattyTerm α β j = ⌊(h : ℝ)*α⌋ ∨
    beattyTerm α β (j+h) - beattyTerm α β j = ⌈(h : ℝ)*α⌉ := by
  have hh := External.Algebrica.floorDifference ((j : ℝ)*α+β) ((h : ℝ)*α)
  have he : ((j+h : ℤ) : ℝ)*α+β = ((j : ℝ)*α+β) + (h : ℝ)*α := by push_cast; ring
  simpa only [beattyTerm, he] using hh

/-- Integer-length form of balance, convenient for comparing minimal lifts. -/
-- zpi: lem-deletion-at-rate-at-most-three
theorem BalancedWord.interval {A : Type*} {W : ℤ → A} (hW : BalancedWord W)
    (c : A) (u v n : ℤ) (hn : 0 ≤ n) :
    |wordIntervalCount W c u (u+n) - wordIntervalCount W c v (v+n)| ≤ 1 := by
  simpa [Int.toNat_of_nonneg hn] using hW c u v n.toNat

-- zpi: lem-deletion-at-rate-at-most-three
theorem wordIntervalCount_bounds {A : Type*} (W : ℤ → A) (c : A) (u v : ℤ) (huv : u ≤ v) :
    0 ≤ wordIntervalCount W c u v ∧ wordIntervalCount W c u v ≤ v-u := by
  classical
  have hh := Finset.card_le_card (Finset.filter_subset (fun t => W t = c) (Finset.Ico u v))
  have hhc : (((Finset.Ico u v).filter (fun t => W t = c)).card : ℤ) ≤
      ((Finset.Ico u v).card : ℤ) := by exact_mod_cast hh
  rw [Int.card_Ico, Int.toNat_of_nonneg (sub_nonneg.mpr huv)] at hhc
  exact ⟨by unfold wordIntervalCount; positivity, hhc⟩

-- zpi: lem-deletion-at-rate-at-most-three
theorem wordIntervalCount_add {A : Type*} (W : ℤ → A) (c : A) (u v w : ℤ)
    (huv : u ≤ v) (hvw : v ≤ w) :
    wordIntervalCount W c u w = wordIntervalCount W c u v + wordIntervalCount W c v w := by
  classical
  have hd : Disjoint (Finset.Ico u v) (Finset.Ico v w) := by
    apply Finset.disjoint_left.mpr
    intro x hx hy
    have hh := Finset.mem_Ico.mp hx
    have hh' := Finset.mem_Ico.mp hy
    omega
  simp only [wordIntervalCount, ← Finset.Ico_union_Ico_eq_Ico huv hvw,
    Finset.filter_union, Finset.card_union_of_disjoint (Finset.disjoint_filter_filter hd), Nat.cast_add]

-- zpi: lem-deletion-at-rate-at-most-three
theorem wordIntervalCount_single {A : Type*} (W : ℤ → A) (c : A) (u : ℤ) :
    wordIntervalCount W c u (u+1) = if W u = c then 1 else 0 := by
  classical
  have hs : Finset.Ico u (u+1) = {u} := by ext t; simp only [Finset.mem_Ico, Finset.mem_singleton]; omega
  by_cases hc : W u = c
  · rw [wordIntervalCount, hs]
    simp only [Finset.filter_singleton]
    simp [hc]
  · rw [wordIntervalCount, hs]
    simp only [Finset.filter_singleton]
    simp [hc]

-- zpi: lem-deletion-at-rate-at-most-three
theorem wordIntervalCount_empty {A : Type*} (W : ℤ → A) (c : A) (u : ℤ) :
    wordIntervalCount W c u u = 0 := by simp [wordIntervalCount]

/-- Strict interval-count bounds, equivalent to the two floor/ceiling gap
inequalities used at the end of the source's minimal-lift proof. -/
-- zpi: lem-deletion-at-rate-at-most-three
theorem codingWord_count_strict {m : ℕ} (α β : Fin m → ℝ) (hpart : BeattyPartition α β)
    (a : Fin m) (u v : ℤ) (huv : u ≤ v) :
    ((v-u : ℤ) : ℝ) / α a - 1 <
      (wordIntervalCount (beattyPartitionCodingWord α β hpart) a u v : ℝ) ∧
    (wordIntervalCount (beattyPartitionCodingWord α β hpart) a u v : ℝ) <
      ((v-u : ℤ) : ℝ) / α a + 1 := by
  rw [codingWord_intervalCount α β hpart a u v huv]
  simp only [Int.cast_sub]
  have h₁ := Int.le_ceil (((v : ℝ)-β a)/α a)
  have h₂ := Int.ceil_lt_add_one (((v : ℝ)-β a)/α a)
  have h₃ := Int.le_ceil (((u : ℝ)-β a)/α a)
  have h₄ := Int.ceil_lt_add_one (((u : ℝ)-β a)/α a)
  have he : ((v : ℝ)-(u : ℝ))/α a = ((v : ℝ)-β a)/α a - ((u : ℝ)-β a)/α a := by
    ring
  rw [he]
  constructor <;> linarith

/-- The alphabet after deleting one letter. -/
-- zpi: def-balanced-bi-infinite-word
def DeletedAlphabet (m : ℕ) (a : Fin m) := {i : Fin m // i ≠ a}

/-- Positions retained after deleting `a`. -/
-- zpi: lem-deletion-at-rate-at-most-three
abbrev RetainedPositions {m : ℕ} (W : ℤ → Fin m) (a : Fin m) :=
  {z : ℤ // W z ≠ a}

/-- A compressed deletion is an order-preserving reindexing of exactly the
retained positions. This is the formal version of deleting all `a`'s and
compressing the remaining positions; no arbitrary subsequence is admitted. -/
-- zpi: lem-deletion-at-rate-at-most-three
def IsCompressedDeletion {m : ℕ} (W : ℤ → Fin m) (a : Fin m)
    (W' : ℤ → DeletedAlphabet m a) : Prop :=
  ∃ e : ℤ ≃o RetainedPositions W a, ∀ j : ℤ,
    W' j = ⟨W (e j).val, (e j).property⟩

/-- The source lemma: when the deleted Beatty rate is at most three, a balanced
Beatty coding word admits a balanced compressed deletion. The order-isomorphism
in `IsCompressedDeletion` makes the compression relation part of the theorem,
not an implicit reader convention.

The factor-lift argument from the package is formalized below using the
retained-position order isomorphism and minimal factor lifts. -/
-- zpi: lem-deletion-at-rate-at-most-three
theorem deletionAtRateAtMostThree {m : ℕ} (α β : Fin m → ℝ)
    (hpart : BeattyPartition α β) (a : Fin m) (hrate : α a ≤ 3) :
    ∃ W' : ℤ → DeletedAlphabet m a,
      IsCompressedDeletion (beattyPartitionCodingWord α β hpart) a W' ∧
      BalancedWord W' := by
  classical
  let W : ℤ → Fin m := beattyPartitionCodingWord α β hpart
  have hα : 1 < α a := hpart.1 a
  have hαpos : 0 < α a := lt_trans zero_lt_one hα
  have hbal : BalancedWord W := by
    exact beattyPartitionCodingWord_balanced α β hpart
  obtain ⟨N, hN⟩ := exists_nat_gt (α a / (α a - 1))
  have hden : 0 < α a - 1 := by linarith
  have hN' : α a < (N : ℝ) * (α a - 1) :=
    (div_lt_iff₀ hden).mp hN
  have hNpos : 0 < (N : ℝ) := by
    have hratio : 0 < α a / (α a - 1) := div_pos hαpos hden
    have hNnat : 0 < N := by exact_mod_cast (lt_trans hratio hN)
    exact_mod_cast hNnat
  have hdiv : (N : ℝ) / α a < (N : ℝ) - 1 := by
    apply (div_lt_iff₀ hαpos).2
    nlinarith [hN']
  have hineq : (N : ℝ) / α a + 1 < (N : ℝ) := by linarith
  have hgap_interval : ∀ u : ℤ,
      ∃ t ∈ Finset.Ico u (u + (N : ℤ)), W t ≠ a := by
    intro u
    have hcountR := (codingWord_count_strict α β hpart a u
      (u + (N : ℤ)) (by omega)).2
    have hcount : wordIntervalCount W a u (u + (N : ℤ)) < (N : ℤ) := by
      have hcount' : (wordIntervalCount W a u (u + (N : ℤ)) : ℝ) < (N : ℝ) := by
        have hcountR' :
            (wordIntervalCount W a u (u + (N : ℤ)) : ℝ) <
              ((N : ℤ) : ℝ) / α a + 1 := by
          simpa [W] using hcountR
        push_cast at hcountR'
        linarith
      exact_mod_cast hcount'
    let F := (Finset.Ico u (u + (N : ℤ))).filter (fun t => W t = a)
    have hword_eq : wordIntervalCount W a u (u + (N : ℤ)) = (F.card : ℤ) := by
      unfold wordIntervalCount
      apply congrArg (fun s : Finset ℤ => (s.card : ℤ))
      ext t
      simp [F]
    have hFcard : (F.card : ℤ) < (N : ℤ) := by
      rw [← hword_eq]
      exact hcount
    have hIcard : ((Finset.Ico u (u + (N : ℤ))).card : ℤ) = (N : ℤ) := by
      simp [Int.card_Ico]
    have hFne : F ≠ Finset.Ico u (u + (N : ℤ)) := by
      intro hEq
      rw [hEq, hIcard] at hFcard
      omega
    obtain ⟨t, htI, htF⟩ : ∃ t ∈ Finset.Ico u (u + (N : ℤ)), t ∉ F := by
      by_contra hn
      push Not at hn
      apply hFne
      ext t
      constructor
      · intro ht
        exact (Finset.mem_filter.mp (show t ∈
          (Finset.Ico u (u + (N : ℤ))).filter (fun t => W t = a) by
            simpa [F] using ht)).1
      · intro ht
        simpa [F] using hn t ht
    refine ⟨t, htI, ?_⟩
    intro hta
    apply htF
    change t ∈ (Finset.Ico u (u + (N : ℤ))).filter (fun t => W t = a)
    exact Finset.mem_filter.mpr ⟨htI, hta⟩
  have hnonempty_gap : ∀ z : ℤ, ∃ t : ℤ, z < t ∧ W t ≠ a := by
    intro z
    obtain ⟨t, ht, hnot⟩ := hgap_interval (z + 1)
    have ht' := Finset.mem_Ico.mp ht
    exact ⟨t, by omega, hnot⟩
  have hnonempty_gap_below : ∀ z : ℤ, ∃ t : ℤ, t < z ∧ W t ≠ a := by
    intro z
    obtain ⟨t, ht, hnot⟩ := hgap_interval (z - (N : ℤ))
    have ht' := Finset.mem_Ico.mp ht
    exact ⟨t, by omega, hnot⟩
  let R := RetainedPositions W a
  letI : Nonempty R := by
    obtain ⟨t, ht, hnot⟩ := hnonempty_gap 0
    exact ⟨⟨t, hnot⟩⟩
  letI : NoMaxOrder R := ⟨fun x => by
    obtain ⟨t, ht, hnot⟩ := hnonempty_gap x.val
    exact ⟨⟨t, hnot⟩, ht⟩⟩
  letI : NoMinOrder R := ⟨fun x => by
    obtain ⟨t, ht, hnot⟩ := hnonempty_gap_below x.val
    exact ⟨⟨t, hnot⟩, ht⟩⟩
  letI : SuccOrder R := LinearLocallyFiniteOrder.succOrder R
  letI : PredOrder R := LinearLocallyFiniteOrder.predOrder R
  let e : ℤ ≃o R := (orderIsoIntOfLinearSuccPredArch (ι := R)).symm
  let W' : ℤ → DeletedAlphabet m a := fun j =>
    ⟨W (e j).val, (e j).property⟩
  refine ⟨W', ?_, ?_⟩
  · exact ⟨e, by intro j; rfl⟩
  · have hcount_map : ∀ (c : DeletedAlphabet m a) (u v : ℤ), u ≤ v →
        wordIntervalCount W' c u v =
          wordIntervalCount W c.val (e u).val (e v).val := by
      intro c u v huv
      unfold wordIntervalCount
      apply congrArg (fun n : ℕ => (n : ℤ))
      apply Finset.card_bij (fun j _ => (e j).val)
      · intro j hj
        obtain ⟨hjI, hjc⟩ := Finset.mem_filter.mp hj
        obtain ⟨hju, hjv⟩ := Finset.mem_Ico.mp hjI
        simp only [Finset.mem_filter]
        refine ⟨Finset.mem_Ico.mpr ⟨?_, ?_⟩, ?_⟩
        · exact e.monotone hju
        · exact e.strictMono hjv
        · have hjc' := congrArg Subtype.val hjc
          change W (e j).val = c.val at hjc'
          exact hjc'
      · intro i hi j hj hij
        apply e.injective
        exact Subtype.ext hij
      · intro t ht
        have ht' : t ∈ Finset.Ico (e u).val (e v).val ∧ W t = c.val := by
          simpa only [Finset.mem_filter] using ht
        obtain ⟨htI, htc⟩ := ht'
        obtain ⟨htu, htv⟩ := Finset.mem_Ico.mp htI
        have htret : W t ≠ a := by
          intro hta
          apply c.property
          exact htc.symm.trans hta
        let r : R := ⟨t, htret⟩
        let j : ℤ := e.symm r
        have hju : u ≤ j := by
          have : e u ≤ r := by exact htu
          simpa using e.symm.monotone this
        have hjv : j < v := by
          have : r < e v := by exact htv
          simpa [j] using e.symm.strictMono this
        refine ⟨j, ?_, ?_⟩
        · simp only [Finset.mem_filter]
          refine ⟨Finset.mem_Ico.mpr ⟨hju, hjv⟩, ?_⟩
          apply Subtype.ext
          change W (e j).val = c.val
          rw [show e j = r by simp [j]]
          exact htc
        · change (e j).val = t
          simp [j, r]
    have hretained_count : ∀ (u v : ℤ), u ≤ v →
        (Finset.Ico u v).card =
          ((Finset.Ico (e u).val (e v).val).filter (fun t => W t ≠ a)).card := by
      intro u v huv
      apply Finset.card_bij (fun j _ => (e j).val)
      · intro j hj
        obtain ⟨hju, hjv⟩ := Finset.mem_Ico.mp hj
        simp only [Finset.mem_filter]
        refine ⟨Finset.mem_Ico.mpr ⟨e.monotone hju, e.strictMono hjv⟩, (e j).property⟩
      · intro i hi j hj hij
        apply e.injective
        exact Subtype.ext hij
      · intro t ht
        have ht' : t ∈ Finset.Ico (e u).val (e v).val ∧ W t ≠ a := by
          simpa only [Finset.mem_filter] using ht
        obtain ⟨htu, htv⟩ := Finset.mem_Ico.mp ht'.1
        have htret := ht'.2
        let r : R := ⟨t, htret⟩
        let j : ℤ := e.symm r
        have hju : u ≤ j := by
          have : e u ≤ r := by exact htu
          simpa [j] using e.symm.monotone this
        have hjv : j < v := by
          have : r < e v := by exact htv
          simpa [j] using e.symm.strictMono this
        refine ⟨j, Finset.mem_Ico.mpr ⟨hju, hjv⟩, ?_⟩
        simp [j, r]
    have hretained_count_int : ∀ (u v : ℤ), u ≤ v →
        (((Finset.Ico (e u).val (e v).val).filter (fun t => W t ≠ a)).card : ℤ) = v - u := by
      intro u v huv
      rw [← show (Finset.Ico u v).card =
          ((Finset.Ico (e u).val (e v).val).filter (fun t => W t ≠ a)).card by
            exact hretained_count u v huv]
      simp [Int.card_Ico, Int.toNat_of_nonneg (sub_nonneg.mpr huv)]
    have htotal_count : ∀ (p q : ℤ), p ≤ q →
        wordIntervalCount W a p q +
            (((Finset.Ico p q).filter (fun t => W t ≠ a)).card : ℤ) = q - p := by
      intro p q hpq
      let Feq := (Finset.Ico p q).filter (fun t => W t = a)
      let Fne := (Finset.Ico p q).filter (fun t => W t ≠ a)
      have heq : wordIntervalCount W a p q = (Feq.card : ℤ) := by
        unfold wordIntervalCount
        apply congrArg (fun s : Finset ℤ => (s.card : ℤ))
        ext t
        simp [Feq]
      have hFeq : Feq.card =
          ((Finset.Ico p q).filter (fun t : ℤ => W t = a)).card := by
        apply congrArg Finset.card
        ext t
        simp [Feq]
      have hFne : Fne.card =
          ((Finset.Ico p q).filter (fun t : ℤ => ¬ W t = a)).card := by
        apply congrArg Finset.card
        ext t
        simp [Fne]
      have hcard := Finset.card_filter_add_card_filter_not
        (s := Finset.Ico p q) (fun t : ℤ => W t = a)
      have hcardZ := congrArg (fun n : ℕ => (n : ℤ)) hcard
      have hcardZ' : (Feq.card : ℤ) + (Fne.card : ℤ) = q - p := by
        rw [hFeq, hFne]
        simpa only [Nat.cast_add, Int.card_Ico,
          Int.toNat_of_nonneg (sub_nonneg.mpr hpq)] using hcardZ
      calc
        wordIntervalCount W a p q +
              (((Finset.Ico p q).filter (fun t => W t ≠ a)).card : ℤ) =
            (Feq.card : ℤ) + (Fne.card : ℤ) := by
              rw [heq]
        _ = q - p := hcardZ'
    intro c u v n
    by_cases hn : n = 0
    · subst n
      simp [wordIntervalCount_empty]
    have hnpos : 0 < n := Nat.pos_of_ne_zero hn
    have hnposZ : (1 : ℤ) ≤ (n : ℤ) := by exact_mod_cast hnpos
    let last : ℤ → ℤ := fun x => x + (n : ℤ) - 1
    let p : ℤ → ℤ := fun x => (e x).val
    let q : ℤ → ℤ := fun x => (e (last x)).val + 1
    let k : ℤ → ℤ := fun x => wordIntervalCount W a (p x) (q x)
    have hlast_ge : ∀ x : ℤ, x ≤ last x := by
      intro x
      dsimp [last]
      omega
    have hpq : ∀ x : ℤ, p x ≤ q x := by
      intro x
      dsimp [p, q]
      have hx := e.monotone (hlast_ge x)
      have hxval : (e x).val ≤ (e (last x)).val := hx
      omega
    have hfirst_retained : ∀ x : ℤ, W (p x) ≠ a := by
      intro x
      exact (e x).property
    have hlast_retained : ∀ x : ℤ, W (q x - 1) ≠ a := by
      intro x
      have hx : q x - 1 = (e (last x)).val := by dsimp [q]; omega
      rw [hx]
      exact (e (last x)).property
    have hcount_min : ∀ (c : DeletedAlphabet m a) (x : ℤ),
        wordIntervalCount W' c x (x + (n : ℤ)) =
          wordIntervalCount W c.val (p x) (q x) := by
      intro c x
      dsimp [p, q, last]
      unfold wordIntervalCount
      apply congrArg (fun z : ℕ => (z : ℤ))
      apply Finset.card_bij (fun j _ => (e j).val)
      · intro j hj
        have hj' : j ∈ Finset.Ico x (x + (n : ℤ)) := by
          exact (Finset.mem_filter.mp hj).1
        obtain ⟨hjx, hjlast⟩ := Finset.mem_Ico.mp hj'
        have hjlast' : j ≤ x + (n : ℤ) - 1 := by omega
        have hjc := (Finset.mem_filter.mp hj).2
        simp only [Finset.mem_filter]
        refine ⟨Finset.mem_Ico.mpr ⟨e.monotone hjx, ?_⟩, ?_⟩
        · have hjval : (e j).val ≤ (e (x + (n : ℤ) - 1)).val :=
            e.monotone hjlast'
          omega
        · have hjc' := congrArg Subtype.val hjc
          change W (e j).val = c.val at hjc'
          exact hjc'
      · intro i hi j hj hij
        apply e.injective
        exact Subtype.ext hij
      · intro t ht
        have ht' : t ∈ Finset.Ico (e x).val ((e (x + (n : ℤ) - 1)).val + 1) ∧
            W t = c.val := by
          simpa only [Finset.mem_filter] using ht
        obtain ⟨htx, htq⟩ := Finset.mem_Ico.mp ht'.1
        have htlast : t ≤ (e (x + (n : ℤ) - 1)).val := by omega
        have htret : W t ≠ a := by
          intro hta
          apply c.property
          exact ht'.2.symm.trans hta
        let r : R := ⟨t, htret⟩
        let j : ℤ := e.symm r
        have hjx : x ≤ j := by
          have : e x ≤ r := by exact htx
          simpa [j] using e.symm.monotone this
        have hjlast : j ≤ x + (n : ℤ) - 1 := by
          have : r ≤ e (x + (n : ℤ) - 1) := by exact htlast
          simpa [j] using e.symm.monotone this
        refine ⟨j, ?_, ?_⟩
        · simp only [Finset.mem_filter]
          refine ⟨Finset.mem_Ico.mpr ⟨hjx, by omega⟩, ?_⟩
          apply Subtype.ext
          change W (e j).val = c.val
          rw [show e j = r by simp [j]]
          exact ht'.2
        · change (e j).val = t
          simp [j, r]
    have hretained_min : ∀ (x : ℤ),
        (Finset.Ico x (x + (n : ℤ))).card =
          ((Finset.Ico (p x) (q x)).filter (fun t => W t ≠ a)).card := by
      intro x
      dsimp [p, q, last]
      apply Finset.card_bij (fun j _ => (e j).val)
      · intro j hj
        obtain ⟨hjx, hjlast⟩ := Finset.mem_Ico.mp hj
        have hjlast' : j ≤ x + (n : ℤ) - 1 := by omega
        simp only [Finset.mem_filter]
        refine ⟨Finset.mem_Ico.mpr ⟨e.monotone hjx, ?_⟩, (e j).property⟩
        have hjval : (e j).val ≤ (e (x + (n : ℤ) - 1)).val :=
          e.monotone hjlast'
        omega
      · intro i hi j hj hij
        apply e.injective
        exact Subtype.ext hij
      · intro t ht
        obtain ⟨htI, htna⟩ := Finset.mem_filter.mp ht
        have htI' := Finset.mem_Ico.mp htI
        have htlast : t ≤ (e (x + (n : ℤ) - 1)).val := by
          omega
        let r : R := ⟨t, htna⟩
        let j : ℤ := e.symm r
        have hjx : x ≤ j := by
          have : e x ≤ r := by exact htI'.1
          simpa [j] using e.symm.monotone this
        have hjlast : j ≤ x + (n : ℤ) - 1 := by
          have : r ≤ e (x + (n : ℤ) - 1) := by exact htlast
          simpa [j] using e.symm.monotone this
        refine ⟨j, Finset.mem_Ico.mpr ⟨hjx, by omega⟩, ?_⟩
        simp [j, r]
    have hretained_min_int : ∀ x : ℤ,
        (((Finset.Ico (p x) (q x)).filter (fun t => W t ≠ a)).card : ℤ) = (n : ℤ) := by
      intro x
      rw [← hretained_min x]
      simp [Int.card_Ico]
    have hlen : ∀ x : ℤ, q x - p x = (n : ℤ) + k x := by
      intro x
      have ht := htotal_count (p x) (q x) (hpq x)
      rw [hretained_min_int x] at ht
      change k x + (n : ℤ) = q x - p x at ht
      omega
    have hX : ∀ x : ℤ,
        wordIntervalCount W' c x (x + (n : ℤ)) =
          wordIntervalCount W c.val (p x) (q x) := by
      intro x
      exact hcount_min c x
    have hk_nonneg : ∀ x : ℤ, 0 ≤ k x := by
      intro x
      exact (wordIntervalCount_bounds W a (p x) (q x) (hpq x)).1
    have hordered : ∀ r s : ℤ, k r ≤ k s →
        |wordIntervalCount W' c s (s + (n : ℤ)) -
            wordIntervalCount W' c r (r + (n : ℤ))| ≤ 1 := by
      intro r s hrs
      have hlenr := hlen r
      have hlens := hlen s
      have hkr_nonneg := hk_nonneg r
      have hks_nonneg := hk_nonneg s
      let d : ℤ := k s - k r
      have hd : 0 ≤ d := by
        dsimp [d]
        omega
      have hCend : (p s + 1) + (q r - p r) = q s - d + 1 := by
        have hqs' : p s + (n : ℤ) + k s = q s := by omega
        calc
          (p s + 1) + (q r - p r) = p s + 1 + ((n : ℤ) + k r) := by rw [hlenr]
          _ = p s + (n : ℤ) + k s - (k s - k r) + 1 := by ring
          _ = q s - d + 1 := by rw [hqs']
      rcases eq_or_lt_of_le hd with hd0 | hdpos
      · have hkeq : k s = k r := by dsimp [d] at hd0; omega
        have hlength : q s - p s = q r - p r := by
          rw [hlens, hlenr, hkeq]
        have hbal' := hbal.interval c.val (p s) (p r) (q s - p s)
          (by omega)
        have hqs : p s + (q s - p s) = q s := by omega
        have hqr : p r + (q s - p s) = q r := by omega
        rw [hX s, hX r]
        simpa [hqs, hqr] using hbal'
      · have hd_cases : d = 1 ∨ 2 ≤ d := by omega
        rcases hd_cases with hd1 | hdge
        · have hkstep : k s = k r + 1 := by
            dsimp [d] at hd1
            omega
          have hlength : q s - p s = (q r - p r) + 1 := by
            rw [hlens, hlenr, hkstep]
            omega
          by_cases hgood :
              |wordIntervalCount W' c s (s + (n : ℤ)) -
                  wordIntervalCount W' c r (r + (n : ℤ))| ≤ 1
          · exact hgood
          have hbad : 2 ≤
              |wordIntervalCount W' c s (s + (n : ℤ)) -
                  wordIntervalCount W' c r (r + (n : ℤ))| := by omega
          rw [hX s, hX r] at hbad
          let delta : ℤ :=
            wordIntervalCount W c.val (p s) (q s) -
              wordIntervalCount W c.val (p r) (q r)
          let epsL : ℤ := wordIntervalCount W c.val (p s) (p s + 1)
          let epsR : ℤ := wordIntervalCount W c.val (q s - 1) (q s)
          have hepsL : epsL = 0 ∨ epsL = 1 := by
            have hh := wordIntervalCount_bounds W c.val (p s) (p s + 1) (by omega)
            dsimp [epsL]
            omega
          have hepsR : epsR = 0 ∨ epsR = 1 := by
            have hh := wordIntervalCount_bounds W c.val (q s - 1) (q s) (by omega)
            dsimp [epsR]
            omega
          have hdelta_bad : 2 ≤ |delta| := by
            change 2 ≤ |delta|
            exact hbad
          have hdelL := hbal.interval c.val (p s + 1) (p r) (q r - p r)
            (by omega)
          have hdelR := hbal.interval c.val (p s) (p r) (q r - p r)
            (by omega)
          have hdelLend : (p s + 1) + (q r - p r) = q s := by omega
          have hdelRend : p s + (q r - p r) = q s - 1 := by omega
          rw [hdelLend] at hdelL
          rw [hdelRend] at hdelR
          have hpr : p r + (q r - p r) = q r := by omega
          rw [hpr] at hdelL hdelR
          have hsplitL := wordIntervalCount_add W c.val (p s) (p s + 1) (q s)
            (by omega) (by omega)
          have hsplitR := wordIntervalCount_add W c.val (p s) (q s - 1) (q s)
            (by omega) (by omega)
          have hepsLcount : wordIntervalCount W c.val (p s) (p s + 1) = epsL := by
            rfl
          have hepsRcount : wordIntervalCount W c.val (q s - 1) (q s) = epsR := by
            rfl
          have hineqL : |delta - epsL| ≤ 1 := by
            have heq : delta - epsL =
                wordIntervalCount W c.val (p s + 1) (q s) -
                  wordIntervalCount W c.val (p r) (q r) := by
              dsimp [delta]
              omega
            rw [heq]
            exact hdelL
          have hineqR : |delta - epsR| ≤ 1 := by
            have heq : delta - epsR =
                wordIntervalCount W c.val (p s) (q s - 1) -
                  wordIntervalCount W c.val (p r) (q r) := by
              dsimp [delta]
              omega
            rw [heq]
            exact hdelR
          rw [abs_le] at hineqL hineqR
          have hdelta_two : delta = 2 := by
            by_cases hδ : 0 ≤ delta
            · have hδge : 2 ≤ delta := by
                simpa [abs_of_nonneg hδ] using hdelta_bad
              omega
            · have hδ' : delta ≤ 0 := le_of_not_ge hδ
              rw [abs_of_nonpos hδ'] at hdelta_bad
              omega
          have hepsL_one : epsL = 1 := by omega
          have hepsR_one : epsR = 1 := by omega
          have hleft_c : W (p s) = c.val := by
            by_contra h
            have hs := wordIntervalCount_single W c.val (p s)
            simp [h] at hs
            omega
          have hlast_c : W (q s - 1) = c.val := by
            by_contra h
            have hs := wordIntervalCount_single W c.val (q s - 1)
            rw [show (q s - 1) + 1 = q s by omega] at hs
            simp [h] at hs
            omega
          have hCs : wordIntervalCount W c.val (p s) (q s) =
              wordIntervalCount W c.val (p r) (q r) + 2 := by
            dsimp [delta] at hdelta_two
            omega
          have hleft_split := wordIntervalCount_add W c.val (p r - 1) (p r) (q r)
            (by omega) (by omega)
          have hright_split := wordIntervalCount_add W c.val (p r) (q r) (q r + 1)
            (by omega) (by omega)
          have hleft_bound :
              wordIntervalCount W c.val (p r - 1) (p r) ≤ 1 := by
            have hh := (wordIntervalCount_bounds W c.val (p r - 1) (p r)
              (by omega)).2
            omega
          have hright_bound :
              wordIntervalCount W c.val (q r) (q r + 1) ≤ 1 := by
            have hh := (wordIntervalCount_bounds W c.val (q r) (q r + 1)
              (by omega)).2
            omega
          have hbal_left := hbal.interval c.val (p s) (p r - 1)
            (q r - p r + 1) (by omega)
          have hbal_right := hbal.interval c.val (p s) (p r)
            (q r - p r + 1) (by omega)
          have hleft_end_s : p s + (q r - p r + 1) = q s := by omega
          have hleft_end_r : (p r - 1) + (q r - p r + 1) = q r := by omega
          have hright_end_r : p r + (q r - p r + 1) = q r + 1 := by omega
          rw [hleft_end_s, hleft_end_r] at hbal_left
          rw [hleft_end_s, hright_end_r] at hbal_right
          rw [abs_le] at hbal_left hbal_right
          have hleft_one : wordIntervalCount W c.val (p r - 1) (p r) = 1 := by
            omega
          have hright_one : wordIntervalCount W c.val (q r) (q r + 1) = 1 := by
            omega
          have hWleft : W (p r - 1) = c.val := by
            by_contra h
            have hh : wordIntervalCount W c.val (p r - 1) (p r) = 0 := by
              have hs := wordIntervalCount_single W c.val (p r - 1)
              rw [show (p r - 1) + 1 = p r by omega] at hs
              simpa [h] using hs
            omega
          have hWright : W (q r) = c.val := by
            by_contra h
            have hh : wordIntervalCount W c.val (q r) (q r + 1) = 0 := by
              rw [wordIntervalCount_single]
              simp [h]
            omega
          have hcentral_left0 : wordIntervalCount W a (p r - 1) (p r) = 0 := by
            have hh := wordIntervalCount_single W a (p r - 1)
            rw [show (p r - 1) + 1 = p r by omega] at hh
            simp [hWleft, c.property] at hh
            exact hh
          have hcentral_right0 : wordIntervalCount W a (q r) (q r + 1) = 0 := by
            rw [wordIntervalCount_single]
            simp [hWright, c.property]
          have hcentral_split_left := wordIntervalCount_add W a (p r - 1) (p r) (q r + 1)
            (by omega) (by omega)
          have hcentral_split_right := wordIntervalCount_add W a (p r) (q r) (q r + 1)
            (by omega) (by omega)
          have hcentralA : wordIntervalCount W a (p r - 1) (q r + 1) = k r := by
            have htmp : wordIntervalCount W a (p r - 1) (q r + 1) =
                wordIntervalCount W a (p r - 1) (p r) +
                wordIntervalCount W a (p r) (q r) +
                wordIntervalCount W a (q r) (q r + 1) := by
              rw [hcentral_split_left, hcentral_split_right]
              ring
            dsimp [k]
            omega
          have hcentral_strict := (codingWord_count_strict α β hpart a
            (p r - 1) (q r + 1) (by omega)).1
          have hcentral_ineq :
              (((q r + 1) - (p r - 1) : ℤ) : ℝ) / α a - 1 < (k r : ℝ) := by
            simpa [W, hcentralA] using hcentral_strict
          have hcentral_len : (q r + 1) - (p r - 1) = (q r - p r) + 2 := by omega
          rw [hcentral_len] at hcentral_ineq
          have hbig_div : ((q r - p r + 2 : ℤ) : ℝ) / α a < (k r : ℝ) + 1 := by
            linarith
          have hbig : ((q r - p r + 2 : ℤ) : ℝ) < ((k r : ℝ) + 1) * α a :=
            (div_lt_iff₀ hαpos).mp hbig_div
          have hinterior_left0 : wordIntervalCount W a (p s) (p s + 1) = 0 := by
            rw [wordIntervalCount_single]
            simp [hleft_c, c.property]
          have hinterior_right0 : wordIntervalCount W a (q s - 1) (q s) = 0 := by
            have hh := wordIntervalCount_single W a (q s - 1)
            rw [show (q s - 1) + 1 = q s by omega] at hh
            simp [hlast_c, c.property] at hh
            exact hh
          have hinterior_split_full := wordIntervalCount_add W a (p s) (p s + 1) (q s)
            (by omega) (by omega)
          have hinterior_split_right := wordIntervalCount_add W a (p s + 1) (q s - 1) (q s)
            (by omega) (by omega)
          have hinteriorA : wordIntervalCount W a (p s + 1) (q s - 1) = k s := by
            have htmp : wordIntervalCount W a (p s) (q s) =
                wordIntervalCount W a (p s) (p s + 1) +
                wordIntervalCount W a (p s + 1) (q s - 1) +
                wordIntervalCount W a (q s - 1) (q s) := by
              rw [hinterior_split_full, hinterior_split_right]
              ring
            dsimp [k]
            omega
          have hinterior_strict := (codingWord_count_strict α β hpart a
            (p s + 1) (q s - 1) (by omega)).2
          have hinterior_ineq :
              (k s : ℝ) < (((q s - 1) - (p s + 1) : ℤ) : ℝ) / α a + 1 := by
            simpa [W, hinteriorA] using hinterior_strict
          have hinterior_len : (q s - 1) - (p s + 1) = (q r - p r) - 1 := by omega
          rw [hinterior_len] at hinterior_ineq
          have hsmall_div : (k r : ℝ) < ((q r - p r - 1 : ℤ) : ℝ) / α a := by
            have hkstepR : (k s : ℝ) = (k r : ℝ) + 1 := by exact_mod_cast hkstep
            linarith [hkstepR, hinterior_ineq]
          have hsmall : ((k r : ℝ) * α a) < ((q r - p r - 1 : ℤ) : ℝ) :=
            (lt_div_iff₀ hαpos).mp hsmall_div
          have hcastrel : ((q r - p r + 2 : ℤ) : ℝ) =
              ((q r - p r - 1 : ℤ) : ℝ) + 3 := by
            push_cast
            ring
          have hαgt : 3 < α a := by
            nlinarith [hbig, hsmall, hcastrel]
          exact (not_lt_of_ge hrate hαgt).elim
        · have hleft0 : wordIntervalCount W a (p s) (p s + 1) = 0 := by
            rw [wordIntervalCount_single]
            simp [hfirst_retained s]
          have hlast0 : wordIntervalCount W a (q s - 1) (q s) = 0 := by
            simpa [sub_add_cancel, hlast_retained s] using
              (wordIntervalCount_single W a (q s - 1))
          have hrightbound :
              wordIntervalCount W a (q s - d + 1) (q s - 1) ≤ d - 2 := by
            have hh := (wordIntervalCount_bounds W a (q s - d + 1) (q s - 1)
              (by omega)).2
            omega
          have hrightsplit := wordIntervalCount_add W a (q s - d + 1) (q s - 1) (q s)
            (by omega) (by omega)
          have hright_le : wordIntervalCount W a (q s - d + 1) (q s) ≤ d - 2 := by
            rw [hrightsplit, hlast0]
            omega
          have hsplit := wordIntervalCount_add W a (p s + 1) (q s - d + 1) (q s)
            (by omega) (by omega)
          have hsplit' := wordIntervalCount_add W a (p s) (p s + 1) (q s)
            (by omega) (by omega)
          have hCbound : k r + 2 ≤
              wordIntervalCount W a (p s + 1) (q s - d + 1) := by
            have hs : k s =
                wordIntervalCount W a (p s) (p s + 1) +
                wordIntervalCount W a (p s + 1) (q s - d + 1) +
                wordIntervalCount W a (q s - d + 1) (q s) := by
              rw [show k s = wordIntervalCount W a (p s) (q s) by rfl,
                hsplit', hsplit]
              ring
            rw [hleft0] at hs
            have hdrel : d = k s - k r := by rfl
            linarith [hs, hright_le, hdrel]
          have hbalC := hbal.interval a (p s + 1) (p r) (q r - p r)
            (by omega)
          have hpr : p r + (q r - p r) = q r := by omega
          rw [hCend, hpr] at hbalC
          change |wordIntervalCount W a (p s + 1) (q s - d + 1) - k r| ≤ 1 at hbalC
          rw [abs_le] at hbalC
          exfalso
          omega
    by_cases huv : k u ≤ k v
    · have hh := hordered u v huv
      simpa [abs_sub_comm] using hh
    · have hvu : k v ≤ k u := le_of_not_ge huv
      exact hordered v u hvu
end Fraenkel
