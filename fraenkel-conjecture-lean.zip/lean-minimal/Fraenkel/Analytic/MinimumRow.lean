import Fraenkel.Analytic.Kernel

namespace Fraenkel

open scoped BigOperators Classical

/-- Data for the minimum-row slack argument. The finite set records the
package's distinct unit representatives; `s` is recorded together with the
fact that it is its minimum. -/
-- zpi: def-minimum-row-slack-data
structure MinimumRowSlackData where
  Q : ℤ
  A : Finset ℤ
  hQ : 4 ≤ Q
  hA : UnitRepresentatives Q A
  hA_upper : ∀ a ∈ A, 3 * a < Q
  hA_sum : (∑ a ∈ A, a) ≤ Q
  s : ℤ
  hs_mem : s ∈ A
  hs_min : ∀ a ∈ A, s ≤ a

/-- The number `n=|A|-1` in the minimum-row statements. -/
-- zpi: def-minimum-row-slack-data
def minimumRowN (D : MinimumRowSlackData) : ℕ := D.A.card - 1

/-- The complement size `N=Q-s`. -/
-- zpi: def-minimum-row-slack-data
def minimumRowNComplement (D : MinimumRowSlackData) : ℤ := D.Q - D.s

/-- The minimum-row cyclic distance `d_a`. -/
-- zpi: def-minimum-row-slack-data
noncomputable def minimumRowDistance (D : MinimumRowSlackData) (a : ℤ) : ℤ :=
  cyclicDistance D.Q (D.s * inverseMod D.Q a)

/-- The slack `δ_a=d_a a-N`. -/
-- zpi: def-minimum-row-slack-data
noncomputable def minimumRowDelta (D : MinimumRowSlackData) (a : ℤ) : ℤ :=
  minimumRowDistance D a * a - minimumRowNComplement D

/-- The good minimum-row elements. -/
-- zpi: def-good-and-bad-minimum-row-elements
def GoodMinimumRowElement (D : MinimumRowSlackData) (a : ℤ) : Prop :=
  a ∣ D.Q - D.s ∨ a ∣ D.Q + D.s

/-- The bad minimum-row elements. -/
-- zpi: def-good-and-bad-minimum-row-elements
def BadMinimumRowElement (D : MinimumRowSlackData) (a : ℤ) : Prop :=
  ¬ GoodMinimumRowElement D a

/-- The sum of bad elements, with empty sum zero. -/
-- zpi: def-good-and-bad-minimum-row-elements
noncomputable def badMinimumRowSum (D : MinimumRowSlackData) : ℤ :=
  (∑ a ∈ D.A.erase D.s, if BadMinimumRowElement D a then a else 0)

/-- Product-shell distance `d_ab`. -/
-- zpi: def-product-shell-data
noncomputable def productShellDistance (D : MinimumRowSlackData) (a b : ℤ) : ℤ :=
  cyclicDistance D.Q (a * inverseMod D.Q b)

/-- Product-shell numerator `P_ab=b d_ab`. -/
-- zpi: def-product-shell-data
noncomputable def productShellValue (D : MinimumRowSlackData) (a b : ℤ) : ℤ :=
  b * productShellDistance D a b

/-- The reciprocal row `H_a`. -/
-- zpi: def-product-shell-data
noncomputable def productShellRow (D : MinimumRowSlackData) (a : ℤ) : ℝ :=
  ∑ b ∈ D.A.erase a, (1 : ℝ) / (productShellDistance D a b : ℝ)

/-- The shell alternatives displayed in the package statement. -/
-- zpi: def-product-shell-data
def IsProductShellValue (D : MinimumRowSlackData) (a b : ℤ) : Prop :=
  productShellValue D a b = a ∨
    ∃ j : ℤ, 1 ≤ j ∧
      (productShellValue D a b = j * D.Q - a ∨
        productShellValue D a b = j * D.Q + a)

/-- Minimum-row reciprocal slack identity and the resulting bounds. -/
-- zpi: lem-minimum-row-slack-identity
theorem minimumRowSlackIdentity (D : MinimumRowSlackData) :
    (∀ a ∈ D.A.erase D.s,
      minimumRowNComplement D ≤ minimumRowDistance D a * a) ∧
    (1 - (∑ a ∈ D.A.erase D.s,
        (1 : ℝ) / (minimumRowDistance D a : ℝ))) =
      ((D.Q - (∑ a ∈ D.A, a)) : ℝ) /
          (minimumRowNComplement D : ℝ) +
        (∑ a ∈ D.A.erase D.s,
          (minimumRowDelta D a : ℝ) /
            ((minimumRowDistance D a : ℝ) *
              (minimumRowNComplement D : ℝ))) ∧
    (∀ a ∈ D.A.erase D.s,
      (∃ j : ℤ, 0 ≤ j ∧
        (minimumRowDelta D a = j * D.Q ∨
          minimumRowDelta D a = 2 * D.s + j * D.Q)) ∧
      minimumRowDelta D a ∈
        ({(0 : ℤ), 2 * D.s} : Set ℤ) ∪ Set.Ici D.Q) ∧
    ((∑ a ∈ D.A.erase D.s,
        (1 : ℝ) / (minimumRowDistance D a : ℝ)) ≤ 1) := by
  have hclass : ∀ a ∈ D.A.erase D.s,
      (1 ≤ minimumRowDistance D a ∧ 2 * minimumRowDistance D a ≤ D.Q) ∧
      ∃ j : ℤ, 0 ≤ j ∧
        (minimumRowDelta D a = j * D.Q ∨
          minimumRowDelta D a = 2 * D.s + j * D.Q) := by
    intro a ha
    have hQ : 2 ≤ D.Q := by
      have hQ0 := D.hQ
      omega
    have haA : a ∈ D.A := (Finset.mem_erase.mp ha).2
    have hsa : a ≠ D.s := (Finset.mem_erase.mp ha).1
    have hunit := D.hA.1 a haA
    have hsunit := D.hA.1 D.s D.hs_mem
    have hsinv : (D.s * inverseMod D.Q a) % D.Q ≠ 0 := by
      intro hz
      have hinv := inverseMod_spec D.Q a hQ hunit.2
      have hzero : D.s * inverseMod D.Q a ≡ 0 [ZMOD D.Q] := by
        simpa [Int.ModEq] using hz
      have hprod : (D.s * inverseMod D.Q a) * a ≡ 0 * a [ZMOD D.Q] :=
        hzero.mul_right a
      have h1mod : (1 : ℤ) % D.Q = 1 := by
        exact Int.emod_eq_of_lt (by omega) (by omega)
      have hone : a * inverseMod D.Q a ≡ 1 [ZMOD D.Q] := by
        simpa [Int.ModEq, h1mod] using hinv.2
      have hcalc : (D.s * inverseMod D.Q a) * a ≡ D.s [ZMOD D.Q] := by
        calc
          (D.s * inverseMod D.Q a) * a = D.s * (a * inverseMod D.Q a) := by ring
          _ ≡ D.s * 1 [ZMOD D.Q] := hone.mul_left D.s
          _ = D.s := by ring
      have hsmod : D.s % D.Q = 0 := by
        have : (D.s * inverseMod D.Q a) * a % D.Q = 0 := hprod.eq.trans
          (by simp)
        rw [hcalc.eq] at this
        exact this
      have hsrange : 1 ≤ D.s ∧ D.s < D.Q := by
        have := hsunit
        constructor
        · exact this.1
        · have := D.hA_upper D.s D.hs_mem
          nlinarith
      have : D.s % D.Q = D.s := Int.emod_eq_of_lt (by omega) hsrange.2
      omega
    have hdist := cyclicDistance_bounds D.Q (D.s * inverseMod D.Q a) hQ hsinv
    have hinv := inverseMod_spec D.Q a hQ hunit.2
    have h1mod : (1 : ℤ) % D.Q = 1 := by
      exact Int.emod_eq_of_lt (by omega) (by omega)
    have hone : a * inverseMod D.Q a ≡ 1 [ZMOD D.Q] := by
      simpa [Int.ModEq, h1mod] using hinv.2
    let r : ℤ := (D.s * inverseMod D.Q a) % D.Q
    have hrmod : r ≡ D.s * inverseMod D.Q a [ZMOD D.Q] := by
      dsimp [r]
      exact Int.mod_modEq _ _
    have hprod : minimumRowDistance D a * a ≡ D.s [ZMOD D.Q] ∨
        minimumRowDistance D a * a ≡ -D.s [ZMOD D.Q] := by
      rcases le_total r (D.Q - r) with hle | hle
      · left
        have hd_r : minimumRowDistance D a = r := by
          dsimp [minimumRowDistance, cyclicDistance, r]
          rw [min_eq_left hle]
        rw [hd_r]
        calc
          r * a ≡ (D.s * inverseMod D.Q a) * a [ZMOD D.Q] := hrmod.mul_right a
          _ = D.s * (a * inverseMod D.Q a) := by ring
          _ ≡ D.s * 1 [ZMOD D.Q] := hone.mul_left D.s
          _ = D.s := by ring
      · right
        have hd_qr : minimumRowDistance D a = D.Q - r := by
          dsimp [minimumRowDistance, cyclicDistance, r]
          rw [min_eq_right hle]
        have hq : D.Q ≡ 0 [ZMOD D.Q] := by simp
        have hqr : D.Q - r ≡ -(D.s * inverseMod D.Q a) [ZMOD D.Q] := by
          have hh := hq.sub hrmod
          simpa using hh
        rw [hd_qr]
        calc
          (D.Q - r) * a ≡ (-(D.s * inverseMod D.Q a)) * a [ZMOD D.Q] := hqr.mul_right a
          _ = -(D.s * (a * inverseMod D.Q a)) := by ring
          _ ≡ -(D.s * 1) [ZMOD D.Q] := by
            convert hone.neg.mul_left D.s using 1 <;> ring
          _ = -D.s := by ring
    have hapos : 0 < a := hunit.1
    have hsle : D.s ≤ a := D.hs_min a haA
    have hsalt : D.s < a := lt_of_le_of_ne hsle (Ne.symm hsa)
    have hQpos : 0 < D.Q := by omega
    have hsltQ : D.s < D.Q := by
      have hh := D.hA_upper D.s D.hs_mem
      nlinarith
    have hdpos : 0 < minimumRowDistance D a := by
      have hh := hdist.1
      dsimp [minimumRowDistance] at hh ⊢
      omega
    have hprodpos : 0 < minimumRowDistance D a * a := mul_pos hdpos hapos
    have hda_ge_a : a ≤ minimumRowDistance D a * a := by
      have hh := mul_le_mul_of_nonneg_right hdist.1 hapos.le
      simpa using hh
    refine ⟨hdist, ?_⟩
    rcases hprod with hplus | hminus
    · obtain ⟨j, hj⟩ := Int.modEq_iff_add_fac.mp hplus
      have hjneg : j ≤ -1 := by
        by_contra hjnot
        have hj0 : 0 ≤ j := by omega
        have hqj : 0 ≤ D.Q * j := mul_nonneg (by omega) (by omega)
        nlinarith [hj, hda_ge_a, hsalt]
      let k : ℤ := -j - 1
      have hk : 0 ≤ k := by dsimp [k]; omega
      have hda : minimumRowDistance D a * a = D.Q + D.s + k * D.Q := by
        dsimp [k]
        nlinarith [hj]
      refine ⟨k, hk, ?_⟩
      right
      dsimp [minimumRowDelta, minimumRowNComplement]
      nlinarith [hda]
    · obtain ⟨j, hj⟩ := Int.modEq_iff_add_fac.mp hminus
      have hjneg : j ≤ -1 := by
        by_contra hjnot
        have hj0 : 0 ≤ j := by omega
        have hqj : 0 ≤ D.Q * j := mul_nonneg (by omega) (by omega)
        nlinarith [hj, hprodpos]
      let k : ℤ := -j - 1
      have hk : 0 ≤ k := by dsimp [k]; omega
      have hda : minimumRowDistance D a * a = D.Q - D.s + k * D.Q := by
        dsimp [k]
        nlinarith [hj]
      refine ⟨k, hk, ?_⟩
      left
      dsimp [minimumRowDelta, minimumRowNComplement]
      nlinarith [hda]

  have hQ : 2 ≤ D.Q := by
    have hQ0 := D.hQ
    omega
  have hspos : 0 < D.s := D.hA.1 D.s D.hs_mem |>.1
  have hsltQ : D.s < D.Q := by
    have hh := D.hA_upper D.s D.hs_mem
    nlinarith
  have hNpos : 0 < minimumRowNComplement D := by
    dsimp [minimumRowNComplement]
    omega
  have hterm : ∀ a ∈ D.A.erase D.s,
      (1 : ℝ) / (minimumRowDistance D a : ℝ) =
        (a : ℝ) / (minimumRowNComplement D : ℝ) -
          (minimumRowDelta D a : ℝ) /
            ((minimumRowDistance D a : ℝ) *
              (minimumRowNComplement D : ℝ)) := by
    intro a ha
    obtain ⟨hd, hdelta⟩ := hclass a ha
    have hdpos : 0 < (minimumRowDistance D a : ℝ) := by
      have hh := hd.1
      dsimp [minimumRowDistance] at hh
      exact_mod_cast (show 0 < minimumRowDistance D a by omega)
    have hNR : 0 < (minimumRowNComplement D : ℝ) := by exact_mod_cast hNpos
    have hrel : minimumRowDistance D a * a =
        minimumRowNComplement D + minimumRowDelta D a := by
      dsimp [minimumRowDelta]
      ring
    have hrelR : (minimumRowDistance D a : ℝ) * (a : ℝ) =
        (minimumRowNComplement D : ℝ) + (minimumRowDelta D a : ℝ) := by
      exact_mod_cast hrel
    field_simp
    nlinarith [hrelR]
  have hterm_sum := Finset.sum_congr rfl hterm
  have hsum_a :
      (∑ a ∈ D.A.erase D.s, (a : ℝ)) + (D.s : ℝ) =
        (∑ a ∈ D.A, (a : ℝ)) := by
    simpa using D.A.sum_erase_add (fun a : ℤ => (a : ℝ)) D.hs_mem
  have hidentity :
      (1 - (∑ a ∈ D.A.erase D.s,
        (1 : ℝ) / (minimumRowDistance D a : ℝ))) =
        ((D.Q - (∑ a ∈ D.A, a)) : ℝ) /
            (minimumRowNComplement D : ℝ) +
          (∑ a ∈ D.A.erase D.s,
            (minimumRowDelta D a : ℝ) /
              ((minimumRowDistance D a : ℝ) *
                (minimumRowNComplement D : ℝ))) := by
    rw [show (∑ a ∈ D.A.erase D.s,
        (1 : ℝ) / (minimumRowDistance D a : ℝ)) =
        ∑ a ∈ D.A.erase D.s,
          ((a : ℝ) / (minimumRowNComplement D : ℝ) -
            (minimumRowDelta D a : ℝ) /
              ((minimumRowDistance D a : ℝ) *
                (minimumRowNComplement D : ℝ))) by
      exact hterm_sum]
    have hsplit :
        (∑ a ∈ D.A.erase D.s,
          ((a : ℝ) / (minimumRowNComplement D : ℝ) -
            (minimumRowDelta D a : ℝ) /
              ((minimumRowDistance D a : ℝ) *
                (minimumRowNComplement D : ℝ)))) =
        (∑ a ∈ D.A.erase D.s, (a : ℝ)) /
            (minimumRowNComplement D : ℝ) -
          (∑ a ∈ D.A.erase D.s,
            (minimumRowDelta D a : ℝ) /
              ((minimumRowDistance D a : ℝ) *
                (minimumRowNComplement D : ℝ))) := by
      rw [Finset.sum_sub_distrib, Finset.sum_div]
    rw [hsplit]
    rw [Int.cast_sum]
    rw [← hsum_a]
    dsimp [minimumRowNComplement]
    push_cast
    have hNR : (0 : ℝ) < (D.Q - D.s : ℝ) := by exact_mod_cast hNpos
    have hrational :
        1 - (∑ a ∈ D.A.erase D.s, (a : ℝ)) / (D.Q - D.s : ℝ) =
          ((D.Q : ℝ) -
            ((∑ a ∈ D.A.erase D.s, (a : ℝ)) + (D.s : ℝ))) /
            (D.Q - D.s : ℝ) := by
      field_simp [hNR.ne']
      ring
    linarith [hrational]
  refine ⟨?_, hidentity, ?_, ?_⟩
  · intro a ha
    rcases hclass a ha with ⟨_, ⟨j, hj, hjd⟩⟩
    have hdelta : 0 ≤ minimumRowDelta D a := by
      rcases hjd with hjd | hjd
      · rw [hjd]
        have hQ0 := D.hQ
        nlinarith
      · rw [hjd]
        have hQ0 := D.hQ
        nlinarith [hspos]
    dsimp [minimumRowDelta, minimumRowNComplement] at hdelta ⊢
    nlinarith
  · intro a ha
    refine ⟨hclass a ha |>.2, ?_⟩
    rcases hclass a ha |>.2 with ⟨j, hj, hjd⟩
    rcases hjd with hjd | hjd
    · by_cases hj0 : j = 0
      · left; simp [hj0, hjd]
      · right
        have hj1 : 1 ≤ j := by omega
        have hQj : D.Q ≤ j * D.Q := by nlinarith
        exact (by rw [hjd]; exact hQj)
    · by_cases hj0 : j = 0
      · left; simp [hj0, hjd]
      · right
        have hj1 : 1 ≤ j := by omega
        have hQj : D.Q ≤ j * D.Q := by nlinarith
        exact (by
          rw [hjd]
          calc
            D.Q ≤ j * D.Q := hQj
            _ ≤ 2 * D.s + j * D.Q := by nlinarith [hspos])
  · have hsumA :
      (∑ a ∈ D.A, (a : ℝ)) ≤ (D.Q : ℝ) := by
      rw [← Int.cast_sum]
      exact_mod_cast D.hA_sum
    have hfirst : 0 ≤
        ((D.Q - (∑ a ∈ D.A, a)) : ℝ) /
          (minimumRowNComplement D : ℝ) := by
      have hnumR : 0 ≤ (D.Q : ℝ) - (∑ a ∈ D.A, (a : ℝ)) := by
        linarith [hsumA]
      have hnumR_cast : 0 ≤ (D.Q : ℝ) - ((∑ a ∈ D.A, a) : ℝ) := by
        simpa only [Int.cast_sum] using hnumR
      have hNR : 0 ≤ (minimumRowNComplement D : ℝ) := by exact_mod_cast hNpos.le
      have hdiv_cast := div_nonneg hnumR_cast hNR
      simpa only [Int.cast_sum] using hdiv_cast
    have hdelta_nonneg : ∀ a ∈ D.A.erase D.s,
        0 ≤ (minimumRowDelta D a : ℝ) := by
      intro a ha
      rcases hclass a ha with ⟨_, ⟨j, hj, hjd⟩⟩
      rcases hjd with hjd | hjd
      · rw [hjd]
        have hq0 : 0 ≤ D.Q := by omega
        have hprod : 0 ≤ j * D.Q := mul_nonneg hj hq0
        exact_mod_cast hprod
      · rw [hjd]
        have hq0 : 0 ≤ D.Q := by omega
        have hs0 : 0 ≤ D.s := by omega
        have hprod : 0 ≤ 2 * D.s + j * D.Q := by
          nlinarith [mul_nonneg hj hq0, mul_nonneg (by norm_num : (0 : ℤ) ≤ 2) hs0]
        exact_mod_cast hprod
    have hsum_nonneg : 0 ≤
        (∑ a ∈ D.A.erase D.s,
          (minimumRowDelta D a : ℝ) /
            ((minimumRowDistance D a : ℝ) *
              (minimumRowNComplement D : ℝ))) := by
      apply Finset.sum_nonneg
      intro a ha
      apply div_nonneg (hdelta_nonneg a ha)
      have hd : 0 < (minimumRowDistance D a : ℝ) := by
        have hh := (hclass a ha).1.1
        dsimp [minimumRowDistance] at hh
        have hdInt : 0 < minimumRowDistance D a := by
          dsimp [minimumRowDistance]
          omega
        exact_mod_cast hdInt
      have hNR : 0 < (minimumRowNComplement D : ℝ) := by exact_mod_cast hNpos
      exact mul_nonneg hd.le hNR.le
    nlinarith [hidentity, hfirst, hsum_nonneg]


/-- Passing minimum-row slack and bad-element bound. -/
-- zpi: lem-passing-minimum-row-slack
theorem passingMinimumRowSlack (D : MinimumRowSlackData)
    (hpass : RowPasses D.Q D.A D.s) :
    let E : ℝ := (minimumRowNComplement D : ℝ) *
      (1 - (∑ a ∈ D.A.erase D.s,
        (1 : ℝ) / (minimumRowDistance D a : ℝ)))
    E < 8 * (minimumRowN D : ℝ) / 7 ∧
      (badMinimumRowSum D : ℝ) < 16 * (minimumRowN D : ℝ) / 7 := by
  classical
  have hQ : 2 ≤ D.Q := by
    have hQ0 := D.hQ
    omega
  have hQpos : 0 < D.Q := by omega
  have hspos : 0 < D.s := D.hA.1 D.s D.hs_mem |>.1
  have hsltQ : D.s < D.Q := by
    have hh := D.hA_upper D.s D.hs_mem
    nlinarith
  have hNpos : 0 < minimumRowNComplement D := by
    dsimp [minimumRowNComplement]
    omega
  have hslack := minimumRowSlackIdentity D
  have hdist : ∀ a ∈ D.A.erase D.s,
      1 ≤ minimumRowDistance D a ∧ 2 * minimumRowDistance D a ≤ D.Q := by
    intro a ha
    have hunit := D.hA.1 a (Finset.mem_erase.mp ha).2
    have hsinv : (D.s * inverseMod D.Q a) % D.Q ≠ 0 := by
      intro hz
      have hinv := inverseMod_spec D.Q a hQ hunit.2
      have hzero : D.s * inverseMod D.Q a ≡ 0 [ZMOD D.Q] := by
        simpa [Int.ModEq] using hz
      have hprod : (D.s * inverseMod D.Q a) * a ≡ 0 * a [ZMOD D.Q] :=
        hzero.mul_right a
      have h1mod : (1 : ℤ) % D.Q = 1 := by
        exact Int.emod_eq_of_lt (by omega) (by omega)
      have hone : a * inverseMod D.Q a ≡ 1 [ZMOD D.Q] := by
        simpa [Int.ModEq, h1mod] using hinv.2
      have hcalc : (D.s * inverseMod D.Q a) * a ≡ D.s [ZMOD D.Q] := by
        calc
          (D.s * inverseMod D.Q a) * a = D.s * (a * inverseMod D.Q a) := by ring
          _ ≡ D.s * 1 [ZMOD D.Q] := hone.mul_left D.s
          _ = D.s := by ring
      have hsmod : D.s % D.Q = 0 := by
        have : (D.s * inverseMod D.Q a) * a % D.Q = 0 := hprod.eq.trans
          (by simp)
        rw [hcalc.eq] at this
        exact this
      have hsrange : 1 ≤ D.s ∧ D.s < D.Q := by
        constructor
        · exact D.hA.1 D.s D.hs_mem |>.1
        · exact hsltQ
      have : D.s % D.Q = D.s := Int.emod_eq_of_lt (by omega) hsrange.2
      omega
    exact cyclicDistance_bounds D.Q (D.s * inverseMod D.Q a) hQ hsinv
  have hcard : (D.A.erase D.s).card = D.A.card - 1 :=
    Finset.card_erase_of_mem D.hs_mem
  have hrow : (D.A.erase D.s).Nonempty := by
    change 1 ≤ inverseSineRowMass D.Q D.A D.s at hpass
    by_contra hn
    have he : D.A.erase D.s = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
    have hzero : (1 : ℝ) ≤ 0 := by
      simpa [inverseSineRowMass, he] using hpass
    linarith
  have hnpos : 0 < (minimumRowN D : ℝ) := by
    have hnNat : 0 < D.A.card - 1 := by
      rw [← hcard]
      exact Finset.card_pos.mpr hrow
    dsimp [minimumRowN]
    exact_mod_cast hnNat
  have hsumd :
      (∑ a ∈ D.A.erase D.s, (minimumRowDistance D a : ℝ)) ≤
        (minimumRowN D : ℝ) * (D.Q : ℝ) / 2 := by
    have hpoint : ∀ a ∈ D.A.erase D.s,
        (minimumRowDistance D a : ℝ) ≤ (D.Q : ℝ) / 2 := by
      intro a ha
      have hh := (hdist a ha).2
      have hhR : 2 * (minimumRowDistance D a : ℝ) ≤ (D.Q : ℝ) := by
        exact_mod_cast hh
      nlinarith
    have hs := Finset.sum_le_sum hpoint
    rw [Finset.sum_const, nsmul_eq_mul] at hs
    have hcardR : ((D.A.erase D.s).card : ℝ) = (minimumRowN D : ℝ) := by
      dsimp [minimumRowN]
      rw [hcard]
    rw [hcardR] at hs
    nlinarith
  have hCpos : 0 < inverseSineEnvelopeConstant := by
    dsimp [inverseSineEnvelopeConstant]
    nlinarith [Real.pi_gt_three]
  have hCup : inverseSineEnvelopeConstant < (16 : ℝ) / 7 := by
    dsimp [inverseSineEnvelopeConstant]
    nlinarith [Real.pi_lt_d4]
  have hmass : 1 ≤
      ∑ a ∈ D.A.erase D.s,
        inverseSineKernel D.Q (minimumRowDistance D a) := by
    change 1 ≤ inverseSineRowMass D.Q D.A D.s at hpass
    exact hpass
  have hupper : ∀ a ∈ D.A.erase D.s,
      inverseSineKernel D.Q (minimumRowDistance D a) <
        1 / (minimumRowDistance D a : ℝ) +
          inverseSineEnvelopeConstant * (minimumRowDistance D a : ℝ) /
            (D.Q : ℝ) ^ 2 := by
    intro a ha
    exact inverseSineKernel_upper D.Q (minimumRowDistance D a) hQ (hdist a ha |>.1)
      (hdist a ha |>.2)
  have hsumupper := Finset.sum_lt_sum_of_nonempty hrow hupper
  have hsum_expand :
      (∑ a ∈ D.A.erase D.s,
        (1 / (minimumRowDistance D a : ℝ) +
          inverseSineEnvelopeConstant * (minimumRowDistance D a : ℝ) /
            (D.Q : ℝ) ^ 2)) =
        (∑ a ∈ D.A.erase D.s,
          1 / (minimumRowDistance D a : ℝ)) +
          inverseSineEnvelopeConstant / (D.Q : ℝ) ^ 2 *
            (∑ a ∈ D.A.erase D.s, (minimumRowDistance D a : ℝ)) := by
    rw [Finset.sum_add_distrib]
    congr 1
    have hfactor :
        (∑ a ∈ D.A.erase D.s,
          inverseSineEnvelopeConstant * (minimumRowDistance D a : ℝ) /
            (D.Q : ℝ) ^ 2) =
        ∑ a ∈ D.A.erase D.s,
          (inverseSineEnvelopeConstant / (D.Q : ℝ) ^ 2) *
            (minimumRowDistance D a : ℝ) := by
      apply Finset.sum_congr rfl
      intro a ha
      ring
    rw [hfactor, ← Finset.mul_sum]
  have hgap :
      1 - (∑ a ∈ D.A.erase D.s,
          1 / (minimumRowDistance D a : ℝ)) <
        inverseSineEnvelopeConstant / (D.Q : ℝ) ^ 2 *
          (∑ a ∈ D.A.erase D.s, (minimumRowDistance D a : ℝ)) := by
    have hh := lt_of_le_of_lt hmass hsumupper
    rw [hsum_expand] at hh
    linarith
  let E : ℝ := (minimumRowNComplement D : ℝ) *
      (1 - (∑ a ∈ D.A.erase D.s,
        (1 : ℝ) / (minimumRowDistance D a : ℝ)))
  have hEformula : E =
      ((D.Q - (∑ a ∈ D.A, a)) : ℝ) +
        (∑ a ∈ D.A.erase D.s,
          (minimumRowDelta D a : ℝ) /
            (minimumRowDistance D a : ℝ)) := by
    have hi := hslack.2.1
    have hscale :
        (minimumRowNComplement D : ℝ) *
          (∑ a ∈ D.A.erase D.s,
            (minimumRowDelta D a : ℝ) /
              ((minimumRowDistance D a : ℝ) *
                (minimumRowNComplement D : ℝ))) =
          ∑ a ∈ D.A.erase D.s,
            (minimumRowDelta D a : ℝ) /
              (minimumRowDistance D a : ℝ) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro a ha
      have hdR : 0 < (minimumRowDistance D a : ℝ) := by
        exact_mod_cast (show 0 < minimumRowDistance D a by
          have hh := (hdist a ha).1
          dsimp [minimumRowDistance] at hh ⊢
          omega)
      have hNR : 0 < (minimumRowNComplement D : ℝ) := by exact_mod_cast hNpos
      field_simp [hdR.ne', hNR.ne']
    dsimp [E]
    rw [hi, mul_add, hscale]
    have hNR : 0 < (minimumRowNComplement D : ℝ) := by exact_mod_cast hNpos
    field_simp [hNR.ne']
  have hNRpos : 0 < (minimumRowNComplement D : ℝ) := by exact_mod_cast hNpos
  have hEbound : E <
      (minimumRowNComplement D : ℝ) *
        (inverseSineEnvelopeConstant / (D.Q : ℝ) ^ 2) *
          (∑ a ∈ D.A.erase D.s, (minimumRowDistance D a : ℝ)) := by
    dsimp [E]
    simpa [mul_assoc] using (mul_lt_mul_of_pos_left hgap hNRpos)
  have hNRQ : (minimumRowNComplement D : ℝ) / (D.Q : ℝ) < 1 := by
    have hnum : D.Q - D.s < D.Q := by omega
    have hnumR : ((D.Q - D.s : ℤ) : ℝ) < (D.Q : ℝ) := by exact_mod_cast hnum
    have hQR : 0 < (D.Q : ℝ) := by exact_mod_cast hQpos
    exact (div_lt_iff₀ hQR).2 (by simpa [minimumRowNComplement] using hnumR)
  have hEfinal : E < 8 * (minimumRowN D : ℝ) / 7 := by
    have hcoef : 0 ≤
        (minimumRowNComplement D : ℝ) *
          (inverseSineEnvelopeConstant / (D.Q : ℝ) ^ 2) := by positivity
    have hEbound2 := lt_of_lt_of_le hEbound
      (mul_le_mul_of_nonneg_left hsumd hcoef)
    have hQreal : 0 < (D.Q : ℝ) := by exact_mod_cast hQpos
    have hstep1 : inverseSineEnvelopeConstant *
        ((minimumRowNComplement D : ℝ) / (D.Q : ℝ)) <
        inverseSineEnvelopeConstant := by
      simpa using (mul_lt_mul_of_pos_left hNRQ hCpos)
    have hstep2 : (inverseSineEnvelopeConstant / 2) *
        ((minimumRowNComplement D : ℝ) / (D.Q : ℝ)) < (8 : ℝ) / 7 := by
      nlinarith [hstep1, hCup]
    have hstep3 := mul_lt_mul_of_pos_left hstep2 hnpos
    have halg :
        (minimumRowNComplement D : ℝ) *
          (inverseSineEnvelopeConstant / (D.Q : ℝ) ^ 2) *
            ((minimumRowN D : ℝ) * (D.Q : ℝ) / 2) =
          (minimumRowN D : ℝ) *
            ((inverseSineEnvelopeConstant / 2) *
              ((minimumRowNComplement D : ℝ) / (D.Q : ℝ))) := by
      field_simp
    rw [halg] at hEbound2
    nlinarith
  have hdelta_nonneg : ∀ a ∈ D.A.erase D.s,
      0 ≤ (minimumRowDelta D a : ℝ) := by
    intro a ha
    have hmem := (hslack.2.2.1 a ha).2
    have hmem' : (minimumRowDelta D a = 0 ∨
        minimumRowDelta D a = 2 * D.s) ∨ D.Q ≤ minimumRowDelta D a := by
      simpa [Set.mem_union, Set.mem_insert_iff, Set.mem_singleton_iff, Set.mem_Ici] using hmem
    rcases hmem' with hbase | hQ
    · rcases hbase with hzero | htwo
      · rw [hzero]
        positivity
      · rw [htwo]
        positivity
    · have hq0 : 0 ≤ (D.Q : ℝ) := by exact_mod_cast (show 0 ≤ D.Q by omega)
      have hqR : (D.Q : ℝ) ≤ (minimumRowDelta D a : ℝ) := by exact_mod_cast hQ
      linarith
  have hB_eq : badMinimumRowSum D =
      ∑ a ∈ D.A.erase D.s with BadMinimumRowElement D a, a := by
    dsimp [badMinimumRowSum]
    symm
    exact Finset.sum_filter (fun a => BadMinimumRowElement D a) (fun a : ℤ => a)
  have hB_real : (badMinimumRowSum D : ℝ) =
      ∑ a ∈ D.A.erase D.s with BadMinimumRowElement D a, (a : ℝ) := by
    rw [hB_eq]
    exact Int.cast_sum _ _
  have hB_delta : ∀ a ∈ D.A.erase D.s,
      BadMinimumRowElement D a → D.Q ≤ minimumRowDelta D a := by
    intro a ha hbad
    have hmem := (hslack.2.2.1 a ha).2
    have hmem' : (minimumRowDelta D a = 0 ∨
        minimumRowDelta D a = 2 * D.s) ∨ D.Q ≤ minimumRowDelta D a := by
      simpa [Set.mem_union, Set.mem_insert_iff, Set.mem_singleton_iff, Set.mem_Ici] using hmem
    rcases hmem' with hbase | hQ
    · rcases hbase with hzero | htwo
      · exfalso
        apply hbad
        left
        refine ⟨minimumRowDistance D a, ?_⟩
        dsimp [minimumRowDelta, minimumRowNComplement] at hzero ⊢
        nlinarith [hzero]
      · exfalso
        apply hbad
        right
        refine ⟨minimumRowDistance D a, ?_⟩
        dsimp [minimumRowDelta, minimumRowNComplement] at htwo ⊢
        nlinarith [htwo]
    · exact hQ
  have hratio_bad : ∀ a ∈ D.A.erase D.s,
      BadMinimumRowElement D a →
        (a : ℝ) / 2 < (minimumRowDelta D a : ℝ) /
          (minimumRowDistance D a : ℝ) := by
    intro a ha hbad
    have hδ := hB_delta a ha hbad
    have hdR : 0 < (minimumRowDistance D a : ℝ) := by
      have hh := (hdist a ha).1
      dsimp [minimumRowDistance] at hh
      have hdInt : 0 < minimumRowDistance D a := by
        dsimp [minimumRowDistance]
        omega
      exact_mod_cast hdInt
    have hNR : 0 < (minimumRowNComplement D : ℝ) := by exact_mod_cast hNpos
    have hrel := congrArg (fun z : ℤ => (z : ℝ)) (show
      minimumRowDistance D a * a = minimumRowNComplement D + minimumRowDelta D a by
        dsimp [minimumRowDelta]
        ring)
    push_cast at hrel
    have hδN : (minimumRowNComplement D : ℝ) <
        (minimumRowDelta D a : ℝ) := by
      have hδR : ((D.Q : ℝ) ≤ (minimumRowDelta D a : ℝ)) := by exact_mod_cast hδ
      have hsR : (0 : ℝ) < (D.s : ℝ) := by exact_mod_cast hspos
      dsimp [minimumRowNComplement]
      push_cast
      nlinarith [hsR, hδR]
    apply (lt_div_iff₀ hdR).2
    nlinarith [hrel, hδN]
  have hratio_nonbad : ∀ a ∈ D.A.erase D.s,
      ¬ BadMinimumRowElement D a →
        0 ≤ (minimumRowDelta D a : ℝ) /
          (minimumRowDistance D a : ℝ) := by
    intro a ha hnot
    apply div_nonneg (hdelta_nonneg a ha)
    have hh := (hdist a ha).1
    dsimp [minimumRowDistance] at hh
    have hdInt : 0 < minimumRowDistance D a := by
      dsimp [minimumRowDistance]
      omega
    exact_mod_cast hdInt |>.le
  have hB_nonneg : 0 ≤ (badMinimumRowSum D : ℝ) := by
    rw [hB_real]
    apply Finset.sum_nonneg
    intro a ha
    exact_mod_cast (D.hA.1 a (Finset.mem_erase.mp (Finset.mem_filter.mp ha).1 |>.2)).1.le
  have hB_pos : (badMinimumRowSum D : ℝ) = 0 ∨
      0 < (badMinimumRowSum D : ℝ) := by
    by_cases hz : badMinimumRowSum D = 0
    · exact Or.inl (by simp [hz])
    · have hzR : (badMinimumRowSum D : ℝ) ≠ 0 := by exact_mod_cast hz
      exact Or.inr (lt_of_le_of_ne hB_nonneg (Ne.symm hzR))
  have hbad_bound : (badMinimumRowSum D : ℝ) <
      16 * (minimumRowN D : ℝ) / 7 := by
    rcases hB_pos with hzero | hpositive
    · rw [hzero]
      have : 0 < 16 * (minimumRowN D : ℝ) / 7 := by positivity
      exact this
    · let B : Finset ℤ := D.A.erase D.s |>.filter (fun a => BadMinimumRowElement D a)
      have hB_nonempty : B.Nonempty := by
        by_contra hn
        have he : B = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
        have hz : badMinimumRowSum D = 0 := by
          rw [hB_eq]
          simp [B, he]
        exact hpositive.ne' (by exact_mod_cast hz)
      have hsum_comp :
          (∑ a ∈ D.A.erase D.s,
            (if BadMinimumRowElement D a then (a : ℝ) / 2 else 0)) <
            (∑ a ∈ D.A.erase D.s,
              (minimumRowDelta D a : ℝ) /
                (minimumRowDistance D a : ℝ)) := by
        apply Finset.sum_lt_sum
        · intro a ha
          by_cases hb : BadMinimumRowElement D a
          · rw [if_pos hb]
            exact (hratio_bad a ha hb).le
          · rw [if_neg hb]
            exact hratio_nonbad a ha hb
        · obtain ⟨a, ha⟩ := hB_nonempty
          refine ⟨a, ?_, ?_⟩
          · exact (Finset.mem_filter.mp ha).1
          · rw [if_pos (Finset.mem_filter.mp ha).2]
            exact hratio_bad a (Finset.mem_filter.mp ha).1 (Finset.mem_filter.mp ha).2
      have hsumif :
          (∑ a ∈ D.A.erase D.s,
            (if BadMinimumRowElement D a then (a : ℝ) else 0)) =
            (badMinimumRowSum D : ℝ) := by
        rw [hB_real]
        symm
        exact Finset.sum_filter (fun a => BadMinimumRowElement D a)
          (fun a : ℤ => (a : ℝ))
      have hsum_left :
          (∑ a ∈ D.A.erase D.s,
            (if BadMinimumRowElement D a then (a : ℝ) / 2 else 0)) =
            (badMinimumRowSum D : ℝ) / 2 := by
        have hif : ∀ a : ℤ,
            (if BadMinimumRowElement D a then (a : ℝ) / 2 else 0) =
              (if BadMinimumRowElement D a then (a : ℝ) else 0) / 2 := by
          intro a
          split <;> ring
        simp_rw [hif]
        rw [← Finset.sum_div, hsumif]
      have hE_nonneg :
          (∑ a ∈ D.A.erase D.s,
            (minimumRowDelta D a : ℝ) /
              (minimumRowDistance D a : ℝ)) ≤ E := by
        have hbase : 0 ≤ ((D.Q - (∑ a ∈ D.A, a)) : ℝ) := by
          have hh := D.hA_sum
          exact_mod_cast (by omega : 0 ≤ D.Q - (∑ a ∈ D.A, a))
        rw [hEformula]
        linarith
      rw [hsum_left] at hsum_comp
      have hW_E : (badMinimumRowSum D : ℝ) / 2 < E :=
        lt_of_lt_of_le hsum_comp hE_nonneg
      nlinarith [hW_E, hEfinal]
  exact ⟨hEfinal, hbad_bound⟩


/-- Product-shell bookkeeping, including the special `s=1` consequences. -/
-- zpi: lem-product-shell-bookkeeping
theorem productShellBookkeeping (D : MinimumRowSlackData) :
    (∀ a ∈ D.A, ∀ b ∈ D.A, a ≠ b →
      IsProductShellValue D a b) ∧
    (∀ a ∈ D.A, ∀ b ∈ D.A, a ≠ b →
      (1 : ℝ) / (productShellDistance D a b : ℝ) =
        (b : ℝ) / (productShellValue D a b : ℝ)) ∧
    (∀ a : ℤ, a ∈ D.A → ∀ B : Finset ℤ, B ⊆ D.A.erase a →
      ∀ L T : ℝ, 0 ≤ L → 0 < T →
        ((∑ b ∈ B, (b : ℝ)) ≤ L) →
        (∀ b : ℤ, b ∈ B → T ≤ (productShellValue D a b : ℝ)) →
        ((∑ b ∈ B, (1 : ℝ) / (productShellDistance D a b : ℝ)) ≤ L / T)) ∧
    (∀ a ∈ D.A, ∀ b ∈ D.A, a ≠ b →
      productShellValue D a b = a → b ∣ a) ∧
    (D.s = 1 →
      ∀ a ∈ D.A, ∀ b ∈ D.A, a ≠ b →
        GoodMinimumRowElement D b →
        (productShellValue D a b = D.Q - a ∨
          productShellValue D a b = D.Q + a) →
        ((b ∣ a - 1 ∨ b ∣ a + 1) ∧
          (1 < a → b > a → b = a + 1))) := by
  classical
  have hshell : ∀ a ∈ D.A, ∀ b ∈ D.A, a ≠ b →
      IsProductShellValue D a b := by
    intro a ha b hb hab
    have hQ : 2 ≤ D.Q := by
      have hQ0 := D.hQ
      omega
    have hQpos : 0 < D.Q := by omega
    have haU := D.hA.1 a ha
    have hbU := D.hA.1 b hb
    have haQ : a < D.Q := by
      have hh := D.hA_upper a ha
      nlinarith
    have hbQ : b < D.Q := by
      have hh := D.hA_upper b hb
      nlinarith
    have hsinv : (a * inverseMod D.Q b) % D.Q ≠ 0 := by
      intro hz
      have hinv := inverseMod_spec D.Q b hQ hbU.2
      have hzero : a * inverseMod D.Q b ≡ 0 [ZMOD D.Q] := by
        simpa [Int.ModEq] using hz
      have hprod : (a * inverseMod D.Q b) * b ≡ 0 * b [ZMOD D.Q] :=
        hzero.mul_right b
      have h1mod : (1 : ℤ) % D.Q = 1 := by
        exact Int.emod_eq_of_lt (by omega) (by omega)
      have hone : b * inverseMod D.Q b ≡ 1 [ZMOD D.Q] := by
        simpa [Int.ModEq, h1mod] using hinv.2
      have hcalc : (a * inverseMod D.Q b) * b ≡ a [ZMOD D.Q] := by
        calc
          (a * inverseMod D.Q b) * b = a * (b * inverseMod D.Q b) := by ring
          _ ≡ a * 1 [ZMOD D.Q] := hone.mul_left a
          _ = a := by ring
      have hamod : a % D.Q = 0 := by
        have : (a * inverseMod D.Q b) * b % D.Q = 0 := hprod.eq.trans (by simp)
        rw [hcalc.eq] at this
        exact this
      have harem : a % D.Q = a := Int.emod_eq_of_lt (by omega) haQ
      omega
    have hdist := cyclicDistance_bounds D.Q (a * inverseMod D.Q b) hQ hsinv
    have hinv := inverseMod_spec D.Q b hQ hbU.2
    have h1mod : (1 : ℤ) % D.Q = 1 := by
      exact Int.emod_eq_of_lt (by omega) (by omega)
    have hone : b * inverseMod D.Q b ≡ 1 [ZMOD D.Q] := by
      simpa [Int.ModEq, h1mod] using hinv.2
    let r : ℤ := (a * inverseMod D.Q b) % D.Q
    have hrmod : r ≡ a * inverseMod D.Q b [ZMOD D.Q] := by
      dsimp [r]
      exact Int.mod_modEq _ _
    have hprod : productShellValue D a b ≡ a [ZMOD D.Q] ∨
        productShellValue D a b ≡ -a [ZMOD D.Q] := by
      rcases le_total r (D.Q - r) with hle | hle
      · left
        have hd_r : productShellDistance D a b = r := by
          dsimp [productShellDistance, cyclicDistance, r]
          rw [min_eq_left hle]
        rw [productShellValue, hd_r]
        calc
          b * r ≡ b * (a * inverseMod D.Q b) [ZMOD D.Q] := hrmod.mul_left b
          _ = a * (b * inverseMod D.Q b) := by ring
          _ ≡ a * 1 [ZMOD D.Q] := hone.mul_left a
          _ = a := by ring
      · right
        have hd_qr : productShellDistance D a b = D.Q - r := by
          dsimp [productShellDistance, cyclicDistance, r]
          rw [min_eq_right hle]
        have hq : D.Q ≡ 0 [ZMOD D.Q] := by simp
        have hqr : D.Q - r ≡ -(a * inverseMod D.Q b) [ZMOD D.Q] := by
          have hh := hq.sub hrmod
          simpa using hh
        rw [productShellValue, hd_qr]
        calc
          b * (D.Q - r) ≡ b * (-(a * inverseMod D.Q b)) [ZMOD D.Q] := hqr.mul_left b
          _ = -(a * (b * inverseMod D.Q b)) := by ring
          _ ≡ -(a * 1) [ZMOD D.Q] := by
            convert hone.neg.mul_left a using 1 <;> ring
          _ = -a := by ring
    have hPpos : 0 < productShellValue D a b := by
      dsimp [productShellValue]
      exact mul_pos hbU.1 (by
        dsimp [productShellDistance]
        have := hdist.1
        omega)
    rcases hprod with hplus | hminus
    · obtain ⟨k, hk⟩ := Int.modEq_iff_add_fac.mp hplus
      have hk_nonpos : k ≤ 0 := by
        by_contra hknot
        have hkpos : 1 ≤ k := by omega
        have hqk : 0 < D.Q * k := mul_pos hQpos (by omega)
        nlinarith [hk, hPpos, haU.1]
      have hkc : k = 0 ∨ k ≤ -1 := by omega
      rcases hkc with rfl | hkneg
      · left
        simpa using hk.symm
      · right
        refine ⟨-k, by omega, ?_⟩
        right
        nlinarith [hk]
    · obtain ⟨k, hk⟩ := Int.modEq_iff_add_fac.mp hminus
      have hkneg : k ≤ -1 := by
        by_contra hknot
        have hk0 : 0 ≤ k := by omega
        have hqk : 0 ≤ D.Q * k := mul_nonneg (by omega) (by omega)
        nlinarith [hk, hPpos, haU.1]
      right
      refine ⟨-k, by omega, ?_⟩
      left
      nlinarith [hk]

  have hrecip : ∀ a ∈ D.A, ∀ b ∈ D.A, a ≠ b →
      (1 : ℝ) / (productShellDistance D a b : ℝ) =
        (b : ℝ) / (productShellValue D a b : ℝ) := by
    intro a ha b hb hab
    have haU := D.hA.1 a ha
    have haQ : a < D.Q := by
      have hh := D.hA_upper a ha
      nlinarith
    have hbpos : 0 < b := D.hA.1 b hb |>.1
    have hPpos : 0 < productShellValue D a b := by
      rcases hshell a ha b hb hab with hP | ⟨j, hj, hP⟩
      · rw [hP]
        exact D.hA.1 a ha |>.1
      · have hQ0 := D.hQ
        have hq0 : 0 < D.Q := by omega
        rcases hP with hP | hP
        · rw [hP]
          have hqj : D.Q ≤ j * D.Q := by
            have hh := mul_le_mul_of_nonneg_right hj (show 0 ≤ D.Q by omega)
            simpa using hh
          nlinarith [hqj, haQ]
        · rw [hP]
          have hqj : 0 ≤ j * D.Q := by positivity
          nlinarith [hqj, haU.1]
    have hdpos : 0 < productShellDistance D a b := by
      dsimp [productShellValue] at hPpos
      nlinarith
    dsimp [productShellValue]
    field_simp [hdpos.ne', hbpos.ne']
    push_cast
    ring
  have hsubset : ∀ a : ℤ, a ∈ D.A → ∀ B : Finset ℤ, B ⊆ D.A.erase a →
      ∀ L T : ℝ, 0 ≤ L → 0 < T →
        ((∑ b ∈ B, (b : ℝ)) ≤ L) →
        (∀ b : ℤ, b ∈ B → T ≤ (productShellValue D a b : ℝ)) →
        ((∑ b ∈ B, (1 : ℝ) / (productShellDistance D a b : ℝ)) ≤ L / T) := by
    intro a ha B hB L T hL hT hsum hPT
    have hpoint : ∀ b ∈ B,
        (1 : ℝ) / (productShellDistance D a b : ℝ) ≤ (b : ℝ) / T := by
      intro b hb
      have hbA : b ∈ D.A := (Finset.mem_erase.mp (hB hb)).2
      have hrec := hrecip a ha b hbA (by
        intro heq
        exact (Finset.mem_erase.mp (hB hb)).1 heq.symm)
      have hP : T ≤ (productShellValue D a b : ℝ) := hPT b hb
      have hTpos : 0 < T := hT
      have hbnonneg : 0 ≤ (b : ℝ) := by exact_mod_cast (D.hA.1 b hbA).1.le
      rw [hrec]
      exact div_le_div_of_nonneg_left hbnonneg hTpos hP
    have hs := Finset.sum_le_sum hpoint
    have hsdiv :
        (∑ b ∈ B, (b : ℝ) / T) = (∑ b ∈ B, (b : ℝ)) / T := by
      rw [Finset.sum_div]
    rw [hsdiv] at hs
    exact hs.trans (div_le_div_of_nonneg_right hsum (le_of_lt hT))
  have hdiv : ∀ a ∈ D.A, ∀ b ∈ D.A, a ≠ b →
      productShellValue D a b = a → b ∣ a := by
    intro a ha b hb hab hP
    refine ⟨productShellDistance D a b, ?_⟩
    dsimp [productShellValue] at hP
    exact hP.symm
  have hspecial : D.s = 1 →
      ∀ a ∈ D.A, ∀ b ∈ D.A, a ≠ b →
        GoodMinimumRowElement D b →
        (productShellValue D a b = D.Q - a ∨
          productShellValue D a b = D.Q + a) →
        ((b ∣ a - 1 ∨ b ∣ a + 1) ∧
          (1 < a → b > a → b = a + 1)) := by
    intro hs a ha b hb hab hgood hshellfirst
    have hbP : b ∣ productShellValue D a b := by
      refine ⟨productShellDistance D a b, ?_⟩
      rfl
    have hgood' : b ∣ D.Q - D.s ∨ b ∣ D.Q + D.s := hgood
    rcases hgood' with hminus | hplus
    · rw [hs] at hminus
      rcases hshellfirst with hQa | hQpa
      · have hh := hminus.sub (by simpa [hQa] using hbP)
        have hba : b ∣ a - 1 := by
          convert hh using 1
          ring
        refine ⟨Or.inl hba, ?_⟩
        intro hagt hbgt
        exfalso
        obtain ⟨k, hk⟩ := hba
        have hkpos : 0 < k := by
          by_contra hkn
          have hk0 : k ≤ 0 := by omega
          have : b * k ≤ 0 := mul_nonpos_of_nonneg_of_nonpos
            (D.hA.1 b hb).1.le hk0
          nlinarith [hk]
        have hbk : b ≤ b * k := by
          have := mul_le_mul_of_nonneg_left (show (1 : ℤ) ≤ k by omega)
            (show 0 ≤ b by omega)
          simpa using this
        nlinarith [hk, hbk]
      · have hh := hminus.sub (by simpa [hQpa] using hbP)
        have hba : b ∣ -(a + 1) := by
          convert hh using 1
          ring
        have hba' : b ∣ a + 1 := by
          apply dvd_neg.mp
          exact hba
        refine ⟨Or.inr hba', ?_⟩
        intro hagt hbgt
        obtain ⟨k, hk⟩ := hba'
        have hkpos : 0 < k := by
          by_contra hkn
          have hk0 : k ≤ 0 := by omega
          have : b * k ≤ 0 := mul_nonpos_of_nonneg_of_nonpos
            (D.hA.1 b hb).1.le hk0
          nlinarith [hk]
        have hbk : b ≤ b * k := by
          have := mul_le_mul_of_nonneg_left (show (1 : ℤ) ≤ k by omega)
            (show 0 ≤ b by omega)
          simpa using this
        have hupper : b ≤ a + 1 := by nlinarith [hk, hbk]
        omega
    · rw [hs] at hplus
      rcases hshellfirst with hQa | hQpa
      · have hh := hplus.sub (by simpa [hQa] using hbP)
        have hba : b ∣ a + 1 := by
          convert hh using 1
          ring
        refine ⟨Or.inr hba, ?_⟩
        intro hagt hbgt
        obtain ⟨k, hk⟩ := hba
        have hkpos : 0 < k := by
          by_contra hkn
          have hk0 : k ≤ 0 := by omega
          have : b * k ≤ 0 := mul_nonpos_of_nonneg_of_nonpos
            (D.hA.1 b hb).1.le hk0
          nlinarith [hk]
        have hbk : b ≤ b * k := by
          have := mul_le_mul_of_nonneg_left (show (1 : ℤ) ≤ k by omega)
            (show 0 ≤ b by omega)
          simpa using this
        have hupper : b ≤ a + 1 := by nlinarith [hk, hbk]
        omega
      · have hh := hplus.sub (by simpa [hQpa] using hbP)
        have hba : b ∣ a - 1 := by
          have hneg : b ∣ -(a - 1) := by
            convert hh using 1
            ring
          apply dvd_neg.mp
          exact hneg
        refine ⟨Or.inl hba, ?_⟩
        intro hagt hbgt
        exfalso
        obtain ⟨k, hk⟩ := hba
        have hkpos : 0 < k := by
          by_contra hkn
          have hk0 : k ≤ 0 := by omega
          have : b * k ≤ 0 := mul_nonpos_of_nonneg_of_nonpos
            (D.hA.1 b hb).1.le hk0
          nlinarith [hk]
        have hbk : b ≤ b * k := by
          have := mul_le_mul_of_nonneg_left (show (1 : ℤ) ≤ k by omega)
            (show 0 ≤ b by omega)
          simpa using this
        nlinarith [hk, hbk]
  exact ⟨hshell, hrecip, hsubset, hdiv, hspecial⟩


end Fraenkel
