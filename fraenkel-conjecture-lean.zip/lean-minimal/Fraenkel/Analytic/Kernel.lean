import Fraenkel.External.NistDlmf
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Int.GCD
import Mathlib.Tactic

/-!
# Cyclic distance and the inverse-sine kernel

All integer variables in the entries are represented by `ℤ`. In theorems,
`2 * d ≤ Q` expresses the paper's `d ≤ Q/2` without rounding. Real-valued
quotients explicitly coerce their integer arguments to `ℝ`.

`UnitRepresentatives` permits noncanonical positive representatives but forbids
two representatives of the same residue class. The modular inverse is the
canonical residue of a Bezout coefficient, not integer or real reciprocation.

The analytic envelope includes its optimality assertion. The reciprocal-sine
estimate is proved from exact two-interval trigonometric inequalities; the
borrowed complex small-angle limit is used only for optimality.
-/

open Filter
open scoped BigOperators Topology

namespace Fraenkel

/-- Least cyclic distance. Outside the entry's nonzero-residue domain this is
only a total extension (in particular, the distance of zero is zero). -/
-- zpi: def-cyclic-distance-modulo-q
def cyclicDistance (Q x : ℤ) : ℤ := min (x % Q) (Q - x % Q)

/-- The defining formula for a specified least positive residue. -/
-- zpi: def-cyclic-distance-modulo-q
theorem cyclicDistance_spec (Q x r : ℤ) (_hQ : 2 ≤ Q)
    (_hr : 1 ≤ r ∧ r < Q) (hres : x % Q = r) :
    cyclicDistance Q x = min r (Q - r) := by
  simp only [cyclicDistance, hres]

/-- The bounds asserted in the cyclic-distance entry. -/
-- zpi: def-cyclic-distance-modulo-q
theorem cyclicDistance_bounds (Q x : ℤ) (hQ : 2 ≤ Q) (hx : x % Q ≠ 0) :
    1 ≤ cyclicDistance Q x ∧ 2 * cyclicDistance Q x ≤ Q := by
  have hnonneg := Int.emod_nonneg x (show Q ≠ 0 by omega)
  have hlt := Int.emod_lt_of_pos x (show 0 < Q by omega)
  dsimp [cyclicDistance]
  omega

/-- A canonical modular inverse, on the domain `Int.gcd b Q = 1`, `2 ≤ Q`. -/
-- zpi: def-inverse-sine-row-mass
def inverseMod (Q b : ℤ) : ℤ := Int.gcdA b Q % Q

/-- The modular inverse really is in `1,...,Q-1` and multiplies to one. -/
-- zpi: def-inverse-sine-row-mass
theorem inverseMod_spec (Q b : ℤ) (hQ : 2 ≤ Q) (hcop : Int.gcd b Q = 1) :
    (1 ≤ inverseMod Q b ∧ inverseMod Q b < Q) ∧
      (b * inverseMod Q b) % Q = 1 := by
  have hOne : (1 : ℤ) % Q = 1 := Int.emod_eq_of_lt (by omega) (by omega)
  have hbezout := congrArg (fun z : ℤ => z % Q) (Int.gcd_eq_gcd_ab b Q)
  have hmul : (b * inverseMod Q b) % Q = 1 := by
    simpa [inverseMod, hcop, Int.add_emod, Int.mul_emod, hOne] using hbezout.symm
  have hnonneg := Int.emod_nonneg (Int.gcdA b Q) (show Q ≠ 0 by omega)
  have hlt := Int.emod_lt_of_pos (Int.gcdA b Q) (show 0 < Q by omega)
  have hne : inverseMod Q b ≠ 0 := by
    intro hz
    simp [hz] at hmul
  exact ⟨⟨by dsimp [inverseMod] at *; omega, hlt⟩, hmul⟩

/-- A finite subset of the unit group, represented by distinct positive integers.
Distinct representatives must also denote distinct residue classes. -/
-- zpi: def-inverse-sine-row-mass
def UnitRepresentatives (Q : ℤ) (A : Finset ℤ) : Prop :=
  (∀ a ∈ A, 0 < a ∧ Int.gcd a Q = 1) ∧
    Set.InjOn (fun a : ℤ => a % Q) (A : Set ℤ)

/-- The inverse-sine kernel. Its intended domain is `2 ≤ Q`, `1 ≤ d`, `2*d ≤ Q`. -/
-- zpi: def-inverse-sine-kernel
noncomputable def inverseSineKernel (Q d : ℤ) : ℝ :=
  Real.sin (Real.pi / (Q : ℝ)) / Real.sin (Real.pi * (d : ℝ) / (Q : ℝ))

-- zpi: def-inverse-sine-kernel
theorem inverseSineKernel_spec (Q d : ℤ) (_hQ : 2 ≤ Q) (_hd : 1 ≤ d)
    (_hdQ : 2 * d ≤ Q) :
    inverseSineKernel Q d =
      Real.sin (Real.pi / (Q : ℝ)) / Real.sin (Real.pi * (d : ℝ) / (Q : ℝ)) :=
  rfl

/-- Mass of the row indexed by `a`, with the sum excluding `a` itself. -/
-- zpi: def-inverse-sine-row-mass
noncomputable def inverseSineRowMass (Q : ℤ) (A : Finset ℤ) (a : ℤ) : ℝ :=
  ∑ b ∈ A.erase a, inverseSineKernel Q (cyclicDistance Q (a * inverseMod Q b))

/-- Passing means mass at least one. -/
-- zpi: def-inverse-sine-row-mass
def RowPasses (Q : ℤ) (A : Finset ℤ) (a : ℤ) : Prop :=
  1 ≤ inverseSineRowMass Q A a

/-- Deficient means mass strictly below one. -/
-- zpi: def-inverse-sine-row-mass
def RowDeficient (Q : ℤ) (A : Finset ℤ) (a : ℤ) : Prop :=
  inverseSineRowMass Q A a < 1

-- zpi: def-inverse-sine-row-mass
theorem inverseSineRowMass_spec (Q : ℤ) (A : Finset ℤ) (a : ℤ)
    (_hQ : 2 ≤ Q) (_hA : UnitRepresentatives Q A) (_ha : a ∈ A) :
    inverseSineRowMass Q A a =
      ∑ b ∈ A.erase a, inverseSineKernel Q (cyclicDistance Q (a * inverseMod Q b)) :=
  rfl

-- zpi: def-inverse-sine-row-mass
theorem rowPasses_iff (Q : ℤ) (A : Finset ℤ) (a : ℤ) :
    RowPasses Q A a ↔ 1 ≤ inverseSineRowMass Q A a :=
  Iff.rfl

-- zpi: def-inverse-sine-row-mass
theorem rowDeficient_iff (Q : ℤ) (A : Finset ℤ) (a : ℤ) :
    RowDeficient Q A a ↔ inverseSineRowMass Q A a < 1 :=
  Iff.rfl

/-- The optimal constant `C₀` from the envelope proposition. -/
-- zpi: prop-inverse-sine-envelope
noncomputable def inverseSineEnvelopeConstant : ℝ := 2 * Real.pi - 4

/-- A non-strict uniform upper envelope, used to state optimality. The entry
proves the stronger strict upper bound at `C₀`, so this also covers strict
uniform envelopes at any proposed smaller constant. -/
-- zpi: prop-inverse-sine-envelope
def IsUniformInverseSineEnvelope (C : ℝ) : Prop :=
  ∀ Q d : ℤ, 2 ≤ Q → 1 ≤ d → 2 * d ≤ Q →
    inverseSineKernel Q d ≤ 1 / (d : ℝ) + C * (d : ℝ) / (Q : ℝ) ^ 2

/-- Elementary parameter bounds used in both halves of the kernel estimate. -/
-- zpi: def-inverse-sine-kernel
theorem kernelAngleBounds (Q d : ℤ) (hQ : 2 ≤ Q) (hd : 1 ≤ d) (hdQ : 2 * d ≤ Q) :
    0 < Real.pi / (Q : ℝ) ∧
    Real.pi / (Q : ℝ) ≤ Real.pi * (d : ℝ) / (Q : ℝ) ∧
    0 < Real.pi * (d : ℝ) / (Q : ℝ) ∧
    Real.pi * (d : ℝ) / (Q : ℝ) ≤ Real.pi / 2 := by
  have hQpos : 0 < (Q : ℝ) := by exact_mod_cast (show 0 < Q by omega)
  have hdOne : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
  have hdpos : 0 < (d : ℝ) := by linarith
  have hdQ' : 2 * (d : ℝ) ≤ (Q : ℝ) := by exact_mod_cast hdQ
  refine ⟨by positivity, ?_, by positivity, ?_⟩
  · apply div_le_div_of_nonneg_right _ hQpos.le
    nlinarith [Real.pi_pos]
  · apply (div_le_iff₀ hQpos).mpr
    nlinarith [mul_le_mul_of_nonneg_left hdQ' Real.pi_pos.le]

/-- The monotonicity step in the source proof. Mathlib's concavity theorem
packages the same elementary derivative sign on `[0,π]`. -/
-- zpi: prop-inverse-sine-envelope
theorem sinRatioAntitone (x y : ℝ) (hx : 0 < x) (hxy : x ≤ y) (hy : y ≤ Real.pi) :
    Real.sin y / y ≤ Real.sin x / x := by
  have h := strictConcaveOn_sin_Icc.concaveOn.antitoneOn_slope_gt
    (show (0 : ℝ) ∈ Set.Icc 0 Real.pi from ⟨le_rfl, Real.pi_pos.le⟩)
  have hxy' := h (show x ∈ {t ∈ Set.Icc 0 Real.pi | 0 < t} from
      ⟨⟨hx.le, hxy.trans hy⟩, hx⟩)
    (show y ∈ {t ∈ Set.Icc 0 Real.pi | 0 < t} from
      ⟨⟨hx.le.trans hxy, hy⟩, hx.trans_le hxy⟩) hxy
  simpa [slope_def_field] using hxy'

/-- The lower bound proved by comparing the two sine ratios. -/
-- zpi: prop-inverse-sine-envelope
theorem inverseSineKernel_lower (Q d : ℤ) (hQ : 2 ≤ Q) (hd : 1 ≤ d) (hdQ : 2 * d ≤ Q) :
    1 / (d : ℝ) ≤ inverseSineKernel Q d := by
  obtain ⟨hy, hyx, hx, hxhalf⟩ := kernelAngleBounds Q d hQ hd hdQ
  let y : ℝ := Real.pi / (Q : ℝ)
  let x : ℝ := Real.pi * (d : ℝ) / (Q : ℝ)
  have hxpi : x < Real.pi := lt_of_le_of_lt hxhalf (by linarith [Real.pi_pos])
  have hsinx : 0 < Real.sin x := Real.sin_pos_of_pos_of_lt_pi hx hxpi
  have hdpos : 0 < (d : ℝ) := by exact_mod_cast (show 0 < d by omega)
  have hr := (div_le_div_iff₀ hx hy).mp (sinRatioAntitone y x hy hyx hxpi.le)
  have hxy : x = y * (d : ℝ) := by dsimp [x, y]; ring
  change Real.sin x * y ≤ Real.sin y * x at hr
  have hprod : Real.sin x * y ≤ ((d : ℝ) * Real.sin y) * y := by
    calc
      _ ≤ Real.sin y * x := hr
      _ = _ := by rw [hxy]; ring
  have hsin : Real.sin x ≤ (d : ℝ) * Real.sin y :=
    (mul_le_mul_iff_of_pos_right hy).mp hprod
  exact (div_le_div_iff₀ hdpos hsinx).mpr
    (by simpa [inverseSineKernel, x, y, mul_comm] using hsin)

/-- The coefficient in the reciprocal-sine estimate is larger than `2/9`.
This coarse rational comparison is enough for the small-angle algebra below. -/
-- zpi: prop-inverse-sine-envelope
theorem inverseSineCoefficient_lower :
    (2 : ℝ) / 9 < inverseSineEnvelopeConstant / Real.pi ^ 2 := by
  have hp3 : (3 : ℝ) < Real.pi := Real.pi_gt_three
  have hp4 : Real.pi < 4 := Real.pi_lt_four
  have hp : 0 < Real.pi := Real.pi_pos
  dsimp [inverseSineEnvelopeConstant]
  apply (div_lt_div_iff₀ (by positivity) (by positivity)).2
  nlinarith

/-- A two-angle lower bound for sine on the small part of the interval. -/
-- zpi: prop-inverse-sine-envelope
theorem inverseSine_small_lower {x : ℝ} (hx : 0 < x) (hx1 : x ≤ 1) :
    x * (1 - x ^ 2 / 16) * (1 - x ^ 2 / 8) < Real.sin x := by
  have hxhalf : 0 < x / 2 := by positivity
  have hxhalf1 : x / 2 ≤ 1 := by linarith
  have hs := Real.sin_gt_sub_cube hxhalf hxhalf1
  have hc := Real.one_sub_sq_div_two_le_cos (x := x / 2)
  have hc' : 1 - (x / 2) ^ 2 / 2 ≤ Real.cos (x / 2) := by simpa using hc
  have hA : 0 < x / 2 - (x / 2) ^ 3 / 4 := by nlinarith [sq_nonneg x]
  have hcos : 0 < Real.cos (x / 2) := by
    apply Real.cos_pos_of_mem_Ioo
    constructor
    · nlinarith [Real.pi_pos]
    · nlinarith [Real.pi_gt_three]
  have h1 := mul_lt_mul_of_pos_right hs hcos
  have h2 := mul_le_mul_of_nonneg_left hc' hA.le
  have h3 :
      (x / 2 - (x / 2) ^ 3 / 4) * (1 - (x / 2) ^ 2 / 2) <
        Real.sin (x / 2) * Real.cos (x / 2) :=
    lt_of_le_of_lt h2 h1
  calc
    x * (1 - x ^ 2 / 16) * (1 - x ^ 2 / 8) =
        2 * ((x / 2 - (x / 2) ^ 3 / 4) * (1 - (x / 2) ^ 2 / 2)) := by ring
    _ < 2 * (Real.sin (x / 2) * Real.cos (x / 2)) :=
      mul_lt_mul_of_pos_left h3 (by norm_num)
    _ = Real.sin x := by
      calc
        2 * (Real.sin (x / 2) * Real.cos (x / 2)) =
            Real.sin (2 * (x / 2)) := by
              rw [Real.sin_two_mul]
              ring
        _ = Real.sin x := by congr 1 <;> ring

/-- The reciprocal-sine target follows algebraically on the small subinterval. -/
-- zpi: prop-inverse-sine-envelope
theorem inverseSine_small_target {x : ℝ} (hx : 0 < x) (hx1 : x ≤ 1) :
    x ≤ (1 + inverseSineEnvelopeConstant / Real.pi ^ 2 * x ^ 2) *
      (x * (1 - x ^ 2 / 16) * (1 - x ^ 2 / 8)) := by
  let k : ℝ := inverseSineEnvelopeConstant / Real.pi ^ 2
  have hkl : (2 : ℝ) / 9 < k := by
    dsimp [k]
    exact inverseSineCoefficient_lower
  have hx2 : 0 ≤ x ^ 2 := sq_nonneg x
  have hx2one : x ^ 2 ≤ 1 := by nlinarith [sq_nonneg (1 - x)]
  have hpoly :
      0 ≤ (1 + (2 / 9 : ℝ) * x ^ 2) *
        ((1 - x ^ 2 / 16) * (1 - x ^ 2 / 8)) - 1 := by
    nlinarith [mul_nonneg hx2 (show 0 ≤ 1 - x ^ 2 by linarith),
      mul_nonneg (show 0 ≤ x ^ 2 by positivity) (show 0 ≤ x ^ 2 by positivity)]
  have hfactor : 0 ≤ (1 - x ^ 2 / 16) * (1 - x ^ 2 / 8) := by
    have h16 : 0 ≤ 1 - x ^ 2 / 16 := by nlinarith
    have h8 : 0 ≤ 1 - x ^ 2 / 8 := by nlinarith
    positivity
  dsimp [k] at hkl ⊢
  have hcoef : (2 / 9 : ℝ) * x ^ 2 ≤
      ((2 * Real.pi - 4) / Real.pi ^ 2) * x ^ 2 := by
    change (2 / 9 : ℝ) * x ^ 2 ≤
      ((2 * Real.pi - 4) / Real.pi ^ 2) * x ^ 2
    exact mul_le_mul_of_nonneg_right hkl.le hx2
  have hmul :
      (1 + (2 / 9 : ℝ) * x ^ 2) *
          ((1 - x ^ 2 / 16) * (1 - x ^ 2 / 8)) ≤
        (1 + ((2 * Real.pi - 4) / Real.pi ^ 2) * x ^ 2) *
          ((1 - x ^ 2 / 16) * (1 - x ^ 2 / 8)) := by
    gcongr
  have hprod : 1 ≤
      (1 + ((2 * Real.pi - 4) / Real.pi ^ 2) * x ^ 2) *
        ((1 - x ^ 2 / 16) * (1 - x ^ 2 / 8)) := by
    linarith [hpoly, hmul]
  have hmulx := mul_le_mul_of_nonneg_left hprod hx.le
  calc
    x = x * 1 := by ring
    _ ≤ x * ((1 + ((2 * Real.pi - 4) / Real.pi ^ 2) * x ^ 2) *
        ((1 - x ^ 2 / 16) * (1 - x ^ 2 / 8))) := hmulx
    _ = (1 + ((2 * Real.pi - 4) / Real.pi ^ 2) * x ^ 2) *
        (x * (1 - x ^ 2 / 16) * (1 - x ^ 2 / 8)) := by ring

/-- The reciprocal-sine target follows from the cosine half-angle bound near
`π/2`. -/
-- zpi: prop-inverse-sine-envelope
theorem inverseSine_large_target {x : ℝ} (hx1 : 1 ≤ x)
    (hxpi : x ≤ Real.pi / 2) :
    x ≤ (1 + inverseSineEnvelopeConstant / Real.pi ^ 2 * x ^ 2) *
      (1 - (Real.pi / 2 - x) ^ 2 / 2) := by
  let y : ℝ := Real.pi / 2 - x
  have hp3 : (3 : ℝ) < Real.pi := Real.pi_gt_three
  have hp315 : Real.pi < (16 : ℝ) / 5 := by
    have h := Real.pi_lt_d2
    linarith
  have hy0 : 0 ≤ y := by dsimp [y]; linarith
  have hyY : y ≤ Real.pi / 2 - 1 := by dsimp [y]; linarith
  have hneg : 4 - Real.pi ^ 2 ≤ 0 := by nlinarith
  have hlin : (4 - Real.pi ^ 2) * (Real.pi / 2 - 1) ≤
      (4 - Real.pi ^ 2) * y :=
    mul_le_mul_of_nonpos_left hyY hneg
  have hbase : 0 ≤ Real.pi ^ 2 - 2 * Real.pi + 4 +
      (4 - Real.pi ^ 2) * (Real.pi / 2 - 1) := by
    have hp4 : Real.pi < 4 := Real.pi_lt_four
    have hpos : 0 ≤ Real.pi ^ 2 * (4 - Real.pi) / 2 := by
      have hp : 0 ≤ (4 : ℝ) - Real.pi := sub_nonneg.mpr hp4.le
      positivity
    nlinarith
  have hquad : 0 ≤ (2 * Real.pi - 4) * y ^ 2 := by
    have hp : 0 ≤ (2 : ℝ) * Real.pi - 4 := by nlinarith
    positivity
  have hF : 0 ≤
      -Real.pi ^ 2 * y + Real.pi ^ 2 + 2 * Real.pi * y ^ 2 -
        2 * Real.pi - 4 * y ^ 2 + 4 * y + 4 := by
    nlinarith [hbase, hlin, hquad]
  have hpquad : Real.pi ^ 2 - 2 * Real.pi - 4 < 0 := by
    have hfac : 0 < ((16 : ℝ) / 5 - Real.pi) *
        ((16 : ℝ) / 5 + Real.pi - 2) := by
      have h1 : 0 < (16 : ℝ) / 5 - Real.pi := by linarith
      have h2 : 0 < (16 : ℝ) / 5 + Real.pi - 2 := by linarith
      exact mul_pos h1 h2
    nlinarith
  have hBY :
      (Real.pi ^ 3 * (Real.pi / 2 - 1) - 4 * Real.pi ^ 2 *
          (Real.pi / 2 - 1) ^ 2 + 4 * Real.pi ^ 2 +
        4 * Real.pi * (Real.pi / 2 - 1) ^ 3 +
          8 * Real.pi * (Real.pi / 2 - 1) ^ 2 -
        8 * Real.pi * (Real.pi / 2 - 1) - 16 * Real.pi -
          8 * (Real.pi / 2 - 1) ^ 3 + 16 * (Real.pi / 2 - 1)) < 0 := by
    have hfac : (Real.pi + 2) * (Real.pi ^ 2 - 2 * Real.pi - 4) < 0 :=
      mul_neg_of_pos_of_neg (by positivity) hpquad
    nlinarith
  let B : ℝ → ℝ := fun z =>
      Real.pi ^ 3 * z - 4 * Real.pi ^ 2 * z ^ 2 + 4 * Real.pi ^ 2 +
        4 * Real.pi * z ^ 3 + 8 * Real.pi * z ^ 2 -
        8 * Real.pi * z - 16 * Real.pi - 8 * z ^ 3 + 16 * z
  have hBendpoint : B (Real.pi / 2 - 1) < 0 := by
    dsimp [B]
    exact hBY
  have hBdiff : 0 ≤ B (Real.pi / 2 - 1) - B y := by
    have hnon : 0 ≤ 2 * (Real.pi / 2 - 1 - y) *
        (-Real.pi ^ 2 * y + Real.pi ^ 2 + 2 * Real.pi * y ^ 2 -
          2 * Real.pi - 4 * y ^ 2 + 4 * y + 4) := by
      exact mul_nonneg (mul_nonneg (by norm_num) (by linarith)) hF
    dsimp [B]
    nlinarith [hnon]
  have hB : B y ≤ 0 := by linarith
  have hE : 0 ≤
      (1 - y ^ 2 / 2) *
          (1 + ((2 * Real.pi - 4) / Real.pi ^ 2) *
            (Real.pi / 2 - y) ^ 2) - (Real.pi / 2 - y) := by
    have hnum : 0 ≤ -y * B y := by
      calc
        0 ≤ (-B y) * y := mul_nonneg (neg_nonneg.mpr hB) hy0
        _ = -y * B y := by ring
    have hden : 0 < 4 * Real.pi ^ 2 := by positivity
    have hquot : 0 ≤ -y * B y / (4 * Real.pi ^ 2) :=
      div_nonneg hnum hden.le
    have hid :
        (1 - y ^ 2 / 2) *
            (1 + ((2 * Real.pi - 4) / Real.pi ^ 2) *
              (Real.pi / 2 - y) ^ 2) - (Real.pi / 2 - y) =
          -y * B y / (4 * Real.pi ^ 2) := by
      dsimp [B]
      field_simp
      ring
    rw [hid]
    exact hquot
  have hE' := hE
  dsimp [y] at hE'
  simp only [sub_sub_cancel] at hE'
  dsimp [inverseSineEnvelopeConstant]
  nlinarith [hE']

/-- Reciprocal-sine estimate. The source's Euler-product step is replaced by
exact real trigonometric inequalities on the two subintervals of `[0,π/2]`;
no external numerical computation is used. -/
-- zpi: prop-inverse-sine-envelope
theorem sinReciprocalEulerBound (x : ℝ) (hx : 0 < x) (hxhalf : x ≤ Real.pi / 2) :
    x / Real.sin x ≤ 1 + inverseSineEnvelopeConstant / Real.pi ^ 2 * x ^ 2 := by
  have hxpi : x < Real.pi := by
    nlinarith [hxhalf, Real.pi_pos]
  have hsin : 0 < Real.sin x := Real.sin_pos_of_pos_of_lt_pi hx hxpi
  by_cases hx1 : x ≤ 1
  · have hl := inverseSine_small_lower hx hx1
    have ht := inverseSine_small_target hx hx1
    have hC : 0 ≤ 1 + inverseSineEnvelopeConstant / Real.pi ^ 2 * x ^ 2 := by
      have hcoef : 0 ≤ inverseSineEnvelopeConstant / Real.pi ^ 2 := by
        have hC0 : 0 ≤ inverseSineEnvelopeConstant := by
          dsimp [inverseSineEnvelopeConstant]
          nlinarith [Real.pi_gt_three]
        positivity
      positivity
    have hmul := mul_le_mul_of_nonneg_left hl.le hC
    have htotal : x ≤
        (1 + inverseSineEnvelopeConstant / Real.pi ^ 2 * x ^ 2) *
          Real.sin x := by
      exact le_trans ht (by nlinarith [hmul])
    exact (div_le_iff₀ hsin).2 htotal
  · have hx1' : 1 ≤ x := le_of_not_ge hx1
    have ht := inverseSine_large_target hx1' hxhalf
    let y : ℝ := Real.pi / 2 - x
    have hcos : 1 - y ^ 2 / 2 ≤ Real.sin x := by
      calc
        1 - y ^ 2 / 2 ≤ Real.cos y := Real.one_sub_sq_div_two_le_cos
        _ = Real.sin x := by
          dsimp [y]
          rw [← Real.sin_pi_div_two_sub (Real.pi / 2 - x)]
          congr 1 <;> ring
    have hC : 0 ≤ 1 + inverseSineEnvelopeConstant / Real.pi ^ 2 * x ^ 2 := by
      have hC0 : 0 ≤ inverseSineEnvelopeConstant := by
        dsimp [inverseSineEnvelopeConstant]
        nlinarith [Real.pi_gt_three]
      positivity
    have hmul := mul_le_mul_of_nonneg_left hcos hC
    have ht' : x ≤
        (1 + inverseSineEnvelopeConstant / Real.pi ^ 2 * x ^ 2) *
          (1 - y ^ 2 / 2) := by
      simpa [y] using ht
    have htotal : x ≤
        (1 + inverseSineEnvelopeConstant / Real.pi ^ 2 * x ^ 2) *
          Real.sin x := le_trans ht' hmul
    exact (div_le_iff₀ hsin).2 htotal

/-- The strict upper bound uses `sin y < y` and the proved reciprocal-sine
estimate. -/
-- zpi: prop-inverse-sine-envelope
theorem inverseSineKernel_upper (Q d : ℤ) (hQ : 2 ≤ Q) (hd : 1 ≤ d) (hdQ : 2 * d ≤ Q) :
    inverseSineKernel Q d <
      1 / (d : ℝ) + inverseSineEnvelopeConstant * (d : ℝ) / (Q : ℝ) ^ 2 := by
  obtain ⟨hy, _, hx, hxhalf⟩ := kernelAngleBounds Q d hQ hd hdQ
  let y : ℝ := Real.pi / (Q : ℝ)
  let x : ℝ := Real.pi * (d : ℝ) / (Q : ℝ)
  have hQpos : 0 < (Q : ℝ) := by exact_mod_cast (show 0 < Q by omega)
  have hdpos : 0 < (d : ℝ) := by exact_mod_cast (show 0 < d by omega)
  have hxpi : x < Real.pi := lt_of_le_of_lt hxhalf (by linarith [Real.pi_pos])
  have hsinx : 0 < Real.sin x := Real.sin_pos_of_pos_of_lt_pi hx hxpi
  calc
    inverseSineKernel Q d = Real.sin y / Real.sin x := rfl
    _ < y / Real.sin x := (div_lt_div_iff_of_pos_right hsinx).mpr (Real.sin_lt hy)
    _ = 1 / (d : ℝ) * (x / Real.sin x) := by
      dsimp [x, y]
      field_simp
    _ ≤ 1 / (d : ℝ) * (1 + inverseSineEnvelopeConstant / Real.pi ^ 2 * x ^ 2) :=
      mul_le_mul_of_nonneg_left (sinReciprocalEulerBound x hx hxhalf) (by positivity)
    _ = 1 / (d : ℝ) + inverseSineEnvelopeConstant * (d : ℝ) / (Q : ℝ) ^ 2 := by
      dsimp [x]
      field_simp

/-- The rational comparison is borrowed only through the recorded pi bound. -/
-- zpi: prop-inverse-sine-envelope
theorem inverseSineKernel_rationalComparison (Q d : ℤ) (hQ : 2 ≤ Q) (hd : 1 ≤ d) :
    1 / (d : ℝ) + inverseSineEnvelopeConstant * (d : ℝ) / (Q : ℝ) ^ 2 <
      1 / (d : ℝ) + 16 * (d : ℝ) / (7 * (Q : ℝ) ^ 2) := by
  have hQpos : 0 < (Q : ℝ) := by exact_mod_cast (show 0 < Q by omega)
  have hdpos : 0 < (d : ℝ) := by exact_mod_cast (show 0 < d by omega)
  have hC : inverseSineEnvelopeConstant < (16 : ℝ) / 7 := by
    dsimp [inverseSineEnvelopeConstant]
    nlinarith [Real.pi_lt_d4]
  have h := mul_lt_mul_of_pos_right hC (show 0 < (d : ℝ) / (Q : ℝ) ^ 2 by positivity)
  calc
    _ = 1 / (d : ℝ) + inverseSineEnvelopeConstant * ((d : ℝ) / (Q : ℝ) ^ 2) := by ring
    _ < 1 / (d : ℝ) + (16 / 7) * ((d : ℝ) / (Q : ℝ) ^ 2) := add_lt_add_right h _
    _ = _ := by ring

/-- The source proof's boundary sequence converges to `C₀`. The complex
small-angle borrowing is applied on a punctured approach and then projected
to real parts; no value of `sin z / z` at zero is used. -/
-- zpi: prop-inverse-sine-envelope
theorem optimalitySequence_limit :
    Tendsto (fun n : ℕ => 4 * ((n : ℝ) + 1) *
      (Real.sin (Real.pi / (2 * ((n : ℝ) + 1))) - 1 / ((n : ℝ) + 1)))
      atTop (𝓝 inverseSineEnvelopeConstant) := by
  let t : ℕ → ℝ := fun n => Real.pi / (2 * ((n : ℝ) + 1))
  have ht : Tendsto t atTop (𝓝 (0 : ℝ)) := by
    have h := (tendsto_const_div_atTop_nhds_zero_nat (Real.pi / 2)).comp
      (tendsto_add_atTop_nat 1)
    simpa [t, Function.comp_def, Nat.cast_add, Nat.cast_one, div_div] using h
  have htc : Tendsto (fun n => (t n : ℂ)) atTop (𝓝 (0 : ℂ)) := by
    simpa using (Complex.continuous_ofReal.tendsto 0).comp ht
  have ht0 (n : ℕ) : t n ≠ 0 := by dsimp [t]; positivity
  have htWithin : Tendsto (fun n => (t n : ℂ)) atTop (𝓝[≠] (0 : ℂ)) := by
    refine tendsto_nhdsWithin_iff.mpr ⟨htc, .of_forall ?_⟩
    intro n
    simpa using (Complex.ofReal_ne_zero.mpr (ht0 n))
  have hratio := External.NistDlmf.sineSmallAngleLimit.comp htWithin
  have hr : Tendsto (fun n => Real.sin (t n) / t n) atTop (𝓝 (1 : ℝ)) := by
    have h := (Complex.continuous_re.tendsto (1 : ℂ)).comp hratio
    simpa only [Function.comp_def, ← Complex.ofReal_sin, ← Complex.ofReal_div,
      Complex.ofReal_re, Complex.one_re] using h
  have hscaled := (hr.const_mul (2 * Real.pi)).sub_const 4
  simp only [mul_one] at hscaled
  apply hscaled.congr'
  filter_upwards [] with n
  dsimp [t]
  field_simp
  ring

/-- Optimality via `Q = 2d`, `d → ∞`, following the source proof. -/
-- zpi: prop-inverse-sine-envelope
theorem inverseSineEnvelope_optimal (C : ℝ) (hC : IsUniformInverseSineEnvelope C) :
    inverseSineEnvelopeConstant ≤ C := by
  apply le_of_tendsto optimalitySequence_limit
  filter_upwards [] with n
  let d : ℤ := (n : ℤ) + 1
  have hd : 1 ≤ d := by dsimp [d]; omega
  have hD : 0 < (n : ℝ) + 1 := by positivity
  have hb := hC (2 * d) d (by omega) hd (by omega)
  have hangle : Real.pi * (d : ℝ) / ((2 * d : ℤ) : ℝ) = Real.pi / 2 := by
    dsimp [d]
    push_cast
    field_simp
  rw [inverseSineKernel, hangle, Real.sin_pi_div_two, div_one] at hb
  dsimp [d] at hb
  push_cast at hb
  have hm := mul_le_mul_of_nonneg_left hb (show 0 ≤ 4 * ((n : ℝ) + 1) by positivity)
  have hr : 4 * ((n : ℝ) + 1) *
      (1 / ((n : ℝ) + 1) + C * ((n : ℝ) + 1) / (2 * ((n : ℝ) + 1)) ^ 2) = 4 + C := by
    field_simp
    ring
  rw [hr] at hm
  have hi : 4 * ((n : ℝ) + 1) * (1 / ((n : ℝ) + 1)) = 4 := by field_simp
  nlinarith only [hm, hi]

/-- The complete envelope proposition: all three inequalities and optimality.
This is the single package-result theorem in this module. -/
-- zpi: prop-inverse-sine-envelope
theorem inverseSineEnvelope :
    (∀ Q d : ℤ, 2 ≤ Q → 1 ≤ d → 2 * d ≤ Q →
      (1 / (d : ℝ) ≤ inverseSineKernel Q d) ∧
      (inverseSineKernel Q d <
        1 / (d : ℝ) + inverseSineEnvelopeConstant * (d : ℝ) / (Q : ℝ) ^ 2) ∧
      (1 / (d : ℝ) + inverseSineEnvelopeConstant * (d : ℝ) / (Q : ℝ) ^ 2 <
        1 / (d : ℝ) + 16 * (d : ℝ) / (7 * (Q : ℝ) ^ 2))) ∧
    (∀ C : ℝ, IsUniformInverseSineEnvelope C → inverseSineEnvelopeConstant ≤ C) := by
  refine ⟨?_, inverseSineEnvelope_optimal⟩
  intro Q d hQ hd hdQ
  exact ⟨inverseSineKernel_lower Q d hQ hd hdQ, inverseSineKernel_upper Q d hQ hd hdQ,
    inverseSineKernel_rationalComparison Q d hQ hd⟩

end Fraenkel
