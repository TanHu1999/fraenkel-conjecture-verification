import Fraenkel.Cases.MinimumOneFinite

namespace Fraenkel

/-- Subcritical inverse-sine rigidity: the minimum-row data always contain a
row whose inverse-sine mass is deficient. The proof splits at the minimum
representative `s=1`, exactly as in the package proof. -/
-- zpi: thm-subcritical-inverse-sine-rigidity
theorem subcriticalInverseSineRigidity (D : MinimumRowSlackData) :
    ∃ a ∈ D.A, RowDeficient D.Q D.A a := by
  have hspos : 0 < D.s := (D.hA.1 D.s D.hs_mem).1
  by_cases hgt : 1 < D.s
  · exact deficientRowWhenMinimumGreaterThanOne D hgt
  · have hle : D.s ≤ 1 := by omega
    have heq : D.s = 1 := by omega
    exact deficientRowWhenMinimumEqualsOne D heq

end Fraenkel
