import Fraenkel.Analytic.MinimumRow

namespace Fraenkel

open scoped Classical
set_option maxHeartbeats 4000000

/-- Minimum-row data specialized to the subcritical branch `s=1`. -/
-- zpi: def-s-equals-one-subcritical-data
structure SEqualsOneSubcriticalData extends MinimumRowSlackData where
  hs_one : toMinimumRowSlackData.s = 1

/-- The slack `R=Q-∑a` in the `s=1` branch. -/
-- zpi: def-s-equals-one-subcritical-data
def subcriticalR (D : SEqualsOneSubcriticalData) : ℤ :=
  D.toMinimumRowSlackData.Q - ∑ a ∈ D.toMinimumRowSlackData.A, a

/-- The branch's `n=|A|-1`. -/
-- zpi: def-s-equals-one-subcritical-data
def subcriticalN (D : SEqualsOneSubcriticalData) : ℕ :=
  D.toMinimumRowSlackData.A.card - 1

/-- Selected good elements above the anchor. -/
-- zpi: def-s-equals-one-subcritical-data
noncomputable def selectedGoodElements (D : SEqualsOneSubcriticalData) : Finset ℤ :=
  D.toMinimumRowSlackData.A.filter
    (fun a => 1 < a ∧ GoodMinimumRowElement D.toMinimumRowSlackData a)

/-- The least selected good element, when one exists. -/
-- zpi: def-s-equals-one-subcritical-data
noncomputable def leastSelectedGood (D : SEqualsOneSubcriticalData) : Option ℤ :=
  if h : (selectedGoodElements D).Nonempty then
    some (Finset.min' (selectedGoodElements D) h)
  else none

/-- A value is the least selected good element. -/
-- zpi: def-s-equals-one-subcritical-data
def IsLeastSelectedGood (D : SEqualsOneSubcriticalData) (x : ℤ) : Prop :=
  x ∈ selectedGoodElements D ∧ ∀ y ∈ selectedGoodElements D, x ≤ y

/-- The minimum row when `s=1`: slack bounds and existence of a good element. -/
-- zpi: lem-s-equals-one-minimum-row
private theorem probe_sum_arith (n : ℕ) :
    (∑ k ∈ Finset.range (n + 1), ((k : ℝ) + 2)) =
      ((n : ℝ) + 1) * ((n : ℝ) + 4) / 2 := by
  induction n with
  | zero => norm_num
  | succ n ih =>
      rw [Finset.sum_range_succ, ih]
      push_cast
      ring


private theorem probe_sum_lower_bound (S : Finset ℤ) (h2 : ∀ a ∈ S, 2 ≤ a) :
    ((S.card : ℝ) * ((S.card : ℝ) + 3)) / 2 ≤ ∑ a ∈ S, (a : ℝ) := by
  classical
  by_cases hn : S.Nonempty
  · have hncard : S.card ≠ 0 := Finset.card_ne_zero.mpr hn
    obtain ⟨n, hcard⟩ := Nat.exists_eq_succ_of_ne_zero hncard
    let e : Fin (n + 1) ↪o ℤ := S.orderEmbOfFin hcard
    have he_mem (i : Fin (n + 1)) : e i ∈ S := by
      dsimp [e]
      exact Finset.orderEmbOfFin_mem S hcard i
    have he_lower : ∀ i : Fin (n + 1), (i.val : ℝ) + 2 ≤ (e i : ℝ) := by
      intro i
      induction i using Fin.induction with
      | zero =>
          exact_mod_cast h2 (e 0) (he_mem 0)
      | @succ i hi =>
          have hstepZ : e i.castSucc + 1 ≤ e i.succ := by
            have hlt := e.strictMono (Fin.castSucc_lt_succ (i := i))
            omega
          have hstep : (e i.castSucc : ℝ) + 1 ≤ (e i.succ : ℝ) := by
            exact_mod_cast hstepZ
          have hi' : (i.val : ℝ) + 2 ≤ (e i.castSucc : ℝ) := by
            simpa using hi
          have hnext : (i.val : ℝ) + 3 ≤ (e i.succ : ℝ) := by
            nlinarith [hi', hstep]
          norm_num [Fin.val_succ] at ⊢
          nlinarith [hnext]
    have hsum_image : (∑ a ∈ S, (a : ℝ)) =
        ∑ i : Fin (n + 1), (e i : ℝ) := by
      calc
        (∑ a ∈ S, (a : ℝ)) = ∑ a ∈ Finset.image e Finset.univ, (a : ℝ) := by
          rw [Finset.image_orderEmbOfFin_univ S hcard]
        _ = ∑ i ∈ (Finset.univ : Finset (Fin (n + 1))), (e i : ℝ) := by
          rw [Finset.sum_image]
          intro a ha b hb hab
          exact e.injective hab
        _ = ∑ i : Fin (n + 1), (e i : ℝ) := by simp
    have hsum_lower : (∑ i : Fin (n + 1), ((i.val : ℝ) + 2)) ≤
        ∑ i : Fin (n + 1), (e i : ℝ) := by
      exact Finset.sum_le_sum (fun i hi => he_lower i)
    rw [← hsum_image] at hsum_lower
    have hsum_index :
        (∑ i : Fin (n + 1), ((i.val : ℝ) + 2)) =
          ∑ k ∈ Finset.range (n + 1), ((k : ℝ) + 2) := by
      convert (Fin.sum_univ_eq_sum_range (fun k : ℕ => (k : ℝ) + 2) (n + 1)) using 1 <;> simp
    rw [hsum_index, probe_sum_arith n] at hsum_lower
    have hcardR : (S.card : ℝ) = (n + 1 : ℕ) := by
      exact_mod_cast hcard
    rw [hcardR]
    convert hsum_lower using 1 <;> push_cast <;> ring
  · have hzero : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
    simp [hzero]

theorem sEqualsOneMinimumRow (D : SEqualsOneSubcriticalData)
    (hpass : RowPasses D.toMinimumRowSlackData.Q
      D.toMinimumRowSlackData.A D.toMinimumRowSlackData.s) :
    (subcriticalR D : ℝ) < 8 * (subcriticalN D : ℝ) / 7 ∧
      (badMinimumRowSum D.toMinimumRowSlackData : ℝ) <
        16 * (subcriticalN D : ℝ) / 7 ∧
      ((∀ a ∈ D.toMinimumRowSlackData.A,
          RowPasses D.toMinimumRowSlackData.Q
            D.toMinimumRowSlackData.A a) →
        ∃ a ∈ D.toMinimumRowSlackData.A,
          1 < a ∧ GoodMinimumRowElement D.toMinimumRowSlackData a) := by
  classical
  let E : MinimumRowSlackData := D.toMinimumRowSlackData
  let B : Finset ℤ := E.A.erase E.s
  have hs_one : E.s = 1 := D.hs_one
  have hslack := minimumRowSlackIdentity E
  have hpass_slack := passingMinimumRowSlack E hpass
  have hQ : 2 ≤ E.Q := by
    have h := E.hQ
    omega
  have hspos : 0 < E.s := E.hA.1 E.s E.hs_mem |>.1
  have hslt : E.s < E.Q := by nlinarith [E.hA_upper E.s E.hs_mem]
  have hNpos : 0 < minimumRowNComplement E := by
    dsimp [minimumRowNComplement]
    omega
  have hdist_pos (a : ℤ) (ha : a ∈ B) :
      0 < minimumRowDistance E a := by
    have haA := (Finset.mem_erase.mp ha).2
    have hna := hslack.1 a ha
    have hapos := E.hA.1 a haA |>.1
    nlinarith [hNpos, hna, hapos]
  have hEformula :
      (minimumRowNComplement E : ℝ) *
          (1 - (∑ a ∈ B, (1 : ℝ) /
            (minimumRowDistance E a : ℝ))) =
        ((E.Q - (∑ a ∈ E.A, a)) : ℝ) +
          (∑ a ∈ B,
            (minimumRowDelta E a : ℝ) /
              (minimumRowDistance E a : ℝ)) := by
    have hi := hslack.2.1
    have hscale :
        (minimumRowNComplement E : ℝ) *
          (∑ a ∈ B,
            (minimumRowDelta E a : ℝ) /
              ((minimumRowDistance E a : ℝ) *
                (minimumRowNComplement E : ℝ))) =
          ∑ a ∈ B,
            (minimumRowDelta E a : ℝ) /
              (minimumRowDistance E a : ℝ) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro a ha
      have hdR : 0 < (minimumRowDistance E a : ℝ) := by
        exact_mod_cast hdist_pos a ha
      have hNR : 0 < (minimumRowNComplement E : ℝ) := by
        exact_mod_cast hNpos
      field_simp [hdR.ne', hNR.ne']
    dsimp [B]
    rw [hi, mul_add, hscale]
    have hNR : 0 < (minimumRowNComplement E : ℝ) := by
      exact_mod_cast hNpos
    field_simp [hNR.ne']
    simp [B]
  have hdelta_nonneg (a : ℤ) (ha : a ∈ B) :
      0 ≤ (minimumRowDelta E a : ℝ) := by
    have hm := (hslack.2.2.1 a ha).2
    have hm' : (minimumRowDelta E a = 0 ∨
        minimumRowDelta E a = 2 * E.s) ∨ E.Q ≤ minimumRowDelta E a := by
      simpa [Set.mem_union, Set.mem_insert_iff, Set.mem_singleton_iff,
        Set.mem_Ici] using hm
    rcases hm' with hbase | hlarge
    · rcases hbase with hzero | htwo
      · rw [hzero]
        positivity
      · rw [htwo]
        have : (0 : ℝ) ≤ E.s := by exact_mod_cast hspos.le
        positivity
    · have hQR : (0 : ℝ) ≤ E.Q := by exact_mod_cast (show 0 ≤ E.Q by omega)
      have hlargeR : (E.Q : ℝ) ≤ (minimumRowDelta E a : ℝ) := by exact_mod_cast hlarge
      linarith
  have hRle : (subcriticalR D : ℝ) ≤
      (minimumRowNComplement E : ℝ) *
        (1 - (∑ a ∈ B, (1 : ℝ) /
          (minimumRowDistance E a : ℝ))) := by
    have hsum_nonneg : 0 ≤ ∑ a ∈ B,
        (minimumRowDelta E a : ℝ) /
          (minimumRowDistance E a : ℝ) := by
      apply Finset.sum_nonneg
      intro a ha
      have hdR : 0 < (minimumRowDistance E a : ℝ) := by
        exact_mod_cast hdist_pos a ha
      exact div_nonneg (hdelta_nonneg a ha) hdR.le
    have hsubR : subcriticalR D = E.Q - ∑ a ∈ E.A, a := by
      simp [subcriticalR, E, hs_one]
    have hsubRR : (subcriticalR D : ℝ) =
        (E.Q : ℝ) - ∑ a ∈ E.A, (a : ℝ) := by
      calc
        (subcriticalR D : ℝ) =
            ((E.Q - ∑ a ∈ E.A, a : ℤ) : ℝ) := by exact_mod_cast hsubR
        _ = (E.Q : ℝ) - ∑ a ∈ E.A, (a : ℝ) := by
          push_cast
          ring
    calc
      (subcriticalR D : ℝ) = (E.Q : ℝ) - ∑ a ∈ E.A, (a : ℝ) := hsubRR
      _ ≤ (E.Q : ℝ) - ∑ a ∈ E.A, (a : ℝ) +
          ∑ a ∈ B, (minimumRowDelta E a : ℝ) /
            (minimumRowDistance E a : ℝ) := by linarith
      _ = (minimumRowNComplement E : ℝ) *
          (1 - ∑ a ∈ B, (1 : ℝ) /
            (minimumRowDistance E a : ℝ)) := by
            convert hEformula.symm using 1 <;> push_cast <;> rfl
  have hfirst : (subcriticalR D : ℝ) < 8 * (subcriticalN D : ℝ) / 7 := by
    have hn : subcriticalN D = minimumRowN E := by
      rfl
    rw [hn]
    exact lt_of_le_of_lt hRle hpass_slack.1
  have hsecond : (badMinimumRowSum E : ℝ) <
      16 * (subcriticalN D : ℝ) / 7 := by
    have hn : subcriticalN D = minimumRowN E := by rfl
    rw [hn]
    exact hpass_slack.2
  refine ⟨hfirst, hsecond, ?_⟩
  intro hAll
  by_contra hno
  have hbad (a : ℤ) (ha : a ∈ B) : BadMinimumRowElement E a := by
    intro hgood
    apply hno
    refine ⟨a, (Finset.mem_erase.mp ha).2, ?_, hgood⟩
    have hne : a ≠ E.s := (Finset.mem_erase.mp ha).1
    have hmin := E.hs_min a (Finset.mem_erase.mp ha).2
    omega
  have hW_eq : badMinimumRowSum E = ∑ a ∈ B, a := by
    dsimp [badMinimumRowSum, B]
    apply Finset.sum_congr rfl
    intro a ha
    simp [hbad a ha]
  have hBne : B.Nonempty := by
    by_contra hb
    have hBeq : B = ∅ := Finset.not_nonempty_iff_eq_empty.mp hb
    have hsrow := hAll E.s E.hs_mem
    change 1 ≤ inverseSineRowMass E.Q E.A E.s at hsrow
    have hBeq' : E.A.erase E.s = ∅ := by simpa [B] using hBeq
    simp [inverseSineRowMass, hBeq'] at hsrow
    norm_num at hsrow
  have hBcard : B.card = minimumRowN E := by
    dsimp [B, minimumRowN]
    exact Finset.card_erase_of_mem E.hs_mem
  by_cases hn1 : minimumRowN E = 1
  · have hBcard1 : B.card = 1 := hBcard.trans hn1
    obtain ⟨a, haB⟩ := Finset.card_eq_one.mp hBcard1
    have ha : a ∈ B := by rw [haB]; simp
    have haA : a ∈ E.A := (Finset.mem_erase.mp ha).2
    have hamin := E.hs_min a haA
    have hane : a ≠ E.s := (Finset.mem_erase.mp ha).1
    have ha2 : 2 ≤ a := by omega
    have hW := hpass_slack.2
    rw [hW_eq, haB] at hW
    simp at hW
    have hlt3 : a < 3 := by
      have hN1R : (minimumRowN E : ℝ) = 1 := by exact_mod_cast hn1
      rw [hN1R] at hW
      have haR : (a : ℝ) < 16 / 7 := by nlinarith [hW]
      exact_mod_cast (show (a : ℝ) < 3 by nlinarith)
    have ha2eq : a = 2 := by omega
    have hcop : Int.gcd (2 : ℤ) E.Q = 1 := by
      simpa [ha2eq] using E.hA.1 a haA |>.2
    obtain ⟨k, hQeven | hQodd⟩ := Int.even_or_odd' E.Q
    · have hd2 : (2 : ℤ) ∣ E.Q := by
        refine ⟨k, ?_⟩
        exact hQeven
      have hd2self : (2 : ℤ) ∣ (2 : ℤ) := by
        exact ⟨1, by ring⟩
      have hdg : (2 : ℕ) ∣ Int.gcd 2 E.Q :=
        Int.dvd_gcd hd2self hd2
      rw [hcop] at hdg
      omega
    · have hgood : GoodMinimumRowElement E 2 := by
        left
        refine ⟨k, ?_⟩
        rw [hs_one, hQodd]
        omega
      have h2A : (2 : ℤ) ∈ E.A := by simpa [ha2eq] using haA
      apply hno
      refine ⟨2, ?_, by omega, ?_⟩
      · simpa [E] using h2A
      · simpa [E] using hgood
  · have hBcardpos : 0 < B.card := Finset.card_pos.mpr hBne
    have hnpos : 0 < minimumRowN E := by omega
    have hn2 : 2 ≤ minimumRowN E := by omega
    have h2B : ∀ a ∈ B, 2 ≤ a := by
      intro a ha
      have haA := (Finset.mem_erase.mp ha).2
      have hamin := E.hs_min a haA
      have hne := (Finset.mem_erase.mp ha).1
      omega
    have hsumlower := probe_sum_lower_bound B h2B
    have hW := hpass_slack.2
    rw [hW_eq] at hW
    have hsum_cast : ((∑ a ∈ B, a : ℤ) : ℝ) =
        ∑ a ∈ B, (a : ℝ) := by
      rw [Int.cast_sum]
    rw [hsum_cast] at hW
    have hcardR : (B.card : ℝ) = (minimumRowN E : ℝ) := by
      exact_mod_cast hBcard
    have hn2R : (2 : ℝ) ≤ (minimumRowN E : ℝ) := by exact_mod_cast hn2
    rw [hcardR] at hsumlower
    nlinarith [hsumlower, hW, hn2R]


/-- A least selected good element at least three forces the stated finite bound. -/
-- zpi: lem-least-good-element-at-least-three
theorem leastGoodElementAtLeastThree (D : SEqualsOneSubcriticalData)
    (x : ℤ) (hx : IsLeastSelectedGood D x) (hx3 : 3 ≤ x)
    (hAll : ∀ a ∈ D.toMinimumRowSlackData.A,
      RowPasses D.toMinimumRowSlackData.Q D.toMinimumRowSlackData.A a) :
    subcriticalN D ≤ 36 ∧ D.toMinimumRowSlackData.Q ≤ 703 := by
  classical
  let E : MinimumRowSlackData := D.toMinimumRowSlackData
  have hs : E.s = 1 := D.hs_one
  have hQ : 2 ≤ E.Q := by
    have hQ0 := E.hQ
    omega
  have hqpos : 0 < E.Q := by omega
  have hx' :
      (x ∈ E.A ∧ 1 < x ∧ GoodMinimumRowElement E x) ∧
        (∀ y ∈ E.A, 1 < y → GoodMinimumRowElement E y → x ≤ y) := by
    simpa [IsLeastSelectedGood, selectedGoodElements, E] using hx
  have hxA : x ∈ E.A := hx'.1.1
  have hxgt : 1 < x := hx'.1.2.1
  have hxgood : GoodMinimumRowElement E x := hx'.1.2.2
  have hxleast : ∀ y ∈ E.A, 1 < y → GoodMinimumRowElement E y → x ≤ y := hx'.2
  have hpass := hAll E.s E.hs_mem
  have hmain := sEqualsOneMinimumRow D hpass
  have hn : subcriticalN D = minimumRowN E := by rfl
  have hW : (badMinimumRowSum E : ℝ) <
      16 * (minimumRowN E : ℝ) / 7 := by
    simpa [hn] using hmain.2.1
  have hbook := productShellBookkeeping E
  have hshell := hbook.1
  have hrecip := hbook.2.1
  have hsubset := hbook.2.2.1
  have hdiv := hbook.2.2.2.1
  have hspecial := hbook.2.2.2.2
  let R : Finset ℤ := E.A.erase x
  let R0 : Finset ℤ := R.filter (fun b => b ≠ 1)
  let Bad : Finset ℤ := R0.filter (fun b => BadMinimumRowElement E b)
  let Good0 : Finset ℤ := R0.filter (fun b => ¬ BadMinimumRowElement E b)
  let C : Finset ℤ := Good0.filter (fun b => b = x + 1)
  let Far : Finset ℤ := Good0.filter (fun b => b ≠ x + 1)
  have hgood_one : GoodMinimumRowElement E 1 := by
    left
    exact one_dvd _
  have honeA : (1 : ℤ) ∈ E.A := by
    simpa [hs] using E.hs_mem
  have honeR : (1 : ℤ) ∈ R := by
    exact Finset.mem_erase.mpr ⟨by omega, honeA⟩
  have hbad_one : ¬ BadMinimumRowElement E 1 := by
    intro h
    exact h hgood_one
  have hbad_x : ¬ BadMinimumRowElement E x := by
    intro h
    exact h hxgood
  have hsum_nonneg (S : Finset ℤ) (hS : S ⊆ E.A) :
      0 ≤ ∑ b ∈ S, (b : ℝ) := by
    apply Finset.sum_nonneg
    intro b hb
    have hbpos := E.hA.1 b (hS hb) |>.1
    exact_mod_cast hbpos.le
  have hBad_sub : Bad ⊆ E.A.erase x := by
    intro b hb
    exact (Finset.mem_filter.mp (Finset.mem_filter.mp hb).1).1
  have hGood_sub : Good0 ⊆ E.A.erase x := by
    intro b hb
    exact (Finset.mem_filter.mp (Finset.mem_filter.mp hb).1).1
  have hC_sub : C ⊆ E.A.erase x := fun b hb => hGood_sub (Finset.mem_filter.mp hb).1
  have hFar_sub : Far ⊆ E.A.erase x := fun b hb => hGood_sub (Finset.mem_filter.mp hb).1
  have hbad_sum : (badMinimumRowSum E : ℝ) = ∑ b ∈ Bad, (b : ℝ) := by
    have hset : (E.A.erase E.s).filter
        (fun b => BadMinimumRowElement E b) = Bad := by
      ext b
      constructor
      · intro hb
        have hb0 := Finset.mem_filter.mp hb
        have hbA := Finset.mem_erase.mp hb0.1
        have hbne_x : b ≠ x := by
          intro heq
          subst b
          exact hbad_x hb0.2
        have hbne_one : b ≠ 1 := by
          intro heq
          subst b
          exact hbad_one hb0.2
        exact Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr
          ⟨Finset.mem_erase.mpr ⟨hbne_x, hbA.2⟩, hbne_one⟩, hb0.2⟩
      · intro hb
        have hb0 := Finset.mem_filter.mp hb
        have hbR := Finset.mem_filter.mp hb0.1
        have hbA := Finset.mem_erase.mp hbR.1
        have hbne_s : b ≠ E.s := by
          intro heq
          subst b
          have : BadMinimumRowElement E 1 := by simpa [hs] using hb0.2
          exact hbad_one this
        exact Finset.mem_filter.mpr ⟨Finset.mem_erase.mpr ⟨hbne_s, hbA.2⟩, hb0.2⟩
    have hWint : badMinimumRowSum E =
        ∑ b ∈ (E.A.erase E.s).filter
          (fun b => BadMinimumRowElement E b), b := by
      dsimp [badMinimumRowSum]
      rw [Finset.sum_filter]
    rw [hset] at hWint
    rw [hWint, Int.cast_sum]
  have hC_le : ∑ b ∈ C, (b : ℝ) ≤ (x + 1 : ℝ) := by
    by_cases hc : (x + 1 : ℤ) ∈ C
    · have hCe : C = {x + 1} := by
        ext b
        constructor
        · intro hb
          exact Finset.mem_singleton.mpr (Finset.mem_filter.mp hb).2
        · intro hb
          have hb' : b = x + 1 := Finset.mem_singleton.mp hb
          subst b
          exact hc
      rw [hCe]
      simp
    · have hCe : C = ∅ := by
        ext b
        constructor
        · intro hb
          exfalso
          apply hc
          have hb' := Finset.mem_filter.mp hb
          have hgood : x + 1 ∈ Good0 := by simpa [hb'.2] using hb'.1
          exact Finset.mem_filter.mpr ⟨hgood, rfl⟩
        · simp
      rw [hCe]
      simp
      exact_mod_cast (show (0 : ℤ) ≤ x + 1 by omega)
  have hsumA : (∑ b ∈ E.A, (b : ℝ)) ≤ (E.Q : ℝ) := by
    calc
      (∑ b ∈ E.A, (b : ℝ)) = ((∑ b ∈ E.A, b : ℤ) : ℝ) := by
        rw [Int.cast_sum]
      _ ≤ (E.Q : ℝ) := by exact_mod_cast E.hA_sum
  have hsumR : (∑ b ∈ R, (b : ℝ)) + (x : ℝ) =
      ∑ b ∈ E.A, (b : ℝ) := by
    dsimp [R]
    have hh := Finset.sum_erase_add E.A (fun b : ℤ => (b : ℝ)) hxA
    simpa using hh
  have hsum_R0 : (∑ b ∈ R, (b : ℝ)) =
      1 + ∑ b ∈ R0, (b : ℝ) := by
    have hh := (Finset.sum_filter_add_sum_filter_not R
      (fun b : ℤ => b = 1) (fun b => (b : ℝ))).symm
    have hone : (∑ b ∈ R.filter (fun b : ℤ => b = 1), (b : ℝ)) = 1 := by
      have heq : R.filter (fun b : ℤ => b = 1) = {1} := by
        ext b
        constructor
        · intro hb
          exact Finset.mem_singleton.mpr (Finset.mem_filter.mp hb).2
        · intro hb
          have hb1 : b = 1 := Finset.mem_singleton.mp hb
          subst b
          exact Finset.mem_filter.mpr ⟨honeR, rfl⟩
      rw [heq]
      simp
    simpa [R0, hone, add_comm] using hh
  have hsum_BGood : (∑ b ∈ R0, (b : ℝ)) =
      (∑ b ∈ Bad, (b : ℝ)) + ∑ b ∈ Good0, (b : ℝ) := by
    have hh := (Finset.sum_filter_add_sum_filter_not R0
      (fun b : ℤ => BadMinimumRowElement E b) (fun b => (b : ℝ))).symm
    simpa [Bad, Good0, add_comm] using hh
  have hsum_CFar : (∑ b ∈ Good0, (b : ℝ)) =
      (∑ b ∈ C, (b : ℝ)) + ∑ b ∈ Far, (b : ℝ) := by
    have hh := (Finset.sum_filter_add_sum_filter_not Good0
      (fun b : ℤ => b = x + 1) (fun b => (b : ℝ))).symm
    simpa [C, Far, add_comm] using hh
  have hsum_partition : (∑ b ∈ R, (b : ℝ)) =
      1 + ∑ b ∈ Bad, (b : ℝ) + ∑ b ∈ C, (b : ℝ) +
        ∑ b ∈ Far, (b : ℝ) := by
    linarith [hsum_R0, hsum_BGood, hsum_CFar]
  have hFar_le : ∑ b ∈ Far, (b : ℝ) ≤
      (E.Q : ℝ) - x - 1 - (badMinimumRowSum E : ℝ) -
        ∑ b ∈ C, (b : ℝ) := by
    rw [hbad_sum]
    linarith [hsum_partition, hsumR, hsumA]
  have hQmx : 0 < E.Q - x := by
    have hh := E.hA_upper x hxA
    omega
  have h2Qmx : 0 < 2 * E.Q - x := by omega
  have good_of_dvd_x (b : ℤ) (hbx : b ∣ x) : GoodMinimumRowElement E b := by
    rcases hxgood with hminus | hplus
    · exact Or.inl (dvd_trans hbx hminus)
    · exact Or.inr (dvd_trans hbx hplus)
  have hP_bad (b : ℤ) (hb : b ∈ Bad) :
      E.Q - x ≤ productShellValue E x b := by
    have hb0 := Finset.mem_filter.mp hb
    have hbR := Finset.mem_filter.mp hb0.1
    have hbA := Finset.mem_erase.mp hbR.1
    have hne : x ≠ b := Ne.symm hbA.1
    have halt := hshell x hxA b hbA.2 hne
    rcases halt with hfirst | ⟨j, hj, hminus | hplus⟩
    · have hbx := hdiv x hxA b hbA.2 hne hfirst
      exact False.elim ((hb0.2) (good_of_dvd_x b hbx))
    · have hjQ : E.Q ≤ j * E.Q := by
        have hp : 0 ≤ (j - 1) * E.Q := mul_nonneg (by omega) (by omega)
        nlinarith
      nlinarith [hminus, hjQ]
    · have hjQ : E.Q ≤ j * E.Q := by
        have hp : 0 ≤ (j - 1) * E.Q := mul_nonneg (by omega) (by omega)
        nlinarith
      nlinarith [hplus, hjQ]
  have hP_C (b : ℤ) (hb : b ∈ C) :
      E.Q - x ≤ productShellValue E x b := by
    have hb0 := Finset.mem_filter.mp hb
    have hbG := Finset.mem_filter.mp hb0.1
    have hbR := Finset.mem_filter.mp hbG.1
    have hbA := Finset.mem_erase.mp hbR.1
    have hne : x ≠ b := Ne.symm hbA.1
    have hbGood : GoodMinimumRowElement E b := by
      by_contra hbg
      exact hbG.2 hbg
    have halt := hshell x hxA b hbA.2 hne
    rcases halt with hfirst | ⟨j, hj, hminus | hplus⟩
    · have hbx := hdiv x hxA b hbA.2 hne hfirst
      have hbval := hb0.2
      subst b
      rcases hbx with ⟨k, hk⟩
      have hkpos : 0 < k := by
        by_contra hk0
        have hk' : k ≤ 0 := by omega
        have hp : (x + 1) * k ≤ 0 :=
          mul_nonpos_of_nonneg_of_nonpos (by omega) hk'
        nlinarith [hk]
      nlinarith [hk]
    · have hjQ : E.Q ≤ j * E.Q := by
        have hp : 0 ≤ (j - 1) * E.Q := mul_nonneg (by omega) (by omega)
        nlinarith
      nlinarith [hminus, hjQ]
    · have hjQ : E.Q ≤ j * E.Q := by
        have hp : 0 ≤ (j - 1) * E.Q := mul_nonneg (by omega) (by omega)
        nlinarith
      nlinarith [hplus, hjQ]
  have hP_Far (b : ℤ) (hb : b ∈ Far) :
      2 * E.Q - x ≤ productShellValue E x b := by
    have hbG := Finset.mem_filter.mp hb
    have hb0 := Finset.mem_filter.mp hbG.1
    have hbR := Finset.mem_filter.mp hb0.1
    have hbA := Finset.mem_erase.mp hbR.1
    have hne : x ≠ b := Ne.symm hbA.1
    have hbGood : GoodMinimumRowElement E b := by
      by_contra hbg
      exact hb0.2 hbg
    have hbgt1 : 1 < b := by
      have hbmin := E.hs_min b hbA.2
      have hbmin' : 1 ≤ b := by simpa [hs] using hbmin
      omega
    have hxb : x < b := by
      have hleast := hxleast b hbA.2 hbgt1 hbGood
      have hneq : b ≠ x := hbA.1
      omega
    have halt := hshell x hxA b hbA.2 hne
    rcases halt with hfirst | ⟨j, hj, hminus | hplus⟩
    · have hbx := hdiv x hxA b hbA.2 hne hfirst
      rcases hbx with ⟨k, hk⟩
      have hkpos : 0 < k := by
        by_contra hk0
        have hk' : k ≤ 0 := by omega
        have hp : b * k ≤ 0 := mul_nonpos_of_nonneg_of_nonpos (by omega) hk'
        nlinarith [hk]
      nlinarith [hk]
    · have hj2 : 2 ≤ j := by
        by_contra hj2
        have hj1 : j = 1 := by omega
        subst j
        have hsx' := hspecial hs x hxA b hbA.2 hne hbGood
          (Or.inl (by simpa using hminus))
        have hbx1 := hsx'.2 hxgt hxb
        exact (hbG.2 hbx1)
      have hjQ : 2 * E.Q ≤ j * E.Q := by
        have hp : 0 ≤ (j - 2) * E.Q := mul_nonneg (by omega) (by omega)
        nlinarith
      nlinarith [hminus, hjQ]
    · have hj2 : 2 ≤ j := by
        by_contra hj2
        have hj1 : j = 1 := by omega
        subst j
        have hsx' := hspecial hs x hxA b hbA.2 hne hbGood
          (Or.inr (by simpa using hplus))
        have hbx1 := hsx'.2 hxgt hxb
        exact (hbG.2 hbx1)
      have hjQ : 2 * E.Q ≤ j * E.Q := by
        have hp : 0 ≤ (j - 2) * E.Q := mul_nonneg (by omega) (by omega)
        nlinarith
      nlinarith [hplus, hjQ]
  have hBad_nonneg : 0 ≤ ∑ b ∈ Bad, (b : ℝ) :=
    hsum_nonneg Bad (fun b hb => (Finset.mem_erase.mp (hBad_sub hb)).2)
  have hC_nonneg : 0 ≤ ∑ b ∈ C, (b : ℝ) :=
    hsum_nonneg C (fun b hb => (Finset.mem_erase.mp (hC_sub hb)).2)
  have hFar_nonneg : 0 ≤ ∑ b ∈ Far, (b : ℝ) :=
    hsum_nonneg Far (fun b hb => (Finset.mem_erase.mp (hFar_sub hb)).2)
  have hQmxR : 0 < (E.Q : ℝ) - x := by exact_mod_cast hQmx
  have h2QmxR : (0 : ℝ) < ((2 * E.Q - x : ℤ) : ℝ) := by
    exact_mod_cast h2Qmx
  have hBad_recip :
      (∑ b ∈ Bad, (1 : ℝ) / (productShellDistance E x b : ℝ)) ≤
        (∑ b ∈ Bad, (b : ℝ)) / ((E.Q : ℝ) - x) := by
    refine hsubset x hxA Bad hBad_sub _ _ hBad_nonneg hQmxR le_rfl ?_
    intro b hb
    exact_mod_cast hP_bad b hb
  have hC_recip :
      (∑ b ∈ C, (1 : ℝ) / (productShellDistance E x b : ℝ)) ≤
        (∑ b ∈ C, (b : ℝ)) / ((E.Q : ℝ) - x) := by
    refine hsubset x hxA C hC_sub _ _ hC_nonneg hQmxR le_rfl ?_
    intro b hb
    exact_mod_cast hP_C b hb
  have hFar_recip :
      (∑ b ∈ Far, (1 : ℝ) / (productShellDistance E x b : ℝ)) ≤
        (∑ b ∈ Far, (b : ℝ)) / ((2 * E.Q - x : ℤ) : ℝ) := by
    refine hsubset x hxA Far hFar_sub _ _ hFar_nonneg h2QmxR le_rfl ?_
    intro b hb
    exact_mod_cast hP_Far b hb
  let f : ℤ → ℝ := fun b =>
    (1 : ℝ) / (productShellDistance E x b : ℝ)
  have hsum1f : (∑ b ∈ R, f b) =
      (∑ b ∈ R.filter (fun b : ℤ => b = 1), f b) +
        ∑ b ∈ R0, f b := by
    have hh := (Finset.sum_filter_add_sum_filter_not R
      (fun b : ℤ => b = 1) f).symm
    simpa [R0] using hh
  have hsum2f : (∑ b ∈ R0, f b) =
      (∑ b ∈ Bad, f b) + ∑ b ∈ Good0, f b := by
    have hh := (Finset.sum_filter_add_sum_filter_not R0
      (fun b : ℤ => BadMinimumRowElement E b) f).symm
    simpa [Bad, Good0] using hh
  have hsum3f : (∑ b ∈ Good0, f b) =
      (∑ b ∈ C, f b) + ∑ b ∈ Far, f b := by
    have hh := (Finset.sum_filter_add_sum_filter_not Good0
      (fun b : ℤ => b = x + 1) f).symm
    simpa [C, Far] using hh
  have hinv_one : inverseMod E.Q 1 = 1 := by
    have hi := inverseMod_spec E.Q 1 hQ (Int.gcd_one_left E.Q)
    have hres : inverseMod E.Q 1 % E.Q = 1 := by simpa using hi.2
    have hmod := Int.emod_eq_of_lt (by omega : 0 ≤ inverseMod E.Q 1) hi.1.2
    omega
  have hxnonneg : 0 ≤ x := by
    exact (E.hA.1 x hxA).1.le
  have hxltQ : x < E.Q := by
    have hh := E.hA_upper x hxA
    omega
  have hxres : x % E.Q = x := Int.emod_eq_of_lt hxnonneg hxltQ
  have hdist_one : productShellDistance E x 1 = x := by
    dsimp [productShellDistance, cyclicDistance]
    rw [hinv_one]
    have hmin : min x (E.Q - x) = x := by
      rw [min_eq_left]
      have hh := E.hA_upper x hxA
      omega
    simp only [mul_one]
    rw [hxres]
    exact hmin
  have hRone : R.filter (fun b : ℤ => b = 1) = {1} := by
    ext b
    constructor
    · intro hb
      exact Finset.mem_singleton.mpr (Finset.mem_filter.mp hb).2
    · intro hb
      have hb1 : b = 1 := Finset.mem_singleton.mp hb
      subst b
      exact Finset.mem_filter.mpr ⟨honeR, rfl⟩
  have honef : (∑ b ∈ R.filter (fun b : ℤ => b = 1), f b) =
      1 / (x : ℝ) := by
    rw [hRone]
    simp [f, hdist_one]
  have hHsplit : productShellRow E x =
      1 / (x : ℝ) + (∑ b ∈ Bad, f b) +
        (∑ b ∈ C, f b) + ∑ b ∈ Far, f b := by
    dsimp [productShellRow]
    linarith [hsum1f, hsum2f, hsum3f, honef]
  have hHupper : productShellRow E x ≤
      1 / (x : ℝ) +
        (∑ b ∈ Bad, (b : ℝ)) / ((E.Q : ℝ) - x) +
        (∑ b ∈ C, (b : ℝ)) / ((E.Q : ℝ) - x) +
        (∑ b ∈ Far, (b : ℝ)) / ((2 * E.Q - x : ℤ) : ℝ) := by
    rw [hHsplit]
    dsimp [f] at hBad_recip hC_recip hFar_recip ⊢
    linarith
  have hHshell : productShellRow E x ≤
      1 / (x : ℝ) +
        ((E.Q : ℝ) - x - 1 - (badMinimumRowSum E : ℝ) -
          ∑ b ∈ C, (b : ℝ)) / ((2 * E.Q - x : ℤ) : ℝ) +
        ((badMinimumRowSum E : ℝ) + ∑ b ∈ C, (b : ℝ)) /
          ((E.Q : ℝ) - x) := by
    have hfar_div := div_le_div_of_nonneg_right hFar_le (le_of_lt h2QmxR)
    rw [← hbad_sum] at hHupper
    have htemp : productShellRow E x ≤
        1 / (x : ℝ) + (badMinimumRowSum E : ℝ) / ((E.Q : ℝ) - x) +
          (∑ b ∈ C, (b : ℝ)) / ((E.Q : ℝ) - x) +
          ((E.Q : ℝ) - x - 1 - (badMinimumRowSum E : ℝ) -
            ∑ b ∈ C, (b : ℝ)) / ((2 * E.Q - x : ℤ) : ℝ) := by
      linarith [hHupper, hfar_div]
    calc
      productShellRow E x ≤
          1 / (x : ℝ) + (badMinimumRowSum E : ℝ) / ((E.Q : ℝ) - x) +
            (∑ b ∈ C, (b : ℝ)) / ((E.Q : ℝ) - x) +
            ((E.Q : ℝ) - x - 1 - (badMinimumRowSum E : ℝ) -
              ∑ b ∈ C, (b : ℝ)) / ((2 * E.Q - x : ℤ) : ℝ) := htemp
      _ = 1 / (x : ℝ) +
          ((E.Q : ℝ) - x - 1 - (badMinimumRowSum E : ℝ) -
            ∑ b ∈ C, (b : ℝ)) / ((2 * E.Q - x : ℤ) : ℝ) +
          ((badMinimumRowSum E : ℝ) + ∑ b ∈ C, (b : ℝ)) /
            ((E.Q : ℝ) - x) := by ring
  have hL : (badMinimumRowSum E : ℝ) + ∑ b ∈ C, (b : ℝ) ≤
      (badMinimumRowSum E : ℝ) + x + 1 := by
    linarith [hC_le]
  have hcoef : 0 < (1 : ℝ) / ((E.Q : ℝ) - x) -
      1 / ((2 * E.Q - x : ℤ) : ℝ) := by
    have hlt : (E.Q : ℝ) - x < ((2 * E.Q - x : ℤ) : ℝ) := by
      exact_mod_cast (show E.Q - x < 2 * E.Q - x by omega)
    have hh := one_div_lt_one_div_of_lt hQmxR hlt
    linarith
  have hden_cast : ((2 * E.Q - x : ℤ) : ℝ) =
      2 * (E.Q : ℝ) - x := by
    push_cast
    rfl
  have hHpromote : productShellRow E x ≤
      1 / (x : ℝ) +
        ((E.Q : ℝ) - 2 * x - 2 - (badMinimumRowSum E : ℝ)) /
          ((2 * E.Q - x : ℤ) : ℝ) +
        ((badMinimumRowSum E : ℝ) + x + 1) /
          ((E.Q : ℝ) - x) := by
    calc
      productShellRow E x ≤
          1 / (x : ℝ) +
            ((E.Q : ℝ) - x - 1 - (badMinimumRowSum E : ℝ) -
              ∑ b ∈ C, (b : ℝ)) / ((2 * E.Q - x : ℤ) : ℝ) +
            ((badMinimumRowSum E : ℝ) + ∑ b ∈ C, (b : ℝ)) /
              ((E.Q : ℝ) - x) := hHshell
      _ = 1 / (x : ℝ) + ((E.Q : ℝ) - x - 1) /
          ((2 * E.Q - x : ℤ) : ℝ) +
          ((badMinimumRowSum E : ℝ) + ∑ b ∈ C, (b : ℝ)) *
            (1 / ((E.Q : ℝ) - x) -
              1 / ((2 * E.Q - x : ℤ) : ℝ)) := by
        rw [hden_cast]
        ring
      _ ≤ 1 / (x : ℝ) + ((E.Q : ℝ) - x - 1) /
          ((2 * E.Q - x : ℤ) : ℝ) +
          ((badMinimumRowSum E : ℝ) + x + 1) *
            (1 / ((E.Q : ℝ) - x) -
              1 / ((2 * E.Q - x : ℤ) : ℝ)) := by
            have hmul := mul_le_mul_of_nonneg_right hL (le_of_lt hcoef)
            linarith
      _ = 1 / (x : ℝ) + ((E.Q : ℝ) - 2 * x - 2 -
          (badMinimumRowSum E : ℝ)) /
          ((2 * E.Q - x : ℤ) : ℝ) +
          ((badMinimumRowSum E : ℝ) + x + 1) /
            ((E.Q : ℝ) - x) := by
        rw [hden_cast]
        ring_nf
  have hHpromote2 : productShellRow E x ≤
      (1 / (x : ℝ) + ((E.Q : ℝ) - 2 * x - 2) /
          ((2 * E.Q - x : ℤ) : ℝ) + (x + 1) /
            ((E.Q : ℝ) - x)) +
        (badMinimumRowSum E : ℝ) *
          (1 / ((E.Q : ℝ) - x) -
            1 / ((2 * E.Q - x : ℤ) : ℝ)) := by
    calc
      productShellRow E x ≤
          1 / (x : ℝ) + ((E.Q : ℝ) - 2 * x - 2 -
            (badMinimumRowSum E : ℝ)) /
            ((2 * E.Q - x : ℤ) : ℝ) +
          ((badMinimumRowSum E : ℝ) + x + 1) /
            ((E.Q : ℝ) - x) := hHpromote
      _ = (1 / (x : ℝ) + ((E.Q : ℝ) - 2 * x - 2) /
          ((2 * E.Q - x : ℤ) : ℝ) + (x + 1) /
            ((E.Q : ℝ) - x)) +
        (badMinimumRowSum E : ℝ) *
          (1 / ((E.Q : ℝ) - x) -
            1 / ((2 * E.Q - x : ℤ) : ℝ)) := by
        rw [hden_cast]
        ring_nf
  have hB : 1 / (x : ℝ) + ((E.Q : ℝ) - 2 * x - 2) /
      ((2 * E.Q - x : ℤ) : ℝ) + (x + 1) /
        ((E.Q : ℝ) - x) ≤ (5 : ℝ) / 6 + 2 / (E.Q : ℝ) := by
    rw [hden_cast]
    have hxR : (3 : ℝ) ≤ x := by exact_mod_cast hx3
    have hQ3 : 3 * (x : ℝ) < (E.Q : ℝ) := by
      exact_mod_cast E.hA_upper x hxA
    have hxpos : 0 < (x : ℝ) := by linarith
    have hqpos : 0 < (E.Q : ℝ) := by exact_mod_cast hqpos
    have ha : 0 < (E.Q : ℝ) - x := hQmxR
    have hb : 0 < 2 * (E.Q : ℝ) - x := by
      exact_mod_cast h2Qmx
    let t : ℝ := (E.Q : ℝ) - 3 * x
    have ht : 0 < t := by dsimp [t]; linarith
    have htZ : 1 ≤ E.Q - 3 * x := by
      have hh := E.hA_upper x hxA
      omega
    have ht1 : 1 ≤ t := by
      dsimp [t]
      exact_mod_cast htZ
    have hax : 0 < 2 * x + t := by linarith
    have hbx : 0 < 5 * x + 2 * t := by linarith
    have hax' : 0 < x * 2 + t := by linarith
    have hbx' : 0 < x * 5 + t * 2 := by linarith
    have hrawq : 0 < 3 * x + t := by linarith
    have hrawa : 0 < 3 * x + t - x := by linarith
    have hrawb : 0 < 2 * (3 * x + t) - x := by
      dsimp [t]
      nlinarith [h2Qmx]
    have hqeq : (E.Q : ℝ) = 3 * x + t := by
      dsimp [t]
      ring
    have hid : 6 * (E.Q : ℝ) * x * ((E.Q : ℝ) - x) *
          (2 * (E.Q : ℝ) - x) *
          ((5 : ℝ) / 6 + 2 / (E.Q : ℝ) -
            (1 / x + ((E.Q : ℝ) - 2 * x - 2) /
              (2 * (E.Q : ℝ) - x) + (x + 1) /
                ((E.Q : ℝ) - x))) =
        x ^ 3 * (24 * x - 78) + t * x ^ 2 * (53 * x - 120) +
          t ^ 2 * x * (27 * x - 66) + t ^ 3 * (4 * x - 12) := by
      rw [hqeq]
      ring_nf
      field_simp [ne_of_gt hxpos, ne_of_gt hqpos, ne_of_gt ha, ne_of_gt hb,
        ne_of_gt hax, ne_of_gt hbx, ne_of_gt hax', ne_of_gt hbx']
      ring
    have hpoly : 0 ≤ x ^ 3 * (24 * x - 78) +
          t * x ^ 2 * (53 * x - 120) +
          t ^ 2 * x * (27 * x - 66) + t ^ 3 * (4 * x - 12) := by
      have hxcase : x = 3 ∨ (4 : ℝ) ≤ x := by
        have hxcaseZ : x = 3 ∨ 4 ≤ x := by omega
        rcases hxcaseZ with h3 | h4
        · left; exact_mod_cast h3
        · right; exact_mod_cast h4
      rcases hxcase with hx3R | hx4R
      · rw [hx3R]
        norm_num at ⊢
        nlinarith [ht1]
      · have hc1 : (0 : ℝ) ≤ 24 * (x : ℝ) - 78 := by linarith
        have hc2 : (0 : ℝ) ≤ 53 * (x : ℝ) - 120 := by linarith
        have hc3 : (0 : ℝ) ≤ 27 * (x : ℝ) - 66 := by linarith
        have hc4 : (0 : ℝ) ≤ 4 * (x : ℝ) - 12 := by linarith
        have h1 : 0 ≤ (x : ℝ) ^ 3 * (24 * (x : ℝ) - 78) :=
          mul_nonneg (by positivity) hc1
        have h2 : 0 ≤ t * (x : ℝ) ^ 2 * (53 * (x : ℝ) - 120) :=
          mul_nonneg (mul_nonneg (le_of_lt ht) (by positivity)) hc2
        have h3 : 0 ≤ t ^ 2 * (x : ℝ) * (27 * (x : ℝ) - 66) :=
          mul_nonneg (mul_nonneg (sq_nonneg t) (by positivity)) hc3
        have ht3 : 0 ≤ t ^ 3 := by positivity
        have h4 : 0 ≤ t ^ 3 * (4 * (x : ℝ) - 12) := mul_nonneg ht3 hc4
        linarith
    have hprod : 0 < 6 * (E.Q : ℝ) * x * ((E.Q : ℝ) - x) *
        (2 * (E.Q : ℝ) - x) := by positivity
    have hdiff : 0 ≤ (5 : ℝ) / 6 + 2 / (E.Q : ℝ) -
          (1 / x + ((E.Q : ℝ) - 2 * x - 2) /
            (2 * (E.Q : ℝ) - x) + (x + 1) /
              ((E.Q : ℝ) - x)) := by
      nlinarith [hid, hpoly]
    linarith
  have hdist_bounds (b : ℤ) (hb : b ∈ R) :
      1 ≤ productShellDistance E x b ∧
        2 * productShellDistance E x b ≤ E.Q := by
    have hbR := Finset.mem_erase.mp hb
    have hbA : b ∈ E.A := hbR.2
    have hbU := E.hA.1 b hbA
    have hxU := E.hA.1 x hxA
    have hsinv : (x * inverseMod E.Q b) % E.Q ≠ 0 := by
      intro hz
      have hinv := inverseMod_spec E.Q b hQ hbU.2
      have hzero : x * inverseMod E.Q b ≡ 0 [ZMOD E.Q] := by
        simpa [Int.ModEq] using hz
      have hprod : (x * inverseMod E.Q b) * b ≡ 0 * b [ZMOD E.Q] :=
        hzero.mul_right b
      have h1mod : (1 : ℤ) % E.Q = 1 :=
        Int.emod_eq_of_lt (by omega) (by omega)
      have hone : b * inverseMod E.Q b ≡ 1 [ZMOD E.Q] := by
        simpa [Int.ModEq, h1mod] using hinv.2
      have hcalc : (x * inverseMod E.Q b) * b ≡ x [ZMOD E.Q] := by
        calc
          (x * inverseMod E.Q b) * b = x * (b * inverseMod E.Q b) := by ring
          _ ≡ x * 1 [ZMOD E.Q] := hone.mul_left x
          _ = x := by ring
      have hxmod : x % E.Q = 0 := by
        have hh : (x * inverseMod E.Q b) * b % E.Q = 0 :=
          hprod.eq.trans (by simp)
        rw [hcalc.eq] at hh
        exact hh
      have hxrem : x % E.Q = x := by
        have hxnonneg' := E.hA.1 x hxA |>.1
        have hxlt' := E.hA_upper x hxA
        exact Int.emod_eq_of_lt (by omega) (by omega)
      omega
    have hd := cyclicDistance_bounds E.Q (x * inverseMod E.Q b) hQ hsinv
    simpa [productShellDistance] using hd
  have hCconst : inverseSineEnvelopeConstant < (16 : ℝ) / 7 := by
    dsimp [inverseSineEnvelopeConstant]
    nlinarith [Real.pi_lt_d4]
  have hKernelUpper (b : ℤ) (hb : b ∈ R) :
      inverseSineKernel E.Q (productShellDistance E x b) <
        1 / (productShellDistance E x b : ℝ) +
          (16 : ℝ) / 7 * (productShellDistance E x b : ℝ) /
            (E.Q : ℝ) ^ 2 := by
    have hd := hdist_bounds b hb
    have hh := inverseSineKernel_upper E.Q
      (productShellDistance E x b) hQ hd.1 hd.2
    have hdRZ : 0 ≤ productShellDistance E x b := by omega
    have hdR : 0 ≤ (productShellDistance E x b : ℝ) := by
      exact_mod_cast hdRZ
    have hdRpos : 0 < (productShellDistance E x b : ℝ) := by
      exact_mod_cast (show 0 < productShellDistance E x b by omega)
    have hq2 : 0 < (E.Q : ℝ) ^ 2 := by positivity
    have hnonneg : 0 ≤ (productShellDistance E x b : ℝ) /
        (E.Q : ℝ) ^ 2 := div_nonneg hdR (le_of_lt hq2)
    calc
      inverseSineKernel E.Q (productShellDistance E x b) <
          1 / (productShellDistance E x b : ℝ) +
            inverseSineEnvelopeConstant *
              (productShellDistance E x b : ℝ) / (E.Q : ℝ) ^ 2 := hh
      _ < 1 / (productShellDistance E x b : ℝ) +
          (16 : ℝ) / 7 * (productShellDistance E x b : ℝ) /
            (E.Q : ℝ) ^ 2 := by
        have hmul := mul_lt_mul_of_pos_right hCconst
          (div_pos hdRpos hq2)
        have hmul' :
            inverseSineEnvelopeConstant *
                (productShellDistance E x b : ℝ) / (E.Q : ℝ) ^ 2 <
              (16 : ℝ) / 7 * (productShellDistance E x b : ℝ) /
                (E.Q : ℝ) ^ 2 := by
          convert hmul using 1 <;> ring
        convert add_lt_add_left hmul' (1 / (productShellDistance E x b : ℝ)) using 1 <;> ring
  have hRnonempty : R.Nonempty := ⟨1, honeR⟩
  have hsum_kernel :
      (∑ b ∈ R, inverseSineKernel E.Q (productShellDistance E x b)) <
        ∑ b ∈ R,
          (1 / (productShellDistance E x b : ℝ) +
            (16 : ℝ) / 7 * (productShellDistance E x b : ℝ) /
              (E.Q : ℝ) ^ 2) := by
    apply Finset.sum_lt_sum_of_nonempty hRnonempty
    intro b hb
    exact hKernelUpper b hb
  have hMupper : inverseSineRowMass E.Q E.A x <
      productShellRow E x + (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
        ∑ b ∈ R, (productShellDistance E x b : ℝ) := by
    have hspec := inverseSineRowMass_spec E.Q E.A x hQ E.hA hxA
    dsimp [productShellRow, R]
    rw [hspec]
    have hsum' :
        (∑ b ∈ E.A.erase x,
          inverseSineKernel E.Q (cyclicDistance E.Q
            (x * inverseMod E.Q b))) <
          ∑ b ∈ E.A.erase x,
            (1 / (productShellDistance E x b : ℝ) +
              (16 : ℝ) / 7 * (productShellDistance E x b : ℝ) /
                (E.Q : ℝ) ^ 2) := by
      simpa [productShellDistance] using hsum_kernel
    have hcalc :
        (∑ b ∈ E.A.erase x,
          (16 : ℝ) / 7 * (productShellDistance E x b : ℝ) /
            (E.Q : ℝ) ^ 2) =
          (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
            ∑ b ∈ E.A.erase x, (productShellDistance E x b : ℝ) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro b hb
      ring
    calc
      (∑ b ∈ E.A.erase x,
          inverseSineKernel E.Q (cyclicDistance E.Q
            (x * inverseMod E.Q b))) <
          ∑ b ∈ E.A.erase x,
            (1 / (productShellDistance E x b : ℝ) +
              (16 : ℝ) / 7 * (productShellDistance E x b : ℝ) /
                (E.Q : ℝ) ^ 2) := hsum'
      _ = (∑ b ∈ E.A.erase x,
          1 / (productShellDistance E x b : ℝ)) +
          (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
            ∑ b ∈ E.A.erase x, (productShellDistance E x b : ℝ) := by
        rw [Finset.sum_add_distrib, hcalc]
  have hcardR : R.card = minimumRowN E := by
    dsimp [R, minimumRowN]
    exact Finset.card_erase_of_mem hxA
  have hcardRN : (R.card : ℝ) = (subcriticalN D : ℝ) := by
    rw [hcardR, hn]
  have hdist_sum :
      ∑ b ∈ R, (productShellDistance E x b : ℝ) ≤
        (subcriticalN D : ℝ) * (E.Q : ℝ) / 2 := by
    have hterm : ∀ b ∈ R,
        (productShellDistance E x b : ℝ) ≤ (E.Q : ℝ) / 2 := by
      intro b hb
      have hd := hdist_bounds b hb
      have hh : (2 : ℝ) * (productShellDistance E x b : ℝ) ≤
          (E.Q : ℝ) := by exact_mod_cast hd.2
      nlinarith
    have hsum := Finset.sum_le_sum (fun b hb => hterm b hb)
    calc
      (∑ b ∈ R, (productShellDistance E x b : ℝ)) ≤
          ∑ b ∈ R, (E.Q : ℝ) / 2 := hsum
      _ = (R.card : ℝ) * (E.Q : ℝ) / 2 := by simp; ring
      _ = (subcriticalN D : ℝ) * (E.Q : ℝ) / 2 := by rw [hcardRN]
  have hrem : inverseSineRowMass E.Q E.A x <
      productShellRow E x + 8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)) := by
    have hfac : 0 ≤ (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 := by positivity
    have hmul := mul_le_mul_of_nonneg_left hdist_sum hfac
    have hqne : (E.Q : ℝ) ≠ 0 := ne_of_gt (by exact_mod_cast hqpos)
    have heq : (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
          ((subcriticalN D : ℝ) * (E.Q : ℝ) / 2) =
        8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)) := by
      field_simp [hqne]
      ring
    calc
      inverseSineRowMass E.Q E.A x <
          productShellRow E x + (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
            ∑ b ∈ R, (productShellDistance E x b : ℝ) := hMupper
      _ ≤ productShellRow E x + (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
          ((subcriticalN D : ℝ) * (E.Q : ℝ) / 2) := by linarith
      _ = productShellRow E x + 8 * (subcriticalN D : ℝ) /
          (7 * (E.Q : ℝ)) := by rw [heq]
  have hQ3 : 3 * x < E.Q := E.hA_upper x hxA
  have h2QmxR' : 0 < 2 * (E.Q : ℝ) - (x : ℝ) := by
    rw [← hden_cast]
    exact h2QmxR
  have hcoef_eq :
      1 / ((E.Q : ℝ) - (x : ℝ)) -
          1 / (2 * (E.Q : ℝ) - (x : ℝ)) =
        (E.Q : ℝ) /
          (((E.Q : ℝ) - (x : ℝ)) * (2 * (E.Q : ℝ) - (x : ℝ))) := by
    have h2QmxR'' : 0 < (E.Q : ℝ) * 2 - (x : ℝ) := by
      nlinarith [h2QmxR']
    field_simp [ne_of_gt hQmxR, ne_of_gt h2QmxR'']
    ring
  have hq3R : 0 < (E.Q : ℝ) - 3 * (x : ℝ) := by
    exact_mod_cast (show 0 < E.Q - 3 * x by omega)
  have hq8R : 0 < 8 * (E.Q : ℝ) - 3 * (x : ℝ) := by
    nlinarith [hq3R, hqpos]
  have hpolycoef : 0 < ((E.Q : ℝ) - 3 * (x : ℝ)) *
      (8 * (E.Q : ℝ) - 3 * (x : ℝ)) := mul_pos hq3R hq8R
  have hcross : 10 * (E.Q : ℝ) ^ 2 <
      9 * ((E.Q : ℝ) - (x : ℝ)) * (2 * (E.Q : ℝ) - (x : ℝ)) := by
    nlinarith only [hpolycoef]
  have hdenpos : 0 < ((E.Q : ℝ) - (x : ℝ)) *
      (2 * (E.Q : ℝ) - (x : ℝ)) := mul_pos hQmxR h2QmxR'
  have htenpos : 0 < 10 * (E.Q : ℝ) := by positivity
  have hcross' : (E.Q : ℝ) * (10 * (E.Q : ℝ)) <
      9 * ((E.Q : ℝ) - (x : ℝ)) * (2 * (E.Q : ℝ) - (x : ℝ)) := by
    nlinarith only [hcross]
  have hfracQ : (E.Q : ℝ) <
      (9 * ((E.Q : ℝ) - (x : ℝ)) * (2 * (E.Q : ℝ) - (x : ℝ))) /
        (10 * (E.Q : ℝ)) := (lt_div_iff₀ htenpos).2 hcross'
  have hcoefQ :
      (E.Q : ℝ) /
          (((E.Q : ℝ) - (x : ℝ)) * (2 * (E.Q : ℝ) - (x : ℝ))) <
        (9 : ℝ) / (10 * (E.Q : ℝ)) := by
    apply (div_lt_iff₀ hdenpos).2
    calc
      (E.Q : ℝ) <
          (9 * ((E.Q : ℝ) - (x : ℝ)) * (2 * (E.Q : ℝ) - (x : ℝ))) /
            (10 * (E.Q : ℝ)) := hfracQ
      _ = (9 / (10 * (E.Q : ℝ))) *
          (((E.Q : ℝ) - (x : ℝ)) * (2 * (E.Q : ℝ) - (x : ℝ))) := by ring
  have hWnonneg : 0 ≤ (badMinimumRowSum E : ℝ) := by
    rw [hbad_sum]
    exact hBad_nonneg
  have hcoefpos : 0 <
      1 / ((E.Q : ℝ) - (x : ℝ)) -
        1 / (2 * (E.Q : ℝ) - (x : ℝ)) := by
    rw [hcoef_eq]
    exact div_pos (by exact_mod_cast hqpos) hdenpos
  have hW' : (badMinimumRowSum E : ℝ) <
      16 * (subcriticalN D : ℝ) / 7 := by
    simpa [hn] using hW
  have hmul1 := mul_lt_mul_of_pos_right hW' hcoefpos
  have hcardRNat : R.card = subcriticalN D := by
    rw [hcardR, ← hn]
  have hNpos : 0 < subcriticalN D := by
    rw [← hcardRNat]
    exact Finset.card_pos.mpr hRnonempty
  have hNposR : 0 < (subcriticalN D : ℝ) := by exact_mod_cast hNpos
  have hfactorpos : 0 < 16 * (subcriticalN D : ℝ) / 7 := by positivity
  have hmul2 := mul_lt_mul_of_pos_left hcoefQ hfactorpos
  have hcoefQ' :
      (E.Q : ℝ) /
          (((E.Q : ℝ) - (x : ℝ)) * (2 * (E.Q : ℝ) - (x : ℝ))) =
        1 / ((E.Q : ℝ) - (x : ℝ)) -
          1 / (2 * (E.Q : ℝ) - (x : ℝ)) := hcoef_eq.symm
  rw [hcoefQ'] at hmul2
  have hWcoef :
      (badMinimumRowSum E : ℝ) *
          (1 / ((E.Q : ℝ) - (x : ℝ)) -
            1 / (2 * (E.Q : ℝ) - (x : ℝ))) <
        72 * (subcriticalN D : ℝ) / (35 * (E.Q : ℝ)) := by
    calc
      (badMinimumRowSum E : ℝ) *
          (1 / ((E.Q : ℝ) - (x : ℝ)) -
            1 / (2 * (E.Q : ℝ) - (x : ℝ))) <
          (16 * (subcriticalN D : ℝ) / 7) *
            (1 / ((E.Q : ℝ) - (x : ℝ)) -
              1 / (2 * (E.Q : ℝ) - (x : ℝ))) := hmul1
      _ < (16 * (subcriticalN D : ℝ) / 7) *
          (9 / (10 * (E.Q : ℝ))) := hmul2
      _ = 72 * (subcriticalN D : ℝ) / (35 * (E.Q : ℝ)) := by ring
  have hHbound :
      productShellRow E x + 8 * (subcriticalN D : ℝ) /
          (7 * (E.Q : ℝ)) ≤
        (1 / (x : ℝ) + ((E.Q : ℝ) - 2 * (x : ℝ) - 2) /
          (2 * (E.Q : ℝ) - (x : ℝ)) + ((x : ℝ) + 1) /
          ((E.Q : ℝ) - (x : ℝ)) +
          (badMinimumRowSum E : ℝ) *
            (1 / ((E.Q : ℝ) - (x : ℝ)) -
              1 / (2 * (E.Q : ℝ) - (x : ℝ)))) +
          8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)) := by
    have hh := hHpromote2
    rw [hden_cast] at hh
    have h := add_le_add_right hh
      (8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)))
    simpa [add_comm, add_left_comm, add_assoc] using h
  have hWcoef' :
      (badMinimumRowSum E : ℝ) *
          (1 / ((E.Q : ℝ) - (x : ℝ)) -
            1 / (↑(2 * E.Q - x) : ℝ)) <
        72 * (subcriticalN D : ℝ) / (35 * (E.Q : ℝ)) := by
    rw [hden_cast]
    exact hWcoef
  have hbase :
      1 / (x : ℝ) + ((E.Q : ℝ) - 2 * (x : ℝ) - 2) /
          (2 * (E.Q : ℝ) - (x : ℝ)) + ((x : ℝ) + 1) /
          ((E.Q : ℝ) - (x : ℝ)) +
          (badMinimumRowSum E : ℝ) *
            (1 / ((E.Q : ℝ) - (x : ℝ)) -
              1 / (2 * (E.Q : ℝ) - (x : ℝ))) <
        5 / 6 + 2 / (E.Q : ℝ) +
          72 * (subcriticalN D : ℝ) / (35 * (E.Q : ℝ)) := by
    rw [hden_cast] at hWcoef'
    rw [hden_cast] at hB
    linarith only [hB, hWcoef']
  have hMupper2 :
      inverseSineRowMass E.Q E.A x <
        1 / (x : ℝ) + ((E.Q : ℝ) - 2 * (x : ℝ) - 2) /
            (2 * (E.Q : ℝ) - (x : ℝ)) + ((x : ℝ) + 1) /
            ((E.Q : ℝ) - (x : ℝ)) +
            (badMinimumRowSum E : ℝ) *
              (1 / ((E.Q : ℝ) - (x : ℝ)) -
                1 / (2 * (E.Q : ℝ) - (x : ℝ))) +
          8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)) := by
    exact lt_of_lt_of_le hrem hHbound
  have hMbound :
      inverseSineRowMass E.Q E.A x <
        5 / 6 + 2 / (E.Q : ℝ) +
          72 * (subcriticalN D : ℝ) / (35 * (E.Q : ℝ)) +
          8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)) := by
    linarith only [hMupper2, hbase]
  have hconst :
      72 * (subcriticalN D : ℝ) / (35 * (E.Q : ℝ)) +
          8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)) =
        16 * (subcriticalN D : ℝ) / (5 * (E.Q : ℝ)) := by ring
  have hMfinal : inverseSineRowMass E.Q E.A x <
      5 / 6 + (2 + 16 * (subcriticalN D : ℝ) / 5) / (E.Q : ℝ) := by
    convert hMbound using 1 <;> ring
  have hpassx : RowPasses E.Q E.A x := by
    exact hAll x hxA
  have hpassx' : (1 : ℝ) ≤ inverseSineRowMass E.Q E.A x := by
    exact hpassx
  have hfrac : (1 : ℝ) / 6 <
      (2 + 16 * (subcriticalN D : ℝ) / 5) / (E.Q : ℝ) := by
    have hh : (1 : ℝ) <
        5 / 6 + (2 + 16 * (subcriticalN D : ℝ) / 5) / (E.Q : ℝ) :=
      lt_of_le_of_lt hpassx' hMfinal
    linarith only [hh]
  have hQposR : 0 < (E.Q : ℝ) := by
    exact_mod_cast hqpos
  have hmul := (lt_div_iff₀ hQposR).1 hfrac
  have hQupper : (E.Q : ℝ) <
      12 + 96 * (subcriticalN D : ℝ) / 5 := by
    nlinarith only [hmul]
  let Bset : Finset ℤ := E.A.erase E.s
  have hBset2 : ∀ a ∈ Bset, (2 : ℤ) ≤ a := by
    intro a ha
    have ha' : a ∈ E.A.erase E.s := by simpa [Bset] using ha
    have haA := (Finset.mem_erase.mp ha').2
    have hamin := E.hs_min a haA
    have hne := (Finset.mem_erase.mp ha').1
    omega
  have hsumlower := probe_sum_lower_bound Bset hBset2
  have hcardB : Bset.card = minimumRowN E := by
    dsimp [Bset, minimumRowN]
    exact Finset.card_erase_of_mem E.hs_mem
  have hcardBN : (Bset.card : ℝ) = (subcriticalN D : ℝ) := by
    rw [hcardB, hn]
  have hsum_erase :
      (∑ a ∈ Bset, (a : ℝ)) + 1 = ∑ a ∈ E.A, (a : ℝ) := by
    have hh := Finset.sum_erase_add E.A (fun a : ℤ => (a : ℝ)) E.hs_mem
    have hsR : (E.s : ℝ) = 1 := by exact_mod_cast hs
    dsimp [Bset]
    calc
      (∑ a ∈ E.A.erase E.s, (a : ℝ)) + 1 =
          (∑ a ∈ E.A.erase E.s, (a : ℝ)) + (E.s : ℝ) := by rw [hsR]
      _ = ∑ a ∈ E.A, (a : ℝ) := hh
  have htri :
      ((subcriticalN D : ℝ) + 1) * ((subcriticalN D : ℝ) + 2) / 2 ≤
        (E.Q : ℝ) := by
    rw [hcardBN] at hsumlower
    linarith only [hsumlower, hsum_erase, hsumA]
  have hnleR : (subcriticalN D : ℝ) ≤ 36 := by
    by_contra hnot
    have hnotZ : ¬ subcriticalN D ≤ 36 := by
      intro hnZ
      have hnR : (subcriticalN D : ℝ) ≤ 36 := by exact_mod_cast hnZ
      exact hnot hnR
    have hn37Z : 37 ≤ subcriticalN D := by omega
    have hn37R : (37 : ℝ) ≤ (subcriticalN D : ℝ) := by
      exact_mod_cast hn37Z
    have hquad0 : 0 ≤ ((subcriticalN D : ℝ) - 37) *
        (subcriticalN D : ℝ) := by
      apply mul_nonneg
      · linarith
      · exact le_of_lt hNposR
    have hquad : 37 * (subcriticalN D : ℝ) ≤
        (subcriticalN D : ℝ) ^ 2 := by
      nlinarith only [hquad0]
    nlinarith only [htri, hQupper, hquad, hn37R]
  have hQ703R : (E.Q : ℝ) < 3516 / 5 := by
    nlinarith only [hQupper, hnleR]
  have hQle : E.Q ≤ 703 := by
    by_contra hnot
    have h704 : 704 ≤ E.Q := by omega
    have h704R : (704 : ℝ) ≤ (E.Q : ℝ) := by
      exact_mod_cast h704
    nlinarith only [hQ703R, h704R]
  have hnleNat : subcriticalN D ≤ 36 := by
    exact_mod_cast hnleR
  have hQleD : D.toMinimumRowSlackData.Q ≤ 703 := by
    simpa [E] using hQle
  exact ⟨hnleNat, hQleD⟩

/-- The presence of both `2` and `3` gives the anchor bound. -/
-- zpi: lem-anchor-at-three
theorem anchorAtThree (D : SEqualsOneSubcriticalData)
    (h2 : 2 ∈ D.toMinimumRowSlackData.A)
    (h3 : 3 ∈ D.toMinimumRowSlackData.A)
    (hAll : ∀ a ∈ D.toMinimumRowSlackData.A,
      RowPasses D.toMinimumRowSlackData.Q D.toMinimumRowSlackData.A a) :
    subcriticalN D ≤ 36 ∧ D.toMinimumRowSlackData.Q ≤ 715 := by
  classical
  let E : MinimumRowSlackData := D.toMinimumRowSlackData
  have hs : E.s = 1 := D.hs_one
  have hQ : 2 ≤ E.Q := by
    have h := E.hQ
    omega
  have hqpos : 0 < E.Q := by omega
  have h2E : (2 : ℤ) ∈ E.A := by simpa [E] using h2
  have h3E : (3 : ℤ) ∈ E.A := by simpa [E] using h3
  have hcop2 : Int.gcd (2 : ℤ) E.Q = 1 := by
    simpa [E] using E.hA.1 2 h2E |>.2
  have hodd : ∃ k : ℤ, E.Q = 2 * k + 1 := by
    obtain ⟨k, hk | hk⟩ := Int.even_or_odd' E.Q
    · exfalso
      have hd2 : (2 : ℤ) ∣ E.Q := by
        refine ⟨k, ?_⟩
        exact hk
      have hd2self : (2 : ℤ) ∣ (2 : ℤ) := by exact ⟨1, by ring⟩
      have hdg : (2 : ℕ) ∣ Int.gcd 2 E.Q := Int.dvd_gcd hd2self hd2
      rw [hcop2] at hdg
      omega
    · exact ⟨k, hk⟩
  have hgood2 : GoodMinimumRowElement E 2 := by
    left
    rcases hodd with ⟨k, hk⟩
    refine ⟨k, ?_⟩
    rw [hs]
    omega
  have hcop3 : Int.gcd (3 : ℤ) E.Q = 1 := by
    simpa [E] using E.hA.1 3 h3E |>.2
  have hgood3 : GoodMinimumRowElement E 3 := by
    have hmod3 : E.Q % 3 = 0 ∨ E.Q % 3 = 1 ∨ E.Q % 3 = 2 := by omega
    rcases hmod3 with hzero | hone | htwo
    · have hd3 : (3 : ℤ) ∣ E.Q := Int.dvd_of_emod_eq_zero hzero
      have hd3self : (3 : ℤ) ∣ (3 : ℤ) := by exact ⟨1, by ring⟩
      have hdg : (3 : ℕ) ∣ Int.gcd 3 E.Q := Int.dvd_gcd hd3self hd3
      rw [hcop3] at hdg
      omega
    · left
      rw [hs]
      apply Int.dvd_of_emod_eq_zero
      omega
    · right
      rw [hs]
      apply Int.dvd_of_emod_eq_zero
      omega
  have honeA : (1 : ℤ) ∈ E.A := by simpa [hs] using E.hs_mem
  have hgood1 : GoodMinimumRowElement E 1 := by
    left
    exact one_dvd _
  have hQ3 : 9 < E.Q := by
    have hh := E.hA_upper 3 h3E
    omega
  have hQ11 : (11 : ℤ) ≤ E.Q := by
    rcases hodd with ⟨k, hk⟩
    omega
  have hgood4 (h4 : (4 : ℤ) ∈ E.A) : GoodMinimumRowElement E 4 := by
    have hmod4 : E.Q % 4 = 1 ∨ E.Q % 4 = 3 := by
      rcases hodd with ⟨k, hk⟩
      omega
    rcases hmod4 with h1 | h3
    · left
      rw [hs]
      apply Int.dvd_of_emod_eq_zero
      omega
    · right
      rw [hs]
      apply Int.dvd_of_emod_eq_zero
      omega
  have hpass := hAll E.s E.hs_mem
  have hn : subcriticalN D = minimumRowN E := by rfl
  have hmain := sEqualsOneMinimumRow D hpass
  have hW : (badMinimumRowSum E : ℝ) <
      16 * (minimumRowN E : ℝ) / 7 := by
    simpa [hn] using hmain.2.1
  have hbook := productShellBookkeeping E
  have hshell := hbook.1
  have hrecip := hbook.2.1
  have hsubset := hbook.2.2.1
  have hdiv := hbook.2.2.2.1
  have hspecial := hbook.2.2.2.2
  let R : Finset ℤ := E.A.erase 3
  let R0 : Finset ℤ := R.filter (fun b : ℤ => b ≠ 1)
  let Bad : Finset ℤ := R0.filter (fun b => BadMinimumRowElement E b)
  let Good0 : Finset ℤ := R0.filter (fun b => ¬ BadMinimumRowElement E b)
  let Two : Finset ℤ := Good0.filter (fun b => b = 2)
  let C : Finset ℤ := Good0.filter (fun b => b = 4)
  let Far : Finset ℤ := (Good0.filter (fun b => b ≠ 2)).filter
    (fun b => b ≠ 4)
  have hRsub : R ⊆ E.A.erase 3 := by
    intro b hb
    simpa [R] using hb
  have hRone : (1 : ℤ) ∈ R := by
    exact Finset.mem_erase.mpr ⟨by omega, honeA⟩
  have hRnonempty : R.Nonempty := ⟨1, hRone⟩
  have hR2 : (2 : ℤ) ∈ R := by
    exact Finset.mem_erase.mpr ⟨by omega, h2E⟩
  have hR0sub : R0 ⊆ R := by
    intro b hb
    exact (Finset.mem_filter.mp hb).1
  have hBad_sub : Bad ⊆ E.A.erase 3 := by
    intro b hb
    exact hRsub (hR0sub (Finset.mem_filter.mp hb).1)
  have hGood_sub : Good0 ⊆ E.A.erase 3 := by
    intro b hb
    exact hRsub (hR0sub (Finset.mem_filter.mp hb).1)
  have hTwo_sub : Two ⊆ E.A.erase 3 := fun b hb =>
    hGood_sub (Finset.mem_filter.mp hb).1
  have hC_sub : C ⊆ E.A.erase 3 := fun b hb =>
    hGood_sub (Finset.mem_filter.mp hb).1
  have hFar_sub : Far ⊆ E.A.erase 3 := fun b hb =>
    hGood_sub ((Finset.mem_filter.mp (Finset.mem_filter.mp hb).1).1)
  have hbad_set : (E.A.erase E.s).filter
      (fun b => BadMinimumRowElement E b) = Bad := by
    ext b
    constructor
    · intro hb
      have hb0 := Finset.mem_filter.mp hb
      have hbE := Finset.mem_erase.mp hb0.1
      have hbne3 : b ≠ 3 := by
        intro heq
        subst b
        exact hb0.2 hgood3
      have hbR : b ∈ R := Finset.mem_erase.mpr ⟨hbne3, hbE.2⟩
      have hbR0 : b ∈ R0 := Finset.mem_filter.mpr ⟨hbR, by
        simpa [hs] using hbE.1⟩
      exact Finset.mem_filter.mpr ⟨hbR0, hb0.2⟩
    · intro hb
      have hb0 := Finset.mem_filter.mp hb
      have hbR0 := Finset.mem_filter.mp hb0.1
      have hbR := Finset.mem_erase.mp hbR0.1
      have hbne_s : b ≠ E.s := by
        simpa [hs] using hbR0.2
      exact Finset.mem_filter.mpr
        ⟨Finset.mem_erase.mpr ⟨hbne_s, hbR.2⟩, hb0.2⟩
  have hbad_sum : (badMinimumRowSum E : ℝ) =
      ∑ b ∈ Bad, (b : ℝ) := by
    have hWint : badMinimumRowSum E = ∑ b ∈ Bad, b := by
      calc
        badMinimumRowSum E =
            ∑ b ∈ (E.A.erase E.s).filter
              (fun b => BadMinimumRowElement E b), b := by
          dsimp [badMinimumRowSum]
          symm
          exact Finset.sum_filter _ _
        _ = ∑ b ∈ Bad, b := by rw [hbad_set]
    rw [hWint, Int.cast_sum]
  have hsumA : (∑ b ∈ E.A, (b : ℝ)) ≤ (E.Q : ℝ) := by
    calc
      (∑ b ∈ E.A, (b : ℝ)) = ((∑ b ∈ E.A, b : ℤ) : ℝ) := by
        rw [Int.cast_sum]
      _ ≤ (E.Q : ℝ) := by exact_mod_cast E.hA_sum
  have hsumR : (∑ b ∈ R, (b : ℝ)) + 3 =
      ∑ b ∈ E.A, (b : ℝ) := by
    dsimp [R]
    have hh := Finset.sum_erase_add E.A (fun b : ℤ => (b : ℝ)) h3E
    simpa using hh
  have hsum_R0 : (∑ b ∈ R, (b : ℝ)) =
      1 + ∑ b ∈ R0, (b : ℝ) := by
    have hh := (Finset.sum_filter_add_sum_filter_not R
      (fun b : ℤ => b = 1) (fun b => (b : ℝ))).symm
    have hone : (∑ b ∈ R.filter (fun b : ℤ => b = 1), (b : ℝ)) = 1 := by
      have heq : R.filter (fun b : ℤ => b = 1) = {1} := by
        ext b
        constructor
        · intro hb
          exact Finset.mem_singleton.mpr (Finset.mem_filter.mp hb).2
        · intro hb
          have hb1 : b = 1 := Finset.mem_singleton.mp hb
          subst b
          exact Finset.mem_filter.mpr ⟨hRone, rfl⟩
      rw [heq]
      simp
    simpa [R0, hone, add_comm] using hh
  have hsum_BGood : (∑ b ∈ R0, (b : ℝ)) =
      (∑ b ∈ Bad, (b : ℝ)) + ∑ b ∈ Good0, (b : ℝ) := by
    have hh := (Finset.sum_filter_add_sum_filter_not R0
      (fun b : ℤ => BadMinimumRowElement E b) (fun b => (b : ℝ))).symm
    simpa [Bad, Good0, add_comm] using hh
  let Gnot2 : Finset ℤ := Good0.filter (fun b => b ≠ 2)
  have hsum_TG : (∑ b ∈ Good0, (b : ℝ)) =
      (∑ b ∈ Two, (b : ℝ)) + ∑ b ∈ Gnot2, (b : ℝ) := by
    have hh := (Finset.sum_filter_add_sum_filter_not Good0
      (fun b : ℤ => b = 2) (fun b => (b : ℝ))).symm
    simpa [Two, Gnot2, add_comm] using hh
  have hCeq : Gnot2.filter (fun b : ℤ => b = 4) = C := by
    ext b
    simp [Gnot2, C]
    omega
  have hsum_GCF : (∑ b ∈ Gnot2, (b : ℝ)) =
      (∑ b ∈ C, (b : ℝ)) + ∑ b ∈ Far, (b : ℝ) := by
    have hh := (Finset.sum_filter_add_sum_filter_not Gnot2
      (fun b : ℤ => b = 4) (fun b => (b : ℝ))).symm
    rw [hCeq] at hh
    simpa [Far, add_comm] using hh
  have hsum_partition : (∑ b ∈ R, (b : ℝ)) =
      1 + ∑ b ∈ Bad, (b : ℝ) + ∑ b ∈ Two, (b : ℝ) +
        ∑ b ∈ C, (b : ℝ) + ∑ b ∈ Far, (b : ℝ) := by
    linarith [hsum_R0, hsum_BGood, hsum_TG, hsum_GCF]
  have hTwo_eq : Two = ({2} : Finset ℤ) := by
    ext b
    constructor
    · intro hb
      exact Finset.mem_singleton.mpr (Finset.mem_filter.mp hb).2
    · intro hb
      have hb2 : b = 2 := Finset.mem_singleton.mp hb
      subst b
      have h2R0 : (2 : ℤ) ∈ R0 :=
        Finset.mem_filter.mpr ⟨hR2, by omega⟩
      have h2G : (2 : ℤ) ∈ Good0 :=
        Finset.mem_filter.mpr ⟨h2R0, by
          intro hb
          exact hb hgood2⟩
      exact Finset.mem_filter.mpr ⟨h2G, rfl⟩
  have hsumTwo : (∑ b ∈ Two, (b : ℝ)) = 2 := by
    rw [hTwo_eq]
    simp
  have hC_le : ∑ b ∈ C, (b : ℝ) ≤ (4 : ℝ) := by
    by_cases hc : (4 : ℤ) ∈ C
    · have hCe : C = {4} := by
        ext b
        constructor
        · intro hb
          exact Finset.mem_singleton.mpr (Finset.mem_filter.mp hb).2
        · intro hb
          have hb' : b = 4 := Finset.mem_singleton.mp hb
          subst b
          exact hc
      rw [hCe]
      simp
    · have hCe : C = ∅ := by
        ext b
        constructor
        · intro hb
          exfalso
          apply hc
          have hb' := Finset.mem_filter.mp hb
          have hb4 : b = 4 := hb'.2
          subst b
          exact Finset.mem_filter.mpr ⟨hb'.1, rfl⟩
        · simp
      rw [hCe]
      simp
  have hBad_nonneg : 0 ≤ ∑ b ∈ Bad, (b : ℝ) := by
    apply Finset.sum_nonneg
    intro b hb
    have hbA := (Finset.mem_erase.mp (hBad_sub hb)).2
    have hbpos := E.hA.1 b hbA |>.1
    exact_mod_cast hbpos.le
  have hTwo_nonneg : 0 ≤ ∑ b ∈ Two, (b : ℝ) := by
    rw [hsumTwo]
    norm_num
  have hC_nonneg : 0 ≤ ∑ b ∈ C, (b : ℝ) := by
    apply Finset.sum_nonneg
    intro b hb
    have hbA := (Finset.mem_erase.mp (hC_sub hb)).2
    have hbpos := E.hA.1 b hbA |>.1
    exact_mod_cast hbpos.le
  have hFar_nonneg : 0 ≤ ∑ b ∈ Far, (b : ℝ) := by
    apply Finset.sum_nonneg
    intro b hb
    have hbA := (Finset.mem_erase.mp (hFar_sub hb)).2
    have hbpos := E.hA.1 b hbA |>.1
    exact_mod_cast hbpos.le
  have hP_bad (b : ℤ) (hb : b ∈ Bad) :
      E.Q - 3 ≤ productShellValue E 3 b := by
    have hb0 := Finset.mem_filter.mp hb
    have hbR0 := Finset.mem_filter.mp hb0.1
    have hbR := Finset.mem_erase.mp hbR0.1
    have hbA := hbR.2
    have hne : (3 : ℤ) ≠ b := Ne.symm hbR.1
    have halt := hshell 3 h3E b hbA hne
    rcases halt with hfirst | ⟨j, hj, hminus | hplus⟩
    · have hdb := hdiv 3 h3E b hbA hne hfirst
      obtain ⟨k, hk⟩ := hdb
      have hbpos := E.hA.1 b hbA |>.1
      have hkpos : 0 < k := by
        by_contra hk0
        have hk' : k ≤ 0 := by omega
        have hp : b * k ≤ 0 := mul_nonpos_of_nonneg_of_nonpos
          (by omega) hk'
        nlinarith [hk]
      have hb_le : b ≤ 3 := by nlinarith [hk]
      have hbcases : b = 1 ∨ b = 2 ∨ b = 3 := by omega
      rcases hbcases with rfl | rfl | rfl
      · exact False.elim (hbR0.2 rfl)
      · exact False.elim (hb0.2 hgood2)
      · exact False.elim (hb0.2 hgood3)
    · have hqj : E.Q ≤ j * E.Q := by
        have hh := mul_le_mul_of_nonneg_right hj (show 0 ≤ E.Q by omega)
        nlinarith
      nlinarith [hminus, hqj]
    · have hqj : E.Q ≤ j * E.Q := by
        have hh := mul_le_mul_of_nonneg_right hj (show 0 ≤ E.Q by omega)
        nlinarith
      nlinarith [hplus, hqj]
  have hP_two (b : ℤ) (hb : b ∈ Two) :
      E.Q - 3 ≤ productShellValue E 3 b := by
    have hbT := Finset.mem_filter.mp hb
    have hbG := Finset.mem_filter.mp hbT.1
    have hbR0 := Finset.mem_filter.mp hbG.1
    have hbR := Finset.mem_erase.mp hbR0.1
    have hbA := hbR.2
    have hbval : b = 2 := hbT.2
    have hne : (3 : ℤ) ≠ b := Ne.symm hbR.1
    have halt := hshell 3 h3E b hbA hne
    rcases halt with hfirst | ⟨j, hj, hminus | hplus⟩
    · have hdb := hdiv 3 h3E b hbA hne hfirst
      obtain ⟨k, hk⟩ := hdb
      rw [hbval] at hk
      omega
    · have hqj : E.Q ≤ j * E.Q := by
        have hh := mul_le_mul_of_nonneg_right hj (show 0 ≤ E.Q by omega)
        nlinarith
      nlinarith [hminus, hqj]
    · have hqj : E.Q ≤ j * E.Q := by
        have hh := mul_le_mul_of_nonneg_right hj (show 0 ≤ E.Q by omega)
        nlinarith
      nlinarith [hplus, hqj]
  have hP_C (b : ℤ) (hb : b ∈ C) :
      E.Q - 3 ≤ productShellValue E 3 b := by
    have hbC := Finset.mem_filter.mp hb
    have hbG := Finset.mem_filter.mp hbC.1
    have hbR0 := Finset.mem_filter.mp hbG.1
    have hbR := Finset.mem_erase.mp hbR0.1
    have hbA := hbR.2
    have h4A : (4 : ℤ) ∈ E.A := by
      simpa [hbC.2] using hbA
    have hbGood : GoodMinimumRowElement E b := by
      simpa [hbC.2] using hgood4 h4A
    have hne : (3 : ℤ) ≠ b := Ne.symm hbR.1
    have halt := hshell 3 h3E b hbA hne
    rcases halt with hfirst | ⟨j, hj, hminus | hplus⟩
    · have hdb := hdiv 3 h3E b hbA hne hfirst
      obtain ⟨k, hk⟩ := hdb
      have hbval : b = 4 := hbC.2
      rw [hbval] at hk
      omega
    · have hqj : E.Q ≤ j * E.Q := by
        have hh := mul_le_mul_of_nonneg_right hj (show 0 ≤ E.Q by omega)
        nlinarith
      nlinarith [hminus, hqj]
    · have hqj : E.Q ≤ j * E.Q := by
        have hh := mul_le_mul_of_nonneg_right hj (show 0 ≤ E.Q by omega)
        nlinarith
      nlinarith [hplus, hqj]
  have hP_far (b : ℤ) (hb : b ∈ Far) :
      2 * E.Q - 3 ≤ productShellValue E 3 b := by
    have hbF := Finset.mem_filter.mp hb
    have hbG2 := Finset.mem_filter.mp hbF.1
    have hbG := Finset.mem_filter.mp hbG2.1
    have hb0 := Finset.mem_filter.mp hbG.1
    have hbR := Finset.mem_erase.mp hb0.1
    have hbA := hbR.2
    have hbGood : GoodMinimumRowElement E b := by
      by_contra hbg
      exact hbG.2 hbg
    have hbgt3 : 3 < b := by
      have hmin := E.hs_min b hbA
      have hbne1 := hb0.2
      have hbne2 := hbG2.2
      have hbne3 := hbR.1
      omega
    have hne : (3 : ℤ) ≠ b := Ne.symm hbR.1
    have halt := hshell 3 h3E b hbA hne
    rcases halt with hfirst | ⟨j, hj, hminus | hplus⟩
    · have hdb := hdiv 3 h3E b hbA hne hfirst
      obtain ⟨k, hk⟩ := hdb
      have hbpos := E.hA.1 b hbA |>.1
      have hkpos : 0 < k := by
        by_contra hk0
        have hk' : k ≤ 0 := by omega
        have hp : b * k ≤ 0 := mul_nonpos_of_nonneg_of_nonpos
          (by omega) hk'
        nlinarith [hk]
      nlinarith [hk]
    · have hj2 : 2 ≤ j := by
        by_contra hj2
        have hj1 : j = 1 := by omega
        subst j
        have hsx' := hspecial hs 3 h3E b hbA hne hbGood
          (Or.inl (by simpa using hminus))
        have hbx1 := hsx'.2 (by omega : (1 : ℤ) < 3) hbgt3
        exact hbF.2 hbx1
      have hqj : 2 * E.Q ≤ j * E.Q := by
        have hh := mul_le_mul_of_nonneg_right hj2 (show 0 ≤ E.Q by omega)
        nlinarith
      nlinarith [hminus, hqj]
    · have hj2 : 2 ≤ j := by
        by_contra hj2
        have hj1 : j = 1 := by omega
        subst j
        have hsx' := hspecial hs 3 h3E b hbA hne hbGood
          (Or.inr (by simpa using hplus))
        have hbx1 := hsx'.2 (by omega : (1 : ℤ) < 3) hbgt3
        exact hbF.2 hbx1
      have hqj : 2 * E.Q ≤ j * E.Q := by
        have hh := mul_le_mul_of_nonneg_right hj2 (show 0 ≤ E.Q by omega)
        nlinarith
      nlinarith [hplus, hqj]
  have hQmx : 0 < E.Q - 3 := by omega
  have h2Qmx : 0 < 2 * E.Q - 3 := by omega
  have hQmxR : 0 < (E.Q : ℝ) - 3 := by exact_mod_cast hQmx
  have h2QmxR : 0 < ((2 * E.Q - 3 : ℤ) : ℝ) := by
    exact_mod_cast h2Qmx
  have hBad_recip :
      (∑ b ∈ Bad, (1 : ℝ) / (productShellDistance E 3 b : ℝ)) ≤
        (∑ b ∈ Bad, (b : ℝ)) / ((E.Q : ℝ) - 3) := by
    refine hsubset 3 h3E Bad hBad_sub _ _ hBad_nonneg hQmxR le_rfl ?_
    intro b hb
    exact_mod_cast hP_bad b hb
  have hTwo_recip :
      (∑ b ∈ Two, (1 : ℝ) / (productShellDistance E 3 b : ℝ)) ≤
        (∑ b ∈ Two, (b : ℝ)) / ((E.Q : ℝ) - 3) := by
    refine hsubset 3 h3E Two hTwo_sub _ _ hTwo_nonneg hQmxR le_rfl ?_
    intro b hb
    exact_mod_cast hP_two b hb
  have hC_recip :
      (∑ b ∈ C, (1 : ℝ) / (productShellDistance E 3 b : ℝ)) ≤
        (∑ b ∈ C, (b : ℝ)) / ((E.Q : ℝ) - 3) := by
    refine hsubset 3 h3E C hC_sub _ _ hC_nonneg hQmxR le_rfl ?_
    intro b hb
    exact_mod_cast hP_C b hb
  have hFar_recip :
      (∑ b ∈ Far, (1 : ℝ) / (productShellDistance E 3 b : ℝ)) ≤
        (∑ b ∈ Far, (b : ℝ)) /
          ((2 * E.Q - 3 : ℤ) : ℝ) := by
    refine hsubset 3 h3E Far hFar_sub _ _ hFar_nonneg h2QmxR le_rfl ?_
    intro b hb
    exact_mod_cast hP_far b hb
  let f : ℤ → ℝ := fun b =>
    (1 : ℝ) / (productShellDistance E 3 b : ℝ)
  have hsum1f : (∑ b ∈ R, f b) =
      (∑ b ∈ R.filter (fun b : ℤ => b = 1), f b) +
        ∑ b ∈ R0, f b := by
    have hh := (Finset.sum_filter_add_sum_filter_not R
      (fun b : ℤ => b = 1) f).symm
    simpa [R0] using hh
  have hsum2f : (∑ b ∈ R0, f b) =
      (∑ b ∈ Bad, f b) + ∑ b ∈ Good0, f b := by
    have hh := (Finset.sum_filter_add_sum_filter_not R0
      (fun b : ℤ => BadMinimumRowElement E b) f).symm
    simpa [Bad, Good0] using hh
  have hsum_TGf : (∑ b ∈ Good0, f b) =
      (∑ b ∈ Two, f b) + ∑ b ∈ Gnot2, f b := by
    have hh := (Finset.sum_filter_add_sum_filter_not Good0
      (fun b : ℤ => b = 2) f).symm
    simpa [Two, Gnot2, add_comm] using hh
  have hsum_GCFf : (∑ b ∈ Gnot2, f b) =
      (∑ b ∈ C, f b) + ∑ b ∈ Far, f b := by
    have hh := (Finset.sum_filter_add_sum_filter_not Gnot2
      (fun b : ℤ => b = 4) f).symm
    rw [hCeq] at hh
    simpa [Far, add_comm] using hh
  have hinv_one : inverseMod E.Q 1 = 1 := by
    have hi := inverseMod_spec E.Q 1 hQ (Int.gcd_one_left E.Q)
    have hres : inverseMod E.Q 1 % E.Q = 1 := by simpa using hi.2
    have hmod := Int.emod_eq_of_lt (by omega : 0 ≤ inverseMod E.Q 1) hi.1.2
    omega
  have h3nonneg : 0 ≤ (3 : ℤ) := by omega
  have h3ltQ : (3 : ℤ) < E.Q := by omega
  have h3res : (3 : ℤ) % E.Q = 3 :=
    Int.emod_eq_of_lt h3nonneg h3ltQ
  have hdist_one : productShellDistance E 3 1 = 3 := by
    dsimp [productShellDistance, cyclicDistance]
    rw [hinv_one]
    have hmin : min (3 : ℤ) (E.Q - 3) = 3 := by
      rw [min_eq_left]
      omega
    simp only [mul_one]
    rw [h3res]
    exact hmin
  have hRonef : R.filter (fun b : ℤ => b = 1) = {1} := by
    ext b
    constructor
    · intro hb
      exact Finset.mem_singleton.mpr (Finset.mem_filter.mp hb).2
    · intro hb
      have hb1 : b = 1 := Finset.mem_singleton.mp hb
      subst b
      exact Finset.mem_filter.mpr ⟨hRone, rfl⟩
  have honef : (∑ b ∈ R.filter (fun b : ℤ => b = 1), f b) =
      1 / (3 : ℝ) := by
    rw [hRonef]
    simp [f, hdist_one]
  have hHsplit : productShellRow E 3 =
      1 / (3 : ℝ) + (∑ b ∈ Bad, f b) +
        (∑ b ∈ Two, f b) + (∑ b ∈ C, f b) +
        ∑ b ∈ Far, f b := by
    dsimp [productShellRow, R]
    linarith [hsum1f, hsum2f, hsum_TGf, hsum_GCFf, honef]
  have hHupper : productShellRow E 3 ≤
      1 / (3 : ℝ) +
        (∑ b ∈ Bad, (b : ℝ)) / ((E.Q : ℝ) - 3) +
        (∑ b ∈ Two, (b : ℝ)) / ((E.Q : ℝ) - 3) +
        (∑ b ∈ C, (b : ℝ)) / ((E.Q : ℝ) - 3) +
        (∑ b ∈ Far, (b : ℝ)) /
          ((2 * E.Q - 3 : ℤ) : ℝ) := by
    rw [hHsplit]
    dsimp [f] at hBad_recip hTwo_recip hC_recip hFar_recip ⊢
    linarith
  have hFar_le : ∑ b ∈ Far, (b : ℝ) ≤
      (E.Q : ℝ) - 4 - (badMinimumRowSum E : ℝ) -
        2 - ∑ b ∈ C, (b : ℝ) := by
    rw [← hbad_sum] at hsum_partition
    rw [hsumTwo] at hsum_partition
    linarith [hsum_partition, hsumR, hsumA]
  have hFar_div := div_le_div_of_nonneg_right hFar_le (le_of_lt h2QmxR)
  have hHshell : productShellRow E 3 ≤
      1 / (3 : ℝ) +
        ((E.Q : ℝ) - 4 - (badMinimumRowSum E : ℝ) - 2 -
          ∑ b ∈ C, (b : ℝ)) /
          ((2 * E.Q - 3 : ℤ) : ℝ) +
        ((badMinimumRowSum E : ℝ) + 2 +
          ∑ b ∈ C, (b : ℝ)) / ((E.Q : ℝ) - 3) := by
    have htemp : productShellRow E 3 ≤
        1 / (3 : ℝ) + (badMinimumRowSum E : ℝ) /
            ((E.Q : ℝ) - 3) +
          (∑ b ∈ Two, (b : ℝ)) / ((E.Q : ℝ) - 3) +
          (∑ b ∈ C, (b : ℝ)) / ((E.Q : ℝ) - 3) +
          ((E.Q : ℝ) - 4 - (badMinimumRowSum E : ℝ) - 2 -
            ∑ b ∈ C, (b : ℝ)) /
            ((2 * E.Q - 3 : ℤ) : ℝ) := by
      rw [← hbad_sum] at hHupper
      linarith [hHupper, hFar_div]
    calc
      productShellRow E 3 ≤
          1 / (3 : ℝ) + (badMinimumRowSum E : ℝ) /
              ((E.Q : ℝ) - 3) +
            (∑ b ∈ Two, (b : ℝ)) / ((E.Q : ℝ) - 3) +
            (∑ b ∈ C, (b : ℝ)) / ((E.Q : ℝ) - 3) +
            ((E.Q : ℝ) - 4 - (badMinimumRowSum E : ℝ) - 2 -
              ∑ b ∈ C, (b : ℝ)) /
              ((2 * E.Q - 3 : ℤ) : ℝ) := by
        simpa [hsumTwo] using htemp
      _ = 1 / (3 : ℝ) +
          ((E.Q : ℝ) - 4 - (badMinimumRowSum E : ℝ) - 2 -
            ∑ b ∈ C, (b : ℝ)) /
            ((2 * E.Q - 3 : ℤ) : ℝ) +
          ((badMinimumRowSum E : ℝ) + 2 +
            ∑ b ∈ C, (b : ℝ)) / ((E.Q : ℝ) - 3) := by
        rw [hsumTwo]
        rw [show ((2 * E.Q - 3 : ℤ) : ℝ) =
            2 * (E.Q : ℝ) - 3 by push_cast; rfl]
        ring
  have hL : (badMinimumRowSum E : ℝ) + 2 +
      ∑ b ∈ C, (b : ℝ) ≤ (badMinimumRowSum E : ℝ) + 6 := by
    linarith [hC_le]
  have hden2 : ((2 * E.Q - 3 : ℤ) : ℝ) =
      2 * (E.Q : ℝ) - 3 := by
    push_cast
    ring
  have hcoef : 0 < (1 : ℝ) / ((E.Q : ℝ) - 3) -
      1 / ((2 * E.Q - 3 : ℤ) : ℝ) := by
    rw [hden2]
    have hlt : (E.Q : ℝ) - 3 < 2 * (E.Q : ℝ) - 3 := by
      linarith [hqpos]
    have hh := one_div_lt_one_div_of_lt hQmxR hlt
    linarith
  have hHpromote : productShellRow E 3 ≤
      1 / (3 : ℝ) +
        ((E.Q : ℝ) - 10 - (badMinimumRowSum E : ℝ)) /
          ((2 * E.Q - 3 : ℤ) : ℝ) +
        ((badMinimumRowSum E : ℝ) + 6) /
          ((E.Q : ℝ) - 3) := by
    calc
      productShellRow E 3 ≤
          1 / (3 : ℝ) +
            ((E.Q : ℝ) - 4 - (badMinimumRowSum E : ℝ) - 2 -
              ∑ b ∈ C, (b : ℝ)) /
              ((2 * E.Q - 3 : ℤ) : ℝ) +
            ((badMinimumRowSum E : ℝ) + 2 +
              ∑ b ∈ C, (b : ℝ)) / ((E.Q : ℝ) - 3) := hHshell
      _ = 1 / (3 : ℝ) +
          ((E.Q : ℝ) - 4) /
            ((2 * E.Q - 3 : ℤ) : ℝ) +
          ((badMinimumRowSum E : ℝ) + 2 +
            ∑ b ∈ C, (b : ℝ)) *
            (1 / ((E.Q : ℝ) - 3) -
              1 / ((2 * E.Q - 3 : ℤ) : ℝ)) := by
        rw [hden2]
        ring
      _ ≤ 1 / (3 : ℝ) +
          ((E.Q : ℝ) - 4) /
            ((2 * E.Q - 3 : ℤ) : ℝ) +
          ((badMinimumRowSum E : ℝ) + 6) *
            (1 / ((E.Q : ℝ) - 3) -
              1 / ((2 * E.Q - 3 : ℤ) : ℝ)) := by
        have hh := mul_le_mul_of_nonneg_right hL (le_of_lt hcoef)
        linarith
      _ = 1 / (3 : ℝ) +
          ((E.Q : ℝ) - 10 - (badMinimumRowSum E : ℝ)) /
            ((2 * E.Q - 3 : ℤ) : ℝ) +
          ((badMinimumRowSum E : ℝ) + 6) /
            ((E.Q : ℝ) - 3) := by
        rw [hden2]
        ring
  have hQ11R : (11 : ℝ) ≤ (E.Q : ℝ) := by exact_mod_cast hQ11
  have hqR : 0 < (E.Q : ℝ) := by exact_mod_cast hqpos
  have hB : 1 / (3 : ℝ) + ((E.Q : ℝ) - 10) /
      (2 * (E.Q : ℝ) - 3) + 6 / ((E.Q : ℝ) - 3) ≤
      (5 : ℝ) / 6 + 4 / (E.Q : ℝ) := by
    have hd1 : 0 < (E.Q : ℝ) - 3 := by linarith
    have hd2' : 0 < 2 * (E.Q : ℝ) - 3 := by linarith
    have hprod : 0 < 6 * (E.Q : ℝ) * ((E.Q : ℝ) - 3) *
        (2 * (E.Q : ℝ) - 3) := by positivity
    have hquad0 : 0 ≤ ((E.Q : ℝ) - 11) * (E.Q : ℝ) := by
      exact mul_nonneg (by linarith) (le_of_lt hqR)
    have hpoly : 0 ≤ 3 * (9 * (E.Q : ℝ) ^ 2 -
        87 * (E.Q : ℝ) + 72) := by
      nlinarith [hquad0]
    have hid : 6 * (E.Q : ℝ) * ((E.Q : ℝ) - 3) *
          (2 * (E.Q : ℝ) - 3) *
          ((5 : ℝ) / 6 + 4 / (E.Q : ℝ) -
            (1 / 3 + ((E.Q : ℝ) - 10) /
              (2 * (E.Q : ℝ) - 3) + 6 / ((E.Q : ℝ) - 3))) =
        3 * (9 * (E.Q : ℝ) ^ 2 - 87 * (E.Q : ℝ) + 72) := by
      have hd2comm : 0 < (E.Q : ℝ) * 2 - 3 := by
        linarith [hd2']
      field_simp [ne_of_gt hqR, ne_of_gt hd1, ne_of_gt hd2',
        ne_of_gt hd2comm]
      ring
    nlinarith [hid, hpoly]
  have hpolycoef : 0 < ((E.Q : ℝ) - 9) *
      (8 * (E.Q : ℝ) - 9) := by
    have hqminus : 0 < (E.Q : ℝ) - 9 := by linarith [hQ3]
    have h8minus : 0 < 8 * (E.Q : ℝ) - 9 := by linarith [hQ3]
    exact mul_pos hqminus h8minus
  have hcross : 10 * (E.Q : ℝ) ^ 2 <
      9 * ((E.Q : ℝ) - 3) * (2 * (E.Q : ℝ) - 3) := by
    nlinarith only [hpolycoef]
  have hdenprod : 0 < ((E.Q : ℝ) - 3) *
      (2 * (E.Q : ℝ) - 3) := by
    exact mul_pos (by linarith [hQ3]) (by linarith [hQ3])
  have htenpos : 0 < 10 * (E.Q : ℝ) := by positivity
  have hcross' : (E.Q : ℝ) * (10 * (E.Q : ℝ)) <
      9 * ((E.Q : ℝ) - 3) * (2 * (E.Q : ℝ) - 3) := by
    nlinarith only [hcross]
  have hfracQ : (E.Q : ℝ) <
      (9 * ((E.Q : ℝ) - 3) * (2 * (E.Q : ℝ) - 3)) /
        (10 * (E.Q : ℝ)) := (lt_div_iff₀ htenpos).2 hcross'
  have hcoefQ : (E.Q : ℝ) /
      (((E.Q : ℝ) - 3) * (2 * (E.Q : ℝ) - 3)) <
      (9 : ℝ) / (10 * (E.Q : ℝ)) := by
    apply (div_lt_iff₀ hdenprod).2
    calc
      (E.Q : ℝ) <
          (9 * ((E.Q : ℝ) - 3) * (2 * (E.Q : ℝ) - 3)) /
            (10 * (E.Q : ℝ)) := hfracQ
      _ = (9 / (10 * (E.Q : ℝ))) *
          (((E.Q : ℝ) - 3) * (2 * (E.Q : ℝ) - 3)) := by ring
  have hWnonneg : 0 ≤ (badMinimumRowSum E : ℝ) := by
    rw [hbad_sum]
    exact hBad_nonneg
  have hcoefpos : 0 < (E.Q : ℝ) /
      (((E.Q : ℝ) - 3) * (2 * (E.Q : ℝ) - 3)) := by
    positivity
  have hW' : (badMinimumRowSum E : ℝ) <
      16 * (subcriticalN D : ℝ) / 7 := by
    simpa [hn] using hW
  have hcardR : R.card = minimumRowN E := by
    dsimp [R, minimumRowN]
    exact Finset.card_erase_of_mem h3E
  have hcardRN : (R.card : ℝ) = (subcriticalN D : ℝ) := by
    rw [hcardR, hn]
  have hcardRNat : R.card = subcriticalN D := by
    rw [hcardR, ← hn]
  have hNpos : 0 < subcriticalN D := by
    rw [← hcardRNat]
    exact Finset.card_pos.mpr hRnonempty
  have hNposR : 0 < (subcriticalN D : ℝ) := by exact_mod_cast hNpos
  have hfactorpos : 0 < 16 * (subcriticalN D : ℝ) / 7 := by positivity
  have hmul1 := mul_lt_mul_of_pos_right hW' hcoefpos
  have hmul2 := mul_lt_mul_of_pos_left hcoefQ hfactorpos
  have hWcoef : (badMinimumRowSum E : ℝ) *
      ((E.Q : ℝ) /
        (((E.Q : ℝ) - 3) * (2 * (E.Q : ℝ) - 3))) <
      72 * (subcriticalN D : ℝ) / (35 * (E.Q : ℝ)) := by
    calc
      (badMinimumRowSum E : ℝ) *
          ((E.Q : ℝ) /
            (((E.Q : ℝ) - 3) * (2 * (E.Q : ℝ) - 3))) <
          (16 * (subcriticalN D : ℝ) / 7) *
            ((E.Q : ℝ) /
              (((E.Q : ℝ) - 3) * (2 * (E.Q : ℝ) - 3))) := hmul1
      _ < (16 * (subcriticalN D : ℝ) / 7) *
          (9 / (10 * (E.Q : ℝ))) := hmul2
      _ = 72 * (subcriticalN D : ℝ) / (35 * (E.Q : ℝ)) := by ring
  have hWcoef' : (badMinimumRowSum E : ℝ) *
      (1 / ((E.Q : ℝ) - 3) -
        1 / ((2 * E.Q - 3 : ℤ) : ℝ)) <
      72 * (subcriticalN D : ℝ) / (35 * (E.Q : ℝ)) := by
    rw [hden2]
    rw [show 1 / ((E.Q : ℝ) - 3) -
        1 / (2 * (E.Q : ℝ) - 3) =
        (E.Q : ℝ) / (((E.Q : ℝ) - 3) *
          (2 * (E.Q : ℝ) - 3)) by
          have hd2comm : 0 < (E.Q : ℝ) * 2 - 3 := by linarith
          field_simp [ne_of_gt hQmxR,
            ne_of_gt (show 0 < 2 * (E.Q : ℝ) - 3 by linarith),
            ne_of_gt hd2comm]
          ring]
    exact hWcoef
  have hdist_bounds (b : ℤ) (hb : b ∈ R) :
      1 ≤ productShellDistance E 3 b ∧
        2 * productShellDistance E 3 b ≤ E.Q := by
    have hbR := Finset.mem_erase.mp hb
    have hbA : b ∈ E.A := hbR.2
    have hbU := E.hA.1 b hbA
    have h3U := E.hA.1 3 h3E
    have hsinv : (3 * inverseMod E.Q b) % E.Q ≠ 0 := by
      intro hz
      have hinv := inverseMod_spec E.Q b hQ hbU.2
      have hzero : 3 * inverseMod E.Q b ≡ 0 [ZMOD E.Q] := by
        simpa [Int.ModEq] using hz
      have hprod : (3 * inverseMod E.Q b) * b ≡ 0 * b [ZMOD E.Q] :=
        hzero.mul_right b
      have h1mod : (1 : ℤ) % E.Q = 1 :=
        Int.emod_eq_of_lt (by omega) (by omega)
      have hone : b * inverseMod E.Q b ≡ 1 [ZMOD E.Q] := by
        simpa [Int.ModEq, h1mod] using hinv.2
      have hcalc : (3 * inverseMod E.Q b) * b ≡ 3 [ZMOD E.Q] := by
        calc
          (3 * inverseMod E.Q b) * b = 3 * (b * inverseMod E.Q b) := by ring
          _ ≡ 3 * 1 [ZMOD E.Q] := hone.mul_left 3
          _ = 3 := by ring
      have h3mod : (3 : ℤ) % E.Q = 0 := by
        have hh : (3 * inverseMod E.Q b) * b % E.Q = 0 :=
          hprod.eq.trans (by simp)
        rw [hcalc.eq] at hh
        exact hh
      omega
    have hd := cyclicDistance_bounds E.Q (3 * inverseMod E.Q b) hQ hsinv
    simpa [productShellDistance] using hd
  have hCconst : inverseSineEnvelopeConstant < (16 : ℝ) / 7 := by
    dsimp [inverseSineEnvelopeConstant]
    nlinarith [Real.pi_lt_d4]
  have hKernelUpper (b : ℤ) (hb : b ∈ R) :
      inverseSineKernel E.Q (productShellDistance E 3 b) <
        1 / (productShellDistance E 3 b : ℝ) +
          (16 : ℝ) / 7 * (productShellDistance E 3 b : ℝ) /
            (E.Q : ℝ) ^ 2 := by
    have hd := hdist_bounds b hb
    have hh := inverseSineKernel_upper E.Q
      (productShellDistance E 3 b) hQ hd.1 hd.2
    have hdRZ : 0 ≤ productShellDistance E 3 b := by omega
    have hdR : 0 ≤ (productShellDistance E 3 b : ℝ) := by
      exact_mod_cast hdRZ
    have hdRpos : 0 < (productShellDistance E 3 b : ℝ) := by
      exact_mod_cast (show 0 < productShellDistance E 3 b by omega)
    have hq2 : 0 < (E.Q : ℝ) ^ 2 := by positivity
    have hnonneg : 0 ≤ (productShellDistance E 3 b : ℝ) /
        (E.Q : ℝ) ^ 2 := div_nonneg hdR (le_of_lt hq2)
    calc
      inverseSineKernel E.Q (productShellDistance E 3 b) <
          1 / (productShellDistance E 3 b : ℝ) +
            inverseSineEnvelopeConstant *
              (productShellDistance E 3 b : ℝ) / (E.Q : ℝ) ^ 2 := hh
      _ < 1 / (productShellDistance E 3 b : ℝ) +
          (16 : ℝ) / 7 * (productShellDistance E 3 b : ℝ) /
            (E.Q : ℝ) ^ 2 := by
        have hmul := mul_lt_mul_of_pos_right hCconst
          (div_pos hdRpos hq2)
        have hmul' : inverseSineEnvelopeConstant *
              (productShellDistance E 3 b : ℝ) / (E.Q : ℝ) ^ 2 <
            (16 : ℝ) / 7 * (productShellDistance E 3 b : ℝ) /
              (E.Q : ℝ) ^ 2 := by
          convert hmul using 1 <;> ring
        convert add_lt_add_left hmul' (1 /
          (productShellDistance E 3 b : ℝ)) using 1 <;> ring
  have hsum_kernel :
      (∑ b ∈ R, inverseSineKernel E.Q (productShellDistance E 3 b)) <
        ∑ b ∈ R,
          (1 / (productShellDistance E 3 b : ℝ) +
            (16 : ℝ) / 7 * (productShellDistance E 3 b : ℝ) /
              (E.Q : ℝ) ^ 2) := by
    apply Finset.sum_lt_sum_of_nonempty hRnonempty
    intro b hb
    exact hKernelUpper b hb
  have hMupper : inverseSineRowMass E.Q E.A 3 <
      productShellRow E 3 + (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
        ∑ b ∈ R, (productShellDistance E 3 b : ℝ) := by
    have hspec := inverseSineRowMass_spec E.Q E.A 3 hQ E.hA h3E
    dsimp [productShellRow, R]
    rw [hspec]
    have hsum' :
        (∑ b ∈ E.A.erase 3,
          inverseSineKernel E.Q (cyclicDistance E.Q
            (3 * inverseMod E.Q b))) <
          ∑ b ∈ E.A.erase 3,
            (1 / (productShellDistance E 3 b : ℝ) +
              (16 : ℝ) / 7 * (productShellDistance E 3 b : ℝ) /
                (E.Q : ℝ) ^ 2) := by
      simpa [productShellDistance] using hsum_kernel
    have hcalc :
        (∑ b ∈ E.A.erase 3,
          (16 : ℝ) / 7 * (productShellDistance E 3 b : ℝ) /
            (E.Q : ℝ) ^ 2) =
          (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
            ∑ b ∈ E.A.erase 3, (productShellDistance E 3 b : ℝ) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro b hb
      ring
    calc
      (∑ b ∈ E.A.erase 3,
          inverseSineKernel E.Q (cyclicDistance E.Q
            (3 * inverseMod E.Q b))) <
          ∑ b ∈ E.A.erase 3,
            (1 / (productShellDistance E 3 b : ℝ) +
              (16 : ℝ) / 7 * (productShellDistance E 3 b : ℝ) /
                (E.Q : ℝ) ^ 2) := hsum'
      _ = (∑ b ∈ E.A.erase 3,
          1 / (productShellDistance E 3 b : ℝ)) +
          (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
            ∑ b ∈ E.A.erase 3, (productShellDistance E 3 b : ℝ) := by
        rw [Finset.sum_add_distrib, hcalc]
  have hdist_sum :
      ∑ b ∈ R, (productShellDistance E 3 b : ℝ) ≤
        (subcriticalN D : ℝ) * (E.Q : ℝ) / 2 := by
    have hterm : ∀ b ∈ R,
        (productShellDistance E 3 b : ℝ) ≤ (E.Q : ℝ) / 2 := by
      intro b hb
      have hd := hdist_bounds b hb
      have hh : (2 : ℝ) * (productShellDistance E 3 b : ℝ) ≤
          (E.Q : ℝ) := by exact_mod_cast hd.2
      nlinarith
    have hsum := Finset.sum_le_sum (fun b hb => hterm b hb)
    calc
      (∑ b ∈ R, (productShellDistance E 3 b : ℝ)) ≤
          ∑ b ∈ R, (E.Q : ℝ) / 2 := hsum
      _ = (R.card : ℝ) * (E.Q : ℝ) / 2 := by simp; ring
      _ = (subcriticalN D : ℝ) * (E.Q : ℝ) / 2 := by rw [hcardRN]
  have hrem : inverseSineRowMass E.Q E.A 3 <
      productShellRow E 3 + 8 * (subcriticalN D : ℝ) /
        (7 * (E.Q : ℝ)) := by
    have hfac : 0 ≤ (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 := by positivity
    have hmul := mul_le_mul_of_nonneg_left hdist_sum hfac
    have hqne : (E.Q : ℝ) ≠ 0 := ne_of_gt hqR
    have heq : (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
          ((subcriticalN D : ℝ) * (E.Q : ℝ) / 2) =
        8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)) := by
      field_simp [hqne]
      ring
    calc
      inverseSineRowMass E.Q E.A 3 <
          productShellRow E 3 + (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
            ∑ b ∈ R, (productShellDistance E 3 b : ℝ) := hMupper
      _ ≤ productShellRow E 3 + (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
          ((subcriticalN D : ℝ) * (E.Q : ℝ) / 2) := by linarith
      _ = productShellRow E 3 + 8 * (subcriticalN D : ℝ) /
          (7 * (E.Q : ℝ)) := by rw [heq]
  have hHbound : productShellRow E 3 +
      8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)) ≤
      (1 / (3 : ℝ) + ((E.Q : ℝ) - 10) /
          ((2 * E.Q - 3 : ℤ) : ℝ) + 6 / ((E.Q : ℝ) - 3) +
        (badMinimumRowSum E : ℝ) *
          (1 / ((E.Q : ℝ) - 3) -
            1 / ((2 * E.Q - 3 : ℤ) : ℝ))) +
        8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)) := by
    have hh := add_le_add_right hHpromote
      (8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)))
    rw [hden2] at hh
    have hident :
        1 / (3 : ℝ) + ((E.Q : ℝ) - 10 -
            (badMinimumRowSum E : ℝ)) / (2 * (E.Q : ℝ) - 3) +
          ((badMinimumRowSum E : ℝ) + 6) / ((E.Q : ℝ) - 3) =
          1 / (3 : ℝ) + ((E.Q : ℝ) - 10) /
            (2 * (E.Q : ℝ) - 3) +
            6 / ((E.Q : ℝ) - 3) + (badMinimumRowSum E : ℝ) *
              (1 / ((E.Q : ℝ) - 3) -
                1 / (2 * (E.Q : ℝ) - 3)) := by
      ring
    rw [hident] at hh
    simpa [add_comm, add_left_comm, add_assoc] using hh
  have hMupper2 : inverseSineRowMass E.Q E.A 3 <
      1 / (3 : ℝ) + ((E.Q : ℝ) - 10) /
          ((2 * E.Q - 3 : ℤ) : ℝ) + 6 / ((E.Q : ℝ) - 3) +
        (badMinimumRowSum E : ℝ) *
          (1 / ((E.Q : ℝ) - 3) -
            1 / ((2 * E.Q - 3 : ℤ) : ℝ)) +
        8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)) := by
    exact lt_of_lt_of_le hrem hHbound
  have hbase : 1 / (3 : ℝ) + ((E.Q : ℝ) - 10) /
        ((2 * E.Q - 3 : ℤ) : ℝ) + 6 / ((E.Q : ℝ) - 3) +
      (badMinimumRowSum E : ℝ) *
        (1 / ((E.Q : ℝ) - 3) -
          1 / ((2 * E.Q - 3 : ℤ) : ℝ)) <
      5 / 6 + 4 / (E.Q : ℝ) +
        72 * (subcriticalN D : ℝ) / (35 * (E.Q : ℝ)) := by
    rw [hden2] at hWcoef'
    rw [hden2]
    linarith [hB, hWcoef']
  have hMbound : inverseSineRowMass E.Q E.A 3 <
      5 / 6 + 4 / (E.Q : ℝ) +
        72 * (subcriticalN D : ℝ) / (35 * (E.Q : ℝ)) +
        8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)) := by
    linarith [hMupper2, hbase]
  have hconst : 72 * (subcriticalN D : ℝ) /
        (35 * (E.Q : ℝ)) + 8 * (subcriticalN D : ℝ) /
        (7 * (E.Q : ℝ)) =
      16 * (subcriticalN D : ℝ) / (5 * (E.Q : ℝ)) := by ring
  have hMfinal : inverseSineRowMass E.Q E.A 3 <
      5 / 6 + (4 + 16 * (subcriticalN D : ℝ) / 5) /
        (E.Q : ℝ) := by
    calc
      inverseSineRowMass E.Q E.A 3 <
          5 / 6 + 4 / (E.Q : ℝ) +
            72 * (subcriticalN D : ℝ) / (35 * (E.Q : ℝ)) +
            8 * (subcriticalN D : ℝ) / (7 * (E.Q : ℝ)) := hMbound
      _ = 5 / 6 + (4 + 16 * (subcriticalN D : ℝ) / 5) /
          (E.Q : ℝ) := by
        field_simp [ne_of_gt hqR]
        ring
  have hpass3 : RowPasses E.Q E.A 3 := by
    exact hAll 3 h3E
  have hpass3' : (1 : ℝ) ≤ inverseSineRowMass E.Q E.A 3 := by
    exact hpass3
  have hfrac : (1 : ℝ) / 6 <
      (4 + 16 * (subcriticalN D : ℝ) / 5) / (E.Q : ℝ) := by
    have hh : (1 : ℝ) <
        5 / 6 + (4 + 16 * (subcriticalN D : ℝ) / 5) /
          (E.Q : ℝ) := lt_of_le_of_lt hpass3' hMfinal
    linarith
  have hmulQ := (lt_div_iff₀ hqR).1 hfrac
  have hQupper : (E.Q : ℝ) <
      24 + 96 * (subcriticalN D : ℝ) / 5 := by
    nlinarith only [hmulQ]
  let Bset : Finset ℤ := E.A.erase E.s
  have hBset2 : ∀ a ∈ Bset, (2 : ℤ) ≤ a := by
    intro a ha
    have ha' : a ∈ E.A.erase E.s := by simpa [Bset] using ha
    have haA := (Finset.mem_erase.mp ha').2
    have hamin := E.hs_min a haA
    have hne := (Finset.mem_erase.mp ha').1
    omega
  have hsum_arith (n : ℕ) :
      (∑ k ∈ Finset.range (n + 1), ((k : ℝ) + 2)) =
        ((n : ℝ) + 1) * ((n : ℝ) + 4) / 2 := by
    induction n with
    | zero => norm_num
    | succ n ih =>
        rw [Finset.sum_range_succ, ih]
        push_cast
        ring
  have hsumlower :
      ((Bset.card : ℝ) * ((Bset.card : ℝ) + 3)) / 2 ≤
        ∑ a ∈ Bset, (a : ℝ) := by
    classical
    by_cases hn : Bset.Nonempty
    · have hncard : Bset.card ≠ 0 := Finset.card_ne_zero.mpr hn
      obtain ⟨n, hcard⟩ := Nat.exists_eq_succ_of_ne_zero hncard
      let e : Fin (n + 1) ↪o ℤ := Bset.orderEmbOfFin hcard
      have he_mem (i : Fin (n + 1)) : e i ∈ Bset := by
        dsimp [e]
        exact Finset.orderEmbOfFin_mem Bset hcard i
      have he_lower : ∀ i : Fin (n + 1),
          (i.val : ℝ) + 2 ≤ (e i : ℝ) := by
        intro i
        induction i using Fin.induction with
        | zero =>
            exact_mod_cast hBset2 (e 0) (he_mem 0)
        | @succ i hi =>
            have hstepZ : e i.castSucc + 1 ≤ e i.succ := by
              have hlt := e.strictMono (Fin.castSucc_lt_succ (i := i))
              omega
            have hstep : (e i.castSucc : ℝ) + 1 ≤ (e i.succ : ℝ) := by
              exact_mod_cast hstepZ
            have hi' : (i.val : ℝ) + 2 ≤ (e i.castSucc : ℝ) := by
              simpa using hi
            have hnext : (i.val : ℝ) + 3 ≤ (e i.succ : ℝ) := by
              nlinarith [hi', hstep]
            norm_num [Fin.val_succ] at ⊢
            nlinarith [hnext]
      have hsum_image : (∑ a ∈ Bset, (a : ℝ)) =
          ∑ i : Fin (n + 1), (e i : ℝ) := by
        calc
          (∑ a ∈ Bset, (a : ℝ)) =
              ∑ a ∈ Finset.image e Finset.univ, (a : ℝ) := by
            rw [Finset.image_orderEmbOfFin_univ Bset hcard]
          _ = ∑ i ∈ (Finset.univ : Finset (Fin (n + 1))),
              (e i : ℝ) := by
            rw [Finset.sum_image]
            intro a ha b hb hab
            exact e.injective hab
          _ = ∑ i : Fin (n + 1), (e i : ℝ) := by simp
      have hsum_lower : (∑ i : Fin (n + 1), ((i.val : ℝ) + 2)) ≤
          ∑ i : Fin (n + 1), (e i : ℝ) := by
        exact Finset.sum_le_sum (fun i hi => he_lower i)
      rw [← hsum_image] at hsum_lower
      have hsum_index :
          (∑ i : Fin (n + 1), ((i.val : ℝ) + 2)) =
            ∑ k ∈ Finset.range (n + 1), ((k : ℝ) + 2) := by
        convert (Fin.sum_univ_eq_sum_range
          (fun k : ℕ => (k : ℝ) + 2) (n + 1)) using 1 <;> simp
      rw [hsum_index, hsum_arith n] at hsum_lower
      have hcardR : (Bset.card : ℝ) = (n + 1 : ℕ) := by
        exact_mod_cast hcard
      rw [hcardR]
      convert hsum_lower using 1 <;> push_cast <;> ring
    · have hzero : Bset = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
      simp [hzero]
  have hcardB : Bset.card = minimumRowN E := by
    dsimp [Bset, minimumRowN]
    exact Finset.card_erase_of_mem E.hs_mem
  have hcardBN : (Bset.card : ℝ) = (subcriticalN D : ℝ) := by
    rw [hcardB, hn]
  have hsum_erase :
      (∑ a ∈ Bset, (a : ℝ)) + 1 = ∑ a ∈ E.A, (a : ℝ) := by
    have hh := Finset.sum_erase_add E.A (fun a : ℤ => (a : ℝ)) E.hs_mem
    have hsR : (E.s : ℝ) = 1 := by exact_mod_cast hs
    dsimp [Bset]
    calc
      (∑ a ∈ E.A.erase E.s, (a : ℝ)) + 1 =
          (∑ a ∈ E.A.erase E.s, (a : ℝ)) + (E.s : ℝ) := by rw [hsR]
      _ = ∑ a ∈ E.A, (a : ℝ) := hh
  have htri :
      ((subcriticalN D : ℝ) + 1) * ((subcriticalN D : ℝ) + 2) / 2 ≤
        (E.Q : ℝ) := by
    rw [hcardBN] at hsumlower
    linarith only [hsumlower, hsum_erase, hsumA]
  have hnleR : (subcriticalN D : ℝ) ≤ 36 := by
    by_contra hnot
    have hnotZ : ¬ subcriticalN D ≤ 36 := by
      intro hnZ
      have hnR : (subcriticalN D : ℝ) ≤ 36 := by exact_mod_cast hnZ
      exact hnot hnR
    have hn37Z : 37 ≤ subcriticalN D := by omega
    have hn37R : (37 : ℝ) ≤ (subcriticalN D : ℝ) := by
      exact_mod_cast hn37Z
    have hquad0 : 0 ≤ ((subcriticalN D : ℝ) - 37) *
        (subcriticalN D : ℝ) := by
      apply mul_nonneg
      · linarith
      · exact le_of_lt hNposR
    have hquad : 37 * (subcriticalN D : ℝ) ≤
        (subcriticalN D : ℝ) ^ 2 := by
      nlinarith only [hquad0]
    nlinarith only [htri, hQupper, hquad, hn37R]
  have hQ715R : (E.Q : ℝ) < 3576 / 5 := by
    nlinarith only [hQupper, hnleR]
  have hQle : E.Q ≤ 715 := by
    by_contra hnot
    have h716 : 716 ≤ E.Q := by omega
    have h716R : (716 : ℝ) ≤ (E.Q : ℝ) := by exact_mod_cast h716
    nlinarith only [hQ715R, h716R]
  have hnleNat : subcriticalN D ≤ 36 := by exact_mod_cast hnleR
  have hQleD : D.toMinimumRowSlackData.Q ≤ 715 := by
    simpa [E] using hQle
  exact ⟨hnleNat, hQleD⟩

/-- If `2` is present, `3` absent, and every selected good element is dyadic,
the subcritical data satisfy the smaller bound. -/
-- zpi: lem-no-nondyadic-good-element
theorem noNondyadicGoodElement (D : SEqualsOneSubcriticalData)
    (h2 : 2 ∈ D.toMinimumRowSlackData.A)
    (h3 : 3 ∉ D.toMinimumRowSlackData.A)
    (hDyadic : ∀ a ∈ D.toMinimumRowSlackData.A,
      1 < a → GoodMinimumRowElement D.toMinimumRowSlackData a →
        ∃ k : ℕ, a = (2 : ℤ) ^ k)
    (hAll : ∀ a ∈ D.toMinimumRowSlackData.A,
      RowPasses D.toMinimumRowSlackData.Q D.toMinimumRowSlackData.A a) :
    subcriticalN D ≤ 17 ∧ D.toMinimumRowSlackData.Q ≤ 171 := by
  classical
  let E : MinimumRowSlackData := D.toMinimumRowSlackData
  have hs : E.s = 1 := D.hs_one
  have hQ : 2 ≤ E.Q := by
    have h := E.hQ
    omega
  have h2E : (2 : ℤ) ∈ E.A := by simpa [E] using h2
  have hcop2 : Int.gcd (2 : ℤ) E.Q = 1 := by
    simpa [E] using E.hA.1 2 h2E |>.2
  have hodd : ∃ k : ℤ, E.Q = 2 * k + 1 := by
    obtain ⟨k, hk | hk⟩ := Int.even_or_odd' E.Q
    · exfalso
      have hd2 : (2 : ℤ) ∣ E.Q := by
        refine ⟨k, ?_⟩
        exact hk
      have hd2self : (2 : ℤ) ∣ (2 : ℤ) := by exact ⟨1, by ring⟩
      have hdg : (2 : ℕ) ∣ Int.gcd 2 E.Q := Int.dvd_gcd hd2self hd2
      rw [hcop2] at hdg
      omega
    · exact ⟨k, hk⟩
  have hgood2 : GoodMinimumRowElement E 2 := by
    left
    rcases hodd with ⟨k, hk⟩
    refine ⟨k, ?_⟩
    rw [hs]
    omega
  let Good : Finset ℤ := selectedGoodElements D
  have hGood2 : (2 : ℤ) ∈ Good := by
    dsimp [Good, selectedGoodElements]
    simp only [Finset.mem_filter]
    refine ⟨h2, ?_, ?_⟩
    · omega
    · simpa [E] using hgood2
  have hGoodne : Good.Nonempty := ⟨2, hGood2⟩
  let L : ℤ := Good.max' hGoodne
  have hLmem : L ∈ Good := by
    dsimp [L]
    exact Finset.max'_mem Good hGoodne
  have hL_A : L ∈ E.A := by
    have := (Finset.mem_filter.mp hLmem).1
    simpa [Good, selectedGoodElements, E] using this
  have hL_gt : 1 < L := by
    have := (Finset.mem_filter.mp hLmem).2.1
    simpa [Good, selectedGoodElements] using this
  have hL_good : GoodMinimumRowElement E L := by
    have := (Finset.mem_filter.mp hLmem).2.2
    simpa [Good, selectedGoodElements, E] using this
  obtain ⟨K, hKL⟩ := hDyadic L (by simpa [E] using hL_A) hL_gt hL_good
  let Pow : Finset ℤ := (Finset.range (K + 1)).image (fun j : ℕ => (2 : ℤ) ^ j)
  have hGood_sub : Good ⊆ Pow := by
    intro a ha
    have ha0 := Finset.mem_filter.mp ha
    have haA : a ∈ E.A := by simpa [Good, selectedGoodElements, E] using ha0.1
    have ha_gt : 1 < a := ha0.2.1
    have ha_good : GoodMinimumRowElement E a := by
      simpa [Good, selectedGoodElements, E] using ha0.2.2
    obtain ⟨j, hj⟩ := hDyadic a (by simpa [E] using haA) ha_gt ha_good
    have hjK : j ≤ K := by
      have haL : a ≤ L := Finset.le_max' Good a ha
      by_contra hnot
      have hKj : K < j := by omega
      have hp : (2 : ℤ) ^ K < (2 : ℤ) ^ j :=
        pow_lt_pow_right₀ (by norm_num) hKj
      rw [← hKL, ← hj] at hp
      omega
    apply Finset.mem_image.mpr
    exact ⟨j, Finset.mem_range.mpr (by omega), hj.symm⟩
  have hPow_inj : Function.Injective (fun j : ℕ => (2 : ℤ) ^ j) := by
    exact pow_right_injective₀ (by norm_num) (by norm_num)
  have honePow : (1 : ℤ) ∈ Pow := by
    exact Finset.mem_image.mpr ⟨0, Finset.mem_range.mpr (by omega), by simp⟩
  have hGood_sub_erase : Good ⊆ Pow.erase 1 := by
    intro a ha
    have hagt : 1 < a := (Finset.mem_filter.mp ha).2.1
    exact Finset.mem_erase.mpr ⟨by omega, hGood_sub ha⟩
  have hsumGoodInt : 1 + (∑ a ∈ Good, a) ≤ ∑ p ∈ Pow, p := by
    have hle : (∑ a ∈ Good, a) ≤ ∑ p ∈ Pow.erase 1, p := by
      apply Finset.sum_le_sum_of_subset_of_nonneg hGood_sub_erase
      intro p hp hnot
      obtain ⟨j, hj, rfl⟩ := Finset.mem_image.mp (Finset.mem_erase.mp hp).2
      positivity
    have heq := Finset.sum_erase_add Pow (fun a : ℤ => a) honePow
    have heq' : (∑ p ∈ Pow.erase 1, p) + 1 = ∑ p ∈ Pow, p := by
      simpa [add_comm] using heq
    linarith
  have hsumPow : (∑ p ∈ Pow, p) = ∑ j ∈ Finset.range (K + 1), (2 : ℤ) ^ j := by
    dsimp [Pow]
    rw [Finset.sum_image]
    intro a ha b hb hab
    exact hPow_inj hab
  have hgeom : (∑ j ∈ Finset.range (K + 1), (2 : ℤ) ^ j) =
      (2 : ℤ) ^ (K + 1) - 1 := by
    have hh := geom_sum_mul (2 : ℤ) (K + 1)
    norm_num at hh ⊢
    nlinarith
  have hsumGoodBound : 1 + (∑ a ∈ Good, a) ≤ 2 * L - 1 := by
    calc
      1 + (∑ a ∈ Good, a) ≤ ∑ p ∈ Pow, p := hsumGoodInt
      _ = ∑ j ∈ Finset.range (K + 1), (2 : ℤ) ^ j := hsumPow
      _ = (2 : ℤ) ^ (K + 1) - 1 := hgeom
      _ = 2 * L - 1 := by rw [pow_succ, hKL]; ring
  let A1 : Finset ℤ := E.A.erase E.s
  let Bad : Finset ℤ := A1.filter (fun a => ¬ GoodMinimumRowElement E a)
  have hGood_eq : Good = A1.filter (fun a => GoodMinimumRowElement E a) := by
    ext a
    constructor
    · intro ha
      have ha0 := Finset.mem_filter.mp ha
      have haA : a ∈ E.A := by simpa [Good, selectedGoodElements, E] using ha0.1
      have ha_gt : 1 < a := ha0.2.1
      have ha_good : GoodMinimumRowElement E a := by
        simpa [Good, selectedGoodElements, E] using ha0.2.2
      have hane : a ≠ E.s := by
        intro hae
        rw [hs] at hae
        omega
      exact Finset.mem_filter.mpr
        ⟨Finset.mem_erase.mpr ⟨hane, haA⟩, ha_good⟩
    · intro ha
      have ha0 := Finset.mem_filter.mp ha
      have haA0 := Finset.mem_erase.mp ha0.1
      have haA : a ∈ E.A := haA0.2
      have hamin := E.hs_min a haA
      have ha_gt : 1 < a := by rw [← hs]; omega
      exact Finset.mem_filter.mpr ⟨haA, ha_gt, ha0.2⟩
  have hBadEq : A1.filter (fun a => BadMinimumRowElement E a) = Bad := by
    ext a
    simp [Bad, BadMinimumRowElement]
  have hbad_int : badMinimumRowSum E = ∑ a ∈ Bad, a := by
    calc
      badMinimumRowSum E =
          ∑ a ∈ A1.filter (fun a => BadMinimumRowElement E a), a := by
        dsimp [badMinimumRowSum]
        symm
        exact Finset.sum_filter (fun a => BadMinimumRowElement E a)
          (fun a : ℤ => a)
      _ = ∑ a ∈ Bad, a := by rw [hBadEq]
  have hsum_A1 : (∑ a ∈ A1, a) =
      (∑ a ∈ A1.filter (fun a => GoodMinimumRowElement E a), a) +
        ∑ a ∈ Bad, a := by
    have hh := (Finset.sum_filter_add_sum_filter_not A1
      (fun a : ℤ => GoodMinimumRowElement E a) (fun a => a)).symm
    simpa [Bad] using hh
  have hsum_erase : (∑ a ∈ A1, a) + 1 = ∑ a ∈ E.A, a := by
    have hh := Finset.sum_erase_add E.A (fun a : ℤ => a) E.hs_mem
    simpa [A1, hs] using hh
  have hsum_partition : (∑ a ∈ E.A, a) =
      1 + (∑ a ∈ Good, a) + badMinimumRowSum E := by
    rw [← hsum_erase]
    rw [hsum_A1, ← hGood_eq]
    rw [hbad_int]
    ring
  have hmain := sEqualsOneMinimumRow D (hAll E.s E.hs_mem)
  have hR : (subcriticalR D : ℝ) < 8 * (subcriticalN D : ℝ) / 7 := hmain.1
  have hW : (badMinimumRowSum E : ℝ) < 16 * (subcriticalN D : ℝ) / 7 := hmain.2.1
  have hG : (1 : ℝ) + ((∑ a ∈ Good, a : ℤ) : ℝ) ≤ 2 * (L : ℝ) - 1 := by
    exact_mod_cast hsumGoodBound
  have hLupper : 3 * (L : ℝ) < (E.Q : ℝ) := by
    exact_mod_cast E.hA_upper L hL_A
  have hpartition : (E.Q : ℝ) = 1 + ((∑ a ∈ Good, a : ℤ) : ℝ) +
      (badMinimumRowSum E : ℝ) + (subcriticalR D : ℝ) := by
    have hh : E.Q = 1 + (∑ a ∈ Good, a) + badMinimumRowSum E +
        subcriticalR D := by
      dsimp [subcriticalR]
      change E.Q = 1 + (∑ a ∈ Good, a) + badMinimumRowSum E +
        (E.Q - ∑ a ∈ E.A, a)
      rw [hsum_partition]
      ring
    exact_mod_cast hh
  have hQupper : (E.Q : ℝ) < 72 * (subcriticalN D : ℝ) / 7 - 3 := by
    linarith only [hpartition, hLupper, hG, hW, hR]
  have hA1_lower : ∀ a ∈ A1, (2 : ℤ) ≤ a := by
    intro a ha
    have ha0 := Finset.mem_erase.mp ha
    have hamin := E.hs_min a ha0.2
    omega
  have hsum_arith (n : ℕ) :
      (∑ k ∈ Finset.range (n + 1), ((k : ℝ) + 2)) =
        ((n : ℝ) + 1) * ((n : ℝ) + 4) / 2 := by
    induction n with
    | zero => norm_num
    | succ n ih =>
        rw [Finset.sum_range_succ, ih]
        push_cast
        ring
  have hsumlower :
      ((A1.card : ℝ) * ((A1.card : ℝ) + 3)) / 2 ≤
        ∑ a ∈ A1, (a : ℝ) := by
    classical
    by_cases hn : A1.Nonempty
    · have hncard : A1.card ≠ 0 := Finset.card_ne_zero.mpr hn
      obtain ⟨n, hcard⟩ := Nat.exists_eq_succ_of_ne_zero hncard
      let e : Fin (n + 1) ↪o ℤ := A1.orderEmbOfFin hcard
      have he_mem (i : Fin (n + 1)) : e i ∈ A1 := by
        dsimp [e]
        exact Finset.orderEmbOfFin_mem A1 hcard i
      have he_lower : ∀ i : Fin (n + 1),
          (i.val : ℝ) + 2 ≤ (e i : ℝ) := by
        intro i
        induction i using Fin.induction with
        | zero =>
            exact_mod_cast hA1_lower (e 0) (he_mem 0)
        | @succ i hi =>
            have hstepZ : e i.castSucc + 1 ≤ e i.succ := by
              have hlt := e.strictMono (Fin.castSucc_lt_succ (i := i))
              omega
            have hstep : (e i.castSucc : ℝ) + 1 ≤ (e i.succ : ℝ) := by
              exact_mod_cast hstepZ
            have hi' : (i.val : ℝ) + 2 ≤ (e i.castSucc : ℝ) := by
              simpa using hi
            have hnext : (i.val : ℝ) + 3 ≤ (e i.succ : ℝ) := by
              nlinarith [hi', hstep]
            norm_num [Fin.val_succ] at ⊢
            nlinarith [hnext]
      have hsum_image : (∑ a ∈ A1, (a : ℝ)) =
          ∑ i : Fin (n + 1), (e i : ℝ) := by
        calc
          (∑ a ∈ A1, (a : ℝ)) =
              ∑ a ∈ Finset.image e Finset.univ, (a : ℝ) := by
            rw [Finset.image_orderEmbOfFin_univ A1 hcard]
          _ = ∑ i ∈ (Finset.univ : Finset (Fin (n + 1))),
              (e i : ℝ) := by
            rw [Finset.sum_image]
            intro a ha b hb hab
            exact e.injective hab
          _ = ∑ i : Fin (n + 1), (e i : ℝ) := by simp
      have hsum_lower : (∑ i : Fin (n + 1), ((i.val : ℝ) + 2)) ≤
          ∑ i : Fin (n + 1), (e i : ℝ) := by
        exact Finset.sum_le_sum (fun i hi => he_lower i)
      rw [← hsum_image] at hsum_lower
      have hsum_index :
          (∑ i : Fin (n + 1), ((i.val : ℝ) + 2)) =
            ∑ k ∈ Finset.range (n + 1), ((k : ℝ) + 2) := by
        convert (Fin.sum_univ_eq_sum_range
          (fun k : ℕ => (k : ℝ) + 2) (n + 1)) using 1 <;> simp
      rw [hsum_index, hsum_arith n] at hsum_lower
      have hcardR : (A1.card : ℝ) = (n + 1 : ℕ) := by
        exact_mod_cast hcard
      rw [hcardR]
      convert hsum_lower using 1 <;> push_cast <;> ring
    · have hzero : A1 = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
      simp [hzero]
  have hcard : A1.card = subcriticalN D := by
    change (E.A.erase E.s).card = E.A.card - 1
    exact Finset.card_erase_of_mem E.hs_mem
  have hsumA : (∑ a ∈ E.A, (a : ℝ)) ≤ (E.Q : ℝ) := by
    rw [← Int.cast_sum]
    exact_mod_cast E.hA_sum
  have hsum_eraseR : (∑ a ∈ A1, (a : ℝ)) + 1 =
      ∑ a ∈ E.A, (a : ℝ) := by
    rw [← Int.cast_sum, ← Int.cast_sum]
    exact_mod_cast hsum_erase
  have htri : ((subcriticalN D : ℝ) + 1) *
      ((subcriticalN D : ℝ) + 2) / 2 ≤ (E.Q : ℝ) := by
    rw [hcard] at hsumlower
    linarith only [hsumlower, hsum_eraseR, hsumA]
  have hnle : subcriticalN D ≤ 17 := by
    by_contra hnot
    have hn18 : 18 ≤ subcriticalN D := by omega
    have hn18R : (18 : ℝ) ≤ (subcriticalN D : ℝ) := by exact_mod_cast hn18
    have hquad0 : 0 ≤ ((subcriticalN D : ℝ) - 18) * (subcriticalN D : ℝ) :=
      mul_nonneg (by linarith) (by positivity)
    nlinarith only [htri, hQupper, hn18R, hquad0]
  have hnleR : (subcriticalN D : ℝ) ≤ 17 := by exact_mod_cast hnle
  have hQ172 : (E.Q : ℝ) < 172 := by linarith only [hQupper, hnleR]
  have hQle : E.Q ≤ 171 := by
    have hQlt : E.Q < 172 := by exact_mod_cast hQ172
    omega
  exact ⟨hnle, hQle⟩

end Fraenkel
