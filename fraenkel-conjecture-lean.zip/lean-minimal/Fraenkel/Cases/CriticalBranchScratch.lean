import Fraenkel.Cases.MinimumOneBranches

namespace Fraenkel

open scoped BigOperators Classical

set_option maxHeartbeats 1000000

theorem cPoint2Scratch (K y k t eps ell d eta : ℤ)
    (hK3 : 3 ≤ K) (hkpos : 1 ≤ k) (hklt : k < y)
    (heta : eta = 1 ∨ eta = -1)
    (heps : eps = 1 ∨ eps = -1)
    (hrel : ell * y + eta = t * k + eps)
    (hKt : K = ell + t)
    (hdist : d = ell * y + eta) :
    k * (K - 2) < 2 * d := by
  have heta_low : -1 ≤ eta := by rcases heta with rfl | rfl <;> omega
  have heps_low : -1 ≤ eps := by rcases heps with rfl | rfl <;> omega
  have hidentity : (y + k) *
        (2 * (ell * y + eta) - k * (K - 2)) =
      K * k * (y - k) + 2 * k * (y + k) +
        2 * k * eta + 2 * eps * y := by
    rw [hKt]
    linear_combination 2 * y * hrel
  have htermpos : 0 < K * k * (y - k) := by
    have hKpos : 0 < K := by omega
    have hkm : 0 < y - k := by omega
    positivity
  have hsecondnonneg : 0 ≤ 2 * (k - 1) * (y + k) := by
    have hk1 : 0 ≤ k - 1 := by omega
    have hyk : 0 ≤ y + k := by omega
    have htwo : (0 : ℤ) ≤ 2 := by omega
    have hleft : (0 : ℤ) ≤ 2 * (k - 1) :=
      mul_nonneg htwo hk1
    exact mul_nonneg hleft hyk
  have heta_term : -2 * k ≤ 2 * k * eta := by
    rcases heta with h | h
    · subst eta
      omega
    · subst eta
      omega
  have heps_term : -2 * y ≤ 2 * eps * y := by
    rcases heps with h | h
    · subst eps
      omega
    · subst eps
      omega
  have hlow : 2 * (k - 1) * (y + k) ≤
      2 * k * (y + k) + 2 * k * eta + 2 * eps * y := by
    nlinarith [heta_term, heps_term]
  have hrhspos : 0 < K * k * (y - k) + 2 * k * (y + k) +
        2 * k * eta + 2 * eps * y := by
    nlinarith [htermpos, hsecondnonneg, hlow]
  have hinner : 0 < 2 * (ell * y + eta) - k * (K - 2) := by
    by_contra hnot
    have hinner0 : 2 * (ell * y + eta) - k * (K - 2) ≤ 0 := by omega
    have hprod : (y + k) *
        (2 * (ell * y + eta) - k * (K - 2)) ≤ 0 :=
      mul_nonpos_of_nonneg_of_nonpos (by omega) hinner0
    nlinarith [hidentity, hrhspos, hprod]
  rw [hdist]
  nlinarith [hinner, hrel]

noncomputable def harmonicNumberScratch (j : ℕ) : ℝ :=
  ∑ n ∈ Finset.range j, (1 : ℝ) / (n + 1 : ℝ)

theorem cSecondBoundScratch (C : Finset ℤ) (K y : ℤ) (dist : ℤ → ℤ) (f : ℤ → ℝ)
    (hy : 3 ≤ y) (hK : 3 ≤ K) (κ : ℤ → ℤ)
    (hkpos : ∀ b ∈ C, 1 ≤ κ b)
    (hklt : ∀ b ∈ C, κ b < y)
    (hbrel : ∀ b ∈ C, b = y + κ b)
    (hκinj : ∀ a ∈ C, ∀ b ∈ C, κ a = κ b → a = b)
    (hdpos : ∀ b ∈ C, 0 < dist b)
    (hpoint : ∀ b ∈ C, κ b * (K - 2) < 2 * dist b)
    (hf : ∀ b ∈ C, f b = 1 / (dist b : ℝ)) :
    (∑ b ∈ C, f b) <
      2 * harmonicNumberScratch ((y - 1).natAbs) / (K - 2) := by
  let nfun : ℤ → ℕ := fun b => (κ b - 1).toNat
  let N : Finset ℕ := C.image nfun
  have hnnonneg (b : ℤ) (hb : b ∈ C) : 0 ≤ κ b - 1 := by
    have hh := hkpos b hb
    omega
  have hncast (b : ℤ) (hb : b ∈ C) :
      ((nfun (b : ℤ) : ℕ) : ℤ) = κ b - 1 := by
    dsimp [nfun]
    exact Int.toNat_of_nonneg (hnnonneg b hb)
  have hninj : ∀ a ∈ C, ∀ b ∈ C, nfun a = nfun b → a = b := by
    intro a ha b hb hab
    have habZ := congrArg (fun n : ℕ => (n : ℤ)) hab
    have hEq : κ a - 1 = κ b - 1 := by
      calc
        κ a - 1 = ((nfun (a : ℤ) : ℕ) : ℤ) := (hncast a ha).symm
        _ = ((nfun (b : ℤ) : ℕ) : ℤ) := habZ
        _ = κ b - 1 := hncast b hb
    apply hκinj a ha b hb
    omega
  have hNsub : N ⊆ Finset.range (y - 1).natAbs := by
    intro n hn
    obtain ⟨b, hb, rfl⟩ := Finset.mem_image.mp hn
    apply Finset.mem_range.mpr
    have hYnonneg : 0 ≤ y - 1 := by omega
    have hYcast : ((y - 1).natAbs : ℤ) = y - 1 :=
      Int.natAbs_of_nonneg hYnonneg
    have hnk : (nfun (b : ℤ) : ℕ) < (y - 1).natAbs := by
      rw [← Int.ofNat_lt]
      rw [hncast b hb, hYcast]
      have hh := hklt b hb
      omega
    exact hnk
  have hCsum : (∑ b ∈ C, f b) ≤
      ∑ n ∈ N, 2 / (((n : ℝ) + 1) * (K - 2)) := by
    calc
      (∑ b ∈ C, f b) ≤
          ∑ b ∈ C, 2 / ((κ b : ℝ) * (K - 2)) := by
            apply Finset.sum_le_sum
            intro b hb
            rw [hf b hb]
            have hkR : (0 : ℝ) < κ b := by
              have hh := hkpos b hb
              exact_mod_cast (show 0 < κ b by omega)
            have hKR : (0 : ℝ) < K - 2 := by exact_mod_cast (by omega : 0 < K - 2)
            have hdR : (0 : ℝ) < dist b := by exact_mod_cast (hdpos b hb)
            have hpR : (κ b : ℝ) * (K - 2) < 2 * dist b := by
              exact_mod_cast hpoint b hb
            apply (div_le_div_iff₀ hdR (mul_pos hkR hKR)).2
            nlinarith
      _ = ∑ n ∈ N, 2 / (((n : ℝ) + 1) * (K - 2)) := by
        rw [Finset.sum_image]
        · apply Finset.sum_congr rfl
          intro b hb
          have hcast : ((nfun (b : ℤ) : ℕ) : ℝ) + 1 = (κ b : ℝ) := by
            have hh : ((nfun (b : ℤ) : ℕ) : ℤ) + 1 = κ b := by
              rw [hncast b hb]
              omega
            exact_mod_cast hh
          rw [hcast]
        · intro a ha b hb hab
          exact hninj a ha b hb hab
  have hNsum : (∑ n ∈ N, 2 / (((n : ℝ) + 1) * (K - 2))) ≤
      ∑ n ∈ Finset.range (y - 1).natAbs,
        2 / (((n : ℝ) + 1) * (K - 2)) := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hNsub
    intro n hn hnot
    have hKR : (0 : ℝ) < K - 2 := by exact_mod_cast (by omega : 0 < K - 2)
    positivity
  have hfull :
      (∑ n ∈ Finset.range (y - 1).natAbs,
        2 / (((n : ℝ) + 1) * (K - 2))) =
        2 * harmonicNumberScratch ((y - 1).natAbs) / (K - 2) := by
    dsimp [harmonicNumberScratch]
    calc
      (∑ n ∈ Finset.range (y - 1).natAbs,
          2 / (((n : ℝ) + 1) * (K - 2))) =
          ∑ n ∈ Finset.range (y - 1).natAbs,
            (2 / (K - 2)) * (1 / (n + 1 : ℝ)) := by
              apply Finset.sum_congr rfl
              intro n hn
              field_simp
      _ = (2 / (K - 2)) *
            (∑ n ∈ Finset.range (y - 1).natAbs,
              1 / (n + 1 : ℝ)) := by
              rw [Finset.mul_sum]
      _ = 2 * (∑ n ∈ Finset.range (y - 1).natAbs,
              1 / (n + 1 : ℝ)) / (K - 2) := by ring
  have hterm_strict (b : ℤ) (hb : b ∈ C) :
      f b < 2 / ((κ b : ℝ) * (K - 2)) := by
    rw [hf b hb]
    have hkR : (0 : ℝ) < κ b := by
      have hh := hkpos b hb
      exact_mod_cast (show 0 < κ b by omega)
    have hKR : (0 : ℝ) < K - 2 := by exact_mod_cast (by omega : 0 < K - 2)
    have hdR : (0 : ℝ) < dist b := by exact_mod_cast (hdpos b hb)
    have hpR : (κ b : ℝ) * (K - 2) < 2 * dist b := by
      exact_mod_cast hpoint b hb
    apply (div_lt_div_iff₀ hdR (mul_pos hkR hKR)).2
    nlinarith
  by_cases hCne : C.Nonempty
  · have hstrict : (∑ b ∈ C, f b) <
        ∑ b ∈ C, 2 / ((κ b : ℝ) * (K - 2)) := by
      exact Finset.sum_lt_sum_of_nonempty hCne hterm_strict
    calc
      (∑ b ∈ C, f b) <
          ∑ b ∈ C, 2 / ((κ b : ℝ) * (K - 2)) := hstrict
      _ = ∑ n ∈ N, 2 / (((n : ℝ) + 1) * (K - 2)) := by
        rw [Finset.sum_image]
        · apply Finset.sum_congr rfl
          intro b hb
          have hcast : ((nfun (b : ℤ) : ℕ) : ℝ) + 1 = (κ b : ℝ) := by
            have hh : ((nfun (b : ℤ) : ℕ) : ℤ) + 1 = κ b := by
              rw [hncast b hb]
              omega
            exact_mod_cast hh
          rw [hcast]
        · intro a ha b hb hab
          exact hninj a ha b hb hab
      _ ≤ ∑ n ∈ Finset.range (y - 1).natAbs,
          2 / (((n : ℝ) + 1) * (K - 2)) := hNsum
      _ = 2 * harmonicNumberScratch ((y - 1).natAbs) / (K - 2) := hfull
  · have hCempty : C = ∅ := Finset.not_nonempty_iff_eq_empty.mp hCne
    simp [hCempty]
    have hYpos : 0 < (y - 1).natAbs := by
      have hYcast : ((y - 1).natAbs : ℤ) = y - 1 :=
        Int.natAbs_of_nonneg (by omega)
      omega
    have hHpos : 0 <
        ∑ n ∈ Finset.range (y - 1).natAbs, 1 / (n + 1 : ℝ) := by
      apply Finset.sum_pos'
      · intro n hn
        positivity
      · refine ⟨0, Finset.mem_range.mpr hYpos, ?_⟩
        norm_num
    have hnum : 0 < (2 : ℝ) *
        (∑ n ∈ Finset.range (y - 1).natAbs, 1 / (n + 1 : ℝ)) :=
      mul_pos (by norm_num) hHpos
    have hden : (0 : ℝ) < K - 2 := by
      exact_mod_cast (by omega : 0 < K - 2)
    exact div_pos hnum hden

theorem ellBoundScratch (S : Finset ℤ) (K y eta : ℤ) (dist : ℤ → ℤ) (f : ℤ → ℝ)
    (hy : 2 ≤ y) (hK : 3 ≤ K) (heta : eta = 1 ∨ eta = -1)
    (ellfun : ℤ → ℤ)
    (hellpos : ∀ b ∈ S, 1 ≤ ellfun b)
    (hellupper : ∀ b ∈ S, ellfun b ≤ K - 1)
    (hellinj : ∀ a ∈ S, ∀ b ∈ S, ellfun a = ellfun b → a = b)
    (hdist : ∀ b ∈ S, dist b = ellfun b * y + eta)
    (hdpos : ∀ b ∈ S, 0 < dist b)
    (hf : ∀ b ∈ S, f b = 1 / (dist b : ℝ)) :
    (∑ b ∈ S, f b) ≤
      harmonicNumberScratch ((K - 1).natAbs) / (y - 1) := by
  let nfun : ℤ → ℕ := fun b => (ellfun b - 1).toNat
  let N : Finset ℕ := S.image nfun
  have hnnonneg (b : ℤ) (hb : b ∈ S) : 0 ≤ ellfun b - 1 := by
    have hh := hellpos b hb
    omega
  have hncast (b : ℤ) (hb : b ∈ S) :
      ((nfun (b : ℤ) : ℕ) : ℤ) = ellfun b - 1 := by
    dsimp [nfun]
    exact Int.toNat_of_nonneg (hnnonneg b hb)
  have hninj : ∀ a ∈ S, ∀ b ∈ S, nfun a = nfun b → a = b := by
    intro a ha b hb hab
    have habZ := congrArg (fun n : ℕ => (n : ℤ)) hab
    have hEq : ellfun a - 1 = ellfun b - 1 := by
      calc
        ellfun a - 1 = ((nfun (a : ℤ) : ℕ) : ℤ) := (hncast a ha).symm
        _ = ((nfun (b : ℤ) : ℕ) : ℤ) := habZ
        _ = ellfun b - 1 := hncast b hb
    apply hellinj a ha b hb
    omega
  have hNsub : N ⊆ Finset.range (K - 1).natAbs := by
    intro n hn
    obtain ⟨b, hb, rfl⟩ := Finset.mem_image.mp hn
    apply Finset.mem_range.mpr
    have hYnonneg : 0 ≤ K - 1 := by omega
    have hYcast : ((K - 1).natAbs : ℤ) = K - 1 :=
      Int.natAbs_of_nonneg hYnonneg
    have hnk : (nfun (b : ℤ) : ℕ) < (K - 1).natAbs := by
      rw [← Int.ofNat_lt]
      rw [hncast b hb, hYcast]
      have hh := hellupper b hb
      omega
    exact hnk
  have hSsum : (∑ b ∈ S, f b) ≤
      ∑ n ∈ N, 1 / (((n : ℝ) + 1) * (y - 1)) := by
    calc
      (∑ b ∈ S, f b) ≤
          ∑ b ∈ S, 1 / ((ellfun b : ℝ) * (y - 1)) := by
            apply Finset.sum_le_sum
            intro b hb
            rw [hf b hb]
            have hellR : (0 : ℝ) < ellfun b := by
              have hh := hellpos b hb
              exact_mod_cast (show 0 < ellfun b by omega)
            have hyR : (0 : ℝ) < y - 1 := by
              exact_mod_cast (show 0 < y - 1 by omega)
            have hdR : (0 : ℝ) < dist b := by exact_mod_cast (hdpos b hb)
            have hdlowZ : ellfun b * (y - 1) ≤ dist b := by
              rw [hdist b hb]
              have heta_low : -1 ≤ eta := by rcases heta with rfl | rfl <;> omega
              have hneg : -ellfun b ≤ eta := by
                have hh := hellpos b hb
                omega
              calc
                ellfun b * (y - 1) = ellfun b * y - ellfun b := by ring
                _ ≤ ellfun b * y + eta := by omega
            have hdlow : (ellfun b : ℝ) * (y - 1) ≤ (dist b : ℝ) := by
              exact_mod_cast hdlowZ
            apply (div_le_div_iff₀ hdR (mul_pos hellR hyR)).2
            simpa using hdlow
      _ = ∑ n ∈ N, 1 / (((n : ℝ) + 1) * (y - 1)) := by
        rw [Finset.sum_image]
        · apply Finset.sum_congr rfl
          intro b hb
          have hcast : ((nfun (b : ℤ) : ℕ) : ℝ) + 1 = (ellfun b : ℝ) := by
            have hh : ((nfun (b : ℤ) : ℕ) : ℤ) + 1 = ellfun b := by
              rw [hncast b hb]
              omega
            exact_mod_cast hh
          rw [hcast]
        · intro a ha b hb hab
          exact hninj a ha b hb hab
  have hNsum : (∑ n ∈ N, 1 / (((n : ℝ) + 1) * (y - 1))) ≤
      ∑ n ∈ Finset.range (K - 1).natAbs,
        1 / (((n : ℝ) + 1) * (y - 1)) := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hNsub
    intro n hn hnot
    have hyR : (0 : ℝ) < y - 1 := by
      exact_mod_cast (show 0 < y - 1 by omega)
    positivity
  calc
    (∑ b ∈ S, f b) ≤
        ∑ n ∈ Finset.range (K - 1).natAbs,
          1 / (((n : ℝ) + 1) * (y - 1)) := hSsum.trans hNsum
    _ = harmonicNumberScratch ((K - 1).natAbs) / (y - 1) := by
      dsimp [harmonicNumberScratch]
      calc
        (∑ n ∈ Finset.range (K - 1).natAbs,
            1 / (((n : ℝ) + 1) * (y - 1))) =
            ∑ n ∈ Finset.range (K - 1).natAbs,
              (1 / (n + 1 : ℝ)) / (y - 1) := by
                apply Finset.sum_congr rfl
                intro n hn
                field_simp
        _ = (∑ n ∈ Finset.range (K - 1).natAbs,
              1 / (n + 1 : ℝ)) / (y - 1) := by
                rw [Finset.sum_div]

theorem cFirstBoundScratch (C : Finset ℤ) (K y eta : ℤ) (dist : ℤ → ℤ) (f : ℤ → ℝ)
    (hy : 2 ≤ y) (hK : 3 ≤ K) (hKleY : K ≤ y)
    (heta : eta = 1 ∨ eta = -1)
    (hshape : ∀ b ∈ C, ∃ k t eps ell : ℤ,
      1 ≤ k ∧ k < y ∧ 3 ≤ t ∧ (eps = 1 ∨ eps = -1) ∧
      ell = K - t ∧ 1 ≤ ell ∧ ell ≤ K - 1 ∧
      b = y + k ∧ t * b + eps = K * y + eta ∧
      dist b = ell * y + eta)
    (hdpos : ∀ b ∈ C, 0 < dist b)
    (hf : ∀ b ∈ C, f b = 1 / (dist b : ℝ)) :
    (∑ b ∈ C, f b) ≤
      2 * harmonicNumberScratch ((y - 1).natAbs) / (y - 1) := by
  have hdata : ∀ b ∈ C, ∃ p : ℤ × ℤ × ℤ × ℤ,
      1 ≤ p.1 ∧ p.1 < y ∧ 3 ≤ p.2.1 ∧
      (p.2.2.1 = 1 ∨ p.2.2.1 = -1) ∧
      p.2.2.2 = K - p.2.1 ∧ 1 ≤ p.2.2.2 ∧
      p.2.2.2 ≤ K - 1 ∧ b = y + p.1 ∧
      p.2.1 * b + p.2.2.1 = K * y + eta ∧
      dist b = p.2.2.2 * y + eta := by
    intro b hb
    obtain ⟨k, t, eps, ell, hk, hkl, ht, he, hel, hep, heu, hbk, hq, hd⟩ := hshape b hb
    exact ⟨(k, t, eps, ell), hk, hkl, ht, he, hel, hep, heu, hbk, hq, hd⟩
  let data : ℤ → ℤ × ℤ × ℤ × ℤ := fun b =>
    if hb : b ∈ C then (hdata b hb).choose else (0, 0, 0, 0)
  let ellfun : ℤ → ℤ := fun b => (data b).2.2.2
  let Cplus : Finset ℤ := C.filter (fun b => (data b).2.2.1 = 1)
  let Cminus : Finset ℤ := C.filter (fun b => ¬ (data b).2.2.1 = 1)
  have hdata_mem (b : ℤ) (hb : b ∈ C) :
      1 ≤ (data b).1 ∧ (data b).1 < y ∧ 3 ≤ (data b).2.1 ∧
      ((data b).2.2.1 = 1 ∨ (data b).2.2.1 = -1) ∧
      (data b).2.2.2 = K - (data b).2.1 ∧
      1 ≤ (data b).2.2.2 ∧ (data b).2.2.2 ≤ K - 1 ∧
      b = y + (data b).1 ∧
      (data b).2.1 * b + (data b).2.2.1 = K * y + eta ∧
      dist b = (data b).2.2.2 * y + eta := by
    dsimp [data]
    rw [dif_pos hb]
    exact (hdata b hb).choose_spec
  have hplus_subset : Cplus ⊆ C := by
    intro b hb
    exact (Finset.mem_filter.mp hb).1
  have hminus_subset : Cminus ⊆ C := by
    intro b hb
    exact (Finset.mem_filter.mp hb).1
  have hplus_ell : ∀ b ∈ Cplus, 1 ≤ ellfun b := by
    intro b hb
    rcases hdata_mem b (hplus_subset hb) with
      ⟨_, _, _, _, _, hpos, _, _, _⟩
    exact hpos
  have hplus_ell_upper : ∀ b ∈ Cplus, ellfun b ≤ K - 1 := by
    intro b hb
    rcases hdata_mem b (hplus_subset hb) with
      ⟨_, _, _, _, _, _, hupper, _, _⟩
    exact hupper
  have hminus_ell : ∀ b ∈ Cminus, 1 ≤ ellfun b := by
    intro b hb
    rcases hdata_mem b (hminus_subset hb) with
      ⟨_, _, _, _, _, hpos, _, _, _⟩
    exact hpos
  have hminus_ell_upper : ∀ b ∈ Cminus, ellfun b ≤ K - 1 := by
    intro b hb
    rcases hdata_mem b (hminus_subset hb) with
      ⟨_, _, _, _, _, _, hupper, _, _⟩
    exact hupper
  have hplus_eps : ∀ b ∈ Cplus, (data b).2.2.1 = 1 := by
    intro b hb
    exact (Finset.mem_filter.mp hb).2
  have hminus_eps : ∀ b ∈ Cminus, (data b).2.2.1 = -1 := by
    intro b hb
    have hnot := (Finset.mem_filter.mp hb).2
    rcases (hdata_mem b (hminus_subset hb)).2.2.2.1 with h | h
    · exact False.elim (hnot h)
    · exact h
  have hell_inj : ∀ S : Finset ℤ, S ⊆ C → ∀ e : ℤ,
      (∀ b ∈ S, (data b).2.2.1 = e) →
      (∀ a ∈ S, ∀ b ∈ S, ellfun a = ellfun b → a = b) := by
    intro S hS e hS_eps a ha b hb hab
    have haC := hS ha
    have hbC := hS hb
    rcases hdata_mem a haC with
      ⟨hka, _, _, hepsa, hta, _, _, hba, hqa, hda⟩
    rcases hdata_mem b hbC with
      ⟨hkb, _, _, hepsb, htb, _, _, hbb, hqb, hdb⟩
    have heqa : (data a).2.2.1 = (data b).2.2.1 := by
      rw [hS_eps a ha, hS_eps b hb]
    have habdata : (data a).2.1 = (data b).2.1 := by
      nlinarith [hta, htb, hab]
    have hta' : (data a).2.1 * a + (data a).2.2.1 =
        K * y + eta := hqa
    have htb' : (data b).2.1 * b + (data b).2.2.1 =
        K * y + eta := hqb
    nlinarith [hta', htb', heqa, habdata]
  have hplus_sum := ellBoundScratch Cplus K y eta dist f hy hK heta ellfun
    hplus_ell hplus_ell_upper
    (hell_inj Cplus hplus_subset 1 hplus_eps)
    (fun b hb => by
      rcases hdata_mem b (hplus_subset hb) with
        ⟨_, _, _, _, _, _, _, _, _, hd⟩
      exact hd)
    (fun b hb => hdpos b (hplus_subset hb))
    (fun b hb => hf b (hplus_subset hb))
  have hminus_sum := ellBoundScratch Cminus K y eta dist f hy hK heta ellfun
    hminus_ell hminus_ell_upper
    (hell_inj Cminus hminus_subset (-1) hminus_eps)
    (fun b hb => by
      rcases hdata_mem b (hminus_subset hb) with
        ⟨_, _, _, _, _, _, _, _, _, hd⟩
      exact hd)
    (fun b hb => hdpos b (hminus_subset hb))
    (fun b hb => hf b (hminus_subset hb))
  have hKrange : Finset.range (K - 1).natAbs ⊆
      Finset.range (y - 1).natAbs := by
    intro n hn
    apply Finset.mem_range.mpr
    have hKcast : ((K - 1).natAbs : ℤ) = K - 1 :=
      Int.natAbs_of_nonneg (by omega)
    have hycast : ((y - 1).natAbs : ℤ) = y - 1 :=
      Int.natAbs_of_nonneg (by omega)
    have hh := Finset.mem_range.mp hn
    have hhZ : (n : ℤ) < K - 1 := by
      calc
        (n : ℤ) < ((K - 1).natAbs : ℤ) := by exact_mod_cast hh
        _ = K - 1 := hKcast
    have hnyZ : (n : ℤ) < y - 1 := by
      omega
    rw [← hycast] at hnyZ
    exact_mod_cast hnyZ
  have hHle : harmonicNumberScratch ((K - 1).natAbs) ≤
      harmonicNumberScratch ((y - 1).natAbs) := by
    dsimp [harmonicNumberScratch]
    apply Finset.sum_le_sum_of_subset_of_nonneg hKrange
    intro n hn hnot
    positivity
  have hyRnonneg : (0 : ℝ) ≤ y - 1 := by
    exact_mod_cast (show 0 ≤ y - 1 by omega)
  have hpart : (∑ b ∈ C, f b) =
      (∑ b ∈ Cplus, f b) + ∑ b ∈ Cminus, f b := by
    have hh := (Finset.sum_filter_add_sum_filter_not C
      (fun b : ℤ => (data b).2.2.1 = 1) f).symm
    dsimp [Cplus, Cminus] at hh ⊢
    exact hh
  calc
    (∑ b ∈ C, f b) =
        (∑ b ∈ Cplus, f b) + ∑ b ∈ Cminus, f b := hpart
    _ ≤ harmonicNumberScratch ((y - 1).natAbs) / (y - 1) +
        harmonicNumberScratch ((y - 1).natAbs) / (y - 1) :=
      add_le_add (hplus_sum.trans (div_le_div_of_nonneg_right hHle hyRnonneg))
        (hminus_sum.trans (div_le_div_of_nonneg_right hHle hyRnonneg))
    _ = 2 * harmonicNumberScratch ((y - 1).natAbs) / (y - 1) := by ring

end Fraenkel
