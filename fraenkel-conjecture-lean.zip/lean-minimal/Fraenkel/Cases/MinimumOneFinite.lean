import Fraenkel.Cases.CriticalBranch
import Fraenkel.Cases.MinimumGreaterThanOne

namespace Fraenkel

open scoped BigOperators Classical

/-- The finite candidate pool `𝒫_Q` for the minimum-one feasibility system. -/
-- zpi: def-s-equals-one-finite-feasibility-system
noncomputable def finiteMinimumOnePool (Q : ℤ) : Finset ℤ :=
  (Finset.Icc 1 (Q - 1)).filter
    (fun a => 3 * a < Q ∧ Int.gcd a Q = 1)

/-- The rounded feasibility weight `v_ab` at scale `Λ=10^7`. -/
-- zpi: def-s-equals-one-finite-feasibility-system
noncomputable def finiteMinimumOneWeight (Q a b : ℤ) : ℤ :=
  roundedKnapsackWeight Q a b

/-- A selected finite set is the binary assignment `z_a=1` exactly on that set. -/
-- zpi: def-s-equals-one-finite-feasibility-system
def finiteMinimumOneAssignment (Q : ℤ) (S : Finset ℤ) : Prop :=
  S ⊆ finiteMinimumOnePool Q ∧
    1 ∈ S ∧
    (∑ a ∈ finiteMinimumOnePool Q,
      a * (if a ∈ S then 1 else 0)) ≤ Q ∧
    (∀ a ∈ finiteMinimumOnePool Q,
      (∑ b ∈ (finiteMinimumOnePool Q).erase a,
        finiteMinimumOneWeight Q a b * (if b ∈ S then 1 else 0)) ≥
        knapsackScale * (if a ∈ S then 1 else 0))

/-- The finite binary feasibility system for a given `Q`. -/
-- zpi: def-s-equals-one-finite-feasibility-system
def finiteMinimumOneFeasibilitySystem (Q : ℤ) : Prop :=
  ∃ S : Finset ℤ, finiteMinimumOneAssignment Q S

/-- Exact upper bound used by `row_upper` in the recorded Python verifier.
The tested row is mandatory, even when it was previously undecided. `⊥`
is the unreachable-load marker, not an integer score. -/
-- zpi: prop-s-equals-one-finite-system-infeasible-through-q-715
noncomputable def finiteMinimumOneRowUpper (Q a : ℤ)
    (included excluded : Finset ℤ) : WithBot ℤ :=
  let mandatory := insert a included
  let capacity := Q - ∑ b ∈ mandatory, b
  if capacity < 0 then (-1 : ℤ)
  else
    let base := ∑ b ∈ mandatory.erase a, finiteMinimumOneWeight Q a b
    let optional := finiteMinimumOnePool Q \ (mandatory ∪ excluded)
    (base : WithBot ℤ) +
      (Finset.Icc 0 capacity).sup
        (knapsackDPFinal Q a (optional.sort (· ≤ ·)))

/-- The script branches at the least `(score,index)` pair. The pool is sorted
in increasing order, so keeping the earlier element at equal score implements
exactly the script's index tie-break. -/
-- zpi: prop-s-equals-one-finite-system-infeasible-through-q-715
noncomputable def finiteMinimumOneBranch (Q : ℤ)
    (included excluded : Finset ℤ) (undecided : Finset ℤ) : Option ℤ :=
  (undecided.sort (· ≤ ·)).foldl (fun best a =>
    match best with
    | none => some a
    | some b =>
        if finiteMinimumOneRowUpper Q b included excluded ≤
            finiteMinimumOneRowUpper Q a included excluded then some b else some a) none

/-- Branch-and-knapsack search from `certificates/sc_s1_finite_certificate.py`.
The result records feasibility and nodes visited. Propagation is synchronous
and does not count as a new search node. Include/exclude recursion uses the
script's short-circuit `or`. Exhausted fuel is `none`, NEVER infeasibility;
the certificate below requires completed runs, so no truncation can certify a
case. The propagation call returns its result unchanged (a tail-call encoding
of the Python `while`), while only stable branch calls add a node. Every
recursive call resolves at least one previously undecided vertex. -/
-- zpi: prop-s-equals-one-finite-system-infeasible-through-q-715
noncomputable def finiteMinimumOneSearch (Q : ℤ) :
    ℕ → Finset ℤ → Finset ℤ → Option (Bool × ℕ)
  | 0, _, _ => none
  | fuel + 1, included, excluded =>
      if (∑ a ∈ included, a) > Q ∨
          ∃ a ∈ included, finiteMinimumOneRowUpper Q a included excluded <
            (knapsackScale : WithBot ℤ) then some (false, 1)
      else
        let undecided := finiteMinimumOnePool Q \ (included ∪ excluded)
        let doomed := undecided.filter (fun a =>
          finiteMinimumOneRowUpper Q a included excluded <
            (knapsackScale : WithBot ℤ))
        if doomed.Nonempty then
          finiteMinimumOneSearch Q fuel included (excluded ∪ doomed)
        else
          match finiteMinimumOneBranch Q included excluded undecided with
          | none => some (true, 1)
          | some a => do
              let left ← finiteMinimumOneSearch Q fuel (insert a included) excluded
              if left.1 then some (true, 1 + left.2)
              else
                let right ← finiteMinimumOneSearch Q fuel included (insert a excluded)
                some (right.1, 1 + left.2 + right.2)

/-- The recorded verifier starts with just the anchor included. -/
-- zpi: prop-s-equals-one-finite-system-infeasible-through-q-715
noncomputable def finiteMinimumOneRun (Q : ℤ) : Option (Bool × ℕ) :=
  finiteMinimumOneSearch Q ((finiteMinimumOnePool Q).card + 1) {1} ∅

/-- All denominator values in the recorded scan. -/
-- zpi: prop-s-equals-one-finite-system-infeasible-through-q-715
noncomputable def finiteMinimumOneCases : Finset ℤ := Finset.Icc 4 715

/-- Actual node counts obtained from completed verifier runs. No expected
histogram values occur in these definitions. -/
-- zpi: prop-s-equals-one-finite-system-infeasible-through-q-715
noncomputable def finiteMinimumOneNodeCounts : Finset ℕ :=
  finiteMinimumOneCases.biUnion (fun Q =>
    match finiteMinimumOneRun Q with
    | none => ∅
    | some result => {result.2})

-- zpi: prop-s-equals-one-finite-system-infeasible-through-q-715
noncomputable def finiteMinimumOneNodeHistogram : Finset (ℕ × ℕ) :=
  finiteMinimumOneNodeCounts.image (fun n =>
    (n, (finiteMinimumOneCases.filter (fun Q =>
      (finiteMinimumOneRun Q).map Prod.snd = some n)).card))

/-- The script updates its maximum record only on a strictly larger node
count, scanning denominators in increasing order. -/
-- zpi: prop-s-equals-one-finite-system-infeasible-through-q-715
noncomputable def finiteMinimumOneLargestTree : ℤ × ℕ :=
  (finiteMinimumOneCases.sort (· ≤ ·)).foldl (fun best Q =>
    match finiteMinimumOneRun Q with
    | none => best
    | some result => if best.2 < result.2 then (Q, result.2) else best) (0, 0)

/-- Exact infeasibility and verifier statistics imported from
`certificates/sc_s1_finite_certificate.py`. -/
-- zpi: prop-s-equals-one-finite-system-infeasible-through-q-715
axiom finiteMinimumOneSystemsInfeasible :
    finiteMinimumOneCases.card = 712 ∧
      (∀ Q ∈ finiteMinimumOneCases,
        ¬ finiteMinimumOneFeasibilitySystem Q ∧
          ∃ nodes, finiteMinimumOneRun Q = some (false, nodes)) ∧
      finiteMinimumOneNodeHistogram =
        {(1, 704), (3, 3), (5, 4), (7, 1)} ∧
      finiteMinimumOneLargestTree = (43, 7)

/-- Every pair from the finite pool has a nonzero cyclic distance, so its
rounded verifier weight is nonnegative. -/
theorem finiteMinimumOneWeight_nonneg_of_mem_pool
    (Q a b : ℤ) (hQ : 2 ≤ Q)
    (ha : a ∈ finiteMinimumOnePool Q)
    (hb : b ∈ finiteMinimumOnePool Q) :
    0 ≤ finiteMinimumOneWeight Q a b := by
  have ha' := Finset.mem_filter.mp ha
  have hb' := Finset.mem_filter.mp hb
  have haQ : a < Q := by
    have h := (Finset.mem_Icc.mp ha'.1).2
    omega
  have hQpos : 0 < Q := by omega
  have hprod_ne : (a * inverseMod Q b) % Q ≠ 0 := by
    intro hz
    have hinv := inverseMod_spec Q b hQ hb'.2.2
    have hzero : a * inverseMod Q b ≡ 0 [ZMOD Q] := by
      simpa [Int.ModEq] using hz
    have hprod : (a * inverseMod Q b) * b ≡ 0 * b [ZMOD Q] :=
      hzero.mul_right b
    have h1mod : (1 : ℤ) % Q = 1 :=
      Int.emod_eq_of_lt (by omega) (by omega)
    have hone : b * inverseMod Q b ≡ 1 [ZMOD Q] := by
      simpa [Int.ModEq, h1mod] using hinv.2
    have hcalc : (a * inverseMod Q b) * b ≡ a [ZMOD Q] := by
      calc
        (a * inverseMod Q b) * b = a * (b * inverseMod Q b) := by ring
        _ ≡ a * 1 [ZMOD Q] := hone.mul_left a
        _ = a := by ring
    have hamod : a % Q = 0 := by
      have hz' : (a * inverseMod Q b) * b % Q = 0 :=
        hprod.eq.trans (by simp)
      rw [hcalc.eq] at hz'
      exact hz'
    have haone : 1 ≤ a := by
      exact_mod_cast (Finset.mem_Icc.mp ha'.1).1
    have hapos : 0 ≤ a := by omega
    have hamod' : a % Q = a := Int.emod_eq_of_lt hapos haQ
    omega
  have hdist := cyclicDistance_bounds Q (a * inverseMod Q b) hQ hprod_ne
  have hdpos : 0 < (cyclicDistance Q (a * inverseMod Q b) : ℝ) := by
    exact_mod_cast (show 0 < cyclicDistance Q (a * inverseMod Q b) by omega)
  have hQreal : 0 < (Q : ℝ) := by exact_mod_cast hQpos
  have harg :
      0 ≤ (knapsackScale : ℝ) *
        (1 / (cyclicDistance Q (a * inverseMod Q b) : ℝ) +
          16 * (cyclicDistance Q (a * inverseMod Q b) : ℝ) /
            (7 * (Q : ℝ) ^ 2)) := by
    have hscale : 0 ≤ (knapsackScale : ℝ) := by
      norm_num [knapsackScale]
    positivity
  simpa [finiteMinimumOneWeight, roundedKnapsackWeight] using
    (Int.ceil_nonneg harg)

/-- A passing minimum-row data set with denominator in the recorded range
produces a feasible assignment for the finite verifier. -/
theorem finiteMinimumOneFeasibility_of_all_rows_passing
    (D : MinimumRowSlackData) (hs : D.s = 1) (hQ_upper : D.Q ≤ 715)
    (hAll : ∀ a ∈ D.A, RowPasses D.Q D.A a) :
    finiteMinimumOneFeasibilitySystem D.Q := by
  have hQ : 2 ≤ D.Q := by
    have h := D.hQ
    omega
  have hpool : D.A ⊆ finiteMinimumOnePool D.Q := by
    intro a ha
    have haunit := D.hA.1 a ha
    have haIcc : a ∈ Finset.Icc 1 (D.Q - 1) := by
      rw [Finset.mem_Icc]
      constructor
      · omega
      · have hupper := D.hA_upper a ha
        omega
    exact Finset.mem_filter.mpr ⟨haIcc, ⟨D.hA_upper a ha, haunit.2⟩⟩
  have hone : (1 : ℤ) ∈ D.A := by
    simpa [hs] using D.hs_mem
  have hfilter :
      (finiteMinimumOnePool D.Q).filter (fun a => a ∈ D.A) = D.A := by
    ext a
    constructor
    · intro ha
      exact (Finset.mem_filter.mp ha).2
    · intro ha
      exact Finset.mem_filter.mpr ⟨hpool ha, ha⟩
  have hload_eq :
      (∑ a ∈ finiteMinimumOnePool D.Q,
        a * (if a ∈ D.A then 1 else 0)) = ∑ a ∈ D.A, a := by
    calc
      (∑ a ∈ finiteMinimumOnePool D.Q,
          a * (if a ∈ D.A then 1 else 0)) =
          ∑ a ∈ finiteMinimumOnePool D.Q,
            if a ∈ D.A then a else 0 := by
        apply Finset.sum_congr rfl
        intro a ha
        by_cases h : a ∈ D.A <;> simp [h]
      _ = ∑ a ∈ (finiteMinimumOnePool D.Q).filter
            (fun a => a ∈ D.A), a := by
        rw [Finset.sum_filter]
      _ = ∑ a ∈ D.A, a := by rw [hfilter]
  refine ⟨D.A, hpool, hone, ?_, ?_⟩
  · rw [hload_eq]
    exact D.hA_sum
  · intro a ha
    have hrow_filter :
        ((finiteMinimumOnePool D.Q).erase a).filter (fun b => b ∈ D.A) =
          D.A.erase a := by
      ext b
      constructor
      · intro hb
        have hb' := Finset.mem_filter.mp hb
        exact Finset.mem_erase.mpr
          ⟨(Finset.mem_erase.mp hb'.1).1, hb'.2⟩
      · intro hb
        have hb' := Finset.mem_erase.mp hb
        exact Finset.mem_filter.mpr ⟨
          Finset.mem_erase.mpr ⟨hb'.1, hpool hb'.2⟩, hb'.2⟩
    have hrow_eq :
        (∑ b ∈ (finiteMinimumOnePool D.Q).erase a,
          finiteMinimumOneWeight D.Q a b * (if b ∈ D.A then 1 else 0)) =
          ∑ b ∈ D.A.erase a, finiteMinimumOneWeight D.Q a b := by
      calc
        (∑ b ∈ (finiteMinimumOnePool D.Q).erase a,
            finiteMinimumOneWeight D.Q a b * (if b ∈ D.A then 1 else 0)) =
            ∑ b ∈ (finiteMinimumOnePool D.Q).erase a,
              if b ∈ D.A then finiteMinimumOneWeight D.Q a b else 0 := by
          apply Finset.sum_congr rfl
          intro b hb
          by_cases h : b ∈ D.A <;> simp [h]
        _ = ∑ b ∈ ((finiteMinimumOnePool D.Q).erase a).filter
              (fun b => b ∈ D.A), finiteMinimumOneWeight D.Q a b := by
          rw [Finset.sum_filter]
        _ = ∑ b ∈ D.A.erase a, finiteMinimumOneWeight D.Q a b := by
          rw [hrow_filter]
    by_cases haA : a ∈ D.A
    · have hmass : (1 : ℝ) ≤ inverseSineRowMass D.Q D.A a := hAll a haA
      have hscale : 0 < (knapsackScale : ℝ) := by
        norm_num [knapsackScale]
      have hscaled : (knapsackScale : ℝ) ≤
          (knapsackScale : ℝ) * inverseSineRowMass D.Q D.A a := by
        have hh := mul_le_mul_of_nonneg_left hmass (le_of_lt hscale)
        simpa using hh
      have hterm (b : ℤ) (hb : b ∈ D.A.erase a) :
          (knapsackScale : ℝ) *
              inverseSineKernel D.Q
                (cyclicDistance D.Q (a * inverseMod D.Q b)) <
            (finiteMinimumOneWeight D.Q a b : ℝ) := by
        have hdist := minimumRowDistance_bounds_of_mem D haA
          (Finset.mem_of_mem_erase hb)
        simpa [finiteMinimumOneWeight] using
          (roundedKnapsackWeight_gt_scaled_kernel D.Q a b
            (by omega) hdist.1 hdist.2)
      have hsumterm :
          (∑ b ∈ D.A.erase a,
            (knapsackScale : ℝ) *
              inverseSineKernel D.Q
                (cyclicDistance D.Q (a * inverseMod D.Q b))) ≤
            ∑ b ∈ D.A.erase a,
              (finiteMinimumOneWeight D.Q a b : ℝ) := by
        apply Finset.sum_le_sum
        intro b hb
        exact (hterm b hb).le
      have hfactor :
          (knapsackScale : ℝ) * inverseSineRowMass D.Q D.A a =
            ∑ b ∈ D.A.erase a,
              (knapsackScale : ℝ) *
                inverseSineKernel D.Q
                  (cyclicDistance D.Q (a * inverseMod D.Q b)) := by
        unfold inverseSineRowMass
        rw [Finset.mul_sum]
      have hreal : (knapsackScale : ℝ) ≤
          ∑ b ∈ D.A.erase a,
            (finiteMinimumOneWeight D.Q a b : ℝ) := by
        calc
          (knapsackScale : ℝ) ≤
              (knapsackScale : ℝ) * inverseSineRowMass D.Q D.A a := hscaled
          _ = ∑ b ∈ D.A.erase a,
              (knapsackScale : ℝ) *
                inverseSineKernel D.Q
                  (cyclicDistance D.Q (a * inverseMod D.Q b)) := hfactor
          _ ≤ ∑ b ∈ D.A.erase a,
              (finiteMinimumOneWeight D.Q a b : ℝ) := hsumterm
      rw [hrow_eq, if_pos haA]
      exact_mod_cast hreal
    · have hnonneg :
          0 ≤ ∑ b ∈ (finiteMinimumOnePool D.Q).erase a,
            finiteMinimumOneWeight D.Q a b * (if b ∈ D.A then 1 else 0) := by
        apply Finset.sum_nonneg
        intro b hb
        by_cases hbA : b ∈ D.A
        · have hbpool : b ∈ finiteMinimumOnePool D.Q :=
            Finset.mem_of_mem_erase hb
          have hw := finiteMinimumOneWeight_nonneg_of_mem_pool
            D.Q a b hQ ha (hpool hbA)
          simp [hbA, hw]
        · simp [hbA]
      simpa [haA] using hnonneg

/-- In the recorded denominator range, all passing rows would realize a
finite assignment, contradicting the imported infeasibility certificate. -/
theorem deficientRowWhenMinimumEqualsOne_of_q_le_715
    (D : MinimumRowSlackData) (hs : D.s = 1) (hQ_upper : D.Q ≤ 715) :
    ∃ a ∈ D.A, RowDeficient D.Q D.A a := by
  by_contra hno
  have hAll : ∀ a ∈ D.A, RowPasses D.Q D.A a := by
    intro a ha
    by_contra hnot
    apply hno
    refine ⟨a, ha, ?_⟩
    change inverseSineRowMass D.Q D.A a < 1
    change ¬ (1 ≤ inverseSineRowMass D.Q D.A a) at hnot
    exact lt_of_not_ge hnot
  have hfeasible := finiteMinimumOneFeasibility_of_all_rows_passing
    D hs hQ_upper hAll
  have hmem : D.Q ∈ finiteMinimumOneCases := by
    change D.Q ∈ Finset.Icc 4 715
    exact Finset.mem_Icc.mpr ⟨D.hQ, hQ_upper⟩
  have hnotfeasible :=
    (finiteMinimumOneSystemsInfeasible.2.1 D.Q hmem).1
  exact hnotfeasible hfeasible

/-- If the minimum-one branch omits `2`, the all-passing case is already
below the finite-verifier cutoff. -/
theorem q_le_715_of_all_rows_passing_s_eq_one_of_two_absent
    (D : MinimumRowSlackData) (hs : D.s = 1)
    (h2 : (2 : ℤ) ∉ D.A)
    (hAll : ∀ a ∈ D.A, RowPasses D.Q D.A a) :
    D.Q ≤ 715 := by
  let E : SEqualsOneSubcriticalData := ⟨D, hs⟩
  have hAllE : ∀ a ∈ E.toMinimumRowSlackData.A,
      RowPasses E.toMinimumRowSlackData.Q
        E.toMinimumRowSlackData.A a := by
    simpa [E] using hAll
  have hpass_s : RowPasses E.toMinimumRowSlackData.Q
      E.toMinimumRowSlackData.A E.toMinimumRowSlackData.s := by
    exact hAllE E.toMinimumRowSlackData.s E.toMinimumRowSlackData.hs_mem
  obtain ⟨x, hxA, hxgt, hxgood⟩ :=
    (sEqualsOneMinimumRow E hpass_s).2.2 hAllE
  have hxsel : x ∈ selectedGoodElements E := by
    exact Finset.mem_filter.mpr ⟨hxA, hxgt, hxgood⟩
  have hselne : (selectedGoodElements E).Nonempty := ⟨x, hxsel⟩
  let y : ℤ := (selectedGoodElements E).min' hselne
  have hysel : y ∈ selectedGoodElements E := by
    dsimp [y]
    exact Finset.min'_mem _ hselne
  have hyle : ∀ z ∈ selectedGoodElements E, y ≤ z := by
    intro z hz
    dsimp [y]
    exact Finset.min'_le _ z hz
  have hyleast : IsLeastSelectedGood E y := ⟨hysel, hyle⟩
  have hyA : y ∈ D.A := by
    have hy := (Finset.mem_filter.mp hysel).1
    simpa [E] using hy
  have hygt : 1 < y := (Finset.mem_filter.mp hysel).2.1
  have hy3 : 3 ≤ y := by
    by_contra hy3
    have hy2 : y = 2 := by omega
    apply h2
    rw [← hy2]
    exact hyA
  have hbound := leastGoodElementAtLeastThree E y hyleast hy3 hAllE
  have hQ703 : D.Q ≤ 703 := by
    simpa [E] using hbound.2
  omega

/-- If both `2` and `3` occur in the minimum-one branch, the existing
anchor estimate gives the finite-verifier cutoff. -/
theorem q_le_715_of_all_rows_passing_s_eq_one_of_two_three_present
    (D : MinimumRowSlackData) (hs : D.s = 1)
    (h2 : (2 : ℤ) ∈ D.A) (h3 : (3 : ℤ) ∈ D.A)
    (hAll : ∀ a ∈ D.A, RowPasses D.Q D.A a) :
    D.Q ≤ 715 := by
  let E : SEqualsOneSubcriticalData := ⟨D, hs⟩
  have hAllE : ∀ a ∈ E.toMinimumRowSlackData.A,
      RowPasses E.toMinimumRowSlackData.Q
        E.toMinimumRowSlackData.A a := by
    simpa [E] using hAll
  have hbound := anchorAtThree E h2 h3 hAllE
  simpa [E] using hbound.2

/-- If every selected good element is dyadic, the no-nondyadic branch
also lies below the finite-verifier cutoff. -/
theorem q_le_715_of_all_rows_passing_s_eq_one_of_all_good_dyadic
    (D : MinimumRowSlackData) (hs : D.s = 1)
    (h2 : (2 : ℤ) ∈ D.A) (h3 : (3 : ℤ) ∉ D.A)
    (hDyadic : ∀ a ∈ D.A,
      1 < a → GoodMinimumRowElement D a →
        ∃ k : ℕ, a = (2 : ℤ) ^ k)
    (hAll : ∀ a ∈ D.A, RowPasses D.Q D.A a) :
    D.Q ≤ 715 := by
  let E : SEqualsOneSubcriticalData := ⟨D, hs⟩
  have hAllE : ∀ a ∈ E.toMinimumRowSlackData.A,
      RowPasses E.toMinimumRowSlackData.Q
        E.toMinimumRowSlackData.A a := by
    simpa [E] using hAll
  have hDyadicE : ∀ a ∈ E.toMinimumRowSlackData.A,
      1 < a → GoodMinimumRowElement E.toMinimumRowSlackData a →
        ∃ k : ℕ, a = (2 : ℤ) ^ k := by
    simpa [E] using hDyadic
  have hbound := noNondyadicGoodElement E h2 h3 hDyadicE hAllE
  have hQ171 : D.Q ≤ 171 := by
    simpa [E] using hbound.2
  omega

/-- A positive integer which is not a power of two has the decomposition
used by the critical branch data. -/
theorem criticalTwoAdicDecomposition
    (y : ℤ) (hypos : 0 < y) (hynd : ¬ IsDyadic y) :
    ∃ v : ℕ, ∃ m : ℤ, ∃ J : ℕ,
      y = (2 : ℤ) ^ v * m ∧
      3 ≤ m ∧ m % 2 = 1 ∧
      ¬ (2 : ℤ) ^ (v + 1) ∣ y ∧
      (2 : ℤ) ^ J ≤ m - 1 ∧
      m - 1 < (2 : ℤ) ^ (J + 1) := by
  let n : ℕ := y.natAbs
  have hn : n ≠ 0 := by
    dsimp [n]
    exact Int.natAbs_ne_zero.mpr hypos.ne'
  obtain ⟨v, mN, hmOdd, hyN⟩ := Nat.exists_eq_two_pow_mul_odd hn
  have hmNpos : 0 < mN := by
    rcases hmOdd with ⟨k, hk⟩
    omega
  let m : ℤ := mN
  have hyNcast : (n : ℤ) = y := by
    dsimp [n]
    exact Int.natAbs_of_nonneg hypos.le
  have hdecomp : y = (2 : ℤ) ^ v * m := by
    calc
      y = (n : ℤ) := hyNcast.symm
      _ = ((2 ^ v * mN : ℕ) : ℤ) := by rw [hyN]
      _ = (2 : ℤ) ^ v * (mN : ℤ) := by
        push_cast
        rfl
      _ = (2 : ℤ) ^ v * m := by simp [m]
  have hm_odd : m % 2 = 1 := by
    rcases hmOdd with ⟨k, hk⟩
    have hkZ : (mN : ℤ) = 2 * (k : ℤ) + 1 := by
      exact_mod_cast hk
    dsimp [m]
    rw [hkZ]
    omega
  have hmpos : 0 < m := by
    dsimp [m]
    exact_mod_cast hmNpos
  have hm_lower : 3 ≤ m := by
    by_contra hm3
    have hmone : m = 1 := by omega
    apply hynd
    refine ⟨v, ?_⟩
    simpa [hmone] using hdecomp
  have hm_not_dvd : ¬ (2 : ℤ) ∣ m := by
    intro hdiv
    have hdivN : (2 : ℕ) ∣ mN := by
      exact_mod_cast (show (2 : ℤ) ∣ (mN : ℤ) by simpa [m] using hdiv)
    exact (Nat.not_even_iff_odd.mpr hmOdd)
      (even_iff_two_dvd.mpr hdivN)
  have hv_maximal : ¬ (2 : ℤ) ^ (v + 1) ∣ y := by
    intro hdiv
    have hdiv' : (2 : ℤ) ^ (v + 1) ∣ m * (2 : ℤ) ^ v := by
      rw [hdecomp] at hdiv
      simpa [mul_comm] using hdiv
    have hpowdiv : (2 : ℤ) ^ (v + 1) ∣ (2 : ℤ) ^ v := by
      exact (Int.prime_two : Prime (2 : ℤ)).pow_dvd_of_dvd_mul_left
        (v + 1) hm_not_dvd hdiv'
    obtain ⟨k, hk⟩ := hpowdiv
    have hcancel : (1 : ℤ) = 2 * k := by
      apply mul_left_cancel₀ (show (2 : ℤ) ^ v ≠ 0 by positivity)
      calc
        (2 : ℤ) ^ v * 1 = (2 : ℤ) ^ v := by ring
        _ = (2 : ℤ) ^ (v + 1) * k := hk
        _ = (2 : ℤ) ^ v * (2 * k) := by rw [pow_succ]; ring
    omega
  have hmN_lower : 3 ≤ mN := by
    dsimp [m] at hm_lower
    exact_mod_cast hm_lower
  have hnJ : mN - 1 ≠ 0 := by omega
  let J : ℕ := Nat.log 2 (mN - 1)
  have hJ_lower : (2 : ℤ) ^ J ≤ m - 1 := by
    have h := Nat.pow_log_le_self 2 hnJ
    have hcast : ((mN - 1 : ℕ) : ℤ) = (mN : ℤ) - 1 := by
      rw [Nat.cast_sub (by omega)]
      norm_num
    dsimp [J, m]
    rw [← hcast]
    exact_mod_cast h
  have hJ_upper : m - 1 < (2 : ℤ) ^ (J + 1) := by
    have h := Nat.lt_pow_succ_log_self (by norm_num : 1 < 2) (mN - 1)
    have hcast : ((mN - 1 : ℕ) : ℤ) = (mN : ℤ) - 1 := by
      rw [Nat.cast_sub (by omega)]
      norm_num
    dsimp [J, m]
    rw [← hcast]
    exact_mod_cast h
  exact ⟨v, m, J, hdecomp, hm_lower, hm_odd, hv_maximal,
    hJ_lower, hJ_upper⟩

/-- When the minimum representative equals one, some inverse-sine row is
 deficient. -/
-- zpi: thm-deficient-row-when-minimum-equals-one
theorem deficientRowWhenMinimumEqualsOne
    (D : MinimumRowSlackData) (hs : D.s = 1) :
    ∃ a ∈ D.A, RowDeficient D.Q D.A a := by
  by_contra hno
  have hAll : ∀ a ∈ D.A, RowPasses D.Q D.A a := by
    intro a ha
    by_contra hnot
    apply hno
    refine ⟨a, ha, ?_⟩
    change inverseSineRowMass D.Q D.A a < 1
    change ¬ (1 ≤ inverseSineRowMass D.Q D.A a) at hnot
    exact lt_of_not_ge hnot
  by_cases h2 : (2 : ℤ) ∈ D.A
  · by_cases h3 : (3 : ℤ) ∈ D.A
    · have hQ := q_le_715_of_all_rows_passing_s_eq_one_of_two_three_present
        D hs h2 h3 hAll
      exact hno (deficientRowWhenMinimumEqualsOne_of_q_le_715 D hs hQ)
    · by_cases hDyadic : ∀ a ∈ D.A,
        1 < a → GoodMinimumRowElement D a →
          ∃ k : ℕ, a = (2 : ℤ) ^ k
      · have hQ := q_le_715_of_all_rows_passing_s_eq_one_of_all_good_dyadic
          D hs h2 h3 hDyadic hAll
        exact hno (deficientRowWhenMinimumEqualsOne_of_q_le_715 D hs hQ)
      · push_neg at hDyadic
        obtain ⟨y₀, hy₀A, hy₀gt, hy₀good, hy₀nondyadic⟩ := hDyadic
        let N : Finset ℤ := D.A.filter
          (fun a => 1 < a ∧ GoodMinimumRowElement D a ∧ ¬ IsDyadic a)
        have hy₀N : y₀ ∈ N := by
          exact Finset.mem_filter.mpr
            ⟨hy₀A, hy₀gt, hy₀good, by simpa [IsDyadic] using hy₀nondyadic⟩
        have hNne : N.Nonempty := ⟨y₀, hy₀N⟩
        let y : ℤ := N.min' hNne
        have hyN : y ∈ N := by
          dsimp [y]
          exact Finset.min'_mem N hNne
        have hyA : y ∈ D.A := (Finset.mem_filter.mp hyN).1
        have hygt : 1 < y := (Finset.mem_filter.mp hyN).2.1
        have hygood : GoodMinimumRowElement D y :=
          (Finset.mem_filter.mp hyN).2.2.1
        have hynondyadic : ¬ IsDyadic y :=
          (Finset.mem_filter.mp hyN).2.2.2
        have hyleast : ∀ z ∈ D.A, 1 < z →
            GoodMinimumRowElement D z → ¬ IsDyadic z → y ≤ z := by
          intro z hz hzgt hzgood hznondyadic
          dsimp [y]
          apply Finset.min'_le N z
          exact Finset.mem_filter.mpr ⟨hz, hzgt, hzgood, hznondyadic⟩
        have hypos : 0 < y := (D.hA.1 y hyA).1
        obtain ⟨v, m, J, hy_decomp, hm_lower, hm_odd,
          hv_maximal, hJ_lower, hJ_upper⟩ :=
          criticalTwoAdicDecomposition y hypos hynondyadic
        let L : LeastNondyadicGoodElementData :=
          { toSEqualsOneSubcriticalData := ⟨D, hs⟩
            h2 := h2
            h3 := h3
            hRowOne := hAll D.s D.hs_mem
            y := y
            hy_mem := hyA
            hy_good := hygood
            hy_nondyadic := hynondyadic
            hy_least := hyleast
            v := v
            m := m
            J := J
            hy_decomp := hy_decomp
            hm_lower := hm_lower
            hm_odd := hm_odd
            hv_maximal := hv_maximal
            hJ_lower := hJ_lower
            hJ_upper := hJ_upper }
        have hAllL : ∀ a ∈ L.toMinimumRowSlackData.A,
            RowPasses L.toMinimumRowSlackData.Q L.toMinimumRowSlackData.A a := by
          simpa [L] using hAll
        have hQ289 := refinedEnvelopeVerifierReducesCriticalBranch L hAllL
        have hQ : D.Q ≤ 715 := by
          have hQ' : L.toMinimumRowSlackData.Q ≤ 289 := hQ289.1
          have hQ289D : D.Q ≤ 289 := by
            simpa [L] using hQ'
          omega
        exact hno (deficientRowWhenMinimumEqualsOne_of_q_le_715 D hs hQ)
  · have hQ := q_le_715_of_all_rows_passing_s_eq_one_of_two_absent
      D hs h2 hAll
    exact hno (deficientRowWhenMinimumEqualsOne_of_q_le_715 D hs hQ)

end Fraenkel
