import Fraenkel.Analytic.Kernel
import Mathlib.Tactic

namespace Fraenkel.KnapsackArray

/-- Maximum with `none` representing an unreachable load. -/
def optMax : Option ℤ → Option ℤ → Option ℤ
  | none, y => y
  | x, none => x
  | some x, some y => some (max x y)

/-- Add an item's value without making an unreachable load reachable. -/
def optAdd (x : Option ℤ) (v : ℤ) : Option ℤ :=
  x.map (fun n => n + v)

@[simp] theorem optMax_eq_max (x y : WithBot ℤ) :
    optMax x y = max x y := by
  cases x <;> cases y <;> rfl

@[simp] theorem optAdd_eq_add (x : WithBot ℤ) (v : ℤ) :
    optAdd x v = x + (v : WithBot ℤ) := by
  cases x <;> rfl

/-- The first `n` descending updates, starting at the largest array index. -/
def updatePrefix (dp : Array (Option ℤ)) (b : ℕ) (v : ℤ) (n : ℕ) :
    Array (Option ℤ) :=
  (List.range n).foldl (fun arr i =>
    let u := dp.size - 1 - i
    arr.set! u (optMax (arr.getD u none)
      (optAdd (arr.getD (u - b) none) v))) dp

/-- A descending 0--1 knapsack update on all stored loads at least `b`. -/
def update (dp : Array (Option ℤ)) (b : ℕ) (v : ℤ) :
    Array (Option ℤ) :=
  let cap := dp.size - 1
  if b ≤ cap then updatePrefix dp b v (cap - b + 1) else dp

@[simp] theorem updatePrefix_zero (dp : Array (Option ℤ)) (b : ℕ) (v : ℤ) :
    updatePrefix dp b v 0 = dp := rfl

theorem updatePrefix_succ (dp : Array (Option ℤ)) (b : ℕ) (v : ℤ) (n : ℕ) :
    updatePrefix dp b v (n + 1) =
      (updatePrefix dp b v n).set! (dp.size - 1 - n)
        (optMax ((updatePrefix dp b v n).getD (dp.size - 1 - n) none)
          (optAdd ((updatePrefix dp b v n).getD (dp.size - 1 - n - b) none) v)) := by
  simp [updatePrefix, List.range_succ, List.foldl_append]

@[simp] theorem updatePrefix_size (dp : Array (Option ℤ)) (b : ℕ) (v : ℤ)
    (n : ℕ) : (updatePrefix dp b v n).size = dp.size := by
  induction n with
  | zero => rfl
  | succ n ih => simp [updatePrefix_succ, ih]

/-- Already visited cells have their new value; the entire lower prefix still
has its old value, so an item is never used twice. -/
theorem updatePrefix_getD (dp : Array (Option ℤ)) (b : ℕ) (v : ℤ)
    (n : ℕ) (hn : n ≤ dp.size) (hbn : b + n ≤ dp.size) (u : ℕ) :
    (updatePrefix dp b v n).getD u none =
      if dp.size - n ≤ u ∧ u < dp.size then
        optMax (dp.getD u none) (optAdd (dp.getD (u - b) none) v)
      else dp.getD u none := by
  induction n generalizing u with
  | zero => simp
  | succ n ih =>
      have hn' : n ≤ dp.size := by omega
      have hbn' : b + n ≤ dp.size := by omega
      let j := dp.size - 1 - n
      have hj : j < dp.size := by dsimp [j]; omega
      have hjold : ¬ (dp.size - n ≤ j ∧ j < dp.size) := by dsimp [j]; omega
      have hjbold : ¬ (dp.size - n ≤ j - b ∧ j - b < dp.size) := by
        dsimp [j]; omega
      rw [updatePrefix_succ]
      change ((updatePrefix dp b v n).set! j
        (optMax ((updatePrefix dp b v n).getD j none)
          (optAdd ((updatePrefix dp b v n).getD (j - b) none) v))).getD u none = _
      rw [ih hn' hbn' j, ih hn' hbn' (j - b), if_neg hjold, if_neg hjbold]
      by_cases huj : u = j
      · subst u
        have hnew : dp.size - (n + 1) ≤ j ∧ j < dp.size := by
          dsimp [j]; omega
        simp [Array.set!, hj, hnew]
      · have hget : ∀ x : Option ℤ,
            ((updatePrefix dp b v n).set! j x).getD u none =
              (updatePrefix dp b v n).getD u none := by
          intro x
          simp [Array.set!, Ne.symm huj]
        rw [hget, ih hn' hbn' u]
        have hiff : (dp.size - n ≤ u ∧ u < dp.size) ↔
            (dp.size - (n + 1) ≤ u ∧ u < dp.size) := by
          dsimp [j] at huj; omega
        simp only [hiff]

theorem update_getD (dp : Array (Option ℤ)) (b : ℕ) (v : ℤ)
    (hcap : b ≤ dp.size - 1) (u : ℕ) (hu : u < dp.size) :
    (update dp b v).getD u none =
      if u < b then dp.getD u none
      else optMax (dp.getD u none)
        (optAdd (dp.getD (u - b) none) v) := by
  have hsize : 0 < dp.size := by omega
  rw [update]
  rw [if_pos hcap]
  have hprefix := updatePrefix_getD dp b v (dp.size - 1 - b + 1)
    (by omega) (by omega) u
  by_cases hub : u < b
  · have huv : ¬ (dp.size - (dp.size - 1 - b + 1) ≤ u ∧ u < dp.size) := by
      omega
    calc
      (updatePrefix dp b v (dp.size - 1 - b + 1)).getD u none =
          if dp.size - (dp.size - 1 - b + 1) ≤ u ∧ u < dp.size then
            optMax (dp.getD u none) (optAdd (dp.getD (u - b) none) v)
          else dp.getD u none := hprefix
      _ = dp.getD u none := if_neg huv
      _ = (if u < b then dp.getD u none else
          optMax (dp.getD u none) (optAdd (dp.getD (u - b) none) v)) := by
            rw [if_pos hub]
  · have huv : dp.size - (dp.size - 1 - b + 1) ≤ u ∧ u < dp.size := by
      omega
    calc
      (updatePrefix dp b v (dp.size - 1 - b + 1)).getD u none =
          if dp.size - (dp.size - 1 - b + 1) ≤ u ∧ u < dp.size then
            optMax (dp.getD u none) (optAdd (dp.getD (u - b) none) v)
          else dp.getD u none := hprefix
      _ = optMax (dp.getD u none) (optAdd (dp.getD (u - b) none) v) := if_pos huv
      _ = (if u < b then dp.getD u none else
          optMax (dp.getD u none) (optAdd (dp.getD (u - b) none) v)) := by
            rw [if_neg hub]

/-- The initial array and function layers for a capacity. -/
def initial (cap : ℕ) : Array (Option ℤ) :=
  (Array.replicate (cap + 1) (none : Option ℤ)).set! 0 (some 0)

def initialFn (_cap : ℕ) (u : ℕ) : Option ℤ :=
  if u = 0 then some 0 else none

def stepFn (weight : ℕ → ℤ) (b : ℕ)
    (prev : ℕ → Option ℤ) (u : ℕ) : Option ℤ :=
  if u < b then prev u
  else optMax (prev u) (optAdd (prev (u - b)) (weight b))

def run (cap : ℕ) (weight : ℕ → ℤ) (items : List ℕ) :
    Array (Option ℤ) :=
  items.foldl (fun dp b => update dp b (weight b)) (initial cap)

def runFn (cap : ℕ) (weight : ℕ → ℤ) (items : List ℕ) (u : ℕ) : Option ℤ :=
  (items.foldl (fun prev b => stepFn weight b prev)
    (initialFn cap)) u

theorem initial_size (cap : ℕ) : (initial cap).size = cap + 1 := by
  simp [initial]

theorem initial_getD (cap u : ℕ) (hu : u ≤ cap) :
    (initial cap).getD u none = initialFn cap u := by
  unfold initial initialFn
  by_cases hu0 : u = 0
  · subst u
    simp [Array.getD_getElem?_setIfInBounds]
  · have hu' : u < cap + 1 := by omega
    have hrep : u < (Array.replicate (cap + 1) (none : Option ℤ)).size := by
      simp
      omega
    have hne : 0 ≠ u := by omega
    simp [Array.getD, Array.set!, hrep, hne, hu0, hu']

theorem update_size (dp : Array (Option ℤ)) (b : ℕ) (v : ℤ) :
    (update dp b v).size = dp.size := by
  by_cases h : b ≤ dp.size - 1
  · simp [update, h, updatePrefix_size]
  · simp [update, h]

theorem run_size (cap : ℕ) (weight : ℕ → ℤ) (items : List ℕ) :
    (run cap weight items).size = cap + 1 := by
  have hfold : ∀ (dp : Array (Option ℤ)),
      (items.foldl (fun dp b => update dp b (weight b)) dp).size = dp.size := by
    intro dp
    induction items generalizing dp with
    | nil => rfl
    | cons b items ih =>
        simp only [List.foldl_cons]
        rw [ih, update_size]
  rw [run, hfold, initial_size]

theorem fold_getD (cap : ℕ) (dp : Array (Option ℤ))
    (prev : ℕ → Option ℤ) (items : List ℕ)
    (hsize : dp.size = cap + 1)
    (hget : ∀ u ≤ cap, dp.getD u none = prev u)
    (weight : ℕ → ℤ) (hitems : ∀ b ∈ items, b ≤ cap)
    (u : ℕ) (hu : u ≤ cap) :
    (items.foldl (fun dp b => update dp b (weight b)) dp).getD u none =
      (items.foldl (fun prev b => stepFn weight b prev) prev) u := by
  induction items generalizing dp prev u with
  | nil =>
      simpa using hget u hu
  | cons b items ih =>
      have hb : b ≤ cap := hitems b (by simp)
      have hitems' : ∀ c ∈ items, c ≤ cap := by
        intro c hc
        exact hitems c (by simp [hc])
      have hbcap : b ≤ dp.size - 1 := by
        rw [hsize]
        omega
      have hget' : ∀ u ≤ cap,
          (update dp b (weight b)).getD u none = stepFn weight b prev u := by
        intro u hu
        rw [update_getD dp b (weight b) hbcap u (by omega)]
        rw [hget u hu, hget (u - b) (by omega)]
        rfl
      have hsize' : (update dp b (weight b)).size = cap + 1 := by
        rw [update_size, hsize]
      simp only [List.foldl_cons]
      exact ih (dp := update dp b (weight b)) (prev := stepFn weight b prev)
        hsize' hget' hitems' (u := u) hu

theorem run_getD (cap : ℕ) (weight : ℕ → ℤ) (items : List ℕ)
    (hitems : ∀ b ∈ items, b ≤ cap) (u : ℕ) (hu : u ≤ cap) :
    (run cap weight items).getD u none = runFn cap weight items u := by
  apply fold_getD (cap := cap) (dp := initial cap) (prev := initialFn cap)
    (items := items) (weight := weight)
  · exact initial_size cap
  · intro u hu'
    exact initial_getD cap u hu'
  · exact hitems
  · exact hu

end Fraenkel.KnapsackArray
