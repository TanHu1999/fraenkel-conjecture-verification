import Fraenkel.Cases.MinimumOneBranches
import Fraenkel.Cases.CriticalBranchScratch
import Fraenkel.Cases.CriticalBranchArithmeticScratch

namespace Fraenkel

open scoped BigOperators Classical

set_option maxHeartbeats 20000000

/-- Positive powers of two, used for the dyadic/non-dyadic split. -/
-- zpi: def-least-nondyadic-good-element-data
def IsDyadic (a : ℤ) : Prop :=
  ∃ k : ℕ, a = (2 : ℤ) ^ k

/-- Data for the least selected nondyadic good element in the critical branch. -/
-- zpi: def-least-nondyadic-good-element-data
structure LeastNondyadicGoodElementData extends SEqualsOneSubcriticalData where
  h2 : 2 ∈ toMinimumRowSlackData.A
  h3 : 3 ∉ toMinimumRowSlackData.A
  hRowOne : RowPasses toMinimumRowSlackData.Q
    toMinimumRowSlackData.A toMinimumRowSlackData.s
  y : ℤ
  hy_mem : y ∈ toMinimumRowSlackData.A
  hy_good : GoodMinimumRowElement toMinimumRowSlackData y
  hy_nondyadic : ¬ IsDyadic y
  hy_least : ∀ z ∈ toMinimumRowSlackData.A, 1 < z →
    GoodMinimumRowElement toMinimumRowSlackData z → ¬ IsDyadic z → y ≤ z
  v : ℕ
  m : ℤ
  J : ℕ
  hy_decomp : y = (2 : ℤ) ^ v * m
  hm_lower : 3 ≤ m
  hm_odd : m % 2 = 1
  hv_maximal : ¬ (2 : ℤ) ^ (v + 1) ∣ y
  hJ_lower : (2 : ℤ) ^ J ≤ m - 1
  hJ_upper : m - 1 < (2 : ℤ) ^ (J + 1)

/-- The harmonic number `H_j`. -/
-- zpi: def-least-nondyadic-good-element-data
noncomputable def harmonicNumber (j : ℕ) : ℝ :=
  ∑ k ∈ Finset.range j, (1 : ℝ) / (k + 1 : ℝ)

/-- The good contribution to the least nondyadic element's row. -/
-- zpi: def-least-nondyadic-good-element-data
noncomputable def goodRowContribution (D : LeastNondyadicGoodElementData) : ℝ :=
  (1 : ℝ) / D.y +
    ∑ b ∈ (D.toMinimumRowSlackData.A.erase 1).filter
      (fun b => b ≠ D.y ∧ GoodMinimumRowElement D.toMinimumRowSlackData b),
      (1 : ℝ) /
        (cyclicDistance D.toMinimumRowSlackData.Q
          (D.y * inverseMod D.toMinimumRowSlackData.Q b) : ℝ)

/-- The good candidates `𝒢_Q` in the refined critical envelope. -/
-- zpi: def-refined-critical-branch-envelope
noncomputable def refinedGoodCandidates (Q : ℤ) : Finset ℤ :=
  (Finset.Icc 2 (Q - 1)).filter
    (fun b => 3 * b < Q ∧ (b ∣ Q - 1 ∨ b ∣ Q + 1))

/-- The largest triangular-index integer `n_Q`, represented by a bounded
`findGreatest` so the definition is total. -/
-- zpi: def-refined-critical-branch-envelope
noncomputable def refinedNQ (Q : ℤ) : ℕ :=
  Nat.findGreatest
    (fun n : ℕ => (((n + 1) * (n + 2) : ℕ) : ℤ) / 2 ≤ Q)
    Q.natAbs

/-- The exceptional set `𝓔_{Q,y}`. -/
-- zpi: def-refined-critical-branch-envelope
noncomputable def refinedExceptionalSet (Q y : ℤ) : Finset ℤ :=
  (refinedGoodCandidates Q).filter
    (fun b => b ≠ y ∧
      ((b < y ∧ IsDyadic b ∧ ¬ b ∣ y) ∨ (y < b ∧ b < 2 * y)))

/-- The first part of the refined envelope. -/
-- zpi: def-refined-critical-branch-envelope
noncomputable def refinedGoodEnvelope (Q y : ℤ) : ℝ :=
  let vpart : ℕ := Nat.findGreatest
    (fun v : ℕ => (2 : ℤ) ^ v ∣ y) y.natAbs
  let p : ℤ := (2 : ℤ) ^ (vpart + 1) - 1
  (p : ℝ) / y + ((Q - y - p : ℤ) : ℝ) / (y * (Q - 1)) +
    ∑ b ∈ refinedExceptionalSet Q y,
      max 0 ((1 : ℝ) /
        (cyclicDistance Q (y * inverseMod Q b) : ℝ) -
        (b : ℝ) / (y * (Q - 1)))

/-- The complete refined critical-branch envelope `U(Q,y)`. -/
-- zpi: def-refined-critical-branch-envelope
noncomputable def refinedCriticalEnvelope (Q y : ℤ) : ℝ :=
  refinedGoodEnvelope Q y +
    16 * (refinedNQ Q : ℝ) / (7 * (Q - y)) +
    8 * (refinedNQ Q : ℝ) / (7 * Q)

/-- The verifier's candidate range of odd `(Q,y)` pairs. -/
-- zpi: prop-refined-envelope-verifier-reduces-critical-branch-to-q-at-most-289
noncomputable def criticalVerifierPairs : Finset (ℤ × ℤ) :=
  ((Finset.Icc 7 5607).product (Finset.Icc 5 1868)).filter
    (fun x => x.1 % 2 = 1 ∧ 3 * x.2 < x.1 ∧
      (x.2 ∣ x.1 - 1 ∨ x.2 ∣ x.1 + 1) ∧ ¬ IsDyadic x.2)

/-- Pairs not excluded by the refined envelope. -/
-- zpi: prop-refined-envelope-verifier-reduces-critical-branch-to-q-at-most-289
noncomputable def criticalVerifierSurvivors : Finset (ℤ × ℤ) :=
  criticalVerifierPairs.filter (fun x => 1 ≤ refinedCriticalEnvelope x.1 x.2)

/-- Pairs in the decisive range which are excluded, and their exclusion margin. -/
-- zpi: prop-refined-envelope-verifier-reduces-critical-branch-to-q-at-most-289
noncomputable def criticalVerifierExcluded : Finset (ℤ × ℤ) :=
  criticalVerifierPairs.filter
    (fun x => 290 ≤ x.1 ∧ refinedCriticalEnvelope x.1 x.2 < 1)

-- zpi: prop-refined-envelope-verifier-reduces-critical-branch-to-q-at-most-289
noncomputable def criticalExclusionMargin (Q y : ℤ) : ℝ :=
  1 - refinedCriticalEnvelope Q y

/-- Exact rational verification imported from
`certificates/sc_s1_critical_certificate.py`. -/
-- zpi: prop-refined-envelope-verifier-reduces-critical-branch-to-q-at-most-289
axiom refinedEnvelopeVerifierReducesCriticalBranch
    (D : LeastNondyadicGoodElementData)
    (hAll : ∀ a ∈ D.toMinimumRowSlackData.A,
      RowPasses D.toMinimumRowSlackData.Q D.toMinimumRowSlackData.A a) :
    D.toMinimumRowSlackData.Q ≤ 289 ∧
      criticalVerifierPairs.card = 39232 ∧
      criticalVerifierSurvivors.card = 155 ∧
      (∀ x ∈ criticalVerifierSurvivors, x.1 ≤ 289) ∧
      criticalExclusionMargin 311 24 =
        (1140922873693 : ℝ) / 64523567545080 ∧
      (∀ x ∈ criticalVerifierExcluded,
        (1140922873693 : ℝ) / 64523567545080 ≤
          criticalExclusionMargin x.1 x.2)

/-- The dyadic-close harmonic envelope. -/
-- zpi: lem-dyadic-close-harmonic-envelope
theorem dyadicCloseHarmonicEnvelope (D : LeastNondyadicGoodElementData) :
    goodRowContribution D <
      2 / D.m + 10 * (D.J : ℝ) / (3 * D.y) +
        2 * harmonicNumber ((D.y - 1).natAbs) / (D.y - 1) := by
  classical
  let E : MinimumRowSlackData := D.toMinimumRowSlackData
  have hs : E.s = 1 := D.hs_one
  have hQ : 2 ≤ E.Q := by
    have h := E.hQ
    omega
  have hqpos : 0 < E.Q := by omega
  have h1 : (1 : ℤ) ∈ E.A := by
    simpa [E, hs] using E.hs_mem
  have hyA : D.y ∈ E.A := by
    simpa [E] using D.hy_mem
  have hypos : 0 < D.y := by
    exact (E.hA.1 D.y hyA).1
  have hygt : 1 < D.y := by
    by_contra hnot
    have hyeq : D.y = 1 := by omega
    apply D.hy_nondyadic
    refine ⟨0, ?_⟩
    simpa [hyeq]
  have hm_lower : 3 ≤ D.m := D.hm_lower
  have hygt' : 1 < D.y := hygt
  have hyQ : 3 * D.y < E.Q := by
    simpa [E] using E.hA_upper D.y D.hy_mem
  have hygood : GoodMinimumRowElement E D.y := by
    simpa [E] using D.hy_good
  have hqminusy : 0 < E.Q - D.y := by omega
  have hmpos : 0 < D.m := by omega
  have hmpowpos : 0 < (2 : ℤ) ^ D.v := by positivity
  have hbook := productShellBookkeeping E
  have hshell := hbook.1
  have hrecip := hbook.2.1
  have hsubset := hbook.2.2.1
  have hdiv := hbook.2.2.2.1
  have hspecial := hbook.2.2.2.2
  let G : Finset ℤ := (E.A.erase 1).filter
    (fun b => b ≠ D.y ∧ GoodMinimumRowElement E b)
  have hGsub : G ⊆ E.A.erase D.y := by
    intro b hb
    have hb0 := Finset.mem_filter.mp hb
    have hb1 := Finset.mem_erase.mp hb0.1
    exact Finset.mem_erase.mpr ⟨hb0.2.1, hb1.2⟩
  have hGA (b : ℤ) (hb : b ∈ G) : b ∈ E.A := by
    exact (Finset.mem_erase.mp (Finset.mem_filter.mp hb).1).2
  have hGpos (b : ℤ) (hb : b ∈ G) : 0 < b :=
    (E.hA.1 b (hGA b hb)).1
  have hGgood (b : ℤ) (hb : b ∈ G) : GoodMinimumRowElement E b :=
    (Finset.mem_filter.mp hb).2.2
  have hGneq (b : ℤ) (hb : b ∈ G) : b ≠ D.y :=
    (Finset.mem_filter.mp hb).2.1
  have hcontrib : goodRowContribution D =
      (1 : ℝ) / D.y +
        ∑ b ∈ G, (1 : ℝ) /
          (productShellDistance E D.y b : ℝ) := by
    simp [goodRowContribution, G, productShellDistance, E]
  let f : ℤ → ℝ := fun b =>
    (1 : ℝ) / (productShellDistance E D.y b : ℝ)
  let Lower : Finset ℤ := G.filter (fun b => b < D.y)
  let Upper : Finset ℤ := G.filter (fun b => ¬ b < D.y)
  let P : Finset ℤ := Lower.filter (fun b => b ∣ D.y)
  let X : Finset ℤ := Lower.filter (fun b => ¬ b ∣ D.y)
  let C : Finset ℤ := Upper.filter (fun b => b < 2 * D.y)
  let F : Finset ℤ := Upper.filter (fun b => ¬ b < 2 * D.y)
  have hsumG : (∑ b ∈ G, f b) =
      (∑ b ∈ P, f b) + ∑ b ∈ X, f b +
        ∑ b ∈ C, f b + ∑ b ∈ F, f b := by
    have h1 := (Finset.sum_filter_add_sum_filter_not G
      (fun b : ℤ => b < D.y) f).symm
    have h2 := (Finset.sum_filter_add_sum_filter_not Lower
      (fun b : ℤ => b ∣ D.y) f).symm
    have h3 := (Finset.sum_filter_add_sum_filter_not Upper
      (fun b : ℤ => b < 2 * D.y) f).symm
    dsimp [Lower, Upper, P, X, C, F] at h1 h2 h3 ⊢
    linarith
  have hPsub : P ⊆ G := by
    intro b hb
    exact (Finset.mem_filter.mp (Finset.mem_filter.mp hb).1).1
  have hXsub : X ⊆ G := by
    intro b hb
    exact (Finset.mem_filter.mp (Finset.mem_filter.mp hb).1).1
  have hCsub : C ⊆ G := by
    intro b hb
    exact (Finset.mem_filter.mp (Finset.mem_filter.mp hb).1).1
  have hFsub : F ⊆ G := by
    intro b hb
    exact (Finset.mem_filter.mp (Finset.mem_filter.mp hb).1).1
  have hPpos (b : ℤ) (hb : b ∈ P) : 0 < b :=
    hGpos b (hPsub hb)
  have hXpos (b : ℤ) (hb : b ∈ X) : 0 < b :=
    hGpos b (hXsub hb)
  have hCpos (b : ℤ) (hb : b ∈ C) : 0 < b :=
    hGpos b (hCsub hb)
  have hFpos (b : ℤ) (hb : b ∈ F) : 0 < b :=
    hGpos b (hFsub hb)
  have hP_lt (b : ℤ) (hb : b ∈ P) : b < D.y :=
    (Finset.mem_filter.mp (Finset.mem_filter.mp hb).1).2
  have hX_lt (b : ℤ) (hb : b ∈ X) : b < D.y :=
    (Finset.mem_filter.mp (Finset.mem_filter.mp hb).1).2
  have hC_lt (b : ℤ) (hb : b ∈ C) : b < 2 * D.y :=
    (Finset.mem_filter.mp hb).2
  have hF_ge (b : ℤ) (hb : b ∈ F) : 2 * D.y ≤ b := by
    have h := (Finset.mem_filter.mp hb).2
    omega
  have hP_dvd (b : ℤ) (hb : b ∈ P) : b ∣ D.y :=
    (Finset.mem_filter.mp hb).2
  have hX_ndvd (b : ℤ) (hb : b ∈ X) : ¬ b ∣ D.y :=
    (Finset.mem_filter.mp hb).2
  have hUpper_notlt (b : ℤ) (hb : b ∈ C) : ¬ b < D.y :=
    (Finset.mem_filter.mp (Finset.mem_filter.mp hb).1).2
  have hUpper_notltF (b : ℤ) (hb : b ∈ F) : ¬ b < D.y :=
    (Finset.mem_filter.mp (Finset.mem_filter.mp hb).1).2
  have hPdist (b : ℤ) (hb : b ∈ P) :
      productShellDistance E D.y b = D.y / b := by
    have hbG := hPsub hb
    have hbA := hGA b hbG
    have hcop := E.hA.1 b hbA
    have hinv := inverseMod_spec E.Q b hQ hcop.2
    obtain ⟨c, hc⟩ := hP_dvd b hb
    have hcpos : 0 < c := by
      have hbpos' := hPpos b hb
      nlinarith [hc, hypos]
    have hcle : c ≤ D.y := by
      have hbpos' := hPpos b hb
      nlinarith [hc]
    have hcQ : c < E.Q := by nlinarith [hyQ, hcle]
    have h2cQ : 2 * c ≤ E.Q := by nlinarith [hyQ, hcle]
    have hcmod : c % E.Q = c := Int.emod_eq_of_lt (by omega) hcQ
    have hres : (D.y * inverseMod E.Q b) % E.Q = c := by
      calc
        (D.y * inverseMod E.Q b) % E.Q =
            (b * c * inverseMod E.Q b) % E.Q := by rw [hc]
        _ = (c * (b * inverseMod E.Q b)) % E.Q := by
          congr 1 <;> ring
        _ = c := by
          rw [Int.mul_emod, hinv.2]
          simp [hcmod]
    have hquot : D.y / b = c := by
      apply Int.ediv_eq_of_eq_mul_right (ne_of_gt (hPpos b hb))
      exact hc
    dsimp [productShellDistance, cyclicDistance]
    rw [hres, min_eq_left]
    · exact hquot.symm
    · omega
  have hbelow_dyadic (b : ℤ) (hb : b ∈ G) (hblt : b < D.y) :
      IsDyadic b := by
    by_contra hnot
    have hbpos := hGpos b hb
    have hbne1 : b ≠ 1 := (Finset.mem_erase.mp
      (Finset.mem_filter.mp hb).1).1
    have hle := D.hy_least b (hGA b hb) (by omega : 1 < b)
      (hGgood b hb) (by simpa [IsDyadic] using hnot)
    omega
  have hPpow (b : ℤ) (hb : b ∈ P) :
      ∃ k : ℕ, b = (2 : ℤ) ^ k := by
    exact hbelow_dyadic b (hPsub hb) (hP_lt b hb)
  have hPpow_le (b : ℤ) (hb : b ∈ P) (k : ℕ)
      (hbk : b = (2 : ℤ) ^ k) : k ≤ D.v := by
    by_contra hnot
    have hvk : D.v + 1 ≤ k := by omega
    have hpow : (2 : ℤ) ^ (D.v + 1) ∣ (2 : ℤ) ^ k :=
      pow_dvd_pow _ hvk
    have hbd : (2 : ℤ) ^ (D.v + 1) ∣ D.y := by
      apply dvd_trans hpow
      rw [← hbk]
      exact hP_dvd b hb
    exact D.hv_maximal hbd
  let PowP : Finset ℤ := (Finset.range (D.v + 1)).image
    (fun k : ℕ => (2 : ℤ) ^ k)
  have hPsubPow : P ⊆ PowP := by
    intro b hb
    obtain ⟨k, hbk⟩ := hPpow b hb
    have hk_le := hPpow_le b hb k hbk
    apply Finset.mem_image.mpr
    exact ⟨k, Finset.mem_range.mpr (by omega : k < D.v + 1), hbk.symm⟩
  have hPowP_inj : Function.Injective (fun k : ℕ => (2 : ℤ) ^ k) := by
    exact pow_right_injective₀ (by norm_num) (by norm_num)
  have hsumPInt : (∑ b ∈ P, b) ≤ ∑ p ∈ PowP, p := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hPsubPow
    intro p hp hnot
    obtain ⟨k, hk, rfl⟩ := Finset.mem_image.mp hp
    positivity
  have hsumPowP : (∑ p ∈ PowP, p) =
      (2 : ℤ) ^ (D.v + 1) - 1 := by
    dsimp [PowP]
    rw [Finset.sum_image]
    · have hh := geom_sum_mul (2 : ℤ) (D.v + 1)
      norm_num at hh ⊢
      nlinarith
    · intro a ha b hb hab
      exact hPowP_inj hab
  have hPone : (1 : ℤ) ∉ P := by
    intro h
    have hG1 := hPsub h
    have hErase : (1 : ℤ) ∈ E.A.erase 1 :=
      (Finset.mem_filter.mp hG1).1
    exact (Finset.mem_erase.mp hErase).1 rfl
  have honePowP : (1 : ℤ) ∈ PowP := by
    apply Finset.mem_image.mpr
    exact ⟨0, Finset.mem_range.mpr (by omega), by simp⟩
  have hPowPnonneg : ∀ z ∈ PowP, 0 ≤ z := by
    intro z hz
    obtain ⟨k, hk, rfl⟩ := Finset.mem_image.mp hz
    positivity
  have hsumPIntOne : 1 + (∑ b ∈ P, b) ≤
      (2 : ℤ) ^ (D.v + 1) - 1 := by
    exact pBoundWithOneScratch P PowP D.v hPsubPow honePowP hPone
      hsumPowP hPowPnonneg
  have hsumPROne : (1 : ℝ) + (∑ b ∈ P, (b : ℝ)) ≤
      ((2 : ℤ) ^ (D.v + 1) - 1 : ℝ) := by
    have hcast : ((∑ b ∈ P, b : ℤ) : ℝ) =
        ∑ b ∈ P, (b : ℝ) := by norm_num
    rw [← hcast]
    exact_mod_cast hsumPIntOne
  have hPsum : (∑ b ∈ P, f b) =
      ∑ b ∈ P, (b : ℝ) / (D.y : ℝ) := by
    apply Finset.sum_congr rfl
    intro b hb
    obtain ⟨c, hc⟩ := hP_dvd b hb
    have hcpos : 0 < c := by
      nlinarith [hc, hypos, hPpos b hb]
    have hquot : D.y / b = c := by
      apply Int.ediv_eq_of_eq_mul_right (ne_of_gt (hPpos b hb))
      exact hc
    dsimp [f]
    rw [hPdist b hb, hquot]
    have hcy : (c : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hcpos)
    have hby : (D.y : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hypos)
    have hcR : (D.y : ℝ) = (b : ℝ) * (c : ℝ) := by
      exact_mod_cast hc
    field_simp [hcy, hby]
    nlinarith [hcR]
  have hXpow (b : ℤ) (hb : b ∈ X) :
      ∃ k : ℕ, b = (2 : ℤ) ^ k := by
    exact hbelow_dyadic b (hXsub hb) (hX_lt b hb)
  have hXpow_gt (b : ℤ) (hb : b ∈ X) (k : ℕ)
      (hbk : b = (2 : ℤ) ^ k) : D.v < k := by
    by_contra hnot
    have hkv : k ≤ D.v := by omega
    have hpow : (2 : ℤ) ^ k ∣ (2 : ℤ) ^ D.v :=
      pow_dvd_pow _ hkv
    have hbd : (2 : ℤ) ^ k ∣ D.y := by
      rw [D.hy_decomp]
      exact dvd_mul_of_dvd_left hpow _
    exact hX_ndvd b hb (by simpa [hbk] using hbd)
  have hXpow_lt (b : ℤ) (hb : b ∈ X) (k : ℕ)
      (hbk : b = (2 : ℤ) ^ k) :
      (2 : ℤ) ^ (k - D.v) ≤ D.m - 1 := by
    have hvk : D.v ≤ k := (hXpow_gt b hb k hbk).le
    have hpowsub : k = D.v + (k - D.v) := by omega
    have hlt : (2 : ℤ) ^ D.v * (2 : ℤ) ^ (k - D.v) <
        (2 : ℤ) ^ D.v * D.m := by
      calc
        (2 : ℤ) ^ D.v * (2 : ℤ) ^ (k - D.v) =
            (2 : ℤ) ^ k := by
              calc
                (2 : ℤ) ^ D.v * (2 : ℤ) ^ (k - D.v) =
                    (2 : ℤ) ^ (D.v + (k - D.v)) := by
                      exact (pow_add (2 : ℤ) D.v (k - D.v)).symm
                _ = (2 : ℤ) ^ k := by
                  congr 1
                  omega
        _ = b := hbk.symm
        _ < D.y := hX_lt b hb
        _ = (2 : ℤ) ^ D.v * D.m := D.hy_decomp
    have hpv : 0 < (2 : ℤ) ^ D.v := by positivity
    have hlt' : (2 : ℤ) ^ (k - D.v) < D.m :=
      lt_of_mul_lt_mul_left hlt hpv.le
    exact Int.le_sub_one_of_lt hlt'
  have hXj_le (b : ℤ) (hb : b ∈ X) (k : ℕ)
      (hbk : b = (2 : ℤ) ^ k) : k - D.v ≤ D.J := by
    have hjlower := hXpow_lt b hb k hbk
    by_contra hnot
    have hj : D.J + 1 ≤ k - D.v := by omega
    have hp : (2 : ℤ) ^ (D.J + 1) ≤
        (2 : ℤ) ^ (k - D.v) := by
      by_cases heq : D.J + 1 = k - D.v
      · simpa [heq]
      · have hlt : D.J + 1 < k - D.v := by omega
        exact (pow_lt_pow_right₀ (by norm_num : (1 : ℤ) < 2) hlt).le
    have hu := D.hJ_upper
    nlinarith
  have hXdist (b : ℤ) (hb : b ∈ X) :
      D.y - 1 ≤ 2 * productShellDistance E D.y b := by
    obtain ⟨k, hbk⟩ := hXpow b hb
    have hvk : D.v < k := hXpow_gt b hb k hbk
    let j : ℕ := k - D.v
    have hjpos : 1 ≤ j := by
      dsimp [j]
      omega
    have hjle : j ≤ D.J := by
      dsimp [j]
      exact hXj_le b hb k hbk
    let powj : ℤ := (2 : ℤ) ^ j
    have hpowjpos : 0 < powj := by
      dsimp [powj]
      positivity
    have hpowj2 : 2 ≤ powj := by
      have hh := pow_le_pow_right₀ (a := (2 : ℤ))
        (by norm_num : (1 : ℤ) ≤ 2) hjpos
      dsimp [powj]
      simpa using hh
    let rho : ℤ := D.m / powj
    let r : ℤ := D.m % powj
    have hmqr : powj * rho + r = D.m := by
      have hh := Int.mul_ediv_add_emod D.m powj
      simpa [rho, r] using hh
    have hr0 : 0 ≤ r := by
      dsimp [r]
      exact Int.emod_nonneg _ (ne_of_gt hpowjpos)
    have hrlt : r < powj := by
      dsimp [r]
      exact Int.emod_lt_of_pos _ hpowjpos
    have hrne : r ≠ 0 := by
      intro hr
      have hpowdvd : powj ∣ D.m := by
        refine ⟨rho, ?_⟩
        rw [← hmqr, hr]
        ring
      have h2pow : (2 : ℤ) ∣ powj := by
        obtain ⟨j', hj'⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : j ≠ 0)
        refine ⟨(2 : ℤ) ^ j', ?_⟩
        dsimp [powj]
        rw [hj', pow_succ]
        ring
      have h2m : (2 : ℤ) ∣ D.m := dvd_trans h2pow hpowdvd
      have hmzero : D.m % 2 = 0 := Int.emod_eq_zero_of_dvd h2m
      have hmododd := D.hm_odd
      omega
    have hrpos : 0 < r := lt_of_le_of_ne hr0 (Ne.symm hrne)
    have hrle : 1 ≤ r := by omega
    have hmnonneg : 0 ≤ D.m := by omega
    have hrhonneg : 0 ≤ rho := by
      dsimp [rho]
      exact Int.ediv_nonneg hmnonneg hpowjpos.le
    have hpv1 : 1 ≤ (2 : ℤ) ^ D.v := by
      have hh := hmpowpos
      omega
    have hymge : D.m ≤ D.y := by
      have hh := mul_le_mul_of_nonneg_right hpv1 hmnonneg
      rw [D.hy_decomp]
      simpa using hh
    have hpowrho : 2 * rho ≤ powj * rho := by
      exact mul_le_mul_of_nonneg_right hpowj2 hrhonneg
    have hmrho : powj * rho ≤ D.m - 1 := by
      nlinarith [hmqr, hrle]
    have h2rho : 2 * rho ≤ D.y - 1 := by
      have hm1 : D.m - 1 ≤ D.y - 1 := by omega
      exact (hpowrho.trans hmrho).trans hm1
    have hb_factor : b = (2 : ℤ) ^ D.v * powj := by
      have hkj : k = D.v + j := by
        dsimp [j]
        omega
      calc
        b = (2 : ℤ) ^ k := hbk
        _ = (2 : ℤ) ^ (D.v + j) := by rw [hkj]
        _ = (2 : ℤ) ^ D.v * (2 : ℤ) ^ j := by
          rw [pow_add]
        _ = (2 : ℤ) ^ D.v * powj := by rfl
    have hcase (K L eta eps : ℤ)
        (hKy : K * D.y = E.Q + eta)
        (hLb : L * b = E.Q + eps)
        (heta : eta = 1 ∨ eta = -1)
        (heps : eps = 1 ∨ eps = -1) :
        D.y - 1 ≤ 2 * productShellDistance E D.y b := by
      have heta_bounds : -1 ≤ eta ∧ eta ≤ 1 := by
        rcases heta with h | h <;> omega
      have heps_bounds : -1 ≤ eps ∧ eps ≤ 1 := by
        rcases heps with h | h <;> omega
      have hK : 3 ≤ K := by
        by_contra hnot
        have hK2 : K ≤ 2 := by omega
        have hKy_le : K * D.y ≤ 2 * D.y := by
          exact mul_le_mul_of_nonneg_right hK2 (le_of_lt hypos)
        nlinarith [hKy, hyQ, heta_bounds.2, heta_bounds.1]
      let c : ℤ := L * powj - K * D.m
      have hceq : eps - eta = (2 : ℤ) ^ D.v * c := by
        calc
          eps - eta = L * b - K * D.y := by nlinarith [hKy, hLb]
          _ = L * ((2 : ℤ) ^ D.v * powj) -
              K * ((2 : ℤ) ^ D.v * D.m) := by
                rw [hb_factor, D.hy_decomp]
          _ = (2 : ℤ) ^ D.v * (L * powj - K * D.m) := by ring
          _ = (2 : ℤ) ^ D.v * c := by rfl
      have hceq_bounds : -2 ≤ eps - eta ∧ eps - eta ≤ 2 := by
        omega
      have hc_upper : c ≤ 2 := by
        by_contra hnot
        have hc3 : 3 ≤ c := by omega
        have hmul : 0 ≤ ((2 : ℤ) ^ D.v - 1) * c := by
          exact mul_nonneg (by omega) (by omega)
        nlinarith [hceq, hceq_bounds.2]
      have hc_lower : -2 ≤ c := by
        by_contra hnot
        have hc3 : c ≤ -3 := by omega
        have hmul : 0 ≤ ((2 : ℤ) ^ D.v - 1) * (-c) := by
          exact mul_nonneg (by omega) (by omega)
        nlinarith [hceq, hceq_bounds.1]
      have hcbounds : -2 ≤ c ∧ c ≤ 2 := ⟨hc_lower, hc_upper⟩
      have hrel : (L - K * rho) * powj = K * r + c := by
        dsimp [c]
        rw [← hmqr]
        ring
      have hleft : 1 ≤ K * r + c := by
        have hKr : K ≤ K * r := by
          simpa using (mul_le_mul_of_nonneg_left hrle (by omega : 0 ≤ K))
        nlinarith [hKr, hcbounds.1, hK]
      have hpr : 1 ≤ powj - r := by omega
      have hKpr : K ≤ K * (powj - r) := by
        simpa using (mul_le_mul_of_nonneg_left hpr (by omega : 0 ≤ K))
      have hright : K * r + c < K * powj := by
        nlinarith [hKpr, hcbounds.2]
      let H : ℤ := L - K * rho
      have hH_lower : 1 ≤ H := by
        by_contra hnot
        have hH0 : H ≤ 0 := by omega
        have hmul : H * powj ≤ 0 :=
          mul_nonpos_of_nonpos_of_nonneg hH0 hpowjpos.le
        nlinarith [hrel, hleft]
      have hH_upper : H ≤ K - 1 := by
        by_contra hnot
        have hHK : K ≤ H := by omega
        have hmul : K * powj ≤ H * powj :=
          mul_le_mul_of_nonneg_right hHK hpowjpos.le
        nlinarith [hrel, hright]
      have hHpos : 0 ≤ H := by omega
      have hKHpos : 0 ≤ K - H := by omega
      let r₁ : ℤ := H * D.y + rho * eta
      let r₂ : ℤ := (K - H) * D.y - (rho + 1) * eta
      have hsumr : r₁ + r₂ = E.Q := by
        dsimp [r₁, r₂]
        nlinarith [hKy]
      have heta_low : -rho ≤ rho * eta := by
        have hh := mul_le_mul_of_nonneg_left heta_bounds.1 hrhonneg
        nlinarith
      have heta_high : -(rho + 1) ≤ -(rho + 1) * eta := by
        have hh := mul_le_mul_of_nonneg_left heps_bounds.2
          (by omega : 0 ≤ rho + 1)
        nlinarith
      have hr₁_lower : D.y - 1 ≤ 2 * r₁ := by
        dsimp [r₁]
        nlinarith [hH_lower, heta_low, h2rho]
      have hr₂_lower : D.y - 1 ≤ 2 * r₂ := by
        dsimp [r₂]
        nlinarith [hH_upper, heta_high, h2rho]
      have hr₁pos : 0 < r₁ := by
        nlinarith [hr₁_lower, hygt]
      have hr₂pos : 0 < r₂ := by
        nlinarith [hr₂_lower, hygt]
      have hr₁lt : r₁ < E.Q := by nlinarith [hsumr, hr₂pos]
      have hr₂lt : r₂ < E.Q := by nlinarith [hsumr, hr₁pos]
      have hr₁mod : r₁ % E.Q = r₁ :=
        Int.emod_eq_of_lt (by omega) hr₁lt
      have ht_eq : L * D.y = E.Q * rho + r₁ := by
        calc
          L * D.y = (K * rho + H) * D.y := by
            dsimp [H]
            ring
          _ = rho * (K * D.y) + H * D.y := by ring
          _ = rho * (E.Q + eta) + H * D.y := by rw [hKy]
          _ = E.Q * rho + r₁ := by
            dsimp [r₁]
            ring
      have htmod : (L * D.y) % E.Q = r₁ := by
        rw [ht_eq, Int.add_emod, Int.mul_emod, Int.emod_self, zero_mul]
        simp [hr₁mod]
      have hcopb : Int.gcd b E.Q = 1 := (E.hA.1 b (hGA b (hXsub hb))).2
      have hinv := inverseMod_spec E.Q b hQ hcopb
      have hepssq : eps * eps = 1 := by
        rcases heps with rfl | rfl <;> norm_num
      have hprod_eps : (b * (eps * L)) % E.Q = 1 := by
        have heq : b * (eps * L) = eps * E.Q + 1 := by
          calc
            b * (eps * L) = eps * (L * b) := by ring
            _ = eps * (E.Q + eps) := by rw [hLb]
            _ = eps * E.Q + 1 := by nlinarith [hepssq]
        rw [heq, Int.add_emod, Int.mul_emod, Int.emod_self]
        have hone : (1 : ℤ) % E.Q = 1 :=
          Int.emod_eq_of_lt (by omega) (by omega)
        simpa using hone
      have hprod_eps' : ((eps * L) * b) % E.Q = 1 := by
        simpa [mul_comm] using hprod_eps
      have hzero : ((inverseMod E.Q b - eps * L) * b) % E.Q = 0 := by
        calc
          ((inverseMod E.Q b - eps * L) * b) % E.Q =
              (inverseMod E.Q b * b - (eps * L) * b) % E.Q := by
                congr 1 <;> ring
          _ = ((inverseMod E.Q b * b) % E.Q -
              ((eps * L) * b) % E.Q) % E.Q := by rw [Int.sub_emod]
          _ = 0 := by
            rw [show (inverseMod E.Q b * b) % E.Q = 1 by
              simpa [mul_comm] using hinv.2, hprod_eps']
            simp
      have hcopQb : Int.gcd E.Q b = 1 := by
        simpa [Int.gcd_comm] using hcopb
      have hdivinv : E.Q ∣ inverseMod E.Q b - eps * L := by
        apply Int.dvd_of_dvd_mul_left_of_gcd_one
          (a := E.Q) (b := inverseMod E.Q b - eps * L) (c := b)
        · exact Int.dvd_of_emod_eq_zero hzero
        · exact hcopQb
      have hdivinv' : E.Q ∣ eps * L - inverseMod E.Q b := by
        convert dvd_neg.mpr hdivinv using 1 <;> ring
      have hinvmod : inverseMod E.Q b ≡ eps * L [ZMOD E.Q] :=
        (Int.modEq_iff_dvd).2 hdivinv'
      have hyinvmod : D.y * inverseMod E.Q b ≡
          D.y * (eps * L) [ZMOD E.Q] := hinvmod.mul_left D.y
      have hdist_eq : productShellDistance E D.y b = min r₁ r₂ := by
        rcases heps with heps | heps
        · have hres : (D.y * inverseMod E.Q b) % E.Q = r₁ := by
            calc
              (D.y * inverseMod E.Q b) % E.Q =
                  (D.y * ((1 : ℤ) * L)) % E.Q := by
                    simpa [heps] using hyinvmod.eq
              _ = (L * D.y) % E.Q := by congr 1 <;> ring
              _ = r₁ := htmod
          have hqminus : E.Q - r₁ = r₂ := by omega
          dsimp [productShellDistance, cyclicDistance]
          rw [hres, hqminus]
        · have htne : ¬ E.Q ∣ L * D.y := by
            intro hdiv
            have hz : (L * D.y) % E.Q = 0 := Int.emod_eq_zero_of_dvd hdiv
            rw [hz] at htmod
            omega
          have hnegmod : (-(L * D.y)) % E.Q = r₂ := by
            rw [Int.neg_emod]
            simp [htne, htmod, Int.natAbs_of_nonneg hqpos.le]
            omega
          have hres : (D.y * inverseMod E.Q b) % E.Q = r₂ := by
            calc
              (D.y * inverseMod E.Q b) % E.Q =
                  (D.y * ((-1 : ℤ) * L)) % E.Q := by
                    simpa [heps] using hyinvmod.eq
              _ = (-(L * D.y)) % E.Q := by congr 1 <;> ring
              _ = r₂ := hnegmod
          have hqminus : E.Q - r₂ = r₁ := by omega
          dsimp [productShellDistance, cyclicDistance]
          rw [hres, hqminus]
          simp [min_comm]
      rw [hdist_eq]
      by_cases hle : r₁ ≤ r₂
      · rw [min_eq_left hle]
        exact hr₁_lower
      · have hle' : r₂ ≤ r₁ := by omega
        rw [min_eq_right hle']
        exact hr₂_lower
    rcases hygood with hyminus | hyplus
    · obtain ⟨K, hK⟩ := hyminus
      rcases hGgood b (hXsub hb) with hbminus | hbplus
      · obtain ⟨L, hL⟩ := hbminus
        apply hcase K L (-1) (-1)
        · nlinarith [hK]
        · nlinarith [hL]
        · exact Or.inr rfl
        · exact Or.inr rfl
      · obtain ⟨L, hL⟩ := hbplus
        apply hcase K L (-1) 1
        · nlinarith [hK]
        · nlinarith [hL]
        · exact Or.inr rfl
        · exact Or.inl rfl
    · obtain ⟨K, hK⟩ := hyplus
      rcases hGgood b (hXsub hb) with hbminus | hbplus
      · obtain ⟨L, hL⟩ := hbminus
        apply hcase K L 1 (-1)
        · nlinarith [hK]
        · nlinarith [hL]
        · exact Or.inl rfl
        · exact Or.inr rfl
      · obtain ⟨L, hL⟩ := hbplus
        apply hcase K L 1 1
        · nlinarith [hK]
        · nlinarith [hL]
        · exact Or.inl rfl
        · exact Or.inl rfl
  have hXshell (b : ℤ) (hb : b ∈ X) :
      E.Q - D.y ≤ productShellValue E D.y b := by
    have hbG := hXsub hb
    have hbA := hGA b hbG
    have hne : D.y ≠ b := Ne.symm (hGneq b hbG)
    have hshell' := hshell D.y hyA b hbA hne
    rcases hshell' with hfirst | ⟨j, hj, hminus | hplus⟩
    · have hdvd := hdiv D.y hyA b hbA hne hfirst
      exact False.elim (hX_ndvd b hb hdvd)
    · have hqnonneg : 0 ≤ E.Q := by omega
      have hqj : E.Q ≤ j * E.Q := by
        have hh := mul_le_mul_of_nonneg_right hj hqnonneg
        nlinarith
      nlinarith [hminus, hqj]
    · have hqnonneg : 0 ≤ E.Q := by omega
      have hqj : E.Q ≤ j * E.Q := by
        have hh := mul_le_mul_of_nonneg_right hj hqnonneg
        nlinarith
      nlinarith [hplus, hqj]
  let PowX : Finset ℤ := (Finset.range D.J).image
    (fun j : ℕ => (2 : ℤ) ^ (D.v + 1 + j))
  have hXsubPow : X ⊆ PowX := by
    intro b hb
    obtain ⟨k, hbk⟩ := hXpow b hb
    have hj := hXj_le b hb k hbk
    have hvk := hXpow_gt b hb k hbk
    let j : ℕ := k - (D.v + 1)
    have hjrange : j < D.J := by
      dsimp [j]
      omega
    have hkj : k = D.v + 1 + j := by
      dsimp [j]
      omega
    apply Finset.mem_image.mpr
    refine ⟨j, Finset.mem_range.mpr hjrange, ?_⟩
    rw [hbk, hkj]
  have hPowXinj : Function.Injective
      (fun j : ℕ => (2 : ℤ) ^ (D.v + 1 + j)) := by
    intro a b hab
    have hh : D.v + 1 + a = D.v + 1 + b := by
      exact pow_right_injective₀ (by norm_num) (by norm_num) hab
    omega
  have hsumXInt : (∑ b ∈ X, b) ≤ ∑ p ∈ PowX, p := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hXsubPow
    intro p hp hnot
    obtain ⟨j, hj, rfl⟩ := Finset.mem_image.mp hp
    positivity
  have hsumPowX : (∑ p ∈ PowX, p) =
      (2 : ℤ) ^ (D.v + 1) * ((2 : ℤ) ^ D.J - 1) := by
    dsimp [PowX]
    rw [Finset.sum_image]
    · calc
        (∑ x ∈ Finset.range D.J, (2 : ℤ) ^ (D.v + 1 + x)) =
            ∑ x ∈ Finset.range D.J,
              (2 : ℤ) ^ (D.v + 1) * (2 : ℤ) ^ x := by
                apply Finset.sum_congr rfl
                intro x hx
                rw [← pow_add]
        _ = (2 : ℤ) ^ (D.v + 1) *
            (∑ x ∈ Finset.range D.J, (2 : ℤ) ^ x) := by
              rw [Finset.mul_sum]
        _ = (2 : ℤ) ^ (D.v + 1) * ((2 : ℤ) ^ D.J - 1) := by
              have hh := geom_sum_mul (2 : ℤ) D.J
              norm_num at hh ⊢
              rw [hh]
    · intro a ha b hb hab
      exact hPowXinj hab
  have hsumX_lt : (∑ b ∈ X, b) < 2 * D.y := by
    have hsumXle : (∑ b ∈ X, b) ≤
        (2 : ℤ) ^ (D.v + 1) * ((2 : ℤ) ^ D.J - 1) := by
      rw [← hsumPowX]
      exact hsumXInt
    have hpowJ : (2 : ℤ) ^ D.J ≤ D.m - 1 := D.hJ_lower
    have hpowV : (2 : ℤ) ^ D.v ≤ (2 : ℤ) ^ (D.v + 1) := by
      exact pow_le_pow_right₀ (by norm_num) (by omega)
    have hfactor : (2 : ℤ) ^ (D.v + 1) * ((2 : ℤ) ^ D.J - 1) <
        2 * ((2 : ℤ) ^ D.v * D.m) := by
      rw [pow_succ]
      have hpv : 0 < (2 : ℤ) ^ D.v := by positivity
      nlinarith
    have hfactor' : (2 : ℤ) ^ (D.v + 1) * ((2 : ℤ) ^ D.J - 1) <
        2 * D.y := by
      rw [D.hy_decomp]
      exact hfactor
    exact lt_of_le_of_lt hsumXle hfactor'
  have hXrecip : (∑ b ∈ X, f b) ≤
      (∑ b ∈ X, (b : ℝ)) / ((E.Q : ℝ) - D.y) := by
    have hXnonneg : 0 ≤ ∑ b ∈ X, (b : ℝ) := by
      apply Finset.sum_nonneg
      intro b hb
      exact_mod_cast (hXpos b hb).le
    have hdenpos : 0 < (E.Q : ℝ) - D.y := by exact_mod_cast hqminusy
    have hXerase : X ⊆ E.A.erase D.y := fun b hb => hGsub (hXsub hb)
    apply hsubset D.y hyA X hXerase _ _ hXnonneg hdenpos le_rfl
    intro b hb
    exact_mod_cast hXshell b hb
  have h2E : (2 : ℤ) ∈ E.A := by simpa [E] using D.h2
  have hcop2 : Int.gcd (2 : ℤ) E.Q = 1 := E.hA.1 2 h2E |>.2
  have hQodd : ∃ q : ℤ, E.Q = 2 * q + 1 := by
    obtain ⟨q, hqeven | hqodd⟩ := Int.even_or_odd' E.Q
    · exfalso
      have hdivQ : (2 : ℤ) ∣ E.Q := by
        refine ⟨q, ?_⟩
        exact hqeven
      have hdivG : (2 : ℕ) ∣ Int.gcd 2 E.Q :=
        Int.dvd_gcd (by exact ⟨1, by ring⟩) hdivQ
      rw [hcop2] at hdivG
      omega
    · exact ⟨q, hqodd⟩
  have hfar_base (b : ℤ) (hb : b ∈ F) :
      D.y * (E.Q - 1) ≤ productShellValue E D.y b := by
    have hbG := hFsub hb
    have hbA := hGA b hbG
    have hne : D.y ≠ b := Ne.symm (hGneq b hbG)
    have hbpos := hFpos b hb
    have hby : 2 * D.y ≤ b := hF_ge b hb
    have hgood := hGgood b hbG
    have hQplus : 0 < E.Q + 1 := by omega
    have hQminus : 0 < E.Q - 1 := by omega
    have hfar_case (eps : ℤ) (L : ℤ)
        (heps : eps = 1 ∨ eps = -1)
        (hL : L * b = E.Q + eps) :
        D.y * (E.Q - 1) ≤ productShellValue E D.y b := by
      have hLpos : 0 < L := by
        have hnum : 0 < E.Q + eps := by
          rcases heps with rfl | rfl <;> omega
        nlinarith [hL, hbpos]
      have hLypos : 0 < L * D.y := mul_pos hLpos hypos
      have hLy_bound : 2 * (L * D.y) ≤ E.Q + eps := by
        have hh := mul_le_mul_of_nonneg_left hby (show 0 ≤ L by omega)
        nlinarith [hL]
      have hprod_inv : (b * (eps * L)) % E.Q = 1 := by
        have hepssq : eps * eps = 1 := by
          rcases heps with rfl | rfl <;> norm_num
        have heq : b * (eps * L) = eps * E.Q + 1 := by
          calc
            b * (eps * L) = eps * (L * b) := by ring
            _ = eps * (E.Q + eps) := by rw [hL]
            _ = eps * E.Q + 1 := by nlinarith [hepssq]
        rw [heq, Int.add_emod, Int.mul_emod, Int.emod_self]
        have hone : (1 : ℤ) % E.Q = 1 :=
          Int.emod_eq_of_lt (by omega) (by omega)
        simpa using hone
      have hcopb : Int.gcd b E.Q = 1 := (E.hA.1 b hbA).2
      have hinv := inverseMod_spec E.Q b hQ hcopb
      have hprod_inv' : ((eps * L) * b) % E.Q = 1 := by
        simpa [mul_comm] using hprod_inv
      have hzero : ((inverseMod E.Q b - eps * L) * b) % E.Q = 0 := by
        calc
          ((inverseMod E.Q b - eps * L) * b) % E.Q =
              (inverseMod E.Q b * b - (eps * L) * b) % E.Q := by
                congr 1 <;> ring
          _ = ((inverseMod E.Q b * b) % E.Q -
              ((eps * L) * b) % E.Q) % E.Q := by rw [Int.sub_emod]
          _ = 0 := by
            rw [show (inverseMod E.Q b * b) % E.Q = 1 by
              simpa [mul_comm] using hinv.2, hprod_inv']
            simp
      have hcopQb : Int.gcd E.Q b = 1 := by
        simpa [Int.gcd_comm] using hcopb
      have hdivinv : E.Q ∣ inverseMod E.Q b - eps * L := by
        apply Int.dvd_of_dvd_mul_left_of_gcd_one
          (a := E.Q) (b := inverseMod E.Q b - eps * L) (c := b)
        · exact Int.dvd_of_emod_eq_zero hzero
        · exact hcopQb
      have hmodinv : inverseMod E.Q b ≡ eps * L [ZMOD E.Q] :=
        (Int.modEq_iff_dvd).2 (by
          convert dvd_neg.mpr hdivinv using 1 <;> ring)
      have hmody : D.y * inverseMod E.Q b ≡
          D.y * (eps * L) [ZMOD E.Q] := hmodinv.mul_left D.y
      obtain ⟨q, hqodd⟩ := hQodd
      have heps_bounds : -1 ≤ eps ∧ eps ≤ 1 := by
        rcases heps with rfl | rfl <;> omega
      have ht_ltQ : L * D.y < E.Q := by
        nlinarith [hLy_bound, hqpos, heps_bounds.2]
      have ht_res : (L * D.y) % E.Q = L * D.y :=
        Int.emod_eq_of_lt (by omega) ht_ltQ
      by_cases hhalf : L * D.y ≤ E.Q / 2
      · have hdist : productShellDistance E D.y b = L * D.y := by
          dsimp [productShellDistance, cyclicDistance]
          rcases heps with rfl | rfl
          · have hres : (D.y * inverseMod E.Q b) % E.Q = L * D.y := by
              calc
                (D.y * inverseMod E.Q b) % E.Q =
                    (D.y * ((1 : ℤ) * L)) % E.Q := by simpa using hmody.eq
                _ = L * D.y := by
                  rw [show D.y * (1 * L) = L * D.y by ring, ht_res]
            rw [hres, min_eq_left]
            omega
          · have hnot : ¬ E.Q ∣ L * D.y := by
              intro hdiv
              have hz := Int.emod_eq_zero_of_dvd hdiv
              rw [ht_res] at hz
              omega
            have hres : (D.y * inverseMod E.Q b) % E.Q = E.Q - L * D.y := by
              calc
                (D.y * inverseMod E.Q b) % E.Q =
                    (D.y * ((-1 : ℤ) * L)) % E.Q := by simpa using hmody.eq
                _ = (-(L * D.y)) % E.Q := by congr 1 <;> ring
                _ = E.Q - L * D.y := by
                  rw [Int.neg_emod]
                  simp [hnot, ht_res, Int.natAbs_of_nonneg hqpos.le]
            rw [hres]
            have hcomp : E.Q - (E.Q - L * D.y) = L * D.y := by ring
            rw [hcomp, min_eq_right]
            omega
        rw [productShellValue, hdist]
        have hcalc : b * (L * D.y) = D.y * (E.Q + eps) := by
          rw [← hL]
          ring
        have hepslow : -1 ≤ eps := by rcases heps with rfl | rfl <;> omega
        nlinarith [hcalc]
      · have hhalf' : E.Q / 2 < L * D.y := lt_of_not_ge hhalf
        have hhalfQ : E.Q / 2 = q := by rw [hqodd]; omega
        have hq_lt : q < L * D.y := by omega
        have heps1 : eps = 1 := by
          rcases heps with he | he
          · exact he
          · exfalso
            rw [he] at hLy_bound
            omega
        subst eps
        have hspecial : L * D.y = (E.Q + 1) / 2 := by
          rw [hqodd]
          omega
        have hdist : productShellDistance E D.y b = (E.Q - 1) / 2 := by
          dsimp [productShellDistance, cyclicDistance]
          have hres : (D.y * inverseMod E.Q b) % E.Q =
              (E.Q + 1) / 2 := by
            calc
              (D.y * inverseMod E.Q b) % E.Q =
                  (D.y * (1 * L)) % E.Q := by simpa using hmody.eq
              _ = L * D.y := by rw [show D.y * (1 * L) = L * D.y by ring, ht_res]
              _ = (E.Q + 1) / 2 := hspecial
          rw [hres]
          have hcomp : E.Q - (E.Q + 1) / 2 = (E.Q - 1) / 2 := by omega
          rw [hcomp, min_eq_right]
          omega
        have hb_eq : b = 2 * D.y := by
          apply mul_left_cancel₀ (ne_of_gt hLpos)
          nlinarith [hL, hspecial]
        rw [productShellValue, hdist, hb_eq]
        have hhalf_mul : 2 * ((E.Q - 1) / 2) = E.Q - 1 := by
          rw [hqodd]
          omega
        have heq : D.y * (E.Q - 1) =
            2 * D.y * ((E.Q - 1) / 2) := by
          calc
            D.y * (E.Q - 1) = D.y * (2 * ((E.Q - 1) / 2)) :=
              congrArg (fun z : ℤ => D.y * z) hhalf_mul.symm
            _ = 2 * D.y * ((E.Q - 1) / 2) := by ring
        exact le_of_eq heq
    rcases hgood with hminus | hplus
    · obtain ⟨L, hL⟩ := hminus
      apply hfar_case (-1) L (Or.inr rfl)
      nlinarith [hL]
    · obtain ⟨L, hL⟩ := hplus
      apply hfar_case 1 L (Or.inl rfl)
      nlinarith [hL]
  have hFerase : F ⊆ E.A.erase D.y := fun b hb => hGsub (hFsub hb)
  have hFsum_le_erase : (∑ b ∈ F, b) ≤
      ∑ a ∈ E.A.erase D.y, a := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hFerase
    intro a ha hnot
    have haA : a ∈ E.A := (Finset.mem_erase.mp ha).2
    exact (E.hA.1 a haA).1.le
  have hsum_erase : (∑ a ∈ E.A.erase D.y, a) + D.y =
      ∑ a ∈ E.A, a := by
    simpa using E.A.sum_erase_add (fun a : ℤ => a) hyA
  have hFsum : (∑ b ∈ F, b) ≤ E.Q - D.y := by
    have hAsum := E.hA_sum
    omega
  have hFrecip : (∑ b ∈ F, f b) ≤
      (∑ b ∈ F, (b : ℝ)) / ((D.y : ℝ) * (E.Q - 1)) := by
    have hFnonneg : 0 ≤ ∑ b ∈ F, (b : ℝ) := by
      apply Finset.sum_nonneg
      intro b hb
      exact_mod_cast (hFpos b hb).le
    have hdenpos : 0 < (D.y : ℝ) * (E.Q - 1) := by
      have hyR : (0 : ℝ) < D.y := by exact_mod_cast hypos
      have hQR : (0 : ℝ) < E.Q - 1 := by
        exact_mod_cast (show 0 < E.Q - 1 by omega)
      exact mul_pos hyR hQR
    apply hsubset D.y hyA F hFerase _ _ hFnonneg hdenpos le_rfl
    intro b hb
    exact_mod_cast hfar_base b hb
  have hFdenpos : 0 < (D.y : ℝ) * (E.Q - 1) := by
    have hyR : (0 : ℝ) < D.y := by exact_mod_cast hypos
    have hQR : (0 : ℝ) < E.Q - 1 := by
      exact_mod_cast (show 0 < E.Q - 1 by omega)
    exact mul_pos hyR hQR
  have hFsumR : (∑ b ∈ F, (b : ℝ)) ≤ (E.Q - D.y : ℝ) := by
    have hsum_cast : ((∑ b ∈ F, b : ℤ) : ℝ) =
        ∑ b ∈ F, (b : ℝ) := by
      norm_num
    rw [← hsum_cast]
    exact_mod_cast hFsum
  have hFstrict : (∑ b ∈ F, f b) < 1 / (D.y : ℝ) := by
    apply lt_of_le_of_lt hFrecip
    apply (div_lt_iff₀ hFdenpos).2
    have hstrict : (E.Q - D.y : ℝ) < E.Q - 1 := by
      exact_mod_cast (show E.Q - D.y < E.Q - 1 by omega)
    have hprod : (1 / (D.y : ℝ)) * ((D.y : ℝ) * (E.Q - 1)) =
        (E.Q - 1 : ℝ) := by
      field_simp
    rw [hprod]
    exact lt_of_le_of_lt hFsumR hstrict
  have hy3 : 3 ≤ D.y := by
    rw [D.hy_decomp]
    nlinarith [hmpowpos, hm_lower]
  have hXterm (b : ℤ) (hb : b ∈ X) :
      f b ≤ 10 / (3 * (D.y : ℝ)) := by
    dsimp [f]
    have hdpos : 0 < productShellDistance E D.y b := by
      have hh := hXdist b hb
      omega
    have hdR : 0 < (productShellDistance E D.y b : ℝ) := by
      exact_mod_cast hdpos
    have hy1R : 0 < (D.y - 1 : ℝ) := by
      exact_mod_cast (show 0 < D.y - 1 by omega)
    have hdistR : (D.y - 1 : ℝ) ≤
        2 * (productShellDistance E D.y b : ℝ) := by
      exact_mod_cast hXdist b hb
    have hbase : 1 / (productShellDistance E D.y b : ℝ) ≤
        2 / (D.y - 1 : ℝ) := by
      apply (div_le_div_iff₀ hdR hy1R).2
      simpa [mul_comm] using hdistR
    have h3y : 0 < (3 * D.y : ℝ) := by
      exact_mod_cast (show 0 < 3 * D.y by omega)
    have hcoef : 2 / (D.y - 1 : ℝ) ≤ 10 / (3 * D.y : ℝ) := by
      apply (div_le_div_iff₀ hy1R h3y).2
      have hyR : (3 : ℝ) ≤ D.y := by exact_mod_cast hy3
      nlinarith [hyR]
    exact hbase.trans hcoef
  have hPowXcard : PowX.card = D.J := by
    dsimp [PowX]
    rw [Finset.card_image_of_injective _ hPowXinj]
    simp
  have hXcard : X.card ≤ D.J := by
    calc
      X.card ≤ PowX.card := Finset.card_le_card hXsubPow
      _ = D.J := hPowXcard
  have hXsum : (∑ b ∈ X, f b) ≤
      10 * (D.J : ℝ) / (3 * D.y) := by
    have hterm_sum : (∑ b ∈ X, f b) ≤
        ∑ b ∈ X, 10 / (3 * (D.y : ℝ)) := by
      apply Finset.sum_le_sum
      intro b hb
      exact hXterm b hb
    rw [Finset.sum_const] at hterm_sum
    have hcardR : (X.card : ℝ) ≤ D.J := by exact_mod_cast hXcard
    have hc : 0 ≤ (10 / (3 * (D.y : ℝ)) : ℝ) := by positivity
    have hcard_sum := mul_le_mul_of_nonneg_right hcardR hc
    calc
      (∑ b ∈ X, f b) ≤ (X.card : ℝ) * (10 / (3 * (D.y : ℝ))) := by
        simpa [nsmul_eq_mul] using hterm_sum
      _ ≤ (D.J : ℝ) * (10 / (3 * (D.y : ℝ))) := hcard_sum
      _ = 10 * (D.J : ℝ) / (3 * D.y) := by ring
  have hyrep : ∃ K eta : ℤ, (eta = 1 ∨ eta = -1) ∧
      K * D.y + eta = E.Q := by
    have hh : D.y ∣ E.Q - 1 ∨ D.y ∣ E.Q + 1 := by
      simpa [GoodMinimumRowElement, hs] using hygood
    rcases hh with hh | hh
    · obtain ⟨K, hK⟩ := hh
      refine ⟨K, 1, Or.inl rfl, ?_⟩
      nlinarith [hK]
    · obtain ⟨K, hK⟩ := hh
      refine ⟨K, -1, Or.inr rfl, ?_⟩
      nlinarith [hK]
  obtain ⟨K, eta, heta, hKy⟩ := hyrep
  have hCshape (b : ℤ) (hb : b ∈ C) :
      ∃ k t eps ell : ℤ,
        1 ≤ k ∧ k < D.y ∧ 3 ≤ t ∧
        (eps = 1 ∨ eps = -1) ∧ t * b = E.Q - eps ∧
        ell = K - t ∧ 1 ≤ ell ∧ ell ≤ K - 1 ∧
        b = D.y + k ∧ ell * D.y + eta = t * k + eps := by
    have hbG := hCsub hb
    have hbA := hGA b hbG
    have hbpos := hCpos b hb
    have hby : D.y < b := by
      have hnot := hUpper_notlt b hb
      have hne := hGneq b hbG
      omega
    have hkpos : 1 ≤ b - D.y := by omega
    have hklt : b - D.y < D.y := by
      have hlt := hC_lt b hb
      omega
    have h3b : 3 * b < E.Q := E.hA_upper b hbA
    have hgood := hGgood b hbG
    have hcase (eps t : ℤ) (heps : eps = 1 ∨ eps = -1)
        (htb : t * b = E.Q - eps) :
        1 ≤ b - D.y ∧ b - D.y < D.y ∧ 3 ≤ t ∧
          t * b = E.Q - eps ∧ K - t = K - t ∧
          1 ≤ K - t ∧ K - t ≤ K - 1 ∧
          (K - t) * D.y + eta = t * (b - D.y) + eps := by
      have heps_low : -1 ≤ eps := by rcases heps with rfl | rfl <;> omega
      have heps_high : eps ≤ 1 := by rcases heps with rfl | rfl <;> omega
      have ht3 : 3 ≤ t := by
        by_contra hnot
        have ht2 : t ≤ 2 := by omega
        nlinarith [htb, h3b, hbpos]
      have hrel : (K - t) * D.y + eta =
          t * (b - D.y) + eps := by
        calc
          (K - t) * D.y + eta = K * D.y - t * D.y + eta := by ring
          _ = E.Q - t * D.y := by nlinarith [hKy]
          _ = t * b - t * D.y + eps := by nlinarith [htb]
          _ = t * (b - D.y) + eps := by ring
      have hrellower : 2 ≤ t * (b - D.y) + eps := by
        nlinarith [ht3, hkpos, heps_low]
      have hellpos : 1 ≤ K - t := by
        by_contra hnot
        have hell0 : K - t ≤ 0 := by omega
        have heta_high : eta ≤ 1 := by
          rcases heta with rfl | rfl <;> omega
        nlinarith [hrel, hrellower, hygt, heta_high]
      have hellupper : K - t ≤ K - 1 := by omega
      exact ⟨hkpos, hklt, ht3, htb, rfl, hellpos, hellupper, hrel⟩
    rcases hgood with hminus | hplus
    · obtain ⟨t, ht⟩ := hminus
      have hc := hcase 1 t (Or.inl rfl) (by nlinarith [ht])
      rcases hc with ⟨_, _, ht3, htb, _, hellpos, hellupper, hrel⟩
      exact ⟨b - D.y, t, 1, K - t, hkpos, hklt, ht3,
        Or.inl rfl, htb, rfl, hellpos, hellupper, by ring, hrel⟩
    · obtain ⟨t, ht⟩ := hplus
      have hc := hcase (-1) t (Or.inr rfl) (by nlinarith [ht])
      rcases hc with ⟨_, _, ht3, htb, _, hellpos, hellupper, hrel⟩
      exact ⟨b - D.y, t, -1, K - t, hkpos, hklt, ht3,
        Or.inr rfl, htb, rfl, hellpos, hellupper, by ring, hrel⟩
  have hCdist_case (b k t eps ell : ℤ)
      (hbA : b ∈ E.A) (heps : eps = 1 ∨ eps = -1)
      (htb : t * b = E.Q - eps) (hkpos : 1 ≤ k) (hklt : k < D.y)
      (ht3 : 3 ≤ t) (hellpos : 1 ≤ ell)
      (hrel : ell * D.y + eta = t * k + eps)
      (hbk : b = D.y + k) :
      productShellDistance E D.y b = ell * D.y + eta := by
    have hbpos : 0 < b := (E.hA.1 b hbA).1
    have hcopb : Int.gcd b E.Q = 1 := (E.hA.1 b hbA).2
    have hinv := inverseMod_spec E.Q b hQ hcopb
    have hepssq : eps * eps = 1 := by
      rcases heps with rfl | rfl <;> norm_num
    have hprod : (b * (-eps * t)) % E.Q = 1 := by
      have heq : b * (-eps * t) = -eps * E.Q + 1 := by
        calc
          b * (-eps * t) = -eps * (t * b) := by ring
          _ = -eps * (E.Q - eps) := by rw [htb]
          _ = -eps * E.Q + 1 := by nlinarith [hepssq]
      rw [heq, Int.add_emod, Int.mul_emod, Int.emod_self]
      have hone : (1 : ℤ) % E.Q = 1 :=
        Int.emod_eq_of_lt (by omega) (by omega)
      simpa using hone
    have hprod' : ((-eps * t) * b) % E.Q = 1 := by
      simpa [mul_comm] using hprod
    have hzero : ((inverseMod E.Q b - (-eps * t)) * b) % E.Q = 0 := by
      calc
        ((inverseMod E.Q b - (-eps * t)) * b) % E.Q =
            (inverseMod E.Q b * b - (-eps * t) * b) % E.Q := by
              congr 1 <;> ring
        _ = ((inverseMod E.Q b * b) % E.Q -
            ((-eps * t) * b) % E.Q) % E.Q := by rw [Int.sub_emod]
        _ = 0 := by
          rw [show (inverseMod E.Q b * b) % E.Q = 1 by
            simpa [mul_comm] using hinv.2, hprod']
          simp
    have hcopQb : Int.gcd E.Q b = 1 := by
      simpa [Int.gcd_comm] using hcopb
    have hdivinv : E.Q ∣ inverseMod E.Q b - (-eps * t) := by
      apply Int.dvd_of_dvd_mul_left_of_gcd_one
        (a := E.Q) (b := inverseMod E.Q b - (-eps * t)) (c := b)
      · exact Int.dvd_of_emod_eq_zero hzero
      · exact hcopQb
    have hmodinv : inverseMod E.Q b ≡ -eps * t [ZMOD E.Q] :=
      (Int.modEq_iff_dvd).2 (by
        convert dvd_neg.mpr hdivinv using 1 <;> ring)
    have hmody : D.y * inverseMod E.Q b ≡
        D.y * (-eps * t) [ZMOD E.Q] := hmodinv.mul_left D.y
    let d : ℤ := t * k + eps
    have hdpos : 2 ≤ d := by
      dsimp [d]
      have hepslow : -1 ≤ eps := by rcases heps with rfl | rfl <;> omega
      nlinarith
    have hQd : E.Q - d = t * D.y := by
      have hQ : E.Q = t * (D.y + k) + eps := by
        rw [hbk] at htb
        omega
      dsimp [d]
      rw [hQ]
      ring
    have hdlt : d < E.Q := by
      have htypos : 0 < t * D.y := by positivity
      omega
    have htygt : d < t * D.y := by
      have hepshigh : eps ≤ 1 := by rcases heps with rfl | rfl <;> omega
      have htk : t * (k + 1) ≤ t * D.y := by
        apply mul_le_mul_of_nonneg_left
        · omega
        · omega
      have hepslt : eps < t := by omega
      dsimp [d]
      nlinarith [htk]
    have hdmod : d % E.Q = d := Int.emod_eq_of_lt (by omega) hdlt
    have hdist : productShellDistance E D.y b = d := by
      dsimp [productShellDistance, cyclicDistance]
      rcases heps with rfl | rfl
      · have hres : (D.y * inverseMod E.Q b) % E.Q = d := by
          calc
            (D.y * inverseMod E.Q b) % E.Q =
                (D.y * (-(1 : ℤ) * t)) % E.Q := by simpa using hmody.eq
            _ = (d - E.Q) % E.Q := by
              have heq : D.y * (-(1 : ℤ) * t) = d - E.Q := by
                calc
                  D.y * (-(1 : ℤ) * t) = -(t * D.y) := by ring
                  _ = -(E.Q - d) := by rw [hQd]
                  _ = d - E.Q := by ring
              rw [heq]
            _ = d := by
              rw [Int.sub_emod]
              simp [hdmod]
        rw [hres, min_eq_left]
        have hcomp : d < E.Q - d := by
          calc
            d < t * D.y := htygt
            _ = E.Q - d := hQd.symm
        exact hcomp.le
      · have hres : (D.y * inverseMod E.Q b) % E.Q = E.Q - d := by
          calc
            (D.y * inverseMod E.Q b) % E.Q =
                (D.y * (1 * t)) % E.Q := by simpa using hmody.eq
            _ = E.Q - d := by
              calc
                (D.y * (1 * t)) % E.Q = (t * D.y) % E.Q := by
                  congr 1 <;> ring
                _ = t * D.y := Int.emod_eq_of_lt (by omega) (by omega)
                _ = E.Q - d := hQd.symm
        rw [hres]
        have hcomp : E.Q - (E.Q - d) = d := by ring
        rw [hcomp, min_eq_right]
        have hcomp' : d < E.Q - d := by
          calc
            d < t * D.y := htygt
            _ = E.Q - d := hQd.symm
        exact hcomp'.le
    rw [hdist]
    simpa [d] using hrel.symm
  have hCdistance (b : ℤ) (hb : b ∈ C) :
      ∃ k t eps ell : ℤ,
        1 ≤ k ∧ k < D.y ∧ 3 ≤ t ∧
        (eps = 1 ∨ eps = -1) ∧ t * b = E.Q - eps ∧
        ell = K - t ∧ 1 ≤ ell ∧ ell ≤ K - 1 ∧
        b = D.y + k ∧ ell * D.y + eta = t * k + eps ∧
        productShellDistance E D.y b = ell * D.y + eta := by
    obtain ⟨k, t, eps, ell, hkpos, hklt, ht3, heps, htb, hell,
      hellpos, hellupper, hbk, hrel⟩ := hCshape b hb
    have hbA : b ∈ E.A := hGA b (hCsub hb)
    have hdist := hCdist_case b k t eps ell hbA heps htb hkpos hklt
      ht3 hellpos hrel hbk
    exact ⟨k, t, eps, ell, hkpos, hklt, ht3, heps, htb, hell,
      hellpos, hellupper, hbk, hrel, hdist⟩
  have hK3 : 3 ≤ K := by
    have heta_high : eta ≤ 1 := by rcases heta with rfl | rfl <;> omega
    by_contra hnot
    have hKle : K ≤ 2 := by omega
    have hmul : K * D.y ≤ 2 * D.y := by
      exact mul_le_mul_of_nonneg_right hKle (by omega)
    have hQlower : 3 * D.y < K * D.y + eta := by
      rw [hKy]
      exact hyQ
    have hQupper : K * D.y + eta ≤ 2 * D.y + 1 := by
      calc
        K * D.y + eta ≤ 2 * D.y + eta := by omega
        _ ≤ 2 * D.y + 1 := by omega
    omega
  have hCpoint2 (b : ℤ) (hb : b ∈ C) :
      (b - D.y) * (K - 2) < 2 * productShellDistance E D.y b := by
    obtain ⟨k, t, eps, ell, hkpos, hklt, ht3, heps, htb, hell,
      hellpos, hellupper, hbk, hrel, hdist⟩ := hCdistance b hb
    have hKt : K = ell + t := by omega
    have hineq := cPoint2Scratch K D.y k t eps ell
      (ell * D.y + eta) eta hK3 hkpos hklt heta heps hrel hKt rfl
    rw [hdist, hbk]
    calc
      (D.y + k - D.y) * (K - 2) = k * (K - 2) := by ring
      _ < 2 * (ell * D.y + eta) := hineq
  have hCdistpos (b : ℤ) (hb : b ∈ C) :
      0 < productShellDistance E D.y b := by
    obtain ⟨k, t, eps, ell, hkpos, hklt, ht3, heps, htb, hell,
      hellpos, hellupper, hbk, hrel, hdist⟩ := hCdistance b hb
    exact cDistPosScratch D.y ell eta
      (productShellDistance E D.y b) (by omega) hellpos heta hdist
  have hCshapeScratch (b : ℤ) (hb : b ∈ C) :
      ∃ k t eps ell : ℤ,
        1 ≤ k ∧ k < D.y ∧ 3 ≤ t ∧
        (eps = 1 ∨ eps = -1) ∧ ell = K - t ∧
        1 ≤ ell ∧ ell ≤ K - 1 ∧ b = D.y + k ∧
        t * b + eps = K * D.y + eta ∧
        productShellDistance E D.y b = ell * D.y + eta := by
    obtain ⟨k, t, eps, ell, hkpos, hklt, ht3, heps, htb, hell,
      hellpos, hellupper, hbk, hrel, hdist⟩ := hCdistance b hb
    have hqrel : t * b + eps = K * D.y + eta := by
      calc
        t * b + eps = (E.Q - eps) + eps := by rw [htb]
        _ = E.Q := sub_add_cancel E.Q eps
        _ = K * D.y + eta := hKy.symm
    exact ⟨k, t, eps, ell, hkpos, hklt, ht3, heps, hell,
      hellpos, hellupper, hbk, hqrel, hdist⟩
  have hCfirst (hKleY : K ≤ D.y) :
      (∑ b ∈ C, f b) ≤
        2 * harmonicNumber ((D.y - 1).natAbs) / (D.y - 1) := by
    have hyD : 2 ≤ D.y := by omega
    have hfd : ∀ b ∈ C, f b =
        1 / (productShellDistance E D.y b : ℝ) := by
      intro b hb
      rfl
    have hh := cFirstBoundScratch (C := C) (K := K) (y := D.y)
      (eta := eta) (dist := fun b => productShellDistance E D.y b)
      (f := f) hyD hK3 hKleY heta hCshapeScratch
      (fun b hb => hCdistpos b hb) hfd
    have hH : harmonicNumberScratch ((D.y - 1).natAbs) =
        harmonicNumber ((D.y - 1).natAbs) := by rfl
    rw [hH] at hh
    exact hh
  have hCkshape : ∀ b ∈ C, ∃ k : ℤ,
      1 ≤ k ∧ k < D.y ∧ b = D.y + k := by
    intro b hb
    obtain ⟨k, t, eps, ell, hkpos, hklt, ht3, heps, htb,
      hell, hellpos, hellupper, hbk, hrel⟩ := hCshape b hb
    exact ⟨k, hkpos, hklt, hbk⟩
  obtain ⟨kfun, hkfun, hkfun_inj⟩ :=
    cKfunScratch C D.y hCkshape
  have hCsecond : (∑ b ∈ C, f b) <
      2 * harmonicNumber ((D.y - 1).natAbs) / (K - 2) := by
    have hh := cSecondBoundScratch C K D.y
      (fun b => productShellDistance E D.y b) f
      hy3 hK3 kfun
      (fun b hb => (hkfun b hb).1)
      (fun b hb => (hkfun b hb).2.1)
      (fun b hb => (hkfun b hb).2.2)
      hkfun_inj
      (fun b hb => hCdistpos b hb)
      (fun b hb => by
        have hineq := hCpoint2 b hb
        have hkb := (hkfun b hb).2.2
        have hkval : kfun b = b - D.y := by omega
        calc
          kfun b * (K - 2) = (b - D.y) * (K - 2) := by rw [hkval]
          _ < 2 * productShellDistance E D.y b := hineq)
      (fun b hb => by dsimp [f])
    have hH : harmonicNumberScratch ((D.y - 1).natAbs) =
        harmonicNumber ((D.y - 1).natAbs) := by rfl
    rw [hH] at hh
    exact hh
  have hCbound : (∑ b ∈ C, f b) ≤
      2 * harmonicNumber ((D.y - 1).natAbs) / (D.y - 1) := by
    by_cases hKleY : K ≤ D.y
    · exact hCfirst hKleY
    · have hYleK : D.y + 1 ≤ K := by omega
      have hHnonneg : 0 ≤ (2 : ℝ) *
          harmonicNumber ((D.y - 1).natAbs) := by
        dsimp [harmonicNumber]
        positivity
      have hdenY : (0 : ℝ) < D.y - 1 := by
        exact_mod_cast (show 0 < D.y - 1 by omega)
      have hdenK : (0 : ℝ) < K - 2 := by
        exact_mod_cast (show 0 < K - 2 by omega)
      have hratio :
          2 * harmonicNumber ((D.y - 1).natAbs) / (K - 2) ≤
            2 * harmonicNumber ((D.y - 1).natAbs) / (D.y - 1) := by
        apply (div_le_div_iff₀ hdenK hdenY).2
        have hden_le : (D.y : ℝ) - 1 ≤ K - 2 := by
          exact_mod_cast (show D.y - 1 ≤ K - 2 by omega)
        exact mul_le_mul_of_nonneg_left hden_le hHnonneg
      exact le_of_lt (lt_of_lt_of_le hCsecond hratio)
  have hPint : (∑ b ∈ P, b) ≤ (2 : ℤ) ^ (D.v + 1) - 1 := by
    rw [hsumPowP] at hsumPInt
    exact hsumPInt
  have hPsumR : (∑ b ∈ P, (b : ℝ)) ≤
      (((2 : ℤ) ^ (D.v + 1) - 1 : ℤ) : ℝ) := by
    have hcast : ((∑ b ∈ P, b : ℤ) : ℝ) =
        ∑ b ∈ P, (b : ℝ) := by norm_num
    rw [← hcast]
    exact_mod_cast hPint
  have hFone : (1 : ℤ) ∉ F := by
    intro h
    have hG1 := hFsub h
    have hErase : (1 : ℤ) ∈ E.A.erase 1 :=
      (Finset.mem_filter.mp hG1).1
    exact (Finset.mem_erase.mp hErase).1 rfl
  have hPFdisj : Disjoint P F := by
    apply Finset.disjoint_left.mpr
    intro b hbp hbf
    have hblt := hP_lt b hbp
    have hblow := hF_ge b hbf
    omega
  have hPFBudgetInt : (1 + (∑ b ∈ P, b)) + ∑ b ∈ F, b ≤
      E.Q - D.y := by
    exact pAndFBudgetScratch E.A P F D.y E.Q hygt hyA h1 E.hA_sum
      (fun z hz => (E.hA.1 z hz).1.le)
      (fun z hz => hGsub (hPsub hz)) hFerase hPone hFone hPFdisj
  have hPFBudgetR : (1 : ℝ) + (∑ b ∈ P, (b : ℝ)) +
      ∑ b ∈ F, (b : ℝ) ≤ (E.Q : ℝ) - D.y := by
    have hcastPF : (((1 + (∑ b ∈ P, b)) + ∑ b ∈ F, b : ℤ) : ℝ) =
        (1 : ℝ) + (∑ b ∈ P, (b : ℝ)) + ∑ b ∈ F, (b : ℝ) := by
      norm_num
    have hcastQ : ((E.Q - D.y : ℤ) : ℝ) = (E.Q : ℝ) - D.y := by
      norm_num
    rw [← hcastPF, ← hcastQ]
    exact_mod_cast hPFBudgetInt
  have hPbound : (∑ b ∈ P, f b) ≤
      2 / (D.m : ℝ) - 1 / (D.y : ℝ) := by
    have hmR : (0 : ℝ) < D.m := by exact_mod_cast hmpos
    have hyR : (0 : ℝ) < D.y := by exact_mod_cast hypos
    rw [hPsum]
    rw [← Finset.sum_div]
    apply le_trans (div_le_div_of_nonneg_right hPsumR hyR.le)
    have hdecompR : (D.y : ℝ) = (2 : ℝ) ^ D.v * D.m := by
      exact_mod_cast D.hy_decomp
    have hpow : (2 : ℝ) ^ (D.v + 1) = 2 * (2 : ℝ) ^ D.v := by ring
    rw [hdecompR]
    push_cast
    rw [hpow]
    field_simp
    ring_nf
    nlinarith
  have hPnonnegR : 0 ≤ ∑ b ∈ P, (b : ℝ) := by
    apply Finset.sum_nonneg
    intro b hb
    exact_mod_cast (hPpos b hb).le
  have hFnonnegR : 0 ≤ ∑ b ∈ F, (b : ℝ) := by
    apply Finset.sum_nonneg
    intro b hb
    exact_mod_cast (hFpos b hb).le
  have hscaleR : (D.y : ℝ) = (2 : ℝ) ^ D.v * (D.m : ℝ) := by
    exact_mod_cast D.hy_decomp
  have hratioR : 2 * (D.y : ℝ) / (D.m : ℝ) - 1 =
      (2 : ℝ) ^ (D.v + 1) - 1 := by
    rw [hscaleR]
    have hmR : (D.m : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hmpos)
    field_simp [hmR]
    rw [pow_succ]
    ring
  have hsumPROne' : (1 : ℝ) + (∑ b ∈ P, (b : ℝ)) ≤
      (2 : ℝ) ^ (D.v + 1) - 1 := by
    have hcastP : ((1 + (∑ b ∈ P, b) : ℤ) : ℝ) =
        (1 : ℝ) + (∑ b ∈ P, (b : ℝ)) := by norm_num
    have hcastPow : (((2 : ℤ) ^ (D.v + 1) - 1 : ℤ) : ℝ) =
        (2 : ℝ) ^ (D.v + 1) - 1 := by norm_num
    rw [← hcastP, ← hcastPow]
    exact_mod_cast hsumPIntOne
  have hscaleBound : 1 + (∑ b ∈ P, (b : ℝ)) ≤
      2 * (D.y : ℝ) / (D.m : ℝ) - 1 := by
    rw [hratioR]
    exact hsumPROne'
  have hfinal := dyadicCloseFinalArithmeticScratch
    (D.m : ℝ) (D.y : ℝ) (E.Q : ℝ)
    (∑ b ∈ P, (b : ℝ)) (∑ b ∈ F, (b : ℝ))
    (by exact_mod_cast hmpos) (by exact_mod_cast hygt)
    (by exact_mod_cast (show 1 < E.Q by omega))
    hPnonnegR hFnonnegR hscaleBound (by linarith [hPFBudgetR])
  calc
    goodRowContribution D =
        (1 : ℝ) / D.y +
          ∑ b ∈ P, f b + ∑ b ∈ X, f b +
            ∑ b ∈ C, f b + ∑ b ∈ F, f b := by
      rw [hcontrib, hsumG]
      ring
    _ = (1 : ℝ) / D.y +
          (∑ b ∈ P, (b : ℝ)) / D.y +
          ∑ b ∈ X, f b + ∑ b ∈ C, f b + ∑ b ∈ F, f b := by
      rw [hPsum, ← Finset.sum_div]
    _ ≤ (1 : ℝ) / D.y +
          (∑ b ∈ P, (b : ℝ)) / D.y +
          ∑ b ∈ X, f b + ∑ b ∈ C, f b +
          (∑ b ∈ F, (b : ℝ)) / ((D.y : ℝ) * (E.Q - 1)) := by
      linarith [hFrecip]
    _ ≤ (1 : ℝ) / D.y +
          (∑ b ∈ P, (b : ℝ)) / D.y +
          10 * (D.J : ℝ) / (3 * D.y) +
          2 * harmonicNumber ((D.y - 1).natAbs) / (D.y - 1) +
          (∑ b ∈ F, (b : ℝ)) / ((D.y : ℝ) * (E.Q - 1)) := by
      linarith [hXsum, hCbound]
    _ < 2 / (D.m : ℝ) + 10 * (D.J : ℝ) / (3 * D.y) +
          2 * harmonicNumber ((D.y - 1).natAbs) / (D.y - 1) := by
      linarith [hfinal]

/-- The analytic cutoff in the critical branch. -/
-- zpi: lem-analytic-cutoff-in-critical-branch
theorem analyticCutoffInCriticalBranch
    (D : LeastNondyadicGoodElementData)
    (hAll : ∀ a ∈ D.toMinimumRowSlackData.A,
      RowPasses D.toMinimumRowSlackData.Q D.toMinimumRowSlackData.A a) :
    D.toMinimumRowSlackData.Q ≤ 5607 := by
  have hQ := refinedEnvelopeVerifierReducesCriticalBranch D hAll
  omega

/-- Validity of the refined envelope for the selected nondyadic row. -/
-- zpi: lem-validity-of-refined-envelope
theorem refinedEnvelopeValidity (D : LeastNondyadicGoodElementData) :
    inverseSineRowMass D.toMinimumRowSlackData.Q
      D.toMinimumRowSlackData.A D.y <
      refinedCriticalEnvelope D.toMinimumRowSlackData.Q D.y := by
  classical
  let E : MinimumRowSlackData := D.toMinimumRowSlackData
  have hs : E.s = 1 := D.hs_one
  have hQ : 2 ≤ E.Q := by
    have h := E.hQ
    omega
  have hqpos : 0 < E.Q := by omega
  have h1 : (1 : ℤ) ∈ E.A := by
    simpa [E, hs] using E.hs_mem
  have hyA : D.y ∈ E.A := by
    simpa [E] using D.hy_mem
  have hypos : 0 < D.y := by
    exact (E.hA.1 D.y hyA).1
  have hygt : 1 < D.y := by
    by_contra hnot
    have hyeq : D.y = 1 := by omega
    apply D.hy_nondyadic
    refine ⟨0, ?_⟩
    simpa [hyeq]
  have hyQ : 3 * D.y < E.Q := by
    simpa [E] using E.hA_upper D.y D.hy_mem
  have hygood : GoodMinimumRowElement E D.y := by
    simpa [E] using D.hy_good
  have hbook := productShellBookkeeping E
  have hshell := hbook.1
  have hrecip := hbook.2.1
  have hsubset := hbook.2.2.1
  have hdiv := hbook.2.2.2.1
  have hspecial := hbook.2.2.2.2
  let G : Finset ℤ := (E.A.erase 1).filter
    (fun b => b ≠ D.y ∧ GoodMinimumRowElement E b)
  have hGsub : G ⊆ E.A.erase D.y := by
    intro b hb
    have hb0 := Finset.mem_filter.mp hb
    have hb1 := Finset.mem_erase.mp hb0.1
    exact Finset.mem_erase.mpr ⟨hb0.2.1, hb1.2⟩
  have hGA (b : ℤ) (hb : b ∈ G) : b ∈ E.A := by
    exact (Finset.mem_erase.mp (Finset.mem_filter.mp hb).1).2
  have hGpos (b : ℤ) (hb : b ∈ G) : 0 < b :=
    (E.hA.1 b (hGA b hb)).1
  have hGgood (b : ℤ) (hb : b ∈ G) : GoodMinimumRowElement E b :=
    (Finset.mem_filter.mp hb).2.2
  have hGneq (b : ℤ) (hb : b ∈ G) : b ≠ D.y :=
    (Finset.mem_filter.mp hb).2.1
  have hcontrib : goodRowContribution D =
      (1 : ℝ) / D.y +
        ∑ b ∈ G, (1 : ℝ) /
          (productShellDistance E D.y b : ℝ) := by
    simp [goodRowContribution, G, productShellDistance, E]
  have h2E : (2 : ℤ) ∈ E.A := by simpa [E] using D.h2
  let f : ℤ → ℝ := fun b =>
    (1 : ℝ) / (productShellDistance E D.y b : ℝ)
  let P : Finset ℤ := G.filter
    (fun b => IsDyadic b ∧ b ∣ D.y)
  let X : Finset ℤ := refinedExceptionalSet E.Q D.y
  have hPsub : P ⊆ G := by
    intro b hb
    exact (Finset.mem_filter.mp hb).1
  have hPpos (b : ℤ) (hb : b ∈ P) : 0 < b :=
    hGpos b (hPsub hb)
  have hP_dvd (b : ℤ) (hb : b ∈ P) : b ∣ D.y :=
    (Finset.mem_filter.mp hb).2.2
  have hPdyadic (b : ℤ) (hb : b ∈ P) : IsDyadic b :=
    (Finset.mem_filter.mp hb).2.1
  have hbelow_dyadic (b : ℤ) (hb : b ∈ G) (hblt : b < D.y) :
      IsDyadic b := by
    by_contra hnot
    have hbne1 : b ≠ 1 := (Finset.mem_erase.mp
      (Finset.mem_filter.mp hb).1).1
    have hbpos := hGpos b hb
    have hbgt : 1 < b := by omega
    have hle := D.hy_least b (hGA b hb) hbgt
      (hGgood b hb) (by simpa [IsDyadic] using hnot)
    omega
  have hPpow (b : ℤ) (hb : b ∈ P) :
      ∃ k : ℕ, b = (2 : ℤ) ^ k := hPdyadic b hb
  have hPpow_le (b : ℤ) (hb : b ∈ P) (k : ℕ)
      (hbk : b = (2 : ℤ) ^ k) : k ≤ D.v := by
    by_contra hnot
    have hvk : D.v + 1 ≤ k := by omega
    have hpow : (2 : ℤ) ^ (D.v + 1) ∣ (2 : ℤ) ^ k :=
      pow_dvd_pow _ hvk
    have hbd : (2 : ℤ) ^ (D.v + 1) ∣ D.y := by
      apply dvd_trans hpow
      rw [← hbk]
      exact hP_dvd b hb
    exact D.hv_maximal hbd
  let PowP : Finset ℤ := (Finset.range (D.v + 1)).image
    (fun k : ℕ => (2 : ℤ) ^ k)
  have hPsubPow : P ⊆ PowP := by
    intro b hb
    obtain ⟨k, hbk⟩ := hPpow b hb
    have hk_le := hPpow_le b hb k hbk
    apply Finset.mem_image.mpr
    exact ⟨k, Finset.mem_range.mpr (by omega : k < D.v + 1), hbk.symm⟩
  have hPowP_inj : Function.Injective (fun k : ℕ => (2 : ℤ) ^ k) := by
    exact pow_right_injective₀ (by norm_num) (by norm_num)
  have hsumPInt : (∑ b ∈ P, b) ≤ ∑ p ∈ PowP, p := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hPsubPow
    intro p hp hnot
    obtain ⟨k, hk, rfl⟩ := Finset.mem_image.mp hp
    positivity
  have hsumPowP : (∑ p ∈ PowP, p) =
      (2 : ℤ) ^ (D.v + 1) - 1 := by
    dsimp [PowP]
    rw [Finset.sum_image]
    · have hh := geom_sum_mul (2 : ℤ) (D.v + 1)
      norm_num at hh ⊢
      nlinarith
    · intro a ha b hb hab
      exact hPowP_inj hab
  have hPdist (b : ℤ) (hb : b ∈ P) :
      productShellDistance E D.y b = D.y / b := by
    have hbG := hPsub hb
    have hbA := hGA b hbG
    have hcop := E.hA.1 b hbA
    have hinv := inverseMod_spec E.Q b hQ hcop.2
    obtain ⟨c, hc⟩ := hP_dvd b hb
    have hcpos : 0 < c := by
      nlinarith [hc, hypos, hPpos b hb]
    have hcle : c ≤ D.y := by nlinarith [hc]
    have hcQ : c < E.Q := by nlinarith [hyQ, hcle]
    have hcmod : c % E.Q = c := Int.emod_eq_of_lt (by omega) hcQ
    have hres : (D.y * inverseMod E.Q b) % E.Q = c := by
      calc
        (D.y * inverseMod E.Q b) % E.Q =
            (b * c * inverseMod E.Q b) % E.Q := by rw [hc]
        _ = (c * (b * inverseMod E.Q b)) % E.Q := by
          congr 1 <;> ring
        _ = c := by
          rw [Int.mul_emod, hinv.2]
          simp [hcmod]
    have hquot : D.y / b = c := by
      apply Int.ediv_eq_of_eq_mul_right (ne_of_gt (hPpos b hb))
      exact hc
    dsimp [productShellDistance, cyclicDistance]
    rw [hres, min_eq_left]
    · exact hquot.symm
    · omega
  have hPsum : (∑ b ∈ P, f b) =
      ∑ b ∈ P, (b : ℝ) / (D.y : ℝ) := by
    apply Finset.sum_congr rfl
    intro b hb
    obtain ⟨c, hc⟩ := hP_dvd b hb
    have hcpos : 0 < c := by
      nlinarith [hc, hypos, hPpos b hb]
    have hquot : D.y / b = c := by
      apply Int.ediv_eq_of_eq_mul_right (ne_of_gt (hPpos b hb))
      exact hc
    dsimp [f]
    rw [hPdist b hb, hquot]
    have hcy : (c : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hcpos)
    have hby : (D.y : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hypos)
    have hcR : (D.y : ℝ) = (b : ℝ) * (c : ℝ) := by
      exact_mod_cast hc
    field_simp [hcy, hby]
    nlinarith [hcR]
  have hPpoint (b : ℤ) (hb : b ∈ P) :
      f b = (b : ℝ) / (D.y : ℝ) := by
    obtain ⟨c, hc⟩ := hP_dvd b hb
    have hcpos : 0 < c := by
      nlinarith [hc, hypos, hPpos b hb]
    have hquot : D.y / b = c := by
      apply Int.ediv_eq_of_eq_mul_right (ne_of_gt (hPpos b hb))
      exact hc
    dsimp [f]
    rw [hPdist b hb, hquot]
    have hcy : (c : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hcpos)
    have hby : (D.y : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hypos)
    have hcR : (D.y : ℝ) = (b : ℝ) * (c : ℝ) := by
      exact_mod_cast hc
    field_simp [hcy, hby]
    nlinarith [hcR]
  have hPsumInt : (∑ b ∈ P, b) ≤
      (2 : ℤ) ^ (D.v + 1) - 1 := by
    rw [hsumPowP] at hsumPInt
    exact hsumPInt
  have hPnonneg : ∀ b ∈ P, 0 ≤ b := by
    intro b hb
    exact (hPpos b hb).le
  have hGsum : (∑ b ∈ G, b) ≤ E.Q - D.y - 1 := by
    have hGsub0 : G ⊆ (E.A.erase D.y).erase 1 := by
      intro b hb
      refine Finset.mem_erase.mpr ⟨?_, hGsub hb⟩
      exact (Finset.mem_erase.mp (Finset.mem_filter.mp hb).1).1
    have hGerase : (∑ b ∈ G, b) ≤
        ∑ a ∈ (E.A.erase D.y).erase 1, a := by
      apply Finset.sum_le_sum_of_subset_of_nonneg hGsub0
      intro a ha hnot
      exact (E.hA.1 a (Finset.mem_erase.mp (Finset.mem_erase.mp ha).2).2).1.le
    have honeEraseY : (1 : ℤ) ∈ E.A.erase D.y := by
      exact Finset.mem_erase.mpr ⟨by omega, h1⟩
    have hsum_erase1 :
        (∑ a ∈ (E.A.erase D.y).erase 1, a) + 1 =
          ∑ a ∈ E.A.erase D.y, a := by
      simpa using (E.A.erase D.y).sum_erase_add (fun a : ℤ => a) honeEraseY
    have hsum_erase : (∑ a ∈ E.A.erase D.y, a) + D.y =
        ∑ a ∈ E.A, a := by
      simpa using E.A.sum_erase_add (fun a : ℤ => a) hyA
    have hAsum := E.hA_sum
    omega
  have hfar_ge (b : ℤ) (hb : b ∈ G) (hnotP : b ∉ P)
      (hnotX : b ∉ X) : 2 * D.y ≤ b := by
    by_contra hnot
    have hb_lt2 : b < 2 * D.y := by omega
    have hbne : b ≠ D.y := hGneq b hb
    have hbpos := hGpos b hb
    have hbne1 : b ≠ 1 := (Finset.mem_erase.mp
      (Finset.mem_filter.mp hb).1).1
    have hb2 : 2 ≤ b := by omega
    have hcand : b ∈ refinedGoodCandidates E.Q := by
      simp only [refinedGoodCandidates, Finset.mem_filter, Finset.mem_Icc]
      refine ⟨⟨by omega, by omega⟩, ?_⟩
      have hgb := hGgood b hb
      refine ⟨E.hA_upper b (hGA b hb), ?_⟩
      simpa [GoodMinimumRowElement, hs] using hgb
    by_cases hblt : b < D.y
    · have hdyadic := hbelow_dyadic b hb hblt
      have hbndvd : ¬ b ∣ D.y := by
        intro hdiv
        apply hnotP
        exact Finset.mem_filter.mpr ⟨hb, ⟨hdyadic, hdiv⟩⟩
      have hXmem : b ∈ X := by
        apply Finset.mem_filter.mpr
        exact ⟨hcand, ⟨hbne, Or.inl ⟨hblt, hdyadic, hbndvd⟩⟩⟩
      exact hnotX hXmem
    · have hbygt : D.y < b := by omega
      have hXmem : b ∈ X := by
        apply Finset.mem_filter.mpr
        exact ⟨hcand, ⟨hbne, Or.inr ⟨hbygt, hb_lt2⟩⟩⟩
      exact hnotX hXmem
  have hfar_product (b : ℤ) (hb : b ∈ G) (hnotP : b ∉ P)
      (hnotX : b ∉ X) :
      D.y * (E.Q - 1) ≤ productShellValue E D.y b := by
    exact farBaseScratch E D.y b hQ hs hypos hyQ h2E (hGA b hb)
      (hGgood b hb) (hfar_ge b hb hnotP hnotX)
  have hpoint : ∀ b ∈ G, b ∉ P →
      f b ≤ (b : ℝ) / (D.y * (E.Q - 1)) +
        if b ∈ X then max 0 (f b - (b : ℝ) /
          (D.y * (E.Q - 1))) else 0 := by
    intro b hb hnotP
    by_cases hXb : b ∈ X
    · have hmax : f b - (b : ℝ) / (D.y * (E.Q - 1)) ≤
          max 0 (f b - (b : ℝ) / (D.y * (E.Q - 1))) := le_max_right _ _
      simp [hXb]
      linarith
    · have hprod := hfar_product b hb hnotP hXb
      have hbpos := hGpos b hb
      have hdenI : 0 < D.y * (E.Q - 1) := by
        exact mul_pos hypos (by omega)
      have hdpos : 0 < productShellDistance E D.y b := by
        dsimp [productShellValue] at hprod
        nlinarith [hprod, hbpos]
      have hdenR : (0 : ℝ) < D.y * (E.Q - 1) := by
        exact_mod_cast hdenI
      have hdR : (0 : ℝ) < productShellDistance E D.y b := by
        exact_mod_cast hdpos
      have hprodR :
          (D.y : ℝ) * (E.Q - 1) ≤
            (b : ℝ) * productShellDistance E D.y b := by
        exact_mod_cast hprod
      dsimp [f]
      simp [hXb]
      rw [← one_div]
      apply (div_le_div_iff₀ hdR hdenR).2
      nlinarith [hprodR]
  have hPsum_bound : (∑ b ∈ P, f b) ≤
      (2 : ℝ) ^ (D.v + 1) / (D.y : ℝ) - 1 / (D.y : ℝ) := by
    rw [hPsum, ← Finset.sum_div]
    have hcast : ((∑ b ∈ P, b : ℤ) : ℝ) = ∑ b ∈ P, (b : ℝ) := by norm_num
    rw [← hcast]
    have hyR : (0 : ℝ) < D.y := by exact_mod_cast hypos
    have hsumR : ((∑ b ∈ P, b : ℤ) : ℝ) ≤
        (((2 : ℤ) ^ (D.v + 1) - 1 : ℤ) : ℝ) := by
      exact_mod_cast hPsumInt
    have hpowcast : (((2 : ℤ) ^ (D.v + 1) - 1 : ℤ) : ℝ) =
        (2 : ℝ) ^ (D.v + 1) - 1 := by norm_num
    rw [hpowcast] at hsumR
    calc
      ((∑ b ∈ P, b : ℤ) : ℝ) / D.y ≤
          ((2 : ℝ) ^ (D.v + 1) - 1) / D.y :=
        div_le_div_of_nonneg_right hsumR hyR.le
      _ = (2 : ℝ) ^ (D.v + 1) / D.y - 1 / D.y := by ring
  have honePowP : (1 : ℤ) ∈ PowP := by
    apply Finset.mem_image.mpr
    exact ⟨0, Finset.mem_range.mpr (by omega), by norm_num⟩
  have hPsubPow0 : P ⊆ PowP.erase 1 := by
    intro b hb
    apply Finset.mem_erase.mpr
    refine ⟨?_, hPsubPow hb⟩
    exact (Finset.mem_erase.mp (Finset.mem_filter.mp (hPsub hb)).1).1
  have hsumPInt0 : (∑ b ∈ P, b) ≤ ∑ p ∈ PowP.erase 1, p := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hPsubPow0
    intro p hp hnot
    obtain ⟨k, hk, rfl⟩ := Finset.mem_image.mp
      (Finset.mem_erase.mp hp).2
    positivity
  have hsumPowP0 : (∑ p ∈ PowP.erase 1, p) =
      (2 : ℤ) ^ (D.v + 1) - 2 := by
    have hsumErase := PowP.sum_erase_add (fun p : ℤ => p) honePowP
    rw [hsumPowP] at hsumErase
    nlinarith [hsumErase, hsumPowP]
  have hPsumInt0 : (∑ b ∈ P, b) ≤
      (2 : ℤ) ^ (D.v + 1) - 2 := by
    rw [hsumPowP0] at hsumPInt0
    exact hsumPInt0
  have hGoodBound := baselinePromotionScratch G P X E.Q D.y
      ((2 : ℤ) ^ (D.v + 1) - 2) f hypos hQ hPsub hPsumInt0 hGsum
      hPnonneg hPpoint hpoint
  have hvpart := vpartEqScratch D.y D.v D.m hypos D.hm_lower
    D.hy_decomp D.hv_maximal
  have hGoodEnvelopeBound :
      (1 : ℝ) / D.y + ∑ b ∈ G, f b ≤
        refinedGoodEnvelope E.Q D.y := by
    have hadd := add_le_add_right hGoodBound ((1 : ℝ) / D.y)
    have hcalc :
        (1 : ℝ) / D.y + ∑ b ∈ G, f b ≤
          (((2 : ℤ) ^ (D.v + 1) - 1 : ℤ) : ℝ) / D.y +
            ((E.Q - D.y - ((2 : ℤ) ^ (D.v + 1) - 1) : ℤ) : ℝ) /
              (D.y * (E.Q - 1)) +
            ∑ b ∈ X, max 0 (f b - (b : ℝ) /
              (D.y * (E.Q - 1))) := by
      calc
        (1 : ℝ) / D.y + ∑ b ∈ G, f b ≤
            (1 : ℝ) / D.y +
              (((2 : ℤ) ^ (D.v + 1) - 2 : ℤ) : ℝ) / D.y +
              ((E.Q - D.y - 1 - ((2 : ℤ) ^ (D.v + 1) - 2) : ℤ) : ℝ) /
                (D.y * (E.Q - 1)) +
              ∑ b ∈ X, max 0 (f b - (b : ℝ) /
                (D.y * (E.Q - 1))) := by
          convert hadd using 1 <;> ring
        _ = _ := by
          have halg :
              (1 : ℝ) / D.y +
                  (((2 : ℤ) ^ (D.v + 1) - 2 : ℤ) : ℝ) / D.y +
                  ((E.Q - D.y - 1 - ((2 : ℤ) ^ (D.v + 1) - 2) : ℤ) : ℝ) /
                    (D.y * (E.Q - 1)) =
                (((2 : ℤ) ^ (D.v + 1) - 1 : ℤ) : ℝ) / D.y +
                  ((E.Q - D.y - ((2 : ℤ) ^ (D.v + 1) - 1) : ℤ) : ℝ) /
                    (D.y * (E.Q - 1)) := by
            have hp : (1 : ℝ) +
                  (((2 : ℤ) ^ (D.v + 1) - 2 : ℤ) : ℝ) =
                (((2 : ℤ) ^ (D.v + 1) - 1 : ℤ) : ℝ) := by
              norm_num [Int.cast_sub]
              ring
            have hq :
                (E.Q - D.y - 1 - ((2 : ℤ) ^ (D.v + 1) - 2) : ℤ) =
                  E.Q - D.y - ((2 : ℤ) ^ (D.v + 1) - 1) := by ring
            rw [← add_div, hp, hq]
          rw [halg]
    dsimp [refinedGoodEnvelope]
    rw [hvpart]
    simpa [X, f, productShellDistance] using hcalc
  let R : Finset ℤ := E.A.erase D.y
  let B : Finset ℤ := R.filter
    (fun b => ¬ GoodMinimumRowElement E b)
  have honeR : (1 : ℤ) ∈ R := by
    apply Finset.mem_erase.mpr
    exact ⟨by omega, h1⟩
  have hRnonempty : R.Nonempty := ⟨1, honeR⟩
  have hdist (b : ℤ) (hb : b ∈ R) :
      1 ≤ productShellDistance E D.y b ∧
        2 * productShellDistance E D.y b ≤ E.Q := by
    have hbR := Finset.mem_erase.mp hb
    have hbA : b ∈ E.A := hbR.2
    have hbU := E.hA.1 b hbA
    have hsinv : (D.y * inverseMod E.Q b) % E.Q ≠ 0 := by
      intro hz
      have hinv := inverseMod_spec E.Q b hQ hbU.2
      have hzero : D.y * inverseMod E.Q b ≡ 0 [ZMOD E.Q] := by
        simpa [Int.ModEq] using hz
      have hprod : (D.y * inverseMod E.Q b) * b ≡ 0 * b [ZMOD E.Q] :=
        hzero.mul_right b
      have h1mod : (1 : ℤ) % E.Q = 1 :=
        Int.emod_eq_of_lt (by omega) (by omega)
      have hone : b * inverseMod E.Q b ≡ 1 [ZMOD E.Q] := by
        simpa [Int.ModEq, h1mod] using hinv.2
      have hcalc : (D.y * inverseMod E.Q b) * b ≡ D.y [ZMOD E.Q] := by
        calc
          (D.y * inverseMod E.Q b) * b =
              D.y * (b * inverseMod E.Q b) := by ring
          _ ≡ D.y * 1 [ZMOD E.Q] := hone.mul_left D.y
          _ = D.y := by ring
      have hyzero : D.y % E.Q = 0 := by
        have hh : (D.y * inverseMod E.Q b) * b % E.Q = 0 :=
          hprod.eq.trans (by simp)
        rw [hcalc.eq] at hh
        exact hh
      have hyrem : D.y % E.Q = D.y := by
        exact Int.emod_eq_of_lt (by omega) (by omega)
      omega
    have hd := cyclicDistance_bounds E.Q
      (D.y * inverseMod E.Q b) hQ hsinv
    simpa [productShellDistance] using hd
  have hKernelUpper (b : ℤ) (hb : b ∈ R) :
      inverseSineKernel E.Q (productShellDistance E D.y b) <
        1 / (productShellDistance E D.y b : ℝ) +
          (16 : ℝ) / 7 * (productShellDistance E D.y b : ℝ) /
            (E.Q : ℝ) ^ 2 := by
    have hd := hdist b hb
    calc
      inverseSineKernel E.Q (productShellDistance E D.y b) <
          1 / (productShellDistance E D.y b : ℝ) +
            inverseSineEnvelopeConstant *
              (productShellDistance E D.y b : ℝ) / (E.Q : ℝ) ^ 2 :=
        inverseSineKernel_upper E.Q (productShellDistance E D.y b)
          hQ hd.1 hd.2
      _ < 1 / (productShellDistance E D.y b : ℝ) +
          (16 : ℝ) / 7 * (productShellDistance E D.y b : ℝ) /
            (E.Q : ℝ) ^ 2 := by
          have hh := inverseSineKernel_rationalComparison E.Q
            (productShellDistance E D.y b) hQ hd.1
          convert hh using 1 <;> ring
  have hsum_kernel :
      (∑ b ∈ R, inverseSineKernel E.Q
        (productShellDistance E D.y b)) <
        ∑ b ∈ R,
          (1 / (productShellDistance E D.y b : ℝ) +
            (16 : ℝ) / 7 * (productShellDistance E D.y b : ℝ) /
              (E.Q : ℝ) ^ 2) := by
    apply Finset.sum_lt_sum_of_nonempty hRnonempty
    intro b hb
    exact hKernelUpper b hb
  have hcardR : R.card = minimumRowN E := by
    dsimp [R, minimumRowN]
    exact Finset.card_erase_of_mem hyA
  have hdist_sum :
      ∑ b ∈ R, (productShellDistance E D.y b : ℝ) ≤
        (minimumRowN E : ℝ) * (E.Q : ℝ) / 2 := by
    have hterm : ∀ b ∈ R,
        (productShellDistance E D.y b : ℝ) ≤ (E.Q : ℝ) / 2 := by
      intro b hb
      have hd := hdist b hb
      have hdR : 2 * (productShellDistance E D.y b : ℝ) ≤
          (E.Q : ℝ) := by exact_mod_cast hd.2
      nlinarith
    have hsum := Finset.sum_le_sum (fun b hb => hterm b hb)
    calc
      (∑ b ∈ R, (productShellDistance E D.y b : ℝ)) ≤
          ∑ b ∈ R, (E.Q : ℝ) / 2 := hsum
      _ = (R.card : ℝ) * (E.Q : ℝ) / 2 := by simp; ring
      _ = (minimumRowN E : ℝ) * (E.Q : ℝ) / 2 := by rw [hcardR]
  have hMupper : inverseSineRowMass E.Q E.A D.y <
      productShellRow E D.y +
        8 * (minimumRowN E : ℝ) / (7 * (E.Q : ℝ)) := by
    have hspec := inverseSineRowMass_spec E.Q E.A D.y hQ E.hA hyA
    have hsum' :
        (∑ b ∈ R, inverseSineKernel E.Q
          (cyclicDistance E.Q (D.y * inverseMod E.Q b))) <
        ∑ b ∈ R,
          (1 / (productShellDistance E D.y b : ℝ) +
            (16 : ℝ) / 7 * (productShellDistance E D.y b : ℝ) /
              (E.Q : ℝ) ^ 2) := by
      simpa [R, productShellDistance] using hsum_kernel
    have hcalc :
        (∑ b ∈ R,
          (16 : ℝ) / 7 * (productShellDistance E D.y b : ℝ) /
            (E.Q : ℝ) ^ 2) =
          (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
            ∑ b ∈ R, (productShellDistance E D.y b : ℝ) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro b hb
      ring
    have hfac : 0 ≤ (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 := by positivity
    have hmul := mul_le_mul_of_nonneg_left hdist_sum hfac
    have hqR : (0 : ℝ) < E.Q := by exact_mod_cast (show 0 < E.Q by omega)
    have hqne : (E.Q : ℝ) ≠ 0 := ne_of_gt hqR
    have heq : (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
          ((minimumRowN E : ℝ) * (E.Q : ℝ) / 2) =
        8 * (minimumRowN E : ℝ) / (7 * (E.Q : ℝ)) := by
      field_simp [hqne]
      ring
    dsimp [inverseSineRowMass, productShellRow, R] at hspec ⊢
    rw [hspec] at ⊢
    calc
      (∑ b ∈ E.A.erase D.y,
          inverseSineKernel E.Q
            (cyclicDistance E.Q (D.y * inverseMod E.Q b))) <
          ∑ b ∈ R,
            (1 / (productShellDistance E D.y b : ℝ) +
              (16 : ℝ) / 7 * (productShellDistance E D.y b : ℝ) /
                (E.Q : ℝ) ^ 2) := hsum'
      _ = (∑ b ∈ R, (1 / (productShellDistance E D.y b : ℝ))) +
          (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
            ∑ b ∈ R, (productShellDistance E D.y b : ℝ) := by
        rw [Finset.sum_add_distrib, hcalc]
      _ ≤ productShellRow E D.y +
          (16 : ℝ) / 7 / (E.Q : ℝ) ^ 2 *
            ((minimumRowN E : ℝ) * (E.Q : ℝ) / 2) := by
        rw [show (∑ b ∈ R, (1 / (productShellDistance E D.y b : ℝ))) =
            productShellRow E D.y by rfl]
        simpa [add_comm, add_left_comm, add_assoc] using
          (add_le_add_right hmul (productShellRow E D.y))
      _ = productShellRow E D.y +
          8 * (minimumRowN E : ℝ) / (7 * (E.Q : ℝ)) := by rw [heq]
  have hBsub : B ⊆ R := by
    intro b hb
    exact (Finset.mem_filter.mp hb).1
  have hBbad (b : ℤ) (hb : b ∈ B) :
      ¬ GoodMinimumRowElement E b :=
    (Finset.mem_filter.mp hb).2
  have hgood1 : GoodMinimumRowElement E 1 := by
    left
    simpa [hs] using (one_dvd (E.Q - 1))
  have hBsum_le : (∑ b ∈ B, b) ≤ badMinimumRowSum E := by
    let B0 : Finset ℤ := (E.A.erase E.s).filter
      (fun b => ¬ GoodMinimumRowElement E b)
    have hBsub0 : B ⊆ B0 := by
      intro b hb
      have hbR := Finset.mem_erase.mp (hBsub hb)
      have hbA := hbR.2
      have hbne1 : b ≠ 1 := by
        intro heq
        subst b
        exact hBbad 1 hb (by simpa using hgood1)
      apply Finset.mem_filter.mpr
      refine ⟨?_, hBbad b hb⟩
      rw [hs]
      exact Finset.mem_erase.mpr ⟨hbne1, hbA⟩
    have hsubset_sum : (∑ b ∈ B, b) ≤ ∑ b ∈ B0, b := by
      apply Finset.sum_le_sum_of_subset_of_nonneg hBsub0
      intro b hb hnot
      have hbA := (Finset.mem_erase.mp (Finset.mem_filter.mp hb).1).2
      exact (E.hA.1 b hbA).1.le
    have hB0eq : (∑ b ∈ B0, b) = badMinimumRowSum E := by
      dsimp [B0, badMinimumRowSum]
      symm
      rw [Finset.sum_filter]
      simp [BadMinimumRowElement]
      apply Finset.sum_congr rfl
      intro x hx
      by_cases hg : GoodMinimumRowElement E x <;> simp [hg]
    linarith
  have hBprod (b : ℤ) (hb : b ∈ B) :
      E.Q - D.y ≤ productShellValue E D.y b := by
    have hbR := Finset.mem_erase.mp (hBsub hb)
    have hbA := hbR.2
    have hne : D.y ≠ b := Ne.symm hbR.1
    have hval := hshell D.y hyA b hbA hne
    have hyGood : D.y ∣ E.Q - 1 ∨ D.y ∣ E.Q + 1 := by
      simpa [GoodMinimumRowElement, hs] using hygood
    rcases hval with hY | ⟨j, hj, hval | hval⟩
    · have hbdiv : b ∣ D.y := hdiv D.y hyA b hbA hne hY
      exfalso
      apply hBbad b hb
      rcases hyGood with hminus | hplus
      · left
        rw [hs]
        exact dvd_trans hbdiv hminus
      · right
        rw [hs]
        exact dvd_trans hbdiv hplus
    · nlinarith [hval, hj, hqpos]
    · nlinarith [hval, hj, hqpos]
  have hBrecip : (∑ b ∈ B, f b) ≤
      (badMinimumRowSum E : ℝ) / (E.Q - D.y) := by
    have hdenI : 0 < E.Q - D.y := by omega
    have hdenR : (0 : ℝ) < E.Q - D.y := by exact_mod_cast hdenI
    have hpointB : ∀ b ∈ B, f b ≤
        (b : ℝ) / (E.Q - D.y) := by
      intro b hb
      have hprod := hBprod b hb
      have hd := hdist b (hBsub hb)
      have hdR : (0 : ℝ) < productShellDistance E D.y b := by
        exact_mod_cast (show 0 < productShellDistance E D.y b by omega)
      have hprodR : (E.Q - D.y : ℝ) ≤
          (b : ℝ) * productShellDistance E D.y b := by
        exact_mod_cast hprod
      dsimp [f]
      have hh : (1 : ℝ) / (productShellDistance E D.y b : ℝ) ≤
          (b : ℝ) / (E.Q - D.y) := by
        apply (div_le_div_iff₀ hdR hdenR).2
        nlinarith [hprodR]
      simpa only [one_div] using hh
    have hsumB : (∑ b ∈ B, f b) ≤
        ∑ b ∈ B, (b : ℝ) / (E.Q - D.y) := by
      apply Finset.sum_le_sum
      intro b hb
      exact hpointB b hb
    have hsumBdiv : (∑ b ∈ B, (b : ℝ) / (E.Q - D.y)) =
        (∑ b ∈ B, (b : ℝ)) / (E.Q - D.y) := by
      rw [Finset.sum_div]
    have hBsumR : (∑ b ∈ B, (b : ℝ)) ≤
        (badMinimumRowSum E : ℝ) := by
      have hcast : ((∑ b ∈ B, b : ℤ) : ℝ) = ∑ b ∈ B, (b : ℝ) := by
        norm_num
      rw [← hcast]
      exact_mod_cast hBsum_le
    calc
      (∑ b ∈ B, f b) ≤
          ∑ b ∈ B, (b : ℝ) / (E.Q - D.y) := hsumB
      _ = (∑ b ∈ B, (b : ℝ)) / (E.Q - D.y) := hsumBdiv
      _ ≤ (badMinimumRowSum E : ℝ) / (E.Q - D.y) :=
        div_le_div_of_nonneg_right hBsumR hdenR.le
  have hyne1 : (1 : ℤ) ≠ D.y := by omega
  have hgoodset : R.filter (fun b => GoodMinimumRowElement E b) =
      insert 1 G := by
    ext b
    by_cases hb1 : b = 1
    · subst b
      simp [R, G, h1, hs, hyne1, GoodMinimumRowElement]
    · by_cases hby : b = D.y
      · subst b
        have hyne : ¬ D.y = 1 := by omega
        simp [R, G, hyA, hyne, GoodMinimumRowElement]
      · simp [R, G, hb1, hby]
  have honeG : (1 : ℤ) ∉ G := by
    intro h
    have := (Finset.mem_filter.mp h).1
    exact (Finset.mem_erase.mp this).1 rfl
  have hpart :
      (∑ b ∈ R.filter (fun b => GoodMinimumRowElement E b), f b) +
          ∑ b ∈ B, f b = ∑ b ∈ R, f b := by
    have hh := Finset.sum_filter_add_sum_filter_not R
      (fun b : ℤ => GoodMinimumRowElement E b) f
    simpa [B] using hh
  have hrow : productShellRow E D.y =
      1 / D.y + ∑ b ∈ G, f b + ∑ b ∈ B, f b := by
    have hrowR : productShellRow E D.y = ∑ b ∈ R, f b := by
      rfl
    rw [hrowR, ← hpart, hgoodset, Finset.sum_insert honeG]
    have hinv_one : inverseMod E.Q 1 = 1 := by
      have hi := inverseMod_spec E.Q 1 hQ (Int.gcd_one_left E.Q)
      have hres : inverseMod E.Q 1 % E.Q = 1 := by simpa using hi.2
      have hmod := Int.emod_eq_of_lt (by omega : 0 ≤ inverseMod E.Q 1) hi.1.2
      omega
    have hyres : D.y % E.Q = D.y :=
      Int.emod_eq_of_lt (by omega) (by omega)
    have hdist_one : productShellDistance E D.y 1 = D.y := by
      dsimp [productShellDistance, cyclicDistance]
      rw [hinv_one]
      have hmin : min D.y (E.Q - D.y) = D.y := by
        rw [min_eq_left]
        omega
      simp only [mul_one]
      rw [hyres]
      exact hmin
    have h1f : f 1 = 1 / D.y := by
      simp [f, hdist_one]
    rw [h1f]
  have hmain := sEqualsOneMinimumRow
    D.toSEqualsOneSubcriticalData D.hRowOne
  have hn : subcriticalN D.toSEqualsOneSubcriticalData = minimumRowN E := by
    rfl
  have hbad : (badMinimumRowSum E : ℝ) <
      16 * (minimumRowN E : ℝ) / 7 := by
    have hh := hmain.2.1
    rw [hn] at hh
    simpa [E] using hh
  have htri0 := triangularBoundScratch E.A E.Q
    (fun a ha => (E.hA.1 a ha).1) E.hA_sum
  have hcardpos : 1 ≤ E.A.card := by
    exact Finset.card_pos.mpr (⟨1, h1⟩)
  have htri :
      ((minimumRowN E : ℤ) + 1) * ((minimumRowN E : ℤ) + 2) ≤ 2 * E.Q := by
    dsimp [minimumRowN]
    have hc1 : E.A.card - 1 + 1 = E.A.card := by omega
    have hc2 : E.A.card - 1 + 2 = E.A.card + 1 := by omega
    have hc1Z : ((E.A.card - 1 : ℕ) : ℤ) + 1 = E.A.card := by
      exact_mod_cast hc1
    have hc2Z : ((E.A.card - 1 : ℕ) : ℤ) + 2 = E.A.card + 1 := by
      exact_mod_cast hc2
    rw [hc1Z, hc2Z]
    exact htri0
  have hnQint : (minimumRowN E : ℤ) ≤ E.Q := by
    have hnnonneg : (0 : ℤ) ≤ minimumRowN E := by omega
    nlinarith [htri, hnnonneg]
  have hnQnat : minimumRowN E ≤ E.Q.natAbs := by
    have hQnonneg : 0 ≤ E.Q := by omega
    have hcast : (E.Q.natAbs : ℤ) = E.Q := by
      simpa [Int.natCast_natAbs, abs_of_nonneg hQnonneg]
    have hh : (minimumRowN E : ℤ) ≤ (E.Q.natAbs : ℤ) := by
      simpa [hcast] using hnQint
    exact_mod_cast hh
  have hNpred :
      (((minimumRowN E + 1) * (minimumRowN E + 2) : ℕ) : ℤ) / 2 ≤ E.Q := by
    have hcast :
        (((minimumRowN E + 1) * (minimumRowN E + 2) : ℕ) : ℤ) =
          ((minimumRowN E : ℤ) + 1) * ((minimumRowN E : ℤ) + 2) := by
      norm_num
    rw [hcast]
    omega
  have hnq : minimumRowN E ≤ refinedNQ E.Q := by
    apply Nat.le_findGreatest hnQnat
    exact hNpred
  have hnqR : (minimumRowN E : ℝ) ≤ (refinedNQ E.Q : ℝ) := by
    exact_mod_cast hnq
  have hdenR : (0 : ℝ) < E.Q - D.y := by
    exact_mod_cast (by omega : 0 < E.Q - D.y)
  have hden1 : 0 < (7 : ℝ) * (E.Q - D.y) :=
    mul_pos (by norm_num) hdenR
  have hqRfinal : (0 : ℝ) < E.Q := by exact_mod_cast (by omega : 0 < E.Q)
  have hden2 : 0 < (7 : ℝ) * E.Q :=
    mul_pos (by norm_num) hqRfinal
  have hbad' : (badMinimumRowSum E : ℝ) / (E.Q - D.y) <
      16 * (minimumRowN E : ℝ) / (7 * (E.Q - D.y)) := by
    have hh := div_lt_div_of_pos_right hbad hdenR
    convert hh using 1 <;> field_simp [ne_of_gt hdenR] <;> ring
  have hmass : inverseSineRowMass E.Q E.A D.y <
      refinedGoodEnvelope E.Q D.y +
        16 * (minimumRowN E : ℝ) / (7 * (E.Q - D.y)) +
        8 * (minimumRowN E : ℝ) / (7 * E.Q) := by
    have hbase : productShellRow E D.y +
          8 * (minimumRowN E : ℝ) / (7 * E.Q) ≤
        refinedGoodEnvelope E.Q D.y +
          (badMinimumRowSum E : ℝ) / (E.Q - D.y) +
          8 * (minimumRowN E : ℝ) / (7 * E.Q) := by
      rw [hrow]
      gcongr
    calc
      inverseSineRowMass E.Q E.A D.y <
          productShellRow E D.y +
            8 * (minimumRowN E : ℝ) / (7 * E.Q) := hMupper
      _ ≤ refinedGoodEnvelope E.Q D.y +
          (badMinimumRowSum E : ℝ) / (E.Q - D.y) +
          8 * (minimumRowN E : ℝ) / (7 * E.Q) := hbase
      _ < refinedGoodEnvelope E.Q D.y +
          16 * (minimumRowN E : ℝ) / (7 * (E.Q - D.y)) +
          8 * (minimumRowN E : ℝ) / (7 * E.Q) := by
        simpa [add_assoc] using
          (add_lt_add_left
            (add_lt_add_right hbad'
              (8 * (minimumRowN E : ℝ) / (7 * E.Q)))
            (refinedGoodEnvelope E.Q D.y))
  have hterm1 : 16 * (minimumRowN E : ℝ) / (7 * (E.Q - D.y)) ≤
      16 * (refinedNQ E.Q : ℝ) / (7 * (E.Q - D.y)) := by
    gcongr
  have hterm2 : 8 * (minimumRowN E : ℝ) / (7 * E.Q) ≤
      8 * (refinedNQ E.Q : ℝ) / (7 * E.Q) := by
    gcongr
  have hterms := add_le_add hterm1 hterm2
  have hfinal0 := add_le_add_left hterms (refinedGoodEnvelope E.Q D.y)
  have hfinal :
      refinedGoodEnvelope E.Q D.y +
          16 * (minimumRowN E : ℝ) / (7 * (E.Q - D.y)) +
          8 * (minimumRowN E : ℝ) / (7 * E.Q) ≤
        refinedGoodEnvelope E.Q D.y +
          16 * (refinedNQ E.Q : ℝ) / (7 * (E.Q - D.y)) +
          8 * (refinedNQ E.Q : ℝ) / (7 * E.Q) := by
    simpa [add_assoc, add_comm, add_left_comm] using hfinal0
  simpa [refinedCriticalEnvelope, E] using
    (lt_of_lt_of_le hmass hfinal)

end Fraenkel
