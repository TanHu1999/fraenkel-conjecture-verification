import Fraenkel.Analytic.MinimumRow
import Fraenkel.Cases.KnapsackArray

namespace Fraenkel

open scoped BigOperators Classical

/-- The finite input domain of the rounded knapsack verifier. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
structure RoundedKnapsackInstance where
  Q : ℤ
  s : ℤ
  hQ_lower : 7 ≤ Q
  hQ_upper : Q ≤ 301
  hs_lower : 2 ≤ s
  hs_upper : 3 * s < Q
  hs_unit : Int.gcd s Q = 1

/-- The scale `L=10^7`. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
def knapsackScale : ℤ := (10 : ℤ) ^ 7

/-- The finite pool `V_{Q,s}`. The upper endpoint `Q-1` is harmless because the
third defining inequality is imposed by the filter. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
noncomputable def knapsackPool (Q s : ℤ) : Finset ℤ :=
  (Finset.Icc s (Q - 1)).filter (fun a => 3 * a < Q ∧ Int.gcd a Q = 1)

/-- A computable list presentation of the same finite pool. -/
def knapsackPoolList (Q s : ℤ) : List ℤ :=
  (List.range (Q - s).toNat).map
      (fun n : ℕ => s + (n : ℤ)) |>.filter
    (fun a => 3 * a < Q ∧ Int.gcd a Q = 1)

theorem knapsackPool_eq_toFinset (Q s : ℤ) :
    knapsackPool Q s = (knapsackPoolList Q s).toFinset := by
  ext a
  simp [knapsackPool, knapsackPoolList, Int.Icc_eq_finset_map]

theorem knapsackPoolList_nodup (Q s : ℤ) :
    (knapsackPoolList Q s).Nodup := by
  unfold knapsackPoolList
  have hmap : ((List.range (Q - s).toNat).map
      (fun n : ℕ => s + (n : ℤ))).Nodup := by
    apply List.Nodup.map
    · intro x y hxy
      change s + (x : ℤ) = s + (y : ℤ) at hxy
      have hxy' : (x : ℤ) = (y : ℤ) := add_left_cancel hxy
      exact_mod_cast hxy'
    · exact List.nodup_range
  exact hmap.filter _

/-- The rounded weight `w_ab`. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
noncomputable def roundedKnapsackWeight (Q a b : ℤ) : ℤ :=
  ⌈(knapsackScale : ℝ) *
      (1 / (cyclicDistance Q (a * inverseMod Q b) : ℝ) +
        16 * (cyclicDistance Q (a * inverseMod Q b) : ℝ) /
          (7 * (Q : ℝ) ^ 2))⌉

/-- A computable maximum on the optional integer score type. -/
def botMaxInt : WithBot ℤ → WithBot ℤ → WithBot ℤ
  | none, y => y
  | x, none => x
  | some x, some y => some (max x y)

@[simp] theorem botMaxInt_eq_max (x y : WithBot ℤ) :
    botMaxInt x y = max x y := by
  cases x <;> cases y <;> rfl

/-- A computable comparison below the verifier scale. -/
def botLtInt (x y : WithBot ℤ) : Bool :=
  match x, y with
  | none, none => false
  | none, some _ => true
  | some _, none => false
  | some x, some y => decide (x < y)

@[simp] theorem botLtInt_eq_decide (x y : WithBot ℤ) :
    botLtInt x y = decide (x < y) := by
  cases x <;> cases y <;> simp [botLtInt]

/-- The same rounded weight, evaluated in the computable field of rationals. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
def roundedKnapsackWeightRat (Q a b : ℤ) : ℤ :=
  ⌈(knapsackScale : ℚ) *
      (1 / (cyclicDistance Q (a * inverseMod Q b) : ℚ) +
        16 * (cyclicDistance Q (a * inverseMod Q b) : ℚ) /
          (7 * (Q : ℚ) ^ 2))⌉

/-- The real and rational presentations of the rounded weight agree. -/
theorem roundedKnapsackWeight_eq_rat (Q a b : ℤ) :
    roundedKnapsackWeight Q a b = roundedKnapsackWeightRat Q a b := by
  unfold roundedKnapsackWeight roundedKnapsackWeightRat
  let r : ℚ := (knapsackScale : ℚ) *
      (1 / (cyclicDistance Q (a * inverseMod Q b) : ℚ) +
        16 * (cyclicDistance Q (a * inverseMod Q b) : ℚ) /
          (7 * (Q : ℚ) ^ 2))
  have hreal : (r : ℝ) =
      (knapsackScale : ℝ) *
        (1 / (cyclicDistance Q (a * inverseMod Q b) : ℝ) +
          16 * (cyclicDistance Q (a * inverseMod Q b) : ℝ) /
            (7 * (Q : ℝ) ^ 2)) := by
    dsimp [r]
    norm_num
  rw [← hreal]
  exact Rat.ceil_cast r

/-- The exact-load dynamic-programming initial layer. `⊥` is NEG_INF. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
noncomputable def knapsackInitial (_C : ℤ) : ℤ → WithBot ℤ :=
  fun u => if u = 0 then (0 : WithBot ℤ) else ⊥

/-- One exact-load 0--1 knapsack update. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
noncomputable def knapsackStep (Q a b : ℤ) (prev : ℤ → WithBot ℤ) :
    ℤ → WithBot ℤ :=
  fun u =>
    if u < b then prev u
    else
      max (prev u)
        (prev (u - b) + (roundedKnapsackWeight Q a b : WithBot ℤ))

/-- All DP layers, including the initial layer and one layer per listed item. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
noncomputable def knapsackDPStates (Q a : ℤ) (items : List ℤ) :
    List (ℤ → WithBot ℤ) :=
  List.scanl (fun prev b => knapsackStep Q a b prev)
    (knapsackInitial (Q - a)) items

/-- The final exact-load DP layer. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
noncomputable def knapsackDPFinal (Q a : ℤ) (items : List ℤ) :
    ℤ → WithBot ℤ :=
  List.foldl (fun prev b => knapsackStep Q a b prev)
    (knapsackInitial (Q - a)) items

/-- The computable exact-load initial layer for rational weights. -/
def knapsackInitialRat (_C : ℤ) : ℤ → WithBot ℤ :=
  fun u => if u = 0 then (0 : WithBot ℤ) else ⊥

/-- One exact-load update using the rationally evaluated rounded weight. -/
def knapsackStepRat (Q a b : ℤ) (prev : ℤ → WithBot ℤ) :
    ℤ → WithBot ℤ :=
  fun u =>
    if u < b then prev u
    else
      botMaxInt (prev u)
        (prev (u - b) + (roundedKnapsackWeightRat Q a b : WithBot ℤ))

/-- Updates by two nonnegative items commute. -/
theorem knapsackStepRat_comm (Q a b c : ℤ) (hb : 0 ≤ b) (hc : 0 ≤ c)
    (f : ℤ → WithBot ℤ) :
    knapsackStepRat Q a b (knapsackStepRat Q a c f) =
      knapsackStepRat Q a c (knapsackStepRat Q a b f) := by
  funext u
  by_cases hbu : u < b
  · by_cases hcu : u < c
    · simp [knapsackStepRat, hbu, hcu]
    · have hcb : u - c < b := by omega
      simp [knapsackStepRat, hbu, hcu, hcb]
  · by_cases hcu : u < c
    · have hbc : u - b < c := by omega
      simp [knapsackStepRat, hbu, hcu, hbc]
    · by_cases hbc : u - b < c
      · have hcb : u - c < b := by omega
        simp [knapsackStepRat, hbu, hcu, hbc, hcb,
          max_assoc, max_comm, max_left_comm, max_add_add_right,
          max_add_add_left, add_assoc, add_comm, add_left_comm]
      · have hcb : ¬ u - c < b := by omega
        simp [knapsackStepRat, hbu, hcu, hbc, hcb]
        rw [max_add, max_add]
        rw [show u - c - b = u - b - c by ring]
        ac_rfl

/-- The final exact-load DP layer with rational weights. -/
def knapsackDPFinalRat (Q a : ℤ) (items : List ℤ) :
    ℤ → WithBot ℤ :=
  List.foldl (fun prev b => knapsackStepRat Q a b prev)
    (knapsackInitialRat (Q - a)) items

def knapsackStepRatSafe (Q a : ℤ) (prev : ℤ → WithBot ℤ) (b : ℤ) :
    ℤ → WithBot ℤ :=
  if 0 ≤ b then knapsackStepRat Q a b prev else prev

theorem knapsackStepRatSafe_comm (Q a : ℤ) :
    RightCommutative (knapsackStepRatSafe Q a) := by
  refine ⟨?_⟩
  intro prev b c
  by_cases hb : 0 ≤ b <;> by_cases hc : 0 ≤ c
  · simp [knapsackStepRatSafe, hb, hc]
    exact (knapsackStepRat_comm Q a b c hb hc prev).symm
  · simp [knapsackStepRatSafe, hb, hc]
  · simp [knapsackStepRatSafe, hb, hc]
  · simp [knapsackStepRatSafe, hb, hc]

theorem knapsackDPFinalRat_perm (Q a : ℤ) {xs ys : List ℤ}
    (hp : xs.Perm ys)
    (hpos : ∀ b ∈ xs, 0 ≤ b) (hpos' : ∀ b ∈ ys, 0 ≤ b) :
    knapsackDPFinalRat Q a xs = knapsackDPFinalRat Q a ys := by
  have hsafe : ∀ (zs : List ℤ), (∀ b ∈ zs, 0 ≤ b) →
      ∀ (prev : ℤ → WithBot ℤ),
        List.foldl (fun prev b => knapsackStepRat Q a b prev) prev zs =
          List.foldl (knapsackStepRatSafe Q a) prev zs := by
    intro zs
    induction zs with
    | nil =>
        intro hzs prev
        rfl
    | cons b zs ih =>
        intro hzs prev
        have hb := hzs b (by simp)
        have hzs' : ∀ c ∈ zs, 0 ≤ c := by
          intro c hc
          exact hzs c (by simp [hc])
        simp only [List.foldl_cons]
        rw [ih hzs' (knapsackStepRat Q a b prev)]
        simp [knapsackStepRatSafe, hb]
  have hxs := hsafe xs hpos (knapsackInitialRat (Q - a))
  have hys := hsafe ys hpos' (knapsackInitialRat (Q - a))
  letI : RightCommutative (knapsackStepRatSafe Q a) :=
    knapsackStepRatSafe_comm Q a
  calc
    knapsackDPFinalRat Q a xs =
        List.foldl (knapsackStepRatSafe Q a)
          (knapsackInitialRat (Q - a)) xs := hxs
    _ = List.foldl (knapsackStepRatSafe Q a)
          (knapsackInitialRat (Q - a)) ys := hp.foldl_eq _
    _ = knapsackDPFinalRat Q a ys := hys.symm

theorem knapsackStep_eq_rat (Q a b : ℤ) (prev : ℤ → WithBot ℤ) :
    knapsackStep Q a b prev = knapsackStepRat Q a b prev := by
  funext u
  by_cases hu : u < b
  · simp [knapsackStep, knapsackStepRat, hu]
  · simp [knapsackStep, knapsackStepRat, hu,
      roundedKnapsackWeight_eq_rat, botMaxInt_eq_max]

/-- The real and rational DP layers agree. -/
theorem knapsackDPFinal_eq_rat (Q a : ℤ) (items : List ℤ) :
    knapsackDPFinal Q a items = knapsackDPFinalRat Q a items := by
  have hfold : ∀ (prev : ℤ → WithBot ℤ),
      List.foldl (fun prev b => knapsackStep Q a b prev) prev items =
        List.foldl (fun prev b => knapsackStepRat Q a b prev) prev items := by
    intro prev
    induction items generalizing prev with
    | nil => rfl
    | cons b items ih =>
        simp only [List.foldl_cons]
        rw [knapsackStep_eq_rat]
        exact ih _
  simpa [knapsackDPFinal, knapsackDPFinalRat, knapsackInitial,
    knapsackInitialRat] using hfold (knapsackInitial (Q - a))

/-- The exact maximum over all integer loads from `0` through `Q-a`. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
noncomputable def exactKnapsackScore (Q a : ℤ) (P : Finset ℤ) : WithBot ℤ :=
  (Finset.Icc 0 (Q - a)).sup
    (knapsackDPFinal Q a (P.erase a).toList)

/-- The same score with rationally evaluated DP weights. -/
noncomputable def exactKnapsackScoreRat (Q a : ℤ) (P : Finset ℤ) : WithBot ℤ :=
  (Finset.Icc 0 (Q - a)).sup
    (knapsackDPFinalRat Q a (P.erase a).toList)

theorem exactKnapsackScore_eq_rat (Q a : ℤ) (P : Finset ℤ) :
    exactKnapsackScore Q a P = exactKnapsackScoreRat Q a P := by
  unfold exactKnapsackScore exactKnapsackScoreRat
  apply Finset.sup_congr rfl
  intro u hu
  rw [knapsackDPFinal_eq_rat]

theorem botMaxInt_fold_sup (l : List (WithBot ℤ)) :
    l.foldl botMaxInt ⊥ = l.toFinset.sup id := by
  have hfold : ∀ (z : WithBot ℤ),
      l.foldl botMaxInt z = max z (l.toFinset.sup id) := by
    induction l with
    | nil => intro z; simp
    | cons x xs ih =>
        intro z
        simp only [List.foldl_cons]
        rw [botMaxInt_eq_max, ih]
        simp [Finset.sup_cons, List.toFinset_cons, max_assoc,
          max_comm, max_left_comm]
  simpa using hfold ⊥

/-- The computable load list for a nonnegative integer capacity. -/
def knapsackLoadList (Q a : ℤ) : List ℤ :=
  (List.range (Q - a + 1).toNat).map (fun n : ℕ => (n : ℤ))

/-- The rational score evaluated by a list fold. -/
def exactKnapsackScoreRatList (Q a : ℤ) (items : List ℤ) : WithBot ℤ :=
  ((knapsackLoadList Q a).map
    (fun u => knapsackDPFinalRat Q a items u)).foldl botMaxInt ⊥

theorem exactKnapsackScoreRatList_eq_finset
    (Q a : ℤ) (items : List ℤ) (hcap : 0 ≤ Q - a) :
    exactKnapsackScoreRatList Q a items =
      (Finset.Icc 0 (Q - a)).sup (knapsackDPFinalRat Q a items) := by
  rw [exactKnapsackScoreRatList, botMaxInt_fold_sup]
  have hloads : (knapsackLoadList Q a).toFinset = Finset.Icc 0 (Q - a) := by
    ext u
    simp [knapsackLoadList, Int.Icc_eq_finset_map, eq_comm]
  have hmap :
      ((knapsackLoadList Q a).map
        (fun u => knapsackDPFinalRat Q a items u)).toFinset =
        (knapsackLoadList Q a).toFinset.image
          (knapsackDPFinalRat Q a items) := by
    ext y
    simp [eq_comm]
  rw [hmap, Finset.sup_image, hloads]
  rfl

/-- The list score agrees with the original score on a computable pool. -/
theorem exactKnapsackScore_eq_ratList_of_pool
    (Q s a : ℤ) (ha : a ∈ knapsackPool Q s) (haQ : a < Q)
    (hpos : ∀ b ∈ knapsackPoolList Q s, 0 ≤ b) :
    exactKnapsackScore Q a (knapsackPool Q s) =
      exactKnapsackScoreRatList Q a ((knapsackPoolList Q s).erase a) := by
  have hP := knapsackPool_eq_toFinset Q s
  have hPerase : (knapsackPool Q s).erase a =
      ((knapsackPoolList Q s).erase a).toFinset := by
    rw [hP]
    ext b
    simp [List.Nodup.mem_erase_iff (knapsackPoolList_nodup Q s)]
  have hperm : ((knapsackPool Q s).erase a).toList.Perm
      ((knapsackPoolList Q s).erase a) := by
    rw [hPerase]
    exact List.toFinset_toList
      ((knapsackPoolList_nodup Q s).erase a)
  have hposP : ∀ b ∈ ((knapsackPool Q s).erase a).toList, 0 ≤ b := by
    intro b hb
    exact hpos b (List.mem_of_mem_erase
      (hperm.mem_iff.mp (by simpa using hb)))
  have hscoreDP :
      (Finset.Icc 0 (Q - a)).sup
          (knapsackDPFinalRat Q a ((knapsackPool Q s).erase a).toList) =
        (Finset.Icc 0 (Q - a)).sup
          (knapsackDPFinalRat Q a ((knapsackPoolList Q s).erase a) ) := by
    apply Finset.sup_congr rfl
    intro u hu
    rw [knapsackDPFinalRat_perm Q a hperm hposP
      (fun b hb => hpos b (List.mem_of_mem_erase hb))]
  rw [exactKnapsackScore_eq_rat]
  rw [exactKnapsackScoreRatList_eq_finset Q a
    ((knapsackPoolList Q s).erase a) (by omega)]
  exact hscoreDP

/-- The list score agrees with the original score for any finite list pool. -/
theorem exactKnapsackScore_eq_ratList_of_finset_list
    (Q a : ℤ) (P : Finset ℤ) (items : List ℤ)
    (hP : P = items.toFinset) (hNodup : items.Nodup)
    (ha : a ∈ P) (haQ : a ≤ Q)
    (hpos : ∀ b ∈ items, 0 ≤ b) :
    exactKnapsackScore Q a P =
      exactKnapsackScoreRatList Q a (items.erase a) := by
  have hPerase : P.erase a = (items.erase a).toFinset := by
    rw [hP]
    ext b
    simp [List.Nodup.mem_erase_iff hNodup]
  have hperm : (P.erase a).toList.Perm (items.erase a) := by
    rw [hPerase]
    exact List.toFinset_toList (hNodup.erase a)
  have hposP : ∀ b ∈ (P.erase a).toList, 0 ≤ b := by
    intro b hb
    exact hpos b (List.mem_of_mem_erase (hperm.mem_iff.mp (by simpa using hb)))
  have hscoreDP :
      (Finset.Icc 0 (Q - a)).sup
          (knapsackDPFinalRat Q a (P.erase a).toList) =
        (Finset.Icc 0 (Q - a)).sup
          (knapsackDPFinalRat Q a (items.erase a)) := by
    apply Finset.sup_congr rfl
    intro u hu
    rw [knapsackDPFinalRat_perm Q a hperm hposP
      (fun b hb => hpos b (List.mem_of_mem_erase hb))]
  rw [exactKnapsackScore_eq_rat]
  rw [exactKnapsackScoreRatList_eq_finset Q a
    (items.erase a) (by omega)]
  exact hscoreDP

/-- Every selected subset is represented by the exact-load DP at its total load. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
theorem knapsackDPFinal_ge_sum (Q a : ℤ) (items : List ℤ) (S : Finset ℤ)
    (hS : ∀ b ∈ S, b ∈ items) (hpos : ∀ b ∈ S, 0 ≤ b) :
    ((∑ b ∈ S, roundedKnapsackWeight Q a b : ℤ) : WithBot ℤ) ≤
      knapsackDPFinal Q a items (∑ b ∈ S, b) := by
  induction items using List.reverseRecOn generalizing S with
  | nil =>
      have hS0 : S = ∅ := by
        apply Finset.eq_empty_iff_forall_notMem.mpr
        intro b hb
        simpa using hS b hb
      simp [hS0, knapsackDPFinal, knapsackInitial]
  | append_singleton b items ih =>
      by_cases hitem : items ∈ S
      · have hSprev : ∀ c ∈ S.erase items, c ∈ b := by
          intro c hc
          have hcS : c ∈ S := (Finset.mem_erase.mp hc).2
          rcases List.mem_append.mp (hS c hcS) with hcb | hci
          · exact hcb
          · have hci' : c = items := by simpa using hci
            exact False.elim ((Finset.mem_erase.mp hc).1 hci')
        have hposprev : ∀ c ∈ S.erase items, 0 ≤ c := by
          intro c hc
          exact hpos c (Finset.mem_erase.mp hc |>.2)
        have hprev := ih (S.erase items) hSprev hposprev
        have hsum :
            (∑ c ∈ S.erase items, c) + items = ∑ c ∈ S, c :=
          S.sum_erase_add (fun c : ℤ => c) hitem
        have hweight :
            (∑ c ∈ S.erase items, roundedKnapsackWeight Q a c) +
                roundedKnapsackWeight Q a items =
              ∑ c ∈ S, roundedKnapsackWeight Q a c :=
          S.sum_erase_add (fun c : ℤ => roundedKnapsackWeight Q a c) hitem
        have hsum_nonneg : 0 ≤ ∑ c ∈ S.erase items, c := by
          exact Finset.sum_nonneg (fun c hc => hpos c (Finset.mem_erase.mp hc |>.2))
        have hload : items ≤ ∑ c ∈ S, c := by
          rw [← hsum]
          omega
        have hload_eq : (∑ c ∈ S, c) - items = ∑ c ∈ S.erase items, c := by
          omega
        have hprev' :
            ((∑ c ∈ S.erase items, roundedKnapsackWeight Q a c : ℤ) : WithBot ℤ) ≤
              List.foldl (fun prev b => knapsackStep Q a b prev)
                (knapsackInitial (Q - a)) b (∑ c ∈ S.erase items, c) := by
          simpa [knapsackDPFinal] using hprev
        rw [knapsackDPFinal, List.foldl_append]
        simp only [List.foldl_cons, List.foldl_nil]
        unfold knapsackStep
        rw [if_neg (by omega)]
        apply le_trans ?_ (le_max_right _ _)
        rw [← hweight]
        rw [hload_eq]
        simp only [WithBot.coe_add]
        have hadd := add_le_add_left hprev'
          (roundedKnapsackWeight Q a items : WithBot ℤ)
        simpa [add_comm] using hadd
      · have hSprev : ∀ c ∈ S, c ∈ b := by
          intro c hc
          rcases List.mem_append.mp (hS c hc) with hcb | hci
          · exact hcb
          · have hci' : c = items := by simpa using hci
            have hitems : items ∈ S := by
              rw [← hci']
              exact hc
            exact False.elim (hitem hitems)
        have hprev := ih S hSprev hpos
        rw [knapsackDPFinal, List.foldl_append]
        simp only [List.foldl_cons, List.foldl_nil]
        unfold knapsackStep
        by_cases hload : (∑ c ∈ S, c) < items
        · rw [if_pos hload]
          exact hprev
        · rw [if_neg hload]
          exact le_trans hprev (le_max_left _ _)

/-- A feasible positive subcollection contributes at most the exact knapsack score. -/
theorem exactKnapsackScore_ge_sum (Q a : ℤ) (P S : Finset ℤ)
    (hS : S ⊆ P.erase a) (hpos : ∀ b ∈ S, 0 ≤ b)
    (hload : (∑ b ∈ S, b) ≤ Q - a) :
    ((∑ b ∈ S, roundedKnapsackWeight Q a b : ℤ) : WithBot ℤ) ≤
      exactKnapsackScore Q a P := by
  have hload_nonneg : 0 ≤ ∑ b ∈ S, b := by
    exact Finset.sum_nonneg (fun b hb => hpos b hb)
  have hmem : (∑ b ∈ S, b) ∈ Finset.Icc 0 (Q - a) := by
    exact Finset.mem_Icc.mpr ⟨hload_nonneg, hload⟩
  have hlist : ∀ b ∈ S, b ∈ (P.erase a).toList := by
    intro b hb
    exact Finset.mem_toList.mpr (hS hb)
  have hdp := knapsackDPFinal_ge_sum Q a (P.erase a).toList S hlist hpos
  unfold exactKnapsackScore
  exact hdp.trans (Finset.le_sup hmem)

/-- Upward rounding makes each verifier weight strictly dominate the scaled kernel. -/
theorem roundedKnapsackWeight_gt_scaled_kernel (Q a b : ℤ)
    (hQ : 2 ≤ Q)
    (hd : 1 ≤ cyclicDistance Q (a * inverseMod Q b))
    (hdQ : 2 * cyclicDistance Q (a * inverseMod Q b) ≤ Q) :
    (knapsackScale : ℝ) *
        inverseSineKernel Q (cyclicDistance Q (a * inverseMod Q b)) <
      (roundedKnapsackWeight Q a b : ℝ) := by
  have hupper := inverseSineKernel_upper Q
    (cyclicDistance Q (a * inverseMod Q b)) hQ hd hdQ
  have hcomparison := inverseSineKernel_rationalComparison Q
    (cyclicDistance Q (a * inverseMod Q b)) hQ hd
  have hkernel := hupper.trans hcomparison
  have hscale : 0 < (knapsackScale : ℝ) := by
    norm_num [knapsackScale]
  have hscaled := mul_lt_mul_of_pos_left hkernel hscale
  have hceil :
      (knapsackScale : ℝ) *
          (1 / (cyclicDistance Q (a * inverseMod Q b) : ℝ) +
            16 * (cyclicDistance Q (a * inverseMod Q b) : ℝ) /
              (7 * (Q : ℝ) ^ 2)) ≤
        (roundedKnapsackWeight Q a b : ℝ) := by
    simpa [roundedKnapsackWeight] using
      (Int.le_ceil ((knapsackScale : ℝ) *
        (1 / (cyclicDistance Q (a * inverseMod Q b) : ℝ) +
          16 * (cyclicDistance Q (a * inverseMod Q b) : ℝ) /
            (7 * (Q : ℝ) ^ 2))))
  exact hscaled.trans_le hceil

/-- Distinctness of the unit representatives keeps every row distance nonzero. -/
theorem minimumRowDistance_bounds_of_mem
    (D : MinimumRowSlackData) {a b : ℤ}
    (ha : a ∈ D.A) (hb : b ∈ D.A) :
    1 ≤ cyclicDistance D.Q (a * inverseMod D.Q b) ∧
      2 * cyclicDistance D.Q (a * inverseMod D.Q b) ≤ D.Q := by
  have hQ : 2 ≤ D.Q := by
    have hQ0 := D.hQ
    omega
  have haU := D.hA.1 a ha
  have hbU := D.hA.1 b hb
  have haQ : a < D.Q := by
    have hh := D.hA_upper a ha
    nlinarith
  have hsinv : (a * inverseMod D.Q b) % D.Q ≠ 0 := by
    intro hz
    have hinv := inverseMod_spec D.Q b hQ hbU.2
    have hzero : a * inverseMod D.Q b ≡ 0 [ZMOD D.Q] := by
      simpa [Int.ModEq] using hz
    have hprod : (a * inverseMod D.Q b) * b ≡ 0 * b [ZMOD D.Q] :=
      hzero.mul_right b
    have h1mod : (1 : ℤ) % D.Q = 1 := by
      exact Int.emod_eq_of_lt (by omega) (by omega)
    have hone : b * inverseMod D.Q b ≡ 1 [ZMOD D.Q] := by
      simpa [Int.ModEq, h1mod] using hinv.2
    have hcalc : (a * inverseMod D.Q b) * b ≡ a [ZMOD D.Q] := by
      calc
        (a * inverseMod D.Q b) * b = a * (b * inverseMod D.Q b) := by ring
        _ ≡ a * 1 [ZMOD D.Q] := hone.mul_left a
        _ = a := by ring
    have hamod : a % D.Q = 0 := by
      have : (a * inverseMod D.Q b) * b % D.Q = 0 := hprod.eq.trans (by simp)
      rw [hcalc.eq] at this
      exact this
    have harem : a % D.Q = a := Int.emod_eq_of_lt (by omega) haQ
    omega
  exact cyclicDistance_bounds D.Q (a * inverseMod D.Q b) hQ hsinv

/-- A passing row has rounded score at least the verifier scale in every
pool containing the selected representatives. -/
theorem exactKnapsackScore_ge_scale_of_rowPasses
    (D : MinimumRowSlackData) (P : Finset ℤ) (a : ℤ)
    (hAP : D.A ⊆ P) (ha : a ∈ D.A)
    (hpass : RowPasses D.Q D.A a) :
    (knapsackScale : WithBot ℤ) ≤ exactKnapsackScore D.Q a P := by
  classical
  have hQ : 2 ≤ D.Q := by
    have hQ0 := D.hQ
    omega
  have haU := D.hA.1 a ha
  have hSnonempty : (D.A.erase a).Nonempty := by
    by_contra hn
    have he : D.A.erase a = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
    have hpass' : (1 : ℝ) ≤ 0 := by
      change 1 ≤ inverseSineRowMass D.Q D.A a at hpass
      simpa [inverseSineRowMass, he] using hpass
    linarith
  have hterm : ∀ b ∈ D.A.erase a,
      (knapsackScale : ℝ) *
          inverseSineKernel D.Q (cyclicDistance D.Q (a * inverseMod D.Q b)) <
        (roundedKnapsackWeight D.Q a b : ℝ) := by
    intro b hb
    have hdist := minimumRowDistance_bounds_of_mem D ha (Finset.mem_erase.mp hb).2
    exact roundedKnapsackWeight_gt_scaled_kernel D.Q a b hQ hdist.1 hdist.2
  have hmass : (1 : ℝ) ≤
      ∑ b ∈ D.A.erase a,
        inverseSineKernel D.Q (cyclicDistance D.Q (a * inverseMod D.Q b)) := by
    change 1 ≤ inverseSineRowMass D.Q D.A a at hpass
    exact hpass
  have hscaledmass : (knapsackScale : ℝ) ≤
      ∑ b ∈ D.A.erase a,
        (knapsackScale : ℝ) *
          inverseSineKernel D.Q (cyclicDistance D.Q (a * inverseMod D.Q b)) := by
    rw [← Finset.mul_sum]
    have hscale_nonneg : 0 ≤ (knapsackScale : ℝ) := by
      norm_num [knapsackScale]
    simpa using mul_le_mul_of_nonneg_left hmass hscale_nonneg
  have hsumweights := Finset.sum_lt_sum_of_nonempty hSnonempty hterm
  have hweights_real : (knapsackScale : ℝ) <
      ∑ b ∈ D.A.erase a, (roundedKnapsackWeight D.Q a b : ℝ) :=
    lt_of_le_of_lt hscaledmass hsumweights
  have hweights_int : knapsackScale <
      ∑ b ∈ D.A.erase a, roundedKnapsackWeight D.Q a b := by
    exact_mod_cast hweights_real
  have hweights_le : knapsackScale ≤
      ∑ b ∈ D.A.erase a, roundedKnapsackWeight D.Q a b := by omega
  have hsubset : D.A.erase a ⊆ P.erase a := by
    intro b hb
    exact Finset.mem_erase.mpr ⟨(Finset.mem_erase.mp hb).1, hAP (Finset.mem_erase.mp hb).2⟩
  have hpos : ∀ b ∈ D.A.erase a, 0 ≤ b := by
    intro b hb
    exact (D.hA.1 b (Finset.mem_erase.mp hb).2).1.le
  have hload : (∑ b ∈ D.A.erase a, b) ≤ D.Q - a := by
    have hsum := D.hA_sum
    have hsum_erase :
        (∑ b ∈ D.A.erase a, b) + a = ∑ b ∈ D.A, b :=
      D.A.sum_erase_add (fun b : ℤ => b) ha
    have ha0 := haU.1
    omega
  have hscore := exactKnapsackScore_ge_sum D.Q a P (D.A.erase a) hsubset hpos hload
  exact (WithBot.coe_le_coe.mpr hweights_le).trans hscore

/-- Vertices whose rounded score is below the scale, computed from one pool
snapshot. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
noncomputable def doomedKnapsackVertices (Q : ℤ) (P : Finset ℤ) : Finset ℤ :=
  P.filter (fun a => exactKnapsackScore Q a P < (knapsackScale : WithBot ℤ))

/-- If the minimum is greater than one and its row passes, some other
selected representative is good. -/
theorem exists_good_minimumRowElement
    (D : MinimumRowSlackData) (hs : 1 < D.s)
    (hpass : RowPasses D.Q D.A D.s) :
    ∃ a ∈ D.A.erase D.s, GoodMinimumRowElement D a := by
  classical
  by_contra hnone
  have hbad := passingMinimumRowSlack D hpass
  have hnonempty : (D.A.erase D.s).Nonempty := by
    by_contra hn
    have he : D.A.erase D.s = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
    have hpass' : (1 : ℝ) ≤ 0 := by
      change 1 ≤ inverseSineRowMass D.Q D.A D.s at hpass
      simpa [inverseSineRowMass, he] using hpass
    linarith
  have hbad_eq : badMinimumRowSum D = ∑ a ∈ D.A.erase D.s, a := by
    apply Finset.sum_congr rfl
    intro a ha
    have hbad_a : BadMinimumRowElement D a := by
      intro hgood
      exact hnone ⟨a, ha, hgood⟩
    simp [hbad_a]
  have hterm : ∀ a ∈ D.A.erase D.s, (3 : ℝ) ≤ (a : ℝ) := by
    intro a ha
    have haU := D.hA.1 a (Finset.mem_erase.mp ha).2
    have hsa := D.hs_min a (Finset.mem_erase.mp ha).2
    have hne := (Finset.mem_erase.mp ha).1
    have hs0 := D.hA.1 D.s D.hs_mem |>.1
    have : 2 ≤ D.s := by omega
    have ha3 : (3 : ℤ) ≤ a := by omega
    exact_mod_cast ha3
  have hsumlower : (3 : ℝ) * (D.A.erase D.s).card ≤
      ∑ a ∈ D.A.erase D.s, (a : ℝ) := by
    have hh := Finset.sum_le_sum hterm
    simpa [Finset.sum_const, nsmul_eq_mul, mul_comm] using hh
  have hcard : ((D.A.erase D.s).card : ℝ) = (minimumRowN D : ℝ) := by
    have hc : (D.A.erase D.s).card = D.A.card - 1 :=
      Finset.card_erase_of_mem D.hs_mem
    dsimp [minimumRowN]
    rw [hc]
  have hbadlower : 3 * (minimumRowN D : ℝ) ≤ (badMinimumRowSum D : ℝ) := by
    have hsum_cast :
        ((∑ a ∈ D.A.erase D.s, a : ℤ) : ℝ) =
          ∑ a ∈ D.A.erase D.s, (a : ℝ) := by
      norm_num
    rw [hbad_eq, hsum_cast, ← hcard]
    exact hsumlower
  have hnpos : 0 < (minimumRowN D : ℝ) := by
    rw [← hcard]
    exact_mod_cast (Finset.card_pos.mpr hnonempty)
  have hbadupper : (badMinimumRowSum D : ℝ) < 16 * (minimumRowN D : ℝ) / 7 := hbad.2
  nlinarith

/-- A least good representative can be chosen inside the selected row. -/
theorem exists_least_good_minimumRowElement
    (D : MinimumRowSlackData) (hs : 1 < D.s)
    (hpass : RowPasses D.Q D.A D.s) :
    ∃ x ∈ D.A.erase D.s, GoodMinimumRowElement D x ∧
      ∀ z ∈ D.A.erase D.s, GoodMinimumRowElement D z → x ≤ z := by
  classical
  obtain ⟨x, hx, hgood⟩ := exists_good_minimumRowElement D hs hpass
  let G := (D.A.erase D.s).filter (GoodMinimumRowElement D)
  have hG : G.Nonempty := by
    refine ⟨x, ?_⟩
    exact Finset.mem_filter.mpr ⟨hx, hgood⟩
  let y : ℤ := G.min' hG
  have hyG : y ∈ G := by
    exact Finset.min'_mem G hG
  have hy := Finset.mem_filter.mp hyG
  refine ⟨y, hy.1, hy.2, ?_⟩
  intro z hz hzg
  exact Finset.min'_le G z (Finset.mem_filter.mpr ⟨hz, hzg⟩)

/-- A selected proper divisor of the least good representative cannot occur. -/
theorem no_selected_proper_divisor_of_least_good
    (D : MinimumRowSlackData) (hs : 1 < D.s)
    {x : ℤ} (hx : x ∈ D.A.erase D.s)
    (hxgood : GoodMinimumRowElement D x)
    (hleast : ∀ z ∈ D.A.erase D.s, GoodMinimumRowElement D z → x ≤ z)
    {b : ℤ} (hb : b ∈ D.A) (hbx : b ∣ x) (hblt : b < x) : False := by
  have hbgood : GoodMinimumRowElement D b := by
    rcases hxgood with hminus | hplus
    · left
      exact dvd_trans hbx hminus
    · right
      exact dvd_trans hbx hplus
  by_cases hbs : b = D.s
  · subst b
    have hsdiv : D.s ∣ D.Q := by
      rcases hbgood with hminus | hplus
      · have htmp := dvd_add hminus (dvd_refl D.s)
        convert htmp using 1 <;> ring
      · have htmp := dvd_sub hplus (dvd_refl D.s)
        convert htmp using 1 <;> ring
    have hcop := D.hA.1 D.s D.hs_mem |>.2
    have hone : D.s ∣ (1 : ℤ) :=
      (Int.gcd_eq_one_iff).1 hcop D.s (dvd_refl D.s) hsdiv
    have hsone : D.s = 1 := Int.eq_one_of_dvd_one
      (D.hA.1 D.s D.hs_mem |>.1.le) hone
    omega
  · have hberase : b ∈ D.A.erase D.s := Finset.mem_erase.mpr ⟨hbs, hb⟩
    have hle := hleast b hberase hbgood
    omega

/-- The minimum representative itself is not good when it is greater than one. -/
theorem not_good_minimumRowElement
    (D : MinimumRowSlackData) (hs : 1 < D.s) :
    ¬ GoodMinimumRowElement D D.s := by
  intro hgood
  have hsdiv : D.s ∣ D.Q := by
    rcases hgood with hminus | hplus
    · have htmp := dvd_add hminus (dvd_refl D.s)
      convert htmp using 1 <;> ring
    · have htmp := dvd_sub hplus (dvd_refl D.s)
      convert htmp using 1 <;> ring
  have hcop := D.hA.1 D.s D.hs_mem |>.2
  have hone : D.s ∣ (1 : ℤ) :=
    (Int.gcd_eq_one_iff).1 hcop D.s (dvd_refl D.s) hsdiv
  have hsone : D.s = 1 := Int.eq_one_of_dvd_one
    (D.hA.1 D.s D.hs_mem |>.1.le) hone
  omega

/-- A good representative in the first shell must be the exceptional value
`x+s`. -/
theorem firstShell_good_eq_add_minimum
    (D : MinimumRowSlackData) (hs : 1 < D.s)
    {x : ℤ} (hx : x ∈ D.A.erase D.s)
    (hxgood : GoodMinimumRowElement D x)
    (hleast : ∀ z ∈ D.A.erase D.s, GoodMinimumRowElement D z → x ≤ z)
    {a : ℤ} (ha : a ∈ D.A.erase x)
    (hgood : GoodMinimumRowElement D a)
    (hP : productShellValue D x a = D.Q - x ∨
      productShellValue D x a = D.Q + x) :
    a = x + D.s := by
  have hxA : x ∈ D.A := (Finset.mem_erase.mp hx).2
  have haA : a ∈ D.A := (Finset.mem_erase.mp ha).2
  have hax : a ≠ x := (Finset.mem_erase.mp ha).1
  have hnotmin := not_good_minimumRowElement D hs
  have has : a ≠ D.s := by
    intro has
    apply hnotmin
    simpa [has] using hgood
  have haEraseS : a ∈ D.A.erase D.s := Finset.mem_erase.mpr ⟨has, haA⟩
  have hxa : x ≤ a := hleast a haEraseS hgood
  have hxa_lt : x < a := by omega
  have hsx : D.s < x := by
    have hsxle := D.hs_min x hxA
    have hxsne := (Finset.mem_erase.mp hx).1
    omega
  have haU := D.hA.1 a haA
  have hPdvd : a ∣ productShellValue D x a := by
    dsimp [productShellValue]
    exact dvd_mul_right _ _
  have hdivx : a ∣ D.Q - x ∨ a ∣ D.Q + x := by
    rcases hP with hminus | hplus
    · left
      simpa [hminus] using hPdvd
    · right
      simpa [hplus] using hPdvd
  have hdiff : a ∣ x - D.s ∨ a ∣ x + D.s := by
    rcases hgood with hsm | hsp <;> rcases hdivx with hxm | hxp
    · left
      have htmp := dvd_sub hsm hxm
      convert htmp using 1 <;> ring
    · right
      have htmp := dvd_sub hxp hsm
      convert htmp using 1 <;> ring
    · right
      have htmp := dvd_sub hsp hxm
      convert htmp using 1 <;> ring
    · left
      have htmp := dvd_sub hxp hsp
      convert htmp using 1 <;> ring
  rcases hdiff with hxs | hxp
  · rcases hxs with ⟨k, hk⟩
    have hxspos : 0 < x - D.s := by omega
    have hxsa : x - D.s < a := by omega
    have hkpos : 0 < k := by
      by_contra hk0
      have hk' : k ≤ 0 := by omega
      have hp : a * k ≤ 0 := mul_nonpos_of_nonneg_of_nonpos haU.1.le hk'
      nlinarith [hk]
    have hka : a ≤ a * k := by
      have hk1 : 1 ≤ k := by omega
      have hh := mul_le_mul_of_nonneg_left hk1 haU.1.le
      simpa using hh
    nlinarith [hk]
  · rcases hxp with ⟨k, hk⟩
    have hxsp : 0 < x + D.s := by omega
    have hxspa : x + D.s < 2 * a := by omega
    have hkpos : 0 < k := by
      by_contra hk0
      have hk' : k ≤ 0 := by omega
      have hp : a * k ≤ 0 := mul_nonpos_of_nonneg_of_nonpos haU.1.le hk'
      nlinarith [hk]
    have hk_le : k ≤ 1 := by
      by_contra hknot
      have hk2 : 2 ≤ k := by omega
      have hka : 2 * a ≤ a * k := by
        have hh := mul_le_mul_of_nonneg_left hk2 haU.1.le
        nlinarith [hh]
      nlinarith [hk]
    have hkone : k = 1 := by omega
    rw [hkone] at hk
    nlinarith [hk]

/-- Every other selected representative contributes at least the first
nontrivial product shell to the least good row. -/
theorem productShellValue_ge_Q_sub_least_good
    (D : MinimumRowSlackData) (hs : 1 < D.s)
    {x : ℤ} (hx : x ∈ D.A.erase D.s)
    (hxgood : GoodMinimumRowElement D x)
    (hleast : ∀ z ∈ D.A.erase D.s, GoodMinimumRowElement D z → x ≤ z) :
    ∀ a ∈ D.A.erase x, D.Q - x ≤ productShellValue D x a := by
  intro a ha
  have hxA : x ∈ D.A := (Finset.mem_erase.mp hx).2
  have haA : a ∈ D.A := (Finset.mem_erase.mp ha).2
  have hax : a ≠ x := (Finset.mem_erase.mp ha).1
  have hdist := minimumRowDistance_bounds_of_mem D hxA haA
  have haU := D.hA.1 a haA
  have hxU := D.hA.1 x hxA
  have hPpos : 0 < productShellValue D x a := by
    dsimp [productShellValue, productShellDistance]
    exact mul_pos haU.1 (by omega)
  have hbook := productShellBookkeeping D
  have hshell := hbook.1 x hxA a haA hax.symm
  rcases hshell with hP | ⟨j, hj, hP⟩
  · have hdiv : a ∣ x := hbook.2.2.2.1 x hxA a haA hax.symm hP
    have hba : a ≤ x := by
      have hmul := mul_le_mul_of_nonneg_left hdist.1 haU.1.le
      dsimp [productShellValue, productShellDistance] at hP ⊢
      nlinarith
    have hblt : a < x := by omega
    exact False.elim (no_selected_proper_divisor_of_least_good D hs hx hxgood hleast
      haA hdiv hblt)
  · have hQpos : 0 < D.Q := by omega
    rcases hP with hminus | hplus
    · have hqj : D.Q ≤ j * D.Q := by
        simpa using mul_le_mul_of_nonneg_right hj (show 0 ≤ D.Q by omega)
      nlinarith [hminus, hqj]
    · have hqj : D.Q ≤ j * D.Q := by
        simpa using mul_le_mul_of_nonneg_right hj (show 0 ≤ D.Q by omega)
      nlinarith [hplus, hqj, hxU.1]

/-- Apart from the exceptional good representative, every good row lies in
at least the second shell. -/
theorem productShellValue_ge_twoQ_sub_for_good
    (D : MinimumRowSlackData) (hs : 1 < D.s)
    {x : ℤ} (hx : x ∈ D.A.erase D.s)
    (hxgood : GoodMinimumRowElement D x)
    (hleast : ∀ z ∈ D.A.erase D.s, GoodMinimumRowElement D z → x ≤ z)
    {a : ℤ} (ha : a ∈ D.A.erase x)
    (hgood : GoodMinimumRowElement D a)
    (hnotexc : a ≠ x + D.s) :
    2 * D.Q - x ≤ productShellValue D x a := by
  have hxA : x ∈ D.A := (Finset.mem_erase.mp hx).2
  have haA : a ∈ D.A := (Finset.mem_erase.mp ha).2
  have hax : a ≠ x := (Finset.mem_erase.mp ha).1
  have hdist := minimumRowDistance_bounds_of_mem D hxA haA
  have haU := D.hA.1 a haA
  have hxU := D.hA.1 x hxA
  have hbook := productShellBookkeeping D
  have hshell := hbook.1 x hxA a haA hax.symm
  rcases hshell with hP | ⟨j, hj, hP⟩
  · have hdiv : a ∣ x := hbook.2.2.2.1 x hxA a haA hax.symm hP
    have hba : a ≤ x := by
      have hmul := mul_le_mul_of_nonneg_left hdist.1 haU.1.le
      dsimp [productShellValue, productShellDistance] at hP ⊢
      nlinarith
    have hblt : a < x := by omega
    exact False.elim (no_selected_proper_divisor_of_least_good D hs hx hxgood hleast
      haA hdiv hblt)
  · have hj2 : 2 ≤ j := by
      by_contra hj2
      have hj1 : j = 1 := by omega
      subst j
      have hfirst : productShellValue D x a = D.Q - x ∨
          productShellValue D x a = D.Q + x := by
        rcases hP with hminus | hplus
        · exact Or.inl (by simpa using hminus)
        · exact Or.inr (by simpa using hplus)
      have heq := firstShell_good_eq_add_minimum D hs hx hxgood hleast ha hgood hfirst
      exact hnotexc heq
    have hq2 : 2 * D.Q ≤ j * D.Q := by
      have hh := mul_le_mul_of_nonneg_right hj2 (show 0 ≤ D.Q by omega)
      simpa using hh
    rcases hP with hminus | hplus
    · nlinarith [hminus, hq2]
    · nlinarith [hplus, hq2, hxU.1]

/-- The least good row has a reciprocal-sum bound separating bad elements,
the possible exceptional good element, and the remaining good elements. -/
theorem leastGood_reciprocal_upper
    (D : MinimumRowSlackData) (hs : 1 < D.s)
    {x : ℤ} (hx : x ∈ D.A.erase D.s)
    (hxgood : GoodMinimumRowElement D x)
    (hleast : ∀ z ∈ D.A.erase D.s, GoodMinimumRowElement D z → x ≤ z) :
    let R := D.A.erase x
    let BadR := R.filter (BadMinimumRowElement D)
    let GoodR := R.filter (GoodMinimumRowElement D)
    let Exc := GoodR.filter (fun a => a = x + D.s)
    let Far := GoodR.filter (fun a => a ≠ x + D.s)
    (∑ a ∈ R, (1 : ℝ) / (productShellDistance D x a : ℝ)) ≤
      (∑ a ∈ BadR, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) +
        (∑ a ∈ Exc, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) +
          (∑ a ∈ Far, (a : ℝ)) / ((2 * D.Q - x : ℤ) : ℝ) := by
  classical
  let R : Finset ℤ := D.A.erase x
  let BadR : Finset ℤ := R.filter (BadMinimumRowElement D)
  let GoodR : Finset ℤ := R.filter (GoodMinimumRowElement D)
  let Exc : Finset ℤ := GoodR.filter (fun a => a = x + D.s)
  let Far : Finset ℤ := GoodR.filter (fun a => a ≠ x + D.s)
  change (∑ a ∈ R, (1 : ℝ) / (productShellDistance D x a : ℝ)) ≤
      (∑ a ∈ BadR, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) +
        (∑ a ∈ Exc, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) +
          (∑ a ∈ Far, (a : ℝ)) / ((2 * D.Q - x : ℤ) : ℝ)
  have hxA : x ∈ D.A := (Finset.mem_erase.mp hx).2
  have hxpos := D.hA.1 x hxA |>.1
  have hQmx : 0 < D.Q - x := by
    have hh := D.hA_upper x hxA
    omega
  have h2Qmx : 0 < 2 * D.Q - x := by
    have hQ0 := D.hQ
    omega
  have hRsub : R ⊆ D.A.erase x := by
    intro a ha
    exact ha
  have hBadsub : BadR ⊆ D.A.erase x :=
    (Finset.filter_subset _ _).trans hRsub
  have hGoodsub : GoodR ⊆ D.A.erase x :=
    (Finset.filter_subset _ _).trans hRsub
  have hExcsub : Exc ⊆ D.A.erase x :=
    (Finset.filter_subset _ _).trans hGoodsub
  have hFarsub : Far ⊆ D.A.erase x :=
    (Finset.filter_subset _ _).trans hGoodsub
  have hsum_nonneg : ∀ S : Finset ℤ, S ⊆ D.A.erase x →
      0 ≤ ∑ a ∈ S, (a : ℝ) := by
    intro S hS
    exact Finset.sum_nonneg (fun a ha => by
      have ha0 := (D.hA.1 a (Finset.mem_erase.mp (hS ha)).2).1.le
      exact_mod_cast ha0)
  have hQmxR : 0 < ((D.Q - x : ℤ) : ℝ) := by exact_mod_cast hQmx
  have h2QmxR : 0 < ((2 * D.Q - x : ℤ) : ℝ) := by exact_mod_cast h2Qmx
  have hBadrecip :
      (∑ a ∈ BadR, (1 : ℝ) / (productShellDistance D x a : ℝ)) ≤
        (∑ a ∈ BadR, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) := by
    have hsubset := (productShellBookkeeping D).2.2.1
    refine hsubset x hxA BadR hBadsub _ _ (hsum_nonneg BadR hBadsub)
      hQmxR le_rfl ?_
    intro a ha
    have hP := productShellValue_ge_Q_sub_least_good D hs hx hxgood hleast
      a (Finset.mem_filter.mp ha).1
    exact_mod_cast hP
  have hExcrecip :
      (∑ a ∈ Exc, (1 : ℝ) / (productShellDistance D x a : ℝ)) ≤
        (∑ a ∈ Exc, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) := by
    have hsubset := (productShellBookkeeping D).2.2.1
    refine hsubset x hxA Exc hExcsub _ _ (hsum_nonneg Exc hExcsub)
      hQmxR le_rfl ?_
    intro a ha
    have hP := productShellValue_ge_Q_sub_least_good D hs hx hxgood hleast
      a (Finset.mem_filter.mp (Finset.mem_filter.mp ha).1).1
    exact_mod_cast hP
  have hFarrecip :
      (∑ a ∈ Far, (1 : ℝ) / (productShellDistance D x a : ℝ)) ≤
        (∑ a ∈ Far, (a : ℝ)) / ((2 * D.Q - x : ℤ) : ℝ) := by
    have hsubset := (productShellBookkeeping D).2.2.1
    refine hsubset x hxA Far hFarsub _ _ (hsum_nonneg Far hFarsub)
      h2QmxR le_rfl ?_
    intro a ha
    have hgood : GoodMinimumRowElement D a :=
      (Finset.mem_filter.mp (Finset.mem_filter.mp ha).1).2
    have haR := (Finset.mem_filter.mp (Finset.mem_filter.mp ha).1).1
    have hP := productShellValue_ge_twoQ_sub_for_good D hs hx hxgood hleast
      haR hgood (Finset.mem_filter.mp ha).2
    exact_mod_cast hP
  have hsum_badgood :
      (∑ a ∈ R, (1 : ℝ) / (productShellDistance D x a : ℝ)) =
        (∑ a ∈ BadR, (1 : ℝ) / (productShellDistance D x a : ℝ)) +
          ∑ a ∈ GoodR, (1 : ℝ) / (productShellDistance D x a : ℝ) := by
    have hh := (Finset.sum_filter_add_sum_filter_not R
      (fun a : ℤ => BadMinimumRowElement D a)
      (fun a : ℤ => (1 : ℝ) / (productShellDistance D x a : ℝ))).symm
    simpa [BadR, GoodR, BadMinimumRowElement] using hh
  have hsum_good :
      (∑ a ∈ GoodR, (1 : ℝ) / (productShellDistance D x a : ℝ)) =
        (∑ a ∈ Exc, (1 : ℝ) / (productShellDistance D x a : ℝ)) +
          ∑ a ∈ Far, (1 : ℝ) / (productShellDistance D x a : ℝ) := by
    have hh := (Finset.sum_filter_add_sum_filter_not GoodR
      (fun a : ℤ => a = x + D.s)
      (fun a : ℤ => (1 : ℝ) / (productShellDistance D x a : ℝ))).symm
    simpa [Exc, Far] using hh
  rw [hsum_badgood, hsum_good]
  simpa [add_assoc] using add_le_add hBadrecip (add_le_add hExcrecip hFarrecip)

/-- The preceding shell bound can be written using the original bad weight and
an explicit exceptional-set sum. -/
theorem leastGood_reciprocal_upper_expanded
    (D : MinimumRowSlackData) (hs : 1 < D.s)
    {x : ℤ} (hx : x ∈ D.A.erase D.s)
    (hxgood : GoodMinimumRowElement D x)
    (hleast : ∀ z ∈ D.A.erase D.s, GoodMinimumRowElement D z → x ≤ z) :
    (∑ a ∈ D.A.erase x,
      (1 : ℝ) / (productShellDistance D x a : ℝ)) ≤
      ((D.s : ℝ) + (badMinimumRowSum D : ℝ) +
          ∑ a ∈ (D.A.erase x).filter (GoodMinimumRowElement D) |>.filter
            (fun a => a = x + D.s), (a : ℝ)) /
          ((D.Q - x : ℤ) : ℝ) +
        ((D.Q : ℝ) - (D.s : ℝ) - (badMinimumRowSum D : ℝ) - (x : ℝ) -
          ∑ a ∈ (D.A.erase x).filter (GoodMinimumRowElement D) |>.filter
            (fun a => a = x + D.s), (a : ℝ)) /
          ((2 * D.Q - x : ℤ) : ℝ) := by
  classical
  let R : Finset ℤ := D.A.erase x
  let BadR : Finset ℤ := R.filter (BadMinimumRowElement D)
  let GoodR : Finset ℤ := R.filter (GoodMinimumRowElement D)
  let Exc : Finset ℤ := GoodR.filter (fun a => a = x + D.s)
  let Far : Finset ℤ := GoodR.filter (fun a => a ≠ x + D.s)
  have hrec := leastGood_reciprocal_upper D hs hx hxgood hleast
  dsimp [R, BadR, GoodR, Exc, Far] at hrec
  have hxA : x ∈ D.A := (Finset.mem_erase.mp hx).2
  have hnotmin := not_good_minimumRowElement D hs
  have hsum_bad0 :
      badMinimumRowSum D =
        ∑ a ∈ (D.A.erase D.s).filter (BadMinimumRowElement D), a := by
    dsimp [badMinimumRowSum]
    rw [← Finset.sum_filter]
  have hbadset :
      BadR = insert D.s ((D.A.erase D.s).filter (BadMinimumRowElement D)) := by
    ext a
    constructor
    · intro ha
      have ha' := Finset.mem_filter.mp ha
      have haR := Finset.mem_erase.mp ha'.1
      by_cases has : a = D.s
      · exact Finset.mem_insert.mpr (Or.inl has)
      · exact Finset.mem_insert.mpr (Or.inr (Finset.mem_filter.mpr ⟨
          Finset.mem_erase.mpr ⟨has, haR.2⟩, ha'.2⟩))
    · intro ha
      rcases Finset.mem_insert.mp ha with rfl | ha
      · have hsx : D.s ≠ x := by
          exact (Finset.mem_erase.mp hx).1.symm
        have hsR : D.s ∈ R := Finset.mem_erase.mpr ⟨hsx, D.hs_mem⟩
        exact Finset.mem_filter.mpr ⟨hsR, hnotmin⟩
      · have ha0 := Finset.mem_filter.mp ha
        have haR := Finset.mem_erase.mp ha0.1
        have hax : a ≠ x := by
          intro hax
          subst a
          exact (ha0.2 hxgood).elim
        exact Finset.mem_filter.mpr ⟨Finset.mem_erase.mpr ⟨hax, haR.2⟩, ha0.2⟩
  have hsnot : D.s ∉ (D.A.erase D.s).filter (BadMinimumRowElement D) := by
    simp
  have hbad_sumR :
      ∑ a ∈ BadR, (a : ℝ) = (D.s : ℝ) + (badMinimumRowSum D : ℝ) := by
    rw [hbadset, Finset.sum_insert hsnot, hsum_bad0]
    norm_num
  have hsum_badgood :
      (∑ a ∈ R, (a : ℝ)) =
        (∑ a ∈ BadR, (a : ℝ)) + ∑ a ∈ GoodR, (a : ℝ) := by
    have hh := (Finset.sum_filter_add_sum_filter_not R
      (fun a : ℤ => BadMinimumRowElement D a) (fun a => (a : ℝ))).symm
    simpa [BadR, GoodR, BadMinimumRowElement] using hh
  have hsum_good :
      (∑ a ∈ GoodR, (a : ℝ)) =
        (∑ a ∈ Exc, (a : ℝ)) + ∑ a ∈ Far, (a : ℝ) := by
    have hh := (Finset.sum_filter_add_sum_filter_not GoodR
      (fun a : ℤ => a = x + D.s) (fun a => (a : ℝ))).symm
    simpa [Exc, Far] using hh
  have hsum_partition :
      (∑ a ∈ R, (a : ℝ)) =
        (∑ a ∈ BadR, (a : ℝ)) + ∑ a ∈ Exc, (a : ℝ) +
          ∑ a ∈ Far, (a : ℝ) := by
    rw [hsum_badgood, hsum_good]
    ring
  have hsumR : (∑ a ∈ R, (a : ℝ)) + (x : ℝ) =
      ∑ a ∈ D.A, (a : ℝ) := by
    dsimp [R]
    simpa using D.A.sum_erase_add (fun a : ℤ => (a : ℝ)) hxA
  have hsumA : (∑ a ∈ D.A, (a : ℝ)) ≤ (D.Q : ℝ) := by
    have hsumA' : (∑ a ∈ D.A, (a : ℝ)) =
        ((∑ a ∈ D.A, a : ℤ) : ℝ) := by
      norm_num
    rw [hsumA']
    exact_mod_cast D.hA_sum
  have hFar_le :
      ∑ a ∈ Far, (a : ℝ) ≤
        (D.Q : ℝ) - (D.s : ℝ) - (badMinimumRowSum D : ℝ) - (x : ℝ) -
          ∑ a ∈ Exc, (a : ℝ) := by
    rw [hbad_sumR] at hsum_partition
    linarith [hsum_partition, hsumR, hsumA]
  have h2Qmx : 0 < 2 * D.Q - x := by
    have hQ0 := D.hQ
    have hxpos := D.hA.1 x hxA |>.1
    have hh := D.hA_upper x hxA
    omega
  have h2QmxR : 0 < ((2 * D.Q - x : ℤ) : ℝ) := by exact_mod_cast h2Qmx
  have hfarquot :
      (∑ a ∈ Far, (a : ℝ)) / ((2 * D.Q - x : ℤ) : ℝ) ≤
        ((D.Q : ℝ) - (D.s : ℝ) - (badMinimumRowSum D : ℝ) - (x : ℝ) -
          ∑ a ∈ Exc, (a : ℝ)) / ((2 * D.Q - x : ℤ) : ℝ) :=
    div_le_div_of_nonneg_right hFar_le h2QmxR.le
  have hmain :
      (∑ a ∈ R, (1 : ℝ) / (productShellDistance D x a : ℝ)) ≤
        (∑ a ∈ BadR, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) +
          (∑ a ∈ Exc, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) +
            (∑ a ∈ Far, (a : ℝ)) / ((2 * D.Q - x : ℤ) : ℝ) := by
    simpa [R, BadR, GoodR, Exc, Far] using hrec
  have hmain_expanded := hmain
  rw [hbad_sumR] at hmain_expanded
  have htarget :
      (∑ a ∈ D.A.erase x,
        (1 : ℝ) / (productShellDistance D x a : ℝ)) ≤
      ((D.s : ℝ) + (badMinimumRowSum D : ℝ) +
          ∑ a ∈ Exc, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) +
        ((D.Q : ℝ) - (D.s : ℝ) - (badMinimumRowSum D : ℝ) - (x : ℝ) -
          ∑ a ∈ Exc, (a : ℝ)) / ((2 * D.Q - x : ℤ) : ℝ) := by
    calc
      _ ≤ ((∑ a ∈ BadR, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) +
          (∑ a ∈ Exc, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) +
          (∑ a ∈ Far, (a : ℝ)) / ((2 * D.Q - x : ℤ) : ℝ)) := hmain
      _ ≤ ((∑ a ∈ BadR, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) +
          (∑ a ∈ Exc, (a : ℝ)) / ((D.Q - x : ℤ) : ℝ) +
          ((D.Q : ℝ) - (D.s : ℝ) - (badMinimumRowSum D : ℝ) - (x : ℝ) -
            ∑ a ∈ Exc, (a : ℝ)) / ((2 * D.Q - x : ℤ) : ℝ)) := by
            gcongr
      _ = _ := by rw [hbad_sumR]; ring
  simpa [R, BadR, GoodR, Exc, Far] using htarget
/-- The two-shell rational expression has a uniform positive gap. -/
theorem twoShellGap_algebra (q x s W C : ℝ)
    (hq : 0 < q) (hx : 0 < x) (h3x : 3 * x < q)
    (halpha : (1 : ℝ) / 3 < 1 - (x + s + C) / q)
    (hW0 : 0 ≤ W)
    (hWle : W / q ≤ 1 - (x + s + C) / q) :
    1 - ((s + W + C) / (q - x) +
      (q - s - W - x - C) / (2 * q - x)) >
      (1 : ℝ) / 6 - W / (2 * q) := by
  let X : ℝ := x / q
  let w : ℝ := W / q
  let alpha : ℝ := 1 - (x + s + C) / q
  let Den : ℝ := (1 - X) * (2 - X)
  have hqmx : 0 < q - x := by nlinarith
  have h2qmx : 0 < 2 * q - x := by nlinarith
  have hXpos : 0 < X := by
    dsimp [X]
    positivity
  have hXlt : X < (1 : ℝ) / 3 := by
    dsimp [X]
    apply (div_lt_iff₀ hq).2
    nlinarith
  have hDenpos : 0 < Den := by
    dsimp [Den]
    have h1 : 0 < 1 - X := by linarith
    have h2 : 0 < 2 - X := by linarith
    positivity
  have hDenlt : Den < 2 := by
    dsimp [Den]
    nlinarith [sq_nonneg X]
  have hw0 : 0 ≤ w := by
    dsimp [w]
    exact div_nonneg hW0 hq.le
  have halpha' : (1 : ℝ) / 3 < alpha := by
    simpa [alpha] using halpha
  have hWle' : w ≤ alpha := by
    simpa [w, alpha] using hWle
  have hDinv : (1 : ℝ) / 2 < 1 / Den := by
    apply (div_lt_div_iff₀ (by norm_num) hDenpos).2
    nlinarith [hDenlt]
  have hFalpha : 0 < alpha / 2 - (1 : ℝ) / 6 := by
    nlinarith [halpha']
  have hF : 0 < (alpha - w) / Den - ((1 : ℝ) / 6 - w / 2) := by
    have hnonneg : 0 ≤ (alpha - w) * (1 / Den - 1 / 2) := by
      exact mul_nonneg (by linarith) (by linarith)
    have hidentity :
        (alpha - w) / Den - ((1 : ℝ) / 6 - w / 2) =
          (alpha / 2 - (1 : ℝ) / 6) +
            (alpha - w) * (1 / Den - 1 / 2) := by ring
    rw [hidentity]
    nlinarith
  have hidentity :
      1 - ((s + W + C) / (q - x) +
        (q - s - W - x - C) / (2 * q - x)) =
        (alpha - w) / Den := by
    dsimp [alpha, w, Den, X]
    have h2qmx' : q * 2 - x ≠ 0 := by nlinarith
    field_simp [hq.ne', hqmx.ne', h2qmx.ne', h2qmx'] <;> ring_nf
  calc
    1 - ((s + W + C) / (q - x) +
        (q - s - W - x - C) / (2 * q - x)) =
        (alpha - w) / Den := hidentity
    _ > (1 : ℝ) / 6 - w / 2 := sub_pos.mp hF
    _ = (1 : ℝ) / 6 - W / (2 * q) := by
      dsimp [w]
      field_simp [hq.ne']

/-- The exceptional good set contributes either zero or the single value
`x+s`. -/
theorem exceptionalGoodSum_eq_zero_or_add
    (D : MinimumRowSlackData) {x : ℤ} :
    let E := (D.A.erase x).filter (GoodMinimumRowElement D) |>.filter
      (fun a => a = x + D.s)
    (∑ a ∈ E, (a : ℝ)) = 0 ∨
      (∑ a ∈ E, (a : ℝ)) = (x + D.s : ℝ) := by
  classical
  let E : Finset ℤ := (D.A.erase x).filter (GoodMinimumRowElement D) |>.filter
    (fun a => a = x + D.s)
  change (∑ a ∈ E, (a : ℝ)) = 0 ∨
    (∑ a ∈ E, (a : ℝ)) = (x + D.s : ℝ)
  by_cases hE : E.Nonempty
  · obtain ⟨a, ha⟩ := hE
    have hae : a = x + D.s := (Finset.mem_filter.mp ha).2
    have hEq : E = {x + D.s} := by
      ext z
      constructor
      · intro hz
        exact Finset.mem_singleton.mpr (Finset.mem_filter.mp hz).2
      · intro hz
        have hzs : z = x + D.s := Finset.mem_singleton.mp hz
        subst z
        subst a
        exact ha
    right
    rw [hEq]
    simp
  · left
    have hzero : E = ∅ := Finset.not_nonempty_iff_eq_empty.mp hE
    simp [hzero]

/-- The minimum-row sum budget bounds the bad weight together with the
exceptional element and the distinguished pair `s,x`. -/
theorem minimumRow_bad_exception_weight_bound
    (D : MinimumRowSlackData) (hs : 1 < D.s) {x : ℤ}
    (hx : x ∈ D.A.erase D.s) (hxgood : GoodMinimumRowElement D x) :
    let E := (D.A.erase x).filter (GoodMinimumRowElement D) |>.filter
      (fun a => a = x + D.s)
    (D.s : ℝ) + (badMinimumRowSum D : ℝ) +
        (∑ a ∈ E, (a : ℝ)) + (x : ℝ) ≤ (D.Q : ℝ) := by
  classical
  let E : Finset ℤ := (D.A.erase x).filter (GoodMinimumRowElement D) |>.filter
    (fun a => a = x + D.s)
  change (D.s : ℝ) + (badMinimumRowSum D : ℝ) +
      (∑ a ∈ E, (a : ℝ)) + (x : ℝ) ≤ (D.Q : ℝ)
  let Bad0 : Finset ℤ := (D.A.erase D.s).filter (BadMinimumRowElement D)
  let Good0 : Finset ℤ := (D.A.erase D.s).filter (GoodMinimumRowElement D)
  have hnotmin := not_good_minimumRowElement D hs
  have hsum_bad0 :
      badMinimumRowSum D = ∑ a ∈ Bad0, (a : ℤ) := by
    dsimp [badMinimumRowSum, Bad0]
    rw [← Finset.sum_filter]
  have hpart :
      (∑ a ∈ D.A.erase D.s, (a : ℝ)) =
        (∑ a ∈ Bad0, (a : ℝ)) + ∑ a ∈ Good0, (a : ℝ) := by
    have hh := (Finset.sum_filter_add_sum_filter_not (D.A.erase D.s)
      (fun a : ℤ => BadMinimumRowElement D a)
      (fun a : ℤ => (a : ℝ))).symm
    simpa [Bad0, Good0, BadMinimumRowElement] using hh
  have hEsub : E ⊆ Good0 := by
    intro a ha
    have haE := Finset.mem_filter.mp ha
    have haG := Finset.mem_filter.mp haE.1
    have haR := Finset.mem_erase.mp haG.1
    have has : a ≠ D.s := by
      intro has
      subst a
      exact hnotmin haG.2
    exact Finset.mem_filter.mpr ⟨Finset.mem_erase.mpr ⟨has, haR.2⟩, haG.2⟩
  have hxGood0 : x ∈ Good0 := by
    exact Finset.mem_filter.mpr ⟨hx, hxgood⟩
  have hxnotE : x ∉ E := by
    intro hxe
    have hxr := (Finset.mem_filter.mp (Finset.mem_filter.mp hxe).1).1
    exact (Finset.mem_erase.mp hxr).1 rfl
  have hinsert : insert x E ⊆ Good0 := by
    intro a ha
    rcases Finset.mem_insert.mp ha with rfl | ha
    · exact hxGood0
    · exact hEsub ha
  have hnonneg : ∀ a ∈ Good0, 0 ≤ (a : ℝ) := by
    intro a ha
    exact_mod_cast (D.hA.1 a (Finset.mem_erase.mp
      (Finset.mem_filter.mp ha).1).2).1.le
  have hsum_insert :
      (∑ a ∈ insert x E, (a : ℝ)) = (x : ℝ) + ∑ a ∈ E, (a : ℝ) := by
    rw [Finset.sum_insert hxnotE]
  have hsum_le :
      (∑ a ∈ insert x E, (a : ℝ)) ≤ ∑ a ∈ Good0, (a : ℝ) := by
    exact Finset.sum_le_sum_of_subset_of_nonneg hinsert
      (fun a ha hnot => hnonneg a ha)
  have hsum_erase :
      (∑ a ∈ D.A.erase D.s, (a : ℝ)) + (D.s : ℝ) =
        ∑ a ∈ D.A, (a : ℝ) := by
    simpa using D.A.sum_erase_add (fun a : ℤ => (a : ℝ)) D.hs_mem
  have hsumA : (∑ a ∈ D.A, (a : ℝ)) ≤ (D.Q : ℝ) := by
    have hsumA' : (∑ a ∈ D.A, (a : ℝ)) =
        ((∑ a ∈ D.A, a : ℤ) : ℝ) := by norm_num
    rw [hsumA']
    exact_mod_cast D.hA_sum
  have hconstraintR :
      (D.s : ℝ) + (∑ a ∈ Bad0, (a : ℝ)) +
          (∑ a ∈ E, (a : ℝ)) + (x : ℝ) ≤ (D.Q : ℝ) := by
    linarith [hpart, hsumA, hsum_erase, hsum_le, hsum_insert]
  have hsum_bad0R :
      (∑ a ∈ Bad0, (a : ℝ)) = (badMinimumRowSum D : ℝ) := by
    calc
      (∑ a ∈ Bad0, (a : ℝ)) =
          ((∑ a ∈ Bad0, a : ℤ) : ℝ) := by norm_num
      _ = (badMinimumRowSum D : ℝ) := by rw [hsum_bad0]
  rw [← hsum_bad0R]
  exact hconstraintR

/-- The least good row has a quantitative reciprocal deficit. -/
theorem leastGood_reciprocal_gap
    (D : MinimumRowSlackData) (hs : 1 < D.s)
    (hpass : RowPasses D.Q D.A D.s)
    {x : ℤ} (hx : x ∈ D.A.erase D.s)
    (hxgood : GoodMinimumRowElement D x)
    (hleast : ∀ z ∈ D.A.erase D.s, GoodMinimumRowElement D z → x ≤ z) :
    1 - (∑ a ∈ D.A.erase x,
      (1 : ℝ) / (productShellDistance D x a : ℝ)) >
      (1 : ℝ) / 6 - (badMinimumRowSum D : ℝ) /
        (2 * (D.Q : ℝ)) := by
  classical
  let E : Finset ℤ := (D.A.erase x).filter (GoodMinimumRowElement D) |>.filter
    (fun a => a = x + D.s)
  let C : ℝ := ∑ a ∈ E, (a : ℝ)
  have hupper := leastGood_reciprocal_upper_expanded D hs hx hxgood hleast
  have hupper' :
      (∑ a ∈ D.A.erase x,
        (1 : ℝ) / (productShellDistance D x a : ℝ)) ≤
        ((D.s : ℝ) + (badMinimumRowSum D : ℝ) + C) /
            ((D.Q - x : ℤ) : ℝ) +
          ((D.Q : ℝ) - (D.s : ℝ) - (badMinimumRowSum D : ℝ) -
              (x : ℝ) - C) /
            ((2 * D.Q - x : ℤ) : ℝ) := by
    simpa [E, C] using hupper
  have hCcase : C = 0 ∨ C = (x + D.s : ℝ) := by
    have hh := exceptionalGoodSum_eq_zero_or_add D (x := x)
    simpa [E, C] using hh
  have hxA : x ∈ D.A := (Finset.mem_erase.mp hx).2
  have hq : 0 < (D.Q : ℝ) := by
    have hQ0 := D.hQ
    exact_mod_cast (show 0 < D.Q by omega)
  have hxR : 0 < (x : ℝ) := by
    exact_mod_cast (D.hA.1 x hxA).1
  have h3x : 3 * (x : ℝ) < (D.Q : ℝ) := by
    exact_mod_cast D.hA_upper x hxA
  have hW0 : 0 ≤ (badMinimumRowSum D : ℝ) := by
    have hWint : 0 ≤ badMinimumRowSum D := by
      dsimp [badMinimumRowSum]
      apply Finset.sum_nonneg
      intro a ha
      by_cases hbad : BadMinimumRowElement D a
      · simp [hbad]
        exact (D.hA.1 a (Finset.mem_erase.mp ha).2).1.le
      · simp [hbad]
    exact_mod_cast hWint
  have hbudget :
      (D.s : ℝ) + (badMinimumRowSum D : ℝ) + C + (x : ℝ) ≤ (D.Q : ℝ) := by
    have hh := minimumRow_bad_exception_weight_bound D hs hx hxgood
    simpa [E, C] using hh
  have hWle :
      (badMinimumRowSum D : ℝ) / (D.Q : ℝ) ≤
        1 - ((x : ℝ) + (D.s : ℝ) + C) / (D.Q : ℝ) := by
    apply (div_le_iff₀ hq).2
    have hident :
        (1 - ((x : ℝ) + (D.s : ℝ) + C) / (D.Q : ℝ)) * (D.Q : ℝ) =
          (D.Q : ℝ) - (x : ℝ) - (D.s : ℝ) - C := by
      field_simp [hq.ne']
      ring
    rw [hident]
    linarith [hbudget]
  have halpha : (1 : ℝ) / 3 <
      1 - ((x : ℝ) + (D.s : ℝ) + C) / (D.Q : ℝ) := by
    have hsx : (D.s : ℝ) < (x : ℝ) := by
      have hsxle := D.hs_min x hxA
      have hxsne := (Finset.mem_erase.mp hx).1
      exact_mod_cast (show D.s < x by omega)
    rcases hCcase with hC0 | hCadd
    · rw [hC0]
      have hnum : 3 * ((x : ℝ) + (D.s : ℝ)) < 2 * (D.Q : ℝ) := by
        nlinarith [h3x]
      have hfrac : ((x : ℝ) + (D.s : ℝ)) / (D.Q : ℝ) <
          (2 : ℝ) / 3 := by
        apply (div_lt_iff₀ hq).2
        nlinarith [hnum]
      have htarget : (1 : ℝ) / 3 <
          1 - ((x : ℝ) + (D.s : ℝ)) / (D.Q : ℝ) := by
        linarith [hfrac]
      simpa using htarget
    · have hxspos : 0 < (x : ℝ) + (D.s : ℝ) := by positivity
      have hEnonempty : E.Nonempty := by
        by_contra hE
        have hE0 : E = ∅ := Finset.not_nonempty_iff_eq_empty.mp hE
        have hC0 : C = 0 := by simp [C, hE0]
        nlinarith [hCadd, hC0, hxspos]
      obtain ⟨a, ha⟩ := hEnonempty
      have haeq : a = x + D.s := (Finset.mem_filter.mp ha).2
      have haR := (Finset.mem_filter.mp (Finset.mem_filter.mp ha).1).1
      have haA := (Finset.mem_erase.mp haR).2
      have hnum : 3 * ((x : ℝ) + (D.s : ℝ)) < (D.Q : ℝ) := by
        have hh := D.hA_upper a haA
        rw [haeq] at hh
        exact_mod_cast hh
      have hnum' : 3 * ((x : ℝ) + (D.s : ℝ) + C) <
          2 * (D.Q : ℝ) := by
        rw [hCadd]
        nlinarith [hnum]
      have hfrac : ((x : ℝ) + (D.s : ℝ) + C) / (D.Q : ℝ) <
          (2 : ℝ) / 3 := by
        apply (div_lt_iff₀ hq).2
        nlinarith [hnum']
      linarith
  have hgap := twoShellGap_algebra (D.Q : ℝ) (x : ℝ) (D.s : ℝ)
    (badMinimumRowSum D : ℝ) C hq hxR h3x halpha hW0 hWle
  have hupper'' :
      (∑ a ∈ D.A.erase x,
        (1 : ℝ) / (productShellDistance D x a : ℝ)) ≤
        ((D.s : ℝ) + (badMinimumRowSum D : ℝ) + C) /
            ((D.Q : ℝ) - (x : ℝ)) +
          ((D.Q : ℝ) - (D.s : ℝ) - (badMinimumRowSum D : ℝ) -
              (x : ℝ) - C) /
            (2 * (D.Q : ℝ) - (x : ℝ)) := by
    convert hupper' using 1 <;> norm_num
  have hle :
      1 - (((D.s : ℝ) + (badMinimumRowSum D : ℝ) + C) /
          ((D.Q : ℝ) - (x : ℝ)) +
        ((D.Q : ℝ) - (D.s : ℝ) - (badMinimumRowSum D : ℝ) -
            (x : ℝ) - C) / (2 * (D.Q : ℝ) - (x : ℝ))) ≤
        1 - (∑ a ∈ D.A.erase x,
          (1 : ℝ) / (productShellDistance D x a : ℝ)) := by
    linarith [hupper'']
  exact lt_of_lt_of_le hgap hle

/-- If every row passes, the denominator is below the analytic threshold
`96 n / 7`, where `n = |A|-1`. -/
theorem q_lt_96_mul_minimumRowN_div_7
    (D : MinimumRowSlackData) (hs : 1 < D.s)
    (hpass : ∀ a ∈ D.A, RowPasses D.Q D.A a) :
    (D.Q : ℝ) < 96 * (minimumRowN D : ℝ) / 7 := by
  classical
  have hpasss := hpass D.s D.hs_mem
  obtain ⟨x, hx, hxgood, hleast⟩ :=
    exists_least_good_minimumRowElement D hs hpasss
  have hxA : x ∈ D.A := (Finset.mem_erase.mp hx).2
  have hpassx := hpass x hxA
  have hQ : 2 ≤ D.Q := by
    have hQ0 := D.hQ
    omega
  have hQpos : 0 < (D.Q : ℝ) := by
    exact_mod_cast (show 0 < D.Q by omega)
  have hRnonempty : (D.A.erase x).Nonempty := by
    by_contra hn
    have he : D.A.erase x = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
    have hpass' : (1 : ℝ) ≤ 0 := by
      change 1 ≤ inverseSineRowMass D.Q D.A x at hpassx
      simpa [inverseSineRowMass, he] using hpassx
    linarith
  have hdist : ∀ a ∈ D.A.erase x,
      1 ≤ cyclicDistance D.Q (x * inverseMod D.Q a) ∧
        2 * cyclicDistance D.Q (x * inverseMod D.Q a) ≤ D.Q := by
    intro a ha
    exact minimumRowDistance_bounds_of_mem D hxA (Finset.mem_erase.mp ha).2
  have hupper : ∀ a ∈ D.A.erase x,
      inverseSineKernel D.Q (cyclicDistance D.Q (x * inverseMod D.Q a)) <
        1 / (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ) +
          inverseSineEnvelopeConstant *
            (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ) /
              (D.Q : ℝ) ^ 2 := by
    intro a ha
    exact inverseSineKernel_upper D.Q
      (cyclicDistance D.Q (x * inverseMod D.Q a)) hQ
      (hdist a ha |>.1) (hdist a ha |>.2)
  have hsumupper := Finset.sum_lt_sum_of_nonempty hRnonempty hupper
  have hsumd :
      (∑ a ∈ D.A.erase x,
        (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ)) ≤
        (minimumRowN D : ℝ) * (D.Q : ℝ) / 2 := by
    have hpoint : ∀ a ∈ D.A.erase x,
        (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ) ≤
          (D.Q : ℝ) / 2 := by
      intro a ha
      have hh := (hdist a ha).2
      have hhR : 2 * (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ) ≤
          (D.Q : ℝ) := by exact_mod_cast hh
      nlinarith
    have hh := Finset.sum_le_sum hpoint
    rw [Finset.sum_const, nsmul_eq_mul] at hh
    have hcard : ((D.A.erase x).card : ℝ) = (minimumRowN D : ℝ) := by
      have hc : (D.A.erase x).card = D.A.card - 1 :=
        Finset.card_erase_of_mem (show x ∈ D.A from hxA)
      dsimp [minimumRowN]
      rw [hc]
    rw [hcard] at hh
    nlinarith
  have hsum_expand :
      (∑ a ∈ D.A.erase x,
        (1 / (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ) +
          inverseSineEnvelopeConstant *
            (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ) /
              (D.Q : ℝ) ^ 2)) =
        (∑ a ∈ D.A.erase x,
          1 / (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ)) +
          inverseSineEnvelopeConstant / (D.Q : ℝ) ^ 2 *
            (∑ a ∈ D.A.erase x,
              (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ)) := by
    rw [Finset.sum_add_distrib]
    congr 1
    have hfactor :
        (∑ a ∈ D.A.erase x,
          inverseSineEnvelopeConstant *
            (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ) /
              (D.Q : ℝ) ^ 2) =
          ∑ a ∈ D.A.erase x,
            (inverseSineEnvelopeConstant / (D.Q : ℝ) ^ 2) *
              (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ) := by
      apply Finset.sum_congr rfl
      intro a ha
      ring
    rw [hfactor, ← Finset.mul_sum]
  have hmass : (1 : ℝ) ≤
      ∑ a ∈ D.A.erase x,
        inverseSineKernel D.Q (cyclicDistance D.Q (x * inverseMod D.Q a)) := by
    change 1 ≤ inverseSineRowMass D.Q D.A x at hpassx
    exact hpassx
  have hrem :
      (∑ a ∈ D.A.erase x,
        inverseSineKernel D.Q (cyclicDistance D.Q (x * inverseMod D.Q a))) -
        (∑ a ∈ D.A.erase x,
          1 / (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ)) <
        8 * (minimumRowN D : ℝ) / (7 * (D.Q : ℝ)) := by
    have hh := lt_of_le_of_lt hmass hsumupper
    rw [hsum_expand] at hh
    have hC : inverseSineEnvelopeConstant < (16 : ℝ) / 7 := by
      dsimp [inverseSineEnvelopeConstant]
      nlinarith [Real.pi_lt_d4]
    have hrem' :
        inverseSineEnvelopeConstant / (D.Q : ℝ) ^ 2 *
            (∑ a ∈ D.A.erase x,
              (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ)) ≤
          8 * (minimumRowN D : ℝ) / (7 * (D.Q : ℝ)) := by
      have hcoef : inverseSineEnvelopeConstant / (D.Q : ℝ) ^ 2 *
            (∑ a ∈ D.A.erase x,
              (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ)) ≤
          (16 / 7 : ℝ) / (D.Q : ℝ) ^ 2 *
            ((minimumRowN D : ℝ) * (D.Q : ℝ) / 2) := by
        have hcoef_le : inverseSineEnvelopeConstant / (D.Q : ℝ) ^ 2 ≤
            (16 / 7 : ℝ) / (D.Q : ℝ) ^ 2 := by
          gcongr
        have hsum_nonneg : 0 ≤
            ∑ a ∈ D.A.erase x,
              (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ) := by
          exact Finset.sum_nonneg (fun a ha => by
            have hh := (hdist a ha).1
            exact_mod_cast (show 0 ≤ cyclicDistance D.Q
              (x * inverseMod D.Q a) by omega))
        have hcoef_nonneg : 0 ≤ (16 / 7 : ℝ) / (D.Q : ℝ) ^ 2 := by positivity
        calc
          _ ≤ (16 / 7 : ℝ) / (D.Q : ℝ) ^ 2 *
                (∑ a ∈ D.A.erase x,
                  (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ)) :=
            mul_le_mul_of_nonneg_right hcoef_le hsum_nonneg
          _ ≤ (16 / 7 : ℝ) / (D.Q : ℝ) ^ 2 *
                ((minimumRowN D : ℝ) * (D.Q : ℝ) / 2) :=
            mul_le_mul_of_nonneg_left hsumd hcoef_nonneg
      calc
        _ ≤ (16 / 7 : ℝ) / (D.Q : ℝ) ^ 2 *
              ((minimumRowN D : ℝ) * (D.Q : ℝ) / 2) := hcoef
        _ = 8 * (minimumRowN D : ℝ) / (7 * (D.Q : ℝ)) := by
          field_simp [hQpos.ne']
          ring
    linarith
  have hgap := leastGood_reciprocal_gap D hs hpasss hx hxgood hleast
  have hW := (passingMinimumRowSlack D hpasss).2
  have hWcomp :
      (badMinimumRowSum D : ℝ) / (2 * (D.Q : ℝ)) <
        8 * (minimumRowN D : ℝ) / (7 * (D.Q : ℝ)) := by
    have hden : 0 < 2 * (D.Q : ℝ) := by positivity
    have hnum : (badMinimumRowSum D : ℝ) <
        16 * (minimumRowN D : ℝ) / 7 := hW
    have hh := div_lt_div_of_pos_right hnum hden
    convert hh using 1 <;> field_simp [hQpos.ne'] <;> ring
  by_contra hnot
  have hQbound : 96 * (minimumRowN D : ℝ) / 7 ≤ (D.Q : ℝ) :=
    le_of_not_gt hnot
  have hsmall :
      16 * (minimumRowN D : ℝ) / (7 * (D.Q : ℝ)) ≤ (1 : ℝ) / 6 := by
    apply (div_le_iff₀ (by positivity : 0 < 7 * (D.Q : ℝ))).2
    nlinarith [hQbound]
  have hgap' :
      1 - (∑ a ∈ D.A.erase x,
        1 / (productShellDistance D x a : ℝ)) >
        (1 : ℝ) / 6 - 8 * (minimumRowN D : ℝ) / (7 * (D.Q : ℝ)) := by
    have hgap0 := hgap
    have hdistEq :
        (∑ a ∈ D.A.erase x,
          1 / (productShellDistance D x a : ℝ)) =
          ∑ a ∈ D.A.erase x,
            1 / (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ) := by
      rfl
    rw [hdistEq] at hgap0
    linarith [hWcomp]
  have hgap'' :
      1 - (∑ a ∈ D.A.erase x,
        1 / (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ)) >
        (1 : ℝ) / 6 - 8 * (minimumRowN D : ℝ) / (7 * (D.Q : ℝ)) := by
    simpa [productShellDistance] using hgap'
  have hHlt :
      (∑ a ∈ D.A.erase x,
        1 / (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ)) <
        (5 : ℝ) / 6 + 8 * (minimumRowN D : ℝ) /
          (7 * (D.Q : ℝ)) := by
    linarith [hgap'']
  have hMminusH :
      (∑ a ∈ D.A.erase x,
        inverseSineKernel D.Q (cyclicDistance D.Q (x * inverseMod D.Q a))) -
        (∑ a ∈ D.A.erase x,
          1 / (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ)) <
        8 * (minimumRowN D : ℝ) / (7 * (D.Q : ℝ)) := hrem
  have hMbound :
      ∑ a ∈ D.A.erase x,
        inverseSineKernel D.Q (cyclicDistance D.Q (x * inverseMod D.Q a)) <
          (5 : ℝ) / 6 + 16 * (minimumRowN D : ℝ) /
            (7 * (D.Q : ℝ)) := by
    have hMltH :
        (∑ a ∈ D.A.erase x,
          inverseSineKernel D.Q (cyclicDistance D.Q (x * inverseMod D.Q a))) <
          (∑ a ∈ D.A.erase x,
            1 / (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ)) +
            8 * (minimumRowN D : ℝ) / (7 * (D.Q : ℝ)) := by
      linarith [hMminusH]
    calc
      _ < (∑ a ∈ D.A.erase x,
          1 / (cyclicDistance D.Q (x * inverseMod D.Q a) : ℝ)) +
            8 * (minimumRowN D : ℝ) / (7 * (D.Q : ℝ)) := hMltH
      _ < ((5 : ℝ) / 6 + 8 * (minimumRowN D : ℝ) /
          (7 * (D.Q : ℝ))) + 8 * (minimumRowN D : ℝ) /
            (7 * (D.Q : ℝ)) := by
        have hh := add_lt_add_left hHlt
          (8 * (minimumRowN D : ℝ) / (7 * (D.Q : ℝ)))
        simpa [add_comm] using hh
      _ = (5 : ℝ) / 6 + 16 * (minimumRowN D : ℝ) /
          (7 * (D.Q : ℝ)) := by ring
  have hMlt :
      ∑ a ∈ D.A.erase x,
        inverseSineKernel D.Q (cyclicDistance D.Q (x * inverseMod D.Q a)) < 1 := by
    have hbound : (5 : ℝ) / 6 + 16 * (minimumRowN D : ℝ) /
        (7 * (D.Q : ℝ)) ≤ 1 := by
      linarith [hsmall]
    exact hMbound.trans_le hbound
  exact (not_lt_of_ge hmass) hMlt

/-- The arithmetic progression beginning at two has the stated sum. -/
theorem sum_range_add_two (n : ℕ) :
    (∑ k ∈ Finset.range (n + 1), ((k : ℝ) + 2)) =
      ((n : ℝ) + 1) * ((n : ℝ) + 4) / 2 := by
  induction n with
  | zero => norm_num
  | succ n ih =>
      rw [Finset.sum_range_succ, ih]
      push_cast
      ring

/-- A finite set of distinct integers at least two has the triangular sum
lower bound. -/
theorem sum_lower_bound_from_two (S : Finset ℤ)
    (h2 : ∀ a ∈ S, 2 ≤ a) :
    ((S.card : ℝ) * ((S.card : ℝ) + 3)) / 2 ≤
      ∑ a ∈ S, (a : ℝ) := by
  classical
  by_cases hn : S.Nonempty
  · have hncard : S.card ≠ 0 := Finset.card_ne_zero.mpr hn
    obtain ⟨n, hcard⟩ := Nat.exists_eq_succ_of_ne_zero hncard
    let e : Fin (n + 1) ↪o ℤ := S.orderEmbOfFin hcard
    have he_mem (i : Fin (n + 1)) : e i ∈ S := by
      dsimp [e]
      exact Finset.orderEmbOfFin_mem S hcard i
    have he_lower : ∀ i : Fin (n + 1), (i.val : ℝ) + 2 ≤ (e i : ℝ) := by
      intro i
      induction i using Fin.induction with
      | zero =>
          exact_mod_cast h2 (e 0) (he_mem 0)
      | @succ i hi =>
          have hstepZ : e i.castSucc + 1 ≤ e i.succ := by
            have hlt := e.strictMono (Fin.castSucc_lt_succ (i := i))
            omega
          have hstep : (e i.castSucc : ℝ) + 1 ≤ (e i.succ : ℝ) := by
            exact_mod_cast hstepZ
          have hi' : (i.val : ℝ) + 2 ≤ (e i.castSucc : ℝ) := by
            simpa using hi
          have hnext : (i.val : ℝ) + 3 ≤ (e i.succ : ℝ) := by
            nlinarith [hi', hstep]
          norm_num [Fin.val_succ] at ⊢
          nlinarith [hnext]
    have hsum_image : (∑ a ∈ S, (a : ℝ)) =
        ∑ i : Fin (n + 1), (e i : ℝ) := by
      calc
        (∑ a ∈ S, (a : ℝ)) =
            ∑ a ∈ Finset.image e Finset.univ, (a : ℝ) := by
          rw [Finset.image_orderEmbOfFin_univ S hcard]
        _ = ∑ i ∈ (Finset.univ : Finset (Fin (n + 1))), (e i : ℝ) := by
          rw [Finset.sum_image]
          intro a ha b hb hab
          exact e.injective hab
        _ = ∑ i : Fin (n + 1), (e i : ℝ) := by simp
    have hsum_lower : (∑ i : Fin (n + 1), ((i.val : ℝ) + 2)) ≤
        ∑ i : Fin (n + 1), (e i : ℝ) := by
      exact Finset.sum_le_sum (fun i hi => he_lower i)
    rw [← hsum_image] at hsum_lower
    have hsum_index :
        (∑ i : Fin (n + 1), ((i.val : ℝ) + 2)) =
          ∑ k ∈ Finset.range (n + 1), ((k : ℝ) + 2) := by
      convert (Fin.sum_univ_eq_sum_range (fun k : ℕ => (k : ℝ) + 2) (n + 1)) using 1 <;> simp
    have hsum_arith := sum_range_add_two n
    rw [hsum_index, hsum_arith] at hsum_lower
    have hcardR : (S.card : ℝ) = (n + 1 : ℕ) := by
      exact_mod_cast hcard
    rw [hcardR]
    convert hsum_lower using 1 <;> push_cast <;> ring
  · have hzero : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
    simp [hzero]

/-- All rows passing forces the finite verifier denominator range. -/
theorem q_le_301_of_all_rows_passing
    (D : MinimumRowSlackData) (hs : 1 < D.s)
    (hpass : ∀ a ∈ D.A, RowPasses D.Q D.A a) :
    D.Q ≤ 301 := by
  have hqanalytic := q_lt_96_mul_minimumRowN_div_7 D hs hpass
  have h2 : ∀ a ∈ D.A, 2 ≤ a := by
    intro a ha
    have hsa := D.hs_min a ha
    have hs2 : 2 ≤ D.s := by omega
    omega
  have hsumlower := sum_lower_bound_from_two D.A h2
  have hsumupper : (∑ a ∈ D.A, (a : ℝ)) ≤ (D.Q : ℝ) := by
    have hsum_cast : (∑ a ∈ D.A, (a : ℝ)) =
        ((∑ a ∈ D.A, a : ℤ) : ℝ) := by norm_num
    rw [hsum_cast]
    exact_mod_cast D.hA_sum
  have hcard_real : (minimumRowN D : ℝ) =
      (D.A.card : ℝ) - 1 := by
    dsimp [minimumRowN]
    have hcardpos : 0 < D.A.card :=
      Finset.card_pos.mpr ⟨D.s, D.hs_mem⟩
    rw [Nat.cast_sub (by omega : 1 ≤ D.A.card)]
    norm_num
  have hcard_le : D.A.card ≤ 23 := by
    by_contra hnot
    have hcard24 : 24 ≤ (D.A.card : ℝ) := by
      exact_mod_cast (show 24 ≤ D.A.card by omega)
    have hcardN : (D.A.card : ℝ) - 1 = (minimumRowN D : ℝ) := by
      linarith [hcard_real]
    have hpoly : 0 <
        7 * (D.A.card : ℝ) ^ 2 - 171 * (D.A.card : ℝ) + 192 := by
      have hsquare : 0 ≤ ((D.A.card : ℝ) - 24) ^ 2 := sq_nonneg _
      nlinarith [hsquare, hcard24]
    rw [← hcardN] at hqanalytic
    nlinarith [hsumlower, hsumupper, hqanalytic, hpoly]
  have hn_le : (minimumRowN D : ℝ) ≤ 22 := by
    rw [hcard_real]
    have hc : (D.A.card : ℝ) ≤ 23 := by exact_mod_cast hcard_le
    linarith
  have hq_lt : (D.Q : ℝ) < 302 := by
    nlinarith [hqanalytic, hn_le]
  have hq_int : D.Q < 302 := by exact_mod_cast hq_lt
  omega

 theorem not_mem_doomedKnapsackVertices
    (D : MinimumRowSlackData) (P : Finset ℤ) (a : ℤ)
    (hAP : D.A ⊆ P) (ha : a ∈ D.A)
    (hpass : RowPasses D.Q D.A a) :
    a ∉ doomedKnapsackVertices D.Q P := by
  intro hdoom
  have hdoom' : a ∈ P ∧
      exactKnapsackScore D.Q a P < (knapsackScale : WithBot ℤ) := by
    simpa [doomedKnapsackVertices] using hdoom
  exact (not_lt_of_ge (exactKnapsackScore_ge_scale_of_rowPasses D P a hAP ha hpass))
    hdoom'.2

/-- The minimum-row representatives lie in the corresponding verifier pool. -/
theorem minimumRow_subset_knapsackPool (D : MinimumRowSlackData) :
    D.A ⊆ knapsackPool D.Q D.s := by
  intro a ha
  have haU := D.hA.1 a ha
  have haQ : a ≤ D.Q - 1 := by
    have hh := D.hA_upper a ha
    omega
  have hsa := D.hs_min a ha
  simp only [knapsackPool, Finset.mem_filter, Finset.mem_Icc]
  exact ⟨⟨hsa, haQ⟩, D.hA_upper a ha, haU.2⟩

/-- State of the synchronous peeling procedure. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
structure KnapsackPeelingState where
  pool : Finset ℤ
  halted : Bool

/-- One synchronous peeling round, including the prescribed stopping rules. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
noncomputable def knapsackPeelingStep (Q s : ℤ)
    (state : KnapsackPeelingState) : KnapsackPeelingState :=
  if state.halted then state
  else
    let R := doomedKnapsackVertices Q state.pool
    let next := state.pool \ R
    if R = ∅ then
      { pool := state.pool, halted := true }
    else
      { pool := next,
        halted := decide (next = ∅ ∨ s ∈ R) }

/-- The initial pool and the state after `k` synchronous rounds. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
noncomputable def knapsackPeelingInitial (Q s : ℤ) : KnapsackPeelingState :=
  { pool := knapsackPool Q s, halted := false }

-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
noncomputable def knapsackPeelingState (Q s : ℤ) : ℕ → KnapsackPeelingState
  | 0 => knapsackPeelingInitial Q s
  | k + 1 => knapsackPeelingStep Q s (knapsackPeelingState Q s k)

/-- Every synchronous peeling state still contains all representatives of a
passing counterexample. -/
theorem knapsackPeelingState_superset
    (D : MinimumRowSlackData)
    (hpass : ∀ a ∈ D.A, RowPasses D.Q D.A a) :
    ∀ k : ℕ, D.A ⊆ (knapsackPeelingState D.Q D.s k).pool := by
  intro k
  induction k with
  | zero =>
      simpa [knapsackPeelingState, knapsackPeelingInitial] using
        (minimumRow_subset_knapsackPool D)
  | succ k ih =>
      let state := knapsackPeelingState D.Q D.s k
      have hpool : D.A ⊆ state.pool := by
        simpa [state] using ih
      by_cases hhalt : state.halted
      · simpa [knapsackPeelingState, knapsackPeelingStep, state, hhalt] using hpool
      · have hnot : ∀ a ∈ D.A, a ∉ doomedKnapsackVertices D.Q state.pool := by
          intro a ha
          exact not_mem_doomedKnapsackVertices D state.pool a hpool ha (hpass a ha)
        have hnext : D.A ⊆ state.pool \ doomedKnapsackVertices D.Q state.pool := by
          intro a ha
          exact Finset.mem_sdiff.mpr ⟨hpool ha, hnot a ha⟩
        by_cases hempty : doomedKnapsackVertices D.Q state.pool = ∅
        · simpa [knapsackPeelingState, knapsackPeelingStep, state, hhalt, hempty]
            using hpool
        · simpa [knapsackPeelingState, knapsackPeelingStep, state, hhalt, hempty]
            using hnext

/-- The vertices removed when round `k` is computed from its snapshot. -/
-- zpi: def-rounded-knapsack-peeling-for-s-greater-than-one
noncomputable def knapsackRemovedAt (Q s : ℤ) (k : ℕ) : Finset ℤ :=
  let state := knapsackPeelingState Q s k
  if state.halted then ∅ else doomedKnapsackVertices Q state.pool

/-- No representative of a passing counterexample is removed at any round. -/
theorem not_mem_knapsackRemovedAt
    (D : MinimumRowSlackData)
    (hpass : ∀ a ∈ D.A, RowPasses D.Q D.A a) :
    ∀ k : ℕ, ∀ a ∈ D.A, a ∉ knapsackRemovedAt D.Q D.s k := by
  intro k a ha
  have hpool := knapsackPeelingState_superset D hpass k
  by_cases hhalt : (knapsackPeelingState D.Q D.s k).halted
  · simp [knapsackRemovedAt, hhalt]
  · simp only [knapsackRemovedAt]
    rw [if_neg hhalt]
    exact not_mem_doomedKnapsackVertices D
      (knapsackPeelingState D.Q D.s k).pool a hpool ha (hpass a ha)

/-- The finite input predicate used by the exact verifier. -/
-- zpi: prop-exact-knapsack-peeling-for-s-greater-than-one
def admissibleKnapsackPair (Q s : ℤ) : Prop :=
  7 ≤ Q ∧ Q ≤ 301 ∧ 2 ≤ s ∧ 3 * s < Q ∧ Int.gcd s Q = 1

/-- All `8,916` candidate pairs, represented as a finite set. -/
-- zpi: prop-exact-knapsack-peeling-for-s-greater-than-one
noncomputable def admissibleKnapsackPairs : Finset (ℤ × ℤ) :=
  (Finset.Icc 7 301).product (Finset.Icc 2 100) |>.filter
    (fun x => admissibleKnapsackPair x.1 x.2)

/-- The first round at which the prescribed minimum is removed, with a total
fallback for inputs outside the verifier domain. -/
-- zpi: prop-exact-knapsack-peeling-for-s-greater-than-one
noncomputable def decisiveKnapsackRound (Q s : ℤ) : ℕ :=
  if h : ∃ k : ℕ, s ∈ knapsackRemovedAt Q s k then
    Nat.find h
  else 0

/-- Number of deletion events through the decisive round for one pair. -/
-- zpi: prop-exact-knapsack-peeling-for-s-greater-than-one
noncomputable def deletionEventsThroughDecisive (Q s : ℤ) : ℕ :=
  ∑ k ∈ Finset.range (decisiveKnapsackRound Q s + 1),
    (knapsackRemovedAt Q s k).card

/-- Aggregate deletion-event count from the verifier. -/
-- zpi: prop-exact-knapsack-peeling-for-s-greater-than-one
noncomputable def aggregateDeletionEvents : ℕ :=
  ∑ x ∈ admissibleKnapsackPairs,
    deletionEventsThroughDecisive x.1 x.2

/-- A computable presentation of the finite pair enumeration. -/
private def admissibleKnapsackPairsComputable : Finset (ℤ × ℤ) :=
  (Finset.range 295 |>.map
      (Nat.castEmbedding.trans (addLeftEmbedding 7))).product
    (Finset.range 99 |>.map
      (Nat.castEmbedding.trans (addLeftEmbedding 2))) |>.filter
        (fun x => 7 ≤ x.1 ∧ x.1 ≤ 301 ∧ 2 ≤ x.2 ∧
          3 * x.2 < x.1 ∧ x.2.gcd x.1 = 1)

private theorem admissibleKnapsackPairs_eq_computable :
    admissibleKnapsackPairs = admissibleKnapsackPairsComputable := by
  ext x
  simp [admissibleKnapsackPairs, admissibleKnapsackPairsComputable,
    admissibleKnapsackPair, Int.Icc_eq_finset_map]

private theorem admissibleKnapsackPairs_card_computable :
    admissibleKnapsackPairs.card = 8916 := by
  rw [admissibleKnapsackPairs_eq_computable]
  native_decide

private abbrev certificateOptMax : Option ℤ → Option ℤ → Option ℤ :=
  KnapsackArray.optMax

private abbrev certificateOptAdd (x : Option ℤ) (v : ℤ) : Option ℤ :=
  KnapsackArray.optAdd x v

private abbrev certificateArrayUpdate (dp : Array (Option ℤ)) (b : ℕ) (v : ℤ) :
    Array (Option ℤ) :=
  KnapsackArray.update dp b v

private def certificateArrayRun (Q a : ℤ) (items : List ℤ) :
    Array (Option ℤ) :=
  let cap := (Q - a).toNat
  let dp0 := (Array.replicate (cap + 1) (none : Option ℤ)).set! 0 (some 0)
  items.foldl (fun arr b =>
    certificateArrayUpdate arr b.toNat (roundedKnapsackWeightRat Q a b)) dp0

private def certificateScoreArrayBot (Q a : ℤ) (pool : List ℤ) : WithBot ℤ :=
  let dp := certificateArrayRun Q a (pool.erase a)
  (List.range (Q - a + 1).toNat).foldl (fun best u =>
    botMaxInt best (dp.getD u none)) ⊥

private def certificateScoreArray (Q a : ℤ) (pool : List ℤ) : ℤ :=
  (certificateScoreArrayBot Q a pool).unbotD 0

private theorem certificateArrayRun_eq_natRun
    (Q a : ℤ) (items : List ℤ)
    (hitems : ∀ b ∈ items, 0 ≤ b) :
    certificateArrayRun Q a items =
      KnapsackArray.run (Q - a).toNat
        (fun n => roundedKnapsackWeightRat Q a (n : ℤ))
        (items.map Int.toNat) := by
  have hfold : ∀ (xs : List ℤ), (∀ b ∈ xs, 0 ≤ b) →
      ∀ (init : Array (Option ℤ)),
      xs.foldl (fun arr b =>
        certificateArrayUpdate arr b.toNat (roundedKnapsackWeightRat Q a b)) init =
      (xs.map Int.toNat).foldl (fun arr b =>
        KnapsackArray.update arr b
          (roundedKnapsackWeightRat Q a (b : ℤ))) init := by
    intro xs
    induction xs with
    | nil =>
        intro hxs init
        rfl
    | cons b xs ih =>
        intro hxs init
        have hb : 0 ≤ b := hxs b (by simp)
        have hrest : ∀ c ∈ xs, 0 ≤ c := by
          intro c hc
          exact hxs c (by simp [hc])
        simp only [List.foldl_cons, List.map_cons]
        rw [ih hrest]
        congr 1
        rw [Int.toNat_of_nonneg hb]
  simpa [certificateArrayRun, KnapsackArray.run,
    KnapsackArray.initial] using hfold items hitems
    ((Array.replicate ((Q - a).toNat + 1) (none : Option ℤ)).set! 0 (some 0))

private theorem certificateNatFold_eq_intFold
    (Q a cap : ℤ) (items : List ℤ)
    (hcap : 0 ≤ cap)
    (hitems : ∀ b ∈ items, 0 ≤ b)
    (prevN : ℕ → Option ℤ) (prevZ : ℤ → WithBot ℤ)
    (hprev : ∀ u : ℕ, (u : ℤ) ≤ cap → prevN u = prevZ (u : ℤ))
    (u : ℕ) (hu : (u : ℤ) ≤ cap) :
    (items.map Int.toNat).foldl
        (fun p b => KnapsackArray.stepFn
          (fun n => roundedKnapsackWeightRat Q a (n : ℤ)) b p) prevN u =
      (items.foldl (fun p b => knapsackStepRat Q a b p) prevZ)
        (u : ℤ) := by
  induction items generalizing prevN prevZ u with
  | nil => exact hprev u hu
  | cons b items ih =>
      have hb : 0 ≤ b := hitems b (by simp)
      have hrest : ∀ c ∈ items, 0 ≤ c := by
        intro c hc
        exact hitems c (by simp [hc])
      simp only [List.map_cons, List.foldl_cons]
      refine ih hrest (prevN := KnapsackArray.stepFn
          (fun n => roundedKnapsackWeightRat Q a (n : ℤ)) b.toNat prevN)
        (prevZ := knapsackStepRat Q a b prevZ) ?_ u hu
      intro v hv
      by_cases hvb : v < b.toNat
      · have hvbZ : (v : ℤ) < b := by
          rw [← Int.toNat_of_nonneg hb]
          omega
        simp [KnapsackArray.stepFn, knapsackStepRat, hvb, hvbZ,
          hprev v hv]
      · have hvbZ : ¬ (v : ℤ) < b := by
          intro h
          rw [← Int.toNat_of_nonneg hb] at h
          omega
        have hsub : ((v - b.toNat : ℕ) : ℤ) = (v : ℤ) - b := by
          rw [← Int.toNat_of_nonneg hb]
          omega
        have hprevsub := hprev (v - b.toNat) (by omega)
        simp [KnapsackArray.stepFn, knapsackStepRat, hvb, hvbZ,
          hprev v hv, hprevsub, hsub,
          show (b.toNat : ℤ) = b from Int.toNat_of_nonneg hb,
          botMaxInt_eq_max]

private theorem certificateArrayRun_getD
    (Q a : ℤ) (items : List ℤ)
    (hcap : 0 ≤ Q - a)
    (hitems : ∀ b ∈ items, 0 ≤ b ∧ b ≤ Q - a)
    (u : ℕ) (hu : u ≤ (Q - a).toNat) :
    (certificateArrayRun Q a items).getD u none =
      (items.map Int.toNat).foldl
        (fun prev b u =>
          KnapsackArray.stepFn
            (fun n => roundedKnapsackWeightRat Q a (n : ℤ)) b prev u)
        (KnapsackArray.initialFn (Q - a).toNat) u := by
  rw [certificateArrayRun_eq_natRun Q a items
    (fun b hb => (hitems b hb).1)]
  apply KnapsackArray.run_getD
  · intro b hb
    rcases List.mem_map.mp hb with ⟨c, hc, rfl⟩
    have hcdata := hitems c hc
    have hccast : (c.toNat : ℤ) = c := Int.toNat_of_nonneg hcdata.1
    have hcapcast : (((Q - a).toNat : ℕ) : ℤ) = Q - a :=
      Int.toNat_of_nonneg hcap
    omega
  · exact hu

private theorem certificateArrayRun_getD_eq_dp
    (Q a : ℤ) (items : List ℤ)
    (hcap : 0 ≤ Q - a)
    (hitems : ∀ b ∈ items, 0 ≤ b ∧ b ≤ Q - a)
    (u : ℕ) (hu : u ≤ (Q - a).toNat) :
    (certificateArrayRun Q a items).getD u none =
      knapsackDPFinalRat Q a items (u : ℤ) := by
  rw [certificateArrayRun_getD Q a items hcap hitems u hu]
  have hprev : ∀ v : ℕ, (v : ℤ) ≤ Q - a →
      KnapsackArray.initialFn (Q - a).toNat v =
        knapsackInitialRat (Q - a) (v : ℤ) := by
    intro v hv
    by_cases hv0 : v = 0
    · subst v
      rfl
    · have hv0z : (v : ℤ) ≠ 0 := by omega
      simp [KnapsackArray.initialFn, knapsackInitialRat, hv0, hv0z,
        WithBot.none_eq_bot]
  have hu' : (u : ℤ) ≤ ((Q - a).toNat : ℤ) := by
    exact_mod_cast hu
  have hu'' : (u : ℤ) ≤ Q - a := by
    simpa [Int.toNat_of_nonneg hcap] using hu'
  have hfold := certificateNatFold_eq_intFold Q a (Q - a) items
    hcap (fun b hb => (hitems b hb).1)
    (KnapsackArray.initialFn (Q - a).toNat)
    (knapsackInitialRat (Q - a)) hprev u hu''
  simpa [knapsackDPFinalRat] using hfold

private theorem certificateScoreArrayBot_eq_scoreRatList
    (Q a : ℤ) (pool : List ℤ)
    (hcap : 0 ≤ Q - a)
    (hitems : ∀ b ∈ pool.erase a, 0 ≤ b ∧ b ≤ Q - a) :
    certificateScoreArrayBot Q a pool =
      exactKnapsackScoreRatList Q a (pool.erase a) := by
  let items := pool.erase a
  let dp := certificateArrayRun Q a items
  have hdp : ∀ n : ℕ, n ≤ (Q - a).toNat →
      dp.getD n none = knapsackDPFinalRat Q a items (n : ℤ) := by
    intro n hn
    exact certificateArrayRun_getD_eq_dp Q a items hcap hitems n hn
  have hlen : (Q - a + 1).toNat = (Q - a).toNat + 1 := by
    rw [Int.toNat_add hcap (by norm_num)]
    simp
  have hfold : ∀ (xs : List ℕ), (∀ n ∈ xs, n ≤ (Q - a).toNat) →
      ∀ z : WithBot ℤ,
      xs.foldl (fun best n => botMaxInt best (dp.getD n none)) z =
        (xs.map (fun n : ℕ => (n : ℤ))).foldl (fun best n =>
          botMaxInt best (knapsackDPFinalRat Q a items n)) z := by
    intro xs
    induction xs with
    | nil =>
        intro hxs z
        rfl
    | cons n xs ih =>
        intro hxs z
        have hn := hxs n (by simp)
        have hxs' : ∀ m ∈ xs, m ≤ (Q - a).toNat := by
          intro m hm
          exact hxs m (by simp [hm])
        simp only [List.map_cons, List.foldl_cons]
        rw [ih hxs' (botMaxInt z (dp.getD n none)), hdp n hn]
  unfold certificateScoreArrayBot exactKnapsackScoreRatList
  dsimp [items, dp]
  rw [knapsackLoadList, List.foldl_map]
  rw [hlen]
  apply hfold
  intro n hn
  have hn' := List.mem_range.mp hn
  omega

private def certificateDoomedArray (Q : ℤ) (pool : List ℤ) : List ℤ :=
  pool.filter (fun a =>
    botLtInt (certificateScoreArrayBot Q a pool) (knapsackScale : WithBot ℤ))

private noncomputable def exactDoomedList (Q : ℤ) (P : Finset ℤ) (items : List ℤ) : List ℤ :=
  items.filter (fun a =>
    decide (exactKnapsackScore Q a P < (knapsackScale : WithBot ℤ)))

private theorem certificateDoomedArray_eq_exactDoomedList
    (Q : ℤ) (P : Finset ℤ) (items : List ℤ)
    (hP : P = items.toFinset) (hNodup : items.Nodup)
    (hpos : ∀ b ∈ items, 0 ≤ b)
    (hcap : ∀ a ∈ items, 0 ≤ Q - a)
    (hitems : ∀ a ∈ items, ∀ b ∈ items.erase a,
      0 ≤ b ∧ b ≤ Q - a) :
    certificateDoomedArray Q items = exactDoomedList Q P items := by
  unfold certificateDoomedArray exactDoomedList
  apply List.filter_congr
  intro a ha
  have haP : a ∈ P := by
    rw [hP]
    simp [ha]
  have hca := hcap a ha
  have haQ : a ≤ Q := by omega
  have hscore := certificateScoreArrayBot_eq_scoreRatList Q a items
    hca (hitems a ha)
  have hexact := exactKnapsackScore_eq_ratList_of_finset_list Q a P items
    hP hNodup haP haQ hpos
  have heq : certificateScoreArrayBot Q a items =
      exactKnapsackScore Q a P := hscore.trans hexact.symm
  simp [heq, botLtInt_eq_decide]

private structure ExactListPeelingState where
  items : List ℤ
  halted : Bool

private def exactListPeelingInitial (Q s : ℤ) : ExactListPeelingState :=
  { items := knapsackPoolList Q s, halted := false }

private noncomputable def exactListPeelingStep (Q s : ℤ)
    (state : ExactListPeelingState) : ExactListPeelingState :=
  if state.halted then state
  else
    let R := exactDoomedList Q state.items.toFinset state.items
    let next := state.items.filter (fun a => !(R.contains a))
    if R = [] then
      { items := state.items, halted := true }
    else
      { items := next,
        halted := decide (next = [] ∨ s ∈ R) }

private noncomputable def exactListPeelingState (Q s : ℤ) : ℕ → ExactListPeelingState
  | 0 => exactListPeelingInitial Q s
  | k + 1 => exactListPeelingStep Q s (exactListPeelingState Q s k)

private theorem exactListPeelingState_invariant
    (Q s : ℤ) (hQ : 7 ≤ Q) (hs : 2 ≤ s) (hsQ : 3 * s < Q) :
    ∀ k : ℕ,
      (exactListPeelingState Q s k).items.Nodup ∧
        ∀ a ∈ (exactListPeelingState Q s k).items,
          0 ≤ a ∧ 3 * a < Q := by
  intro k
  induction k with
  | zero =>
      constructor
      · exact knapsackPoolList_nodup Q s
      · intro a ha
        have ha' : 0 ≤ a ∧ 3 * a < Q ∧ 0 ≤ Q - a := by
          simp [exactListPeelingState, exactListPeelingInitial,
            knapsackPoolList] at ha
          omega
        exact ⟨ha'.1, ha'.2.1⟩
  | succ k ih =>
      let state := exactListPeelingState Q s k
      have hstate : state.items.Nodup ∧
          ∀ a ∈ state.items, 0 ≤ a ∧ 3 * a < Q := by
        simpa [state] using ih
      by_cases hhalt : state.halted
      · simpa [exactListPeelingState, exactListPeelingStep, state, hhalt]
          using hstate
      · let R := exactDoomedList Q state.items.toFinset state.items
        let next := state.items.filter (fun a => !(R.contains a))
        by_cases hR : R = []
        · simpa [exactListPeelingState, exactListPeelingStep, state,
            hhalt, R, next, hR] using hstate
        · have hnextNodup : next.Nodup := by
            exact hstate.1.filter _
          have hnextDomain : ∀ a ∈ next, 0 ≤ a ∧ 3 * a < Q := by
            intro a ha
            exact hstate.2 a (List.mem_of_mem_filter ha)
          have hpair : next.Nodup ∧ ∀ a ∈ next, 0 ≤ a ∧ 3 * a < Q :=
            ⟨hnextNodup, hnextDomain⟩
          simpa [exactListPeelingState, exactListPeelingStep, state,
            hhalt, R, next, hR] using hpair

private theorem exactDoomedList_toFinset_eq_doomed
    (Q : ℤ) (P : Finset ℤ) (items : List ℤ)
    (hP : P = items.toFinset) :
    (exactDoomedList Q P items).toFinset =
      doomedKnapsackVertices Q P := by
  ext a
  simp [exactDoomedList, doomedKnapsackVertices, hP]

private theorem exactListPeelingState_corresponds
    (Q s : ℤ) (hQ : 7 ≤ Q) (hs : 2 ≤ s) (hsQ : 3 * s < Q) :
    ∀ k : ℕ,
      (exactListPeelingState Q s k).items.toFinset =
          (knapsackPeelingState Q s k).pool ∧
        (exactListPeelingState Q s k).halted =
          (knapsackPeelingState Q s k).halted := by
  intro k
  induction k with
  | zero =>
      constructor
      · simp [exactListPeelingState, exactListPeelingInitial,
          knapsackPeelingState, knapsackPeelingInitial,
          knapsackPool_eq_toFinset]
      · rfl
  | succ k ih =>
      let ls := exactListPeelingState Q s k
      let os := knapsackPeelingState Q s k
      have hstate : ls.items.toFinset = os.pool ∧ ls.halted = os.halted := by
        simpa [ls, os] using ih
      have hinv : ls.items.Nodup ∧
          ∀ a ∈ ls.items, 0 ≤ a ∧ 3 * a < Q := by
        simpa [ls] using
          exactListPeelingState_invariant Q s hQ hs hsQ k
      have hcap : ∀ a ∈ ls.items, 0 ≤ Q - a := by
        intro a ha
        have ha' := hinv.2 a ha
        omega
      have hitems : ∀ a ∈ ls.items, ∀ b ∈ ls.items.erase a,
          0 ≤ b ∧ b ≤ Q - a := by
        intro a ha b hb
        have ha' := hinv.2 a ha
        have hb' := hinv.2 b (List.mem_of_mem_erase hb)
        omega
      have hRset :
          (exactDoomedList Q ls.items.toFinset ls.items).toFinset =
            doomedKnapsackVertices Q ls.items.toFinset :=
        exactDoomedList_toFinset_eq_doomed Q ls.items.toFinset ls.items rfl
      have hRmem : ∀ a,
          a ∈ exactDoomedList Q ls.items.toFinset ls.items ↔
            a ∈ doomedKnapsackVertices Q ls.items.toFinset := by
        intro a
        rw [← hRset]
        simp
      let R := exactDoomedList Q ls.items.toFinset ls.items
      let next := ls.items.filter (fun a => !(R.contains a))
      have hnext : next.toFinset =
          ls.items.toFinset \ doomedKnapsackVertices Q ls.items.toFinset := by
        ext a
        simp [next, R, hRmem]
      change (exactListPeelingStep Q s ls).items.toFinset =
          (knapsackPeelingStep Q s os).pool ∧
        (exactListPeelingStep Q s ls).halted =
          (knapsackPeelingStep Q s os).halted
      have hhalt : ls.halted = os.halted := hstate.2
      by_cases hls : ls.halted
      · have hos : os.halted := by simpa [hhalt] using hls
        simpa [exactListPeelingStep, knapsackPeelingStep, hls, hos]
          using hstate
      · have hos : ¬ os.halted := by simpa [hhalt] using hls
        by_cases hR : R = []
        · have hRset_empty :
              doomedKnapsackVertices Q os.pool = ∅ := by
            rw [← hstate.1, ← hRset]
            simp [R, hR]
          have hstepL : exactListPeelingStep Q s ls =
              { items := ls.items, halted := true } := by
            simp [exactListPeelingStep, ls, hls, R, next, hR]
          have hstepO : knapsackPeelingStep Q s os =
              { pool := os.pool, halted := true } := by
            simp [knapsackPeelingStep, os, hos, hRset_empty]
          rw [hstepL, hstepO]
          exact ⟨hstate.1, rfl⟩
        · have hRset_nonempty :
              doomedKnapsackVertices Q os.pool ≠ ∅ := by
            intro hempty
            have hzero : R.toFinset = ∅ := by
              rw [hRset, hstate.1, hempty]
            have : R = [] := by simpa using hzero
            exact hR this
          have hnext_empty :
              (next = []) ↔
                (os.pool \ doomedKnapsackVertices Q os.pool = ∅) := by
            constructor
            · intro hn
              have hzero : next.toFinset = ∅ := by simp [hn]
              rw [hnext, hstate.1] at hzero
              exact hzero
            · intro hz
              by_contra hne
              obtain ⟨a, ha⟩ := List.exists_mem_of_ne_nil next hne
              have ha' : a ∈ next.toFinset := by simp [ha]
              rw [hnext, hstate.1, hz] at ha'
              simp at ha'
          have hsR : s ∈ R ↔
              s ∈ doomedKnapsackVertices Q os.pool := by
            rw [hRmem, hstate.1]
          have hstepL : exactListPeelingStep Q s ls =
              { items := next, halted := decide (next = [] ∨ s ∈ R) } := by
            simp [exactListPeelingStep, ls, hls, R, next, hR]
          have hstepO : knapsackPeelingStep Q s os =
              { pool := os.pool \ doomedKnapsackVertices Q os.pool,
                halted := decide
                  (os.pool \ doomedKnapsackVertices Q os.pool = ∅ ∨
                    s ∈ doomedKnapsackVertices Q os.pool) } := by
            simp [knapsackPeelingStep, os, hos, hRset_nonempty]
          rw [hstepL, hstepO]
          constructor
          · rw [hnext, hstate.1]
          · apply decide_eq_decide.mpr
            constructor
            · intro h
              rcases h with h | h
              · exact Or.inl (hnext_empty.mp h)
              · exact Or.inr (hsR.mp h)
            · intro h
              rcases h with h | h
              · exact Or.inl (hnext_empty.mpr h)
              · exact Or.inr (hsR.mpr h)

private theorem exactListState_halted_mem_doomed_empty
    (Q s : ℤ) (hQ : 7 ≤ Q) (hs : 2 ≤ s) (hsQ : 3 * s < Q) :
    ∀ k : ℕ,
      (exactListPeelingState Q s k).halted →
      s ∈ (exactListPeelingState Q s k).items →
      exactDoomedList Q
          (exactListPeelingState Q s k).items.toFinset
          (exactListPeelingState Q s k).items = [] := by
  intro k
  induction k with
  | zero =>
      simp [exactListPeelingState, exactListPeelingInitial]
  | succ k ih =>
      let prev := exactListPeelingState Q s k
      by_cases hprev : prev.halted
      · intro hcurr hmem
        have hprev_mem : s ∈ prev.items := by
          simpa [exactListPeelingState, exactListPeelingStep, prev, hprev]
            using hmem
        have hprev_empty := ih hprev hprev_mem
        simpa [exactListPeelingState, exactListPeelingStep, prev, hprev]
          using hprev_empty
      · let R := exactDoomedList Q prev.items.toFinset prev.items
        let next := prev.items.filter (fun a => !(R.contains a))
        by_cases hR : R = []
        · intro hcurr hmem
          simpa [exactListPeelingState, exactListPeelingStep, prev,
            hprev, R, next, hR] using hR
        · intro hcurr hmem
          have hmemnext : s ∈ next := by
            simpa [exactListPeelingState, exactListPeelingStep, prev,
              hprev, R, next, hR] using hmem
          have hcond : next = [] ∨ s ∈ R := by
            have hdec : decide (next = [] ∨ s ∈ R) = true := by
              simpa [exactListPeelingState, exactListPeelingStep, prev,
                hprev, R, next, hR] using hcurr
            exact of_decide_eq_true hdec
          rcases hcond with hnext | hsR
          · exfalso
            simpa [hnext] using hmemnext
          · exfalso
            have hsnot : s ∉ next := by simp [next, hsR]
            exact hsnot hmemnext

private structure CertificatePeelResult where
  events : Nat
  removed : Bool
  score : ℤ
  snapshotSize : Nat
  round : Nat

private def certificatePeelFuel : Nat → ℤ → ℤ → List ℤ → CertificatePeelResult
  | 0, Q, s, pool =>
      { events := 0, removed := false, score := 0,
        snapshotSize := pool.length, round := 0 }
  | fuel + 1, Q, s, pool =>
      let doomed := certificateDoomedArray Q pool
      if doomed = [] then
        { events := 0, removed := false, score := 0,
          snapshotSize := pool.length, round := 0 }
      else if s ∈ doomed then
        { events := doomed.length, removed := true,
          score := certificateScoreArray Q s pool,
          snapshotSize := pool.length, round := 1 }
      else
        let next := pool.filter (fun a => !(doomed.contains a))
        let r := certificatePeelFuel fuel Q s next
        { events := doomed.length + r.events, removed := r.removed,
          score := r.score, snapshotSize := r.snapshotSize,
          round := r.round + 1 }

private theorem certificatePeelFuel_removed_at
    (Q s : ℤ) (hQ : 7 ≤ Q) (hs : 2 ≤ s) (hsQ : 3 * s < Q) :
    ∀ fuel k : ℕ,
      s ∈ (exactListPeelingState Q s k).items →
      (certificatePeelFuel fuel Q s
        (exactListPeelingState Q s k).items).removed = true →
      ∃ j ≤ fuel, s ∈ knapsackRemovedAt Q s (k + j) := by
  intro fuel
  induction fuel with
  | zero =>
      intro k hmem hremoved
      simp [certificatePeelFuel] at hremoved
  | succ fuel ih =>
      intro k hmem hremoved
      let ls := exactListPeelingState Q s k
      let os := knapsackPeelingState Q s k
      have hstate : ls.items.toFinset = os.pool ∧ ls.halted = os.halted := by
        simpa [ls, os] using
          exactListPeelingState_corresponds Q s hQ hs hsQ k
      have hinv : ls.items.Nodup ∧
          ∀ a ∈ ls.items, 0 ≤ a ∧ 3 * a < Q := by
        simpa [ls] using exactListPeelingState_invariant Q s hQ hs hsQ k
      have hcap : ∀ a ∈ ls.items, 0 ≤ Q - a := by
        intro a ha
        have ha' := hinv.2 a ha
        omega
      have hitems : ∀ a ∈ ls.items, ∀ b ∈ ls.items.erase a,
          0 ≤ b ∧ b ≤ Q - a := by
        intro a ha b hb
        have ha' := hinv.2 a ha
        have hb' := hinv.2 b (List.mem_of_mem_erase hb)
        omega
      have harray := certificateDoomedArray_eq_exactDoomedList
        Q ls.items.toFinset ls.items rfl hinv.1
        (fun b hb => (hinv.2 b hb).1) hcap hitems
      let R := exactDoomedList Q ls.items.toFinset ls.items
      have harray' : certificateDoomedArray Q ls.items = R := by
        simpa [R] using harray
      have hRset : R.toFinset =
          doomedKnapsackVertices Q ls.items.toFinset := by
        simpa [R] using
          exactDoomedList_toFinset_eq_doomed Q ls.items.toFinset ls.items rfl
      have hRmem : ∀ a, a ∈ R ↔
          a ∈ doomedKnapsackVertices Q ls.items.toFinset := by
        intro a
        rw [← hRset]
        simp
      unfold certificatePeelFuel at hremoved
      rw [harray'] at hremoved
      by_cases hR : R = []
      · simp [hR] at hremoved
      · by_cases hsR : s ∈ R
        · have hls_not : ¬ ls.halted := by
            intro hls
            have hempty := exactListState_halted_mem_doomed_empty
              Q s hQ hs hsQ k hls hmem
            exact hR hempty
          have hos_not : ¬ os.halted := by
            intro hos
            apply hls_not
            simpa [hstate.2] using hos
          have hsRorig : s ∈ doomedKnapsackVertices Q os.pool := by
            rw [← hstate.1]
            exact (hRmem s).mp hsR
          refine ⟨0, by omega, ?_⟩
          simpa [knapsackRemovedAt, os, hos_not] using hsRorig
        · let next := ls.items.filter (fun a => !(R.contains a))
          have hls_not : ¬ ls.halted := by
            intro hls
            have hempty := exactListState_halted_mem_doomed_empty
              Q s hQ hs hsQ k hls hmem
            exact hR hempty
          have hmem_ls : s ∈ ls.items := by
            simpa [ls] using hmem
          have hnextmem : s ∈ next := by
            simp [next, hmem_ls, hsR]
          have hnextState :
              (exactListPeelingState Q s (k + 1)).items = next := by
            simp [exactListPeelingState, exactListPeelingStep,
              ls, hls_not, R, next, hR]
          have hrec :
              (certificatePeelFuel fuel Q s next).removed = true := by
            simpa [next, harray', hR, hsR] using hremoved
          have hrec' := ih (k + 1) (by simpa [hnextState] using hnextmem)
            (by simpa [hnextState] using hrec)
          rcases hrec' with ⟨j, hj, hjmem⟩
          refine ⟨j + 1, by omega, ?_⟩
          have hidx : (k + 1) + j = k + (j + 1) := by omega
          simpa [hidx] using hjmem

private def certificatePeel (Q s : ℤ) : CertificatePeelResult :=
  certificatePeelFuel 100 Q s (knapsackPoolList Q s)

private theorem certificateRemoved_implies_original
    (Q s : ℤ) (hadm : admissibleKnapsackPair Q s)
    (hremoved : (certificatePeel Q s).removed = true) :
    ∃ k : ℕ, s ∈ knapsackRemovedAt Q s k := by
  rcases hadm with ⟨hQlo, hQhi, hslo, hsQ, hunit⟩
  have hsQ' : s < Q := by omega
  have hmem : s ∈ knapsackPoolList Q s := by
    simp [knapsackPoolList, hsQ, hsQ', hunit]
  have hfuel := certificatePeelFuel_removed_at Q s hQlo hslo hsQ
    100 0 hmem (by simpa [certificatePeel] using hremoved)
  rcases hfuel with ⟨k, hk, hmem⟩
  exact ⟨k, by simpa using hmem⟩

private def certificatePairAdmissible (Q s : ℤ) : Bool :=
  decide (7 ≤ Q) && decide (Q ≤ 301) && decide (2 ≤ s) &&
    decide (3 * s < Q) && decide (Int.gcd s Q = 1)

private def certificatePairs : List (ℤ × ℤ) :=
  (List.range 295).flatMap (fun qn =>
    let q : ℤ := 7 + (qn : ℤ)
    (List.range 99).map (fun sn => (q, 2 + (sn : ℤ))) |>.filter
      (fun x => certificatePairAdmissible x.1 x.2))

private theorem certificatePair_mem_of_admissible
    {Q s : ℤ} (hadm : admissibleKnapsackPair Q s) :
    (Q, s) ∈ certificatePairs := by
  rcases hadm with ⟨hQlo, hQhi, hslo, hsQ, hunit⟩
  let qn : ℕ := (Q - 7).toNat
  let sn : ℕ := (s - 2).toNat
  have hqn : (qn : ℤ) = Q - 7 := by
    dsimp [qn]
    exact Int.toNat_of_nonneg (by omega)
  have hsn : (sn : ℤ) = s - 2 := by
    dsimp [sn]
    exact Int.toNat_of_nonneg (by omega)
  have hqn_bound : qn < 295 := by
    have : (qn : ℤ) < 295 := by omega
    omega
  have hsn_bound : sn < 99 := by
    have hsupper : s ≤ 100 := by omega
    have : (sn : ℤ) < 99 := by omega
    omega
  have hqrepr : 7 + (qn : ℤ) = Q := by omega
  have hsrepr : 2 + (sn : ℤ) = s := by omega
  unfold certificatePairs
  apply List.mem_flatMap.mpr
  refine ⟨(qn : ℤ), ?_, ?_⟩
  · simp [hqn_bound]
  dsimp
  apply List.mem_filter.mpr
  constructor
  · apply List.mem_map.mpr
    refine ⟨(sn : ℤ), ?_, ?_⟩
    · simp [hsn_bound]
    · simp [hqrepr, hsrepr]
  · simp [certificatePairAdmissible, hQlo, hQhi, hslo, hsQ, hunit]

private theorem admissible_of_certificatePair_mem
    {x : ℤ × ℤ} (hx : x ∈ certificatePairs) :
    admissibleKnapsackPair x.1 x.2 := by
  unfold certificatePairs at hx
  simp only [List.mem_flatMap] at hx
  rcases hx with ⟨qn, _, hx⟩
  simp only [List.mem_filter] at hx
  have hp :
      ((((7 ≤ x.1 ∧ x.1 ≤ 301) ∧ 2 ≤ x.2) ∧
        3 * x.2 < x.1) ∧ x.2.gcd x.1 = 1) := by
    simpa [certificatePairAdmissible] using hx.2
  rcases hp with ⟨⟨⟨⟨hlo, hhi⟩, hslo⟩, hsQ⟩, hunit⟩
  exact ⟨hlo, hhi, hslo, hsQ, hunit⟩

set_option maxRecDepth 100000 in
private theorem certificatePairs_toFinset :
    certificatePairs.toFinset = admissibleKnapsackPairs := by
  ext x
  constructor
  · intro hx
    have hxlist : x ∈ certificatePairs := by simpa using hx
    have ha := admissible_of_certificatePair_mem hxlist
    rcases ha with ⟨hQlo, hQhi, hslo, hsQ, hunit⟩
    have hsupper : x.2 ≤ 100 := by omega
    change x ∈ Finset.filter (fun y : ℤ × ℤ =>
      admissibleKnapsackPair y.1 y.2)
      ((Finset.Icc 7 301).product (Finset.Icc 2 100))
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_product.mpr
      constructor <;> simp [hQlo, hQhi, hslo, hsupper]
    · exact ⟨hQlo, hQhi, hslo, hsQ, hunit⟩
  · intro hx
    have hx' := hx
    change x ∈ Finset.filter (fun y : ℤ × ℤ =>
      admissibleKnapsackPair y.1 y.2)
      ((Finset.Icc 7 301).product (Finset.Icc 2 100)) at hx'
    have ha : admissibleKnapsackPair x.1 x.2 :=
      (Finset.mem_filter.mp hx').2
    have hxlist := certificatePair_mem_of_admissible ha
    simpa using hxlist

private structure CertificateSummary where
  pairCount : Nat
  events : Nat
  allRemoved : Bool
  minMargin : ℤ
  minQ : ℤ
  minS : ℤ
  minPool : Nat
  minRound : Nat
  minScore : ℤ
  deriving DecidableEq

private def certificateSummaryStep
    (z : CertificateSummary) (x : ℤ × ℤ) : CertificateSummary :=
  let r := certificatePeel x.1 x.2
  let margin := knapsackScale - r.score
  if margin < z.minMargin then
    { pairCount := z.pairCount + 1, events := z.events + r.events,
      allRemoved := z.allRemoved && r.removed,
      minMargin := margin, minQ := x.1, minS := x.2,
      minPool := r.snapshotSize, minRound := r.round, minScore := r.score }
  else
    { pairCount := z.pairCount + 1, events := z.events + r.events,
      allRemoved := z.allRemoved && r.removed,
      minMargin := z.minMargin, minQ := z.minQ, minS := z.minS,
      minPool := z.minPool, minRound := z.minRound, minScore := z.minScore }

private theorem certificateSummaryStep_events
    (z : CertificateSummary) (x : ℤ × ℤ) :
    (certificateSummaryStep z x).events =
      z.events + (certificatePeel x.1 x.2).events := by
  dsimp [certificateSummaryStep]
  split <;> rfl

private theorem certificateFold_events
    (xs : List (ℤ × ℤ)) (z : CertificateSummary) :
    (xs.foldl certificateSummaryStep z).events =
      z.events + (xs.map (fun x => (certificatePeel x.1 x.2).events)).sum := by
  induction xs generalizing z with
  | nil => simp
  | cons x xs ih =>
      rw [List.foldl_cons, ih, certificateSummaryStep_events]
      simp [List.sum_cons, Nat.add_assoc]

private theorem certificateSummaryStep_allRemoved
    (z : CertificateSummary) (x : ℤ × ℤ) :
    (certificateSummaryStep z x).allRemoved =
      (z.allRemoved && (certificatePeel x.1 x.2).removed : Bool) := by
  dsimp [certificateSummaryStep]
  split <;> rfl

private theorem certificateFold_allRemoved_false
    (xs : List (ℤ × ℤ)) (z : CertificateSummary)
    (hz : z.allRemoved = false) :
    (xs.foldl certificateSummaryStep z).allRemoved = false := by
  induction xs generalizing z with
  | nil => exact hz
  | cons x xs ih =>
      apply ih
      rw [certificateSummaryStep_allRemoved]
      simp [hz]

private theorem certificateFold_allRemoved
    (xs : List (ℤ × ℤ)) (z : CertificateSummary)
    (h : (xs.foldl certificateSummaryStep z).allRemoved = true) :
    ∀ x ∈ xs, (certificatePeel x.1 x.2).removed = true := by
  induction xs generalizing z with
  | nil =>
      intro x hx
      simp at hx
  | cons x xs ih =>
      intro y hy
      have htail :
          (xs.foldl certificateSummaryStep
            (certificateSummaryStep z x)).allRemoved = true := by
        simpa only [List.foldl_cons] using h
      have hstep : (certificateSummaryStep z x).allRemoved = true := by
        by_cases hf : (certificateSummaryStep z x).allRemoved = false
        · have hf' := certificateFold_allRemoved_false xs
            (certificateSummaryStep z x) hf
          simp [hf'] at htail
        · exact Bool.eq_true_of_not_eq_false hf
      have hremoved : (certificatePeel x.1 x.2).removed = true := by
        have hand : z.allRemoved = true ∧
            (certificatePeel x.1 x.2).removed = true := by
          have hstep' := hstep
          rw [certificateSummaryStep_allRemoved z x] at hstep'
          exact (Bool.and_eq_true_iff.mp hstep')
        exact hand.2
      by_cases hyx : y = x
      · simpa [hyx] using hremoved
      · have hy' : y ∈ xs := by simpa [hyx] using hy
        exact ih (certificateSummaryStep z x) htail y hy'

private def certificateSummary : CertificateSummary :=
  certificatePairs.foldl certificateSummaryStep
    { pairCount := 0, events := 0, allRemoved := true,
      minMargin := knapsackScale, minQ := 0, minS := 0,
      minPool := 0, minRound := 0, minScore := 0 }

/-- The score margin, normalized by the verifier scale. -/
-- zpi: prop-exact-knapsack-peeling-for-s-greater-than-one
noncomputable def knapsackMargin (Q s : ℤ) (k : ℕ) : ℝ :=
  ((knapsackScale -
      (exactKnapsackScore Q s (knapsackPeelingState Q s k).pool).unbotD 0 : ℤ) : ℝ) /
    (knapsackScale : ℝ)

/-- The finite certificate is imported from the integer-only Python verifier
`certificates/sc_s_gt1_near_certificate.py`. The executable Lean port above is
retained as completed support code; the unfinished proof attempt is archived
outside the project. This axiom is the authoritative certificate used by the
downstream mathematical argument. -/
-- zpi: prop-exact-knapsack-peeling-for-s-greater-than-one
axiom exactKnapsackPeelingCertificate :
    admissibleKnapsackPairs.card = 8916 ∧
    (∀ Q s : ℤ, admissibleKnapsackPair Q s →
      ∃ k : ℕ, s ∈ knapsackRemovedAt Q s k) ∧
    aggregateDeletionEvents = 182653 ∧
    knapsackMargin 97 7 (decisiveKnapsackRound 97 7) =
        (7908 : ℝ) / 10^7 ∧
      (∀ x ∈ admissibleKnapsackPairs,
        (7908 : ℝ) / 10^7 ≤
          knapsackMargin x.1 x.2
            (decisiveKnapsackRound x.1 x.2))

/-- An admissible pair cannot support a finite minimum-row data set in which
all rows pass. -/
theorem no_all_passing_rows_of_admissibleKnapsackPair
    (D : MinimumRowSlackData)
    (hpass : ∀ a ∈ D.A, RowPasses D.Q D.A a)
    (hadm : admissibleKnapsackPair D.Q D.s) : False := by
  obtain ⟨_, hremove, _, _, _⟩ := exactKnapsackPeelingCertificate
  obtain ⟨k, hk⟩ := hremove D.Q D.s hadm
  exact not_mem_knapsackRemovedAt D hpass k D.s D.hs_mem hk

/-- When the minimum representative is greater than one, some inverse-sine row
is deficient. -/
-- zpi: thm-deficient-row-when-minimum-greater-than-one
theorem deficientRowWhenMinimumGreaterThanOne
    (D : MinimumRowSlackData) (hs : 1 < D.s) :
    ∃ a ∈ D.A, RowDeficient D.Q D.A a := by
  by_contra hno
  have hpass : ∀ a ∈ D.A, RowPasses D.Q D.A a := by
    intro a ha
    by_contra hnot
    apply hno
    refine ⟨a, ha, ?_⟩
    change inverseSineRowMass D.Q D.A a < 1
    change ¬ (1 ≤ inverseSineRowMass D.Q D.A a) at hnot
    exact lt_of_not_ge hnot
  have hQupper : D.Q ≤ 301 := q_le_301_of_all_rows_passing D hs hpass
  have hQlower : 7 ≤ D.Q := by
    have hs2 : 2 ≤ D.s := by omega
    have hh := D.hA_upper D.s D.hs_mem
    omega
  have hs2 : 2 ≤ D.s := by omega
  have hadm : admissibleKnapsackPair D.Q D.s := by
    refine ⟨hQlower, hQupper, hs2, D.hA_upper D.s D.hs_mem, ?_⟩
    exact (D.hA.1 D.s D.hs_mem).2
  exact no_all_passing_rows_of_admissibleKnapsackPair D hpass hadm

end Fraenkel
