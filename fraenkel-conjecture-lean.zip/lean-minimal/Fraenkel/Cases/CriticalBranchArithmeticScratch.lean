import Fraenkel.Cases.CriticalBranchScratch

namespace Fraenkel

set_option maxHeartbeats 1000000

 theorem cDistPosScratch (y ell eta d : ℤ) (hy3 : 3 ≤ y)
    (hellpos : 1 ≤ ell) (heta : eta = 1 ∨ eta = -1)
    (hdist : d = ell * y + eta) : 0 < d := by
  have hmul : y ≤ ell * y := by
    simpa using (mul_le_mul_of_nonneg_right hellpos (show 0 ≤ y by omega))
  have heta_low : -1 ≤ eta := by rcases heta with rfl | rfl <;> omega
  rw [hdist]
  have hlow : y - 1 ≤ ell * y + eta := by omega
  omega

theorem cKfunScratch (C : Finset ℤ) (y : ℤ)
    (hshape : ∀ b ∈ C, ∃ k : ℤ, 1 ≤ k ∧ k < y ∧ b = y + k) :
    ∃ kfun : ℤ → ℤ,
      (∀ b ∈ C, 1 ≤ kfun b ∧ kfun b < y ∧ b = y + kfun b) ∧
      (∀ a ∈ C, ∀ b ∈ C, kfun a = kfun b → a = b) := by
  let kfun : ℤ → ℤ := fun b =>
    if hb : b ∈ C then (hshape b hb).choose else 0
  have hkfun (b : ℤ) (hb : b ∈ C) :
      1 ≤ kfun b ∧ kfun b < y ∧ b = y + kfun b := by
    have hkeq : kfun b = (hshape b hb).choose := by
      unfold kfun
      split
      · rfl
      · rename_i h
        exact False.elim (h hb)
    rw [hkeq]
    rcases (hshape b hb).choose_spec with ⟨hk, hkl, hbk⟩
    exact ⟨hk, hkl, hbk⟩
  have hinj : ∀ a ∈ C, ∀ b ∈ C, kfun a = kfun b → a = b := by
    intro a ha b hb hab
    have hka := (hkfun a ha).2.2
    have hkb := (hkfun b hb).2.2
    omega
  exact ⟨kfun, hkfun, hinj⟩

theorem cKshapeFromFullScratch (C : Finset ℤ) (y : ℤ)
    (R : ℤ → ℤ → ℤ → ℤ → ℤ → Prop)
    (hD : ∀ b ∈ C, ∃ k t eps ell : ℤ,
      1 ≤ k ∧ k < y ∧ 3 ≤ t ∧
      (eps = 1 ∨ eps = -1) ∧
      t * b = 0 ∧ ell = 0 ∧ 1 ≤ ell ∧ ell ≤ 0 ∧
      b = y + k ∧ R b k t eps ell) :
    ∀ b ∈ C, ∃ k : ℤ, 1 ≤ k ∧ k < y ∧ b = y + k := by
  intro b hb
  obtain ⟨k, t, eps, ell, hk, hkl, ht, heps, htb, hell,
    hellpos, hellupper, hbk, hR⟩ := hD b hb
  exact ⟨k, hk, hkl, hbk⟩

theorem baselinePromotionScratch (G P X : Finset ℤ) (Q y p : ℤ)
    (f : ℤ → ℝ) (hy : 0 < y) (hQ : 2 ≤ Q) (hPsub : P ⊆ G)
    (hPsum : (∑ b ∈ P, b) ≤ p)
    (hGsum : (∑ b ∈ G, b) ≤ Q - y - 1)
    (hPnonneg : ∀ b ∈ P, 0 ≤ b)
    (hfP : ∀ b ∈ P, f b = (b : ℝ) / y)
    (hpoint : ∀ b ∈ G, b ∉ P →
      f b ≤ (b : ℝ) / (y * (Q - 1)) +
        if b ∈ X then max 0 (f b - (b : ℝ) / (y * (Q - 1))) else 0) :
    (∑ b ∈ G, f b) ≤
      p / y + (Q - y - 1 - p : ℤ) / (y * (Q - 1)) + 
        ∑ b ∈ X, max 0 (f b - (b : ℝ) / (y * (Q - 1))) := by
  have hQ1 : 0 < Q - 1 := by omega
  have hyR : (0 : ℝ) < y := by exact_mod_cast hy
  have hQ1R : (0 : ℝ) < Q - 1 := by exact_mod_cast hQ1
  let R : Finset ℤ := G.filter (fun b => b ∉ P)
  have hRsub : R ⊆ G := by
    intro b hb
    exact (Finset.mem_filter.mp hb).1
  have hRnot (b : ℤ) (hb : b ∈ R) : b ∉ P :=
    (Finset.mem_filter.mp hb).2
  have hsumG : (∑ b ∈ G, f b) =
      (∑ b ∈ P, f b) + ∑ b ∈ R, f b := by
    have h := (Finset.sum_filter_add_sum_filter_not G
      (fun b : ℤ => b ∈ P) f).symm
    have hfilter : G.filter (fun b : ℤ => b ∈ P) = P := by
      ext b
      constructor
      · intro hb
        exact (Finset.mem_filter.mp hb).2
      · intro hb
        exact Finset.mem_filter.mpr ⟨hPsub hb, hb⟩
    simpa [R, hfilter] using h
  have hsumR : (∑ b ∈ R, f b) ≤
      (∑ b ∈ R, (b : ℝ) / (y * (Q - 1))) +
        ∑ b ∈ X, max 0 (f b - (b : ℝ) / (y * (Q - 1))) := by
    have hbase : (∑ b ∈ R, f b) ≤
        ∑ b ∈ R, ((b : ℝ) / (y * (Q - 1)) +
          if b ∈ X then max 0 (f b - (b : ℝ) / (y * (Q - 1))) else 0) := by
      apply Finset.sum_le_sum
      intro b hb
      exact hpoint b (hRsub hb) (hRnot b hb)
    have hsplit :
        (∑ b ∈ R, ((b : ℝ) / (y * (Q - 1)) +
          if b ∈ X then max 0 (f b - (b : ℝ) / (y * (Q - 1))) else 0)) =
        (∑ b ∈ R, (b : ℝ) / (y * (Q - 1))) +
          ∑ b ∈ R.filter (fun b => b ∈ X),
            max 0 (f b - (b : ℝ) / (y * (Q - 1))) := by
      rw [Finset.sum_add_distrib]
      congr 1
      conv_rhs => rw [Finset.sum_filter]
    have hbase' : (∑ b ∈ R, f b) ≤
        (∑ b ∈ R, (b : ℝ) / (y * (Q - 1))) +
          ∑ b ∈ R.filter (fun b => b ∈ X),
            max 0 (f b - (b : ℝ) / (y * (Q - 1))) := by
      calc
        (∑ b ∈ R, f b) ≤
            ∑ b ∈ R, ((b : ℝ) / (y * (Q - 1)) +
              if b ∈ X then max 0
                (f b - (b : ℝ) / (y * (Q - 1))) else 0) := hbase
        _ = _ := hsplit
    have hRX : R.filter (fun b => b ∈ X) ⊆ X := by
      intro b hb
      exact (Finset.mem_filter.mp hb).2
    have hnonneg : ∀ b : ℤ, 0 ≤
        max 0 (f b - (b : ℝ) / (y * (Q - 1))) := by
      intro b
      exact le_max_left _ _
    have hprom := Finset.sum_le_sum_of_subset_of_nonneg hRX
      (fun b hb hnot => hnonneg b)
    linarith [hbase', hprom]
  have hsumP : (∑ b ∈ P, f b) =
      (∑ b ∈ P, (b : ℝ)) / y := by
    calc
      (∑ b ∈ P, f b) = ∑ b ∈ P, (b : ℝ) / y := by
        apply Finset.sum_congr rfl
        intro b hb
        rw [hfP b hb]
      _ = (∑ b ∈ P, (b : ℝ)) / y := by
        rw [Finset.sum_div]
  have hsumRbase : (∑ b ∈ R, (b : ℝ) / (y * (Q - 1))) =
      ((∑ b ∈ G, (b : ℝ)) - ∑ b ∈ P, (b : ℝ)) / (y * (Q - 1)) := by
    have hsum := (Finset.sum_filter_add_sum_filter_not G
      (fun b : ℤ => b ∈ P) (fun b => (b : ℝ))).symm
    have hfilter : G.filter (fun b : ℤ => b ∈ P) = P := by
      ext b
      constructor
      · intro hb
        exact (Finset.mem_filter.mp hb).2
      · intro hb
        exact Finset.mem_filter.mpr ⟨hPsub hb, hb⟩
    rw [hfilter] at hsum
    have hsum' :
        (∑ b ∈ G, (b : ℝ)) =
          (∑ b ∈ P, (b : ℝ)) + ∑ b ∈ R, (b : ℝ) := by
      simpa [R] using hsum
    have hsumdiff :
        (∑ b ∈ R, (b : ℝ)) =
          (∑ b ∈ G, (b : ℝ)) - ∑ b ∈ P, (b : ℝ) := by
      linarith
    calc
      (∑ b ∈ R, (b : ℝ) / (y * (Q - 1))) =
          (∑ b ∈ R, (b : ℝ)) / (y * (Q - 1)) := by
            rw [Finset.sum_div]
      _ = ((∑ b ∈ G, (b : ℝ)) - ∑ b ∈ P, (b : ℝ)) /
          (y * (Q - 1)) := by rw [hsumdiff]
  have hsumGcast : (∑ b ∈ G, (b : ℝ)) ≤ (Q - y - 1 : ℝ) := by
    have hcast : ((∑ b ∈ G, b : ℤ) : ℝ) = ∑ b ∈ G, (b : ℝ) := by
      norm_num
    rw [← hcast]
    exact_mod_cast hGsum
  have hsumPcast : (∑ b ∈ P, (b : ℝ)) ≤ (p : ℝ) := by
    have hcast : ((∑ b ∈ P, b : ℤ) : ℝ) = ∑ b ∈ P, (b : ℝ) := by
      norm_num
    rw [← hcast]
    exact_mod_cast hPsum
  have hPnonnegR : 0 ≤ (∑ b ∈ P, (b : ℝ)) := by
    apply Finset.sum_nonneg
    intro b hb
    exact_mod_cast (hPnonneg b hb)
  have hdenpos : 0 < (y : ℝ) * (Q - 1) := mul_pos hyR hQ1R
  have hbase_bound :
      (∑ b ∈ P, (b : ℝ)) / y +
        ((∑ b ∈ G, (b : ℝ)) - ∑ b ∈ P, (b : ℝ)) /
          (y * (Q - 1)) ≤
      p / y + (Q - y - 1 - p : ℤ) / (y * (Q - 1)) := by
    push_cast
    have hQ2R : (0 : ℝ) ≤ Q - 2 := by exact_mod_cast (show 0 ≤ Q - 2 by omega)
    have hcoef : 0 ≤ (Q - 2 : ℝ) / ((y : ℝ) * (Q - 1)) := by
      positivity
    have hmono :
        (∑ b ∈ P, (b : ℝ)) / y +
          ((Q - y - 1 : ℤ) - ∑ b ∈ P, (b : ℝ)) /
            (y * (Q - 1)) ≤
        p / y + ((Q - y - 1 : ℤ) - p) /
            (y * (Q - 1)) := by
      have hSP := hsumPcast
      have hyne : (y : ℝ) ≠ 0 := ne_of_gt hyR
      have hq1ne : (Q - 1 : ℝ) ≠ 0 := ne_of_gt hQ1R
      field_simp [hyne, hq1ne]
      nlinarith
    have hsum_replace :
        ((∑ b ∈ G, (b : ℝ)) - ∑ b ∈ P, (b : ℝ)) /
            (y * (Q - 1)) ≤
          ((Q - y - 1 : ℝ) - ∑ b ∈ P, (b : ℝ)) /
            (y * (Q - 1)) := by
      apply div_le_div_of_nonneg_right
      linarith
      positivity
    have hsum_replace' :
        ((∑ b ∈ G, (b : ℝ)) - ∑ b ∈ P, (b : ℝ)) /
            (y * (Q - 1)) ≤
          ((Q : ℝ) - y - 1 - ∑ b ∈ P, (b : ℝ)) /
            (y * (Q - 1)) := by
      convert hsum_replace using 1 <;> norm_num
    have hfirst :
        (∑ b ∈ P, (b : ℝ)) / y +
            ((∑ b ∈ G, (b : ℝ)) - ∑ b ∈ P, (b : ℝ)) /
              (y * (Q - 1)) ≤
          (∑ b ∈ P, (b : ℝ)) / y +
            ((Q : ℝ) - y - 1 - ∑ b ∈ P, (b : ℝ)) /
              (y * (Q - 1)) := by
      simpa [add_comm, add_left_comm, add_assoc] using
        (add_le_add_right hsum_replace'
          ((∑ b ∈ P, (b : ℝ)) / y))
    push_cast at hmono
    exact hfirst.trans hmono
  calc
    (∑ b ∈ G, f b) = (∑ b ∈ P, f b) + ∑ b ∈ R, f b := hsumG
    _ ≤ (∑ b ∈ P, f b) +
        ((∑ b ∈ R, (b : ℝ) / (y * (Q - 1))) +
          ∑ b ∈ X, max 0 (f b - (b : ℝ) / (y * (Q - 1)))) := by
      simpa [add_comm, add_left_comm, add_assoc] using
        (add_le_add_right hsumR (∑ b ∈ P, f b))
    _ = (∑ b ∈ P, (b : ℝ)) / y +
        ((∑ b ∈ G, (b : ℝ)) - ∑ b ∈ P, (b : ℝ)) /
          (y * (Q - 1)) +
        ∑ b ∈ X, max 0 (f b - (b : ℝ) / (y * (Q - 1))) := by
      rw [hsumP, hsumRbase]
      ring
    _ ≤ p / y + (Q - y - 1 - p : ℤ) / (y * (Q - 1)) +
        ∑ b ∈ X, max 0 (f b - (b : ℝ) / (y * (Q - 1))) := by
      simpa [add_assoc, add_left_comm, add_comm] using
        (add_le_add_right hbase_bound
          (∑ b ∈ X, max 0 (f b - (b : ℝ) / (y * (Q - 1)))))

theorem vpartEqScratch (y : ℤ) (v : ℕ) (m : ℤ)
    (hypos : 0 < y) (hm3 : 3 ≤ m)
    (hdecomp : y = (2 : ℤ) ^ v * m)
    (hvmax : ¬ (2 : ℤ) ^ (v + 1) ∣ y) :
    Nat.findGreatest (fun n : ℕ => (2 : ℤ) ^ n ∣ y) y.natAbs = v := by
  have hnat : ∀ n : ℕ, n ≤ 2 ^ n := by
    intro n
    induction n with
    | zero => simp
    | succ n ih =>
        rw [pow_succ]
        have hpowone : 1 ≤ 2 ^ n := Nat.one_le_pow n 2 (by omega)
        exact (Nat.succ_le_succ ih).trans (by omega)
  have hvpow_nat : v ≤ 2 ^ v := hnat v
  have hpowpos : 0 < (2 : ℤ) ^ v := by positivity
  have hpow_le_y : (2 : ℤ) ^ v ≤ y := by
    rw [hdecomp]
    nlinarith
  have hv_le_yZ : (v : ℤ) ≤ y := by
    have hvcast : (v : ℤ) ≤ (2 : ℤ) ^ v := by exact_mod_cast hvpow_nat
    exact hvcast.trans hpow_le_y
  have hyabsZ : (y.natAbs : ℤ) = y :=
    Int.natAbs_of_nonneg (by omega : 0 ≤ y)
  have hv_le_absZ : (v : ℤ) ≤ (y.natAbs : ℤ) := by
    rw [hyabsZ]
    exact hv_le_yZ
  have hv_le_abs : v ≤ y.natAbs := by
    exact_mod_cast hv_le_absZ
  have hvdiv : (2 : ℤ) ^ v ∣ y := by
    refine ⟨m, ?_⟩
    exact hdecomp
  let P : ℕ → Prop := fun n => (2 : ℤ) ^ n ∣ y
  have hvdivP : P v := hvdiv
  have hvpart_ge : v ≤ Nat.findGreatest P y.natAbs := by
    exact Nat.le_findGreatest hv_le_abs hvdivP
  have hvpart_div : (2 : ℤ) ^ Nat.findGreatest P y.natAbs ∣ y := by
    have hp := Nat.findGreatest_spec (P := P) hv_le_abs hvdivP
    simpa [P] using hp
  have hvpart_le : Nat.findGreatest P y.natAbs ≤ v := by
    by_contra hnot
    have hvk : v + 1 ≤ Nat.findGreatest P y.natAbs := by omega
    have hpow : (2 : ℤ) ^ (v + 1) ∣
        (2 : ℤ) ^ Nat.findGreatest P y.natAbs :=
      pow_dvd_pow _ hvk
    exact hvmax (dvd_trans hpow hvpart_div)
  exact le_antisymm hvpart_le hvpart_ge

theorem farBaseScratch (E : MinimumRowSlackData) (y b : ℤ)
    (hQ : 2 ≤ E.Q) (hs : E.s = 1) (hypos : 0 < y)
    (hyQ : 3 * y < E.Q) (h2E : (2 : ℤ) ∈ E.A) (hbA : b ∈ E.A)
    (hgood : GoodMinimumRowElement E b) (hby : 2 * y ≤ b) :
    y * (E.Q - 1) ≤ productShellValue E y b := by
  have hqpos : 0 < E.Q := by omega
  have hbpos : 0 < b := (E.hA.1 b hbA).1
  have hne : y ≠ b := by
    intro h
    subst b
    omega
  have hQplus : 0 < E.Q + 1 := by omega
  have hQminus : 0 < E.Q - 1 := by omega
  have hcop2 : Int.gcd (2 : ℤ) E.Q = 1 := E.hA.1 2 h2E |>.2
  have hQodd : ∃ q : ℤ, E.Q = 2 * q + 1 := by
    obtain ⟨q, hqeven | hqodd⟩ := Int.even_or_odd' E.Q
    · exfalso
      have hdivQ : (2 : ℤ) ∣ E.Q := by
        refine ⟨q, ?_⟩
        exact hqeven
      have hdivG : (2 : ℕ) ∣ Int.gcd 2 E.Q :=
        Int.dvd_gcd (by exact ⟨1, by ring⟩) hdivQ
      rw [hcop2] at hdivG
      omega
    · exact ⟨q, hqodd⟩
  have hfar_case (eps : ℤ) (L : ℤ)
      (heps : eps = 1 ∨ eps = -1)
      (hL : L * b = E.Q + eps) :
      y * (E.Q - 1) ≤ productShellValue E y b := by
    have hLpos : 0 < L := by
      have hnum : 0 < E.Q + eps := by
        rcases heps with rfl | rfl <;> omega
      nlinarith [hL, hbpos]
    have hLypos : 0 < L * y := mul_pos hLpos hypos
    have hLy_bound : 2 * (L * y) ≤ E.Q + eps := by
      have hh := mul_le_mul_of_nonneg_left hby (show 0 ≤ L by omega)
      nlinarith [hL]
    have hprod_inv : (b * (eps * L)) % E.Q = 1 := by
      have hepssq : eps * eps = 1 := by
        rcases heps with rfl | rfl <;> norm_num
      have heq : b * (eps * L) = eps * E.Q + 1 := by
        calc
          b * (eps * L) = eps * (L * b) := by ring
          _ = eps * (E.Q + eps) := by rw [hL]
          _ = eps * E.Q + 1 := by nlinarith [hepssq]
      rw [heq, Int.add_emod, Int.mul_emod, Int.emod_self]
      have hone : (1 : ℤ) % E.Q = 1 :=
        Int.emod_eq_of_lt (by omega) (by omega)
      simpa using hone
    have hcopb : Int.gcd b E.Q = 1 := (E.hA.1 b hbA).2
    have hinv := inverseMod_spec E.Q b hQ hcopb
    have hprod_inv' : ((eps * L) * b) % E.Q = 1 := by
      simpa [mul_comm] using hprod_inv
    have hzero : ((inverseMod E.Q b - eps * L) * b) % E.Q = 0 := by
      calc
        ((inverseMod E.Q b - eps * L) * b) % E.Q =
            (inverseMod E.Q b * b - (eps * L) * b) % E.Q := by
              congr 1 <;> ring
        _ = ((inverseMod E.Q b * b) % E.Q -
            ((eps * L) * b) % E.Q) % E.Q := by rw [Int.sub_emod]
        _ = 0 := by
          rw [show (inverseMod E.Q b * b) % E.Q = 1 by
            simpa [mul_comm] using hinv.2, hprod_inv']
          simp
    have hcopQb : Int.gcd E.Q b = 1 := by
      simpa [Int.gcd_comm] using hcopb
    have hdivinv : E.Q ∣ inverseMod E.Q b - eps * L := by
      apply Int.dvd_of_dvd_mul_left_of_gcd_one
        (a := E.Q) (b := inverseMod E.Q b - eps * L) (c := b)
      · exact Int.dvd_of_emod_eq_zero hzero
      · exact hcopQb
    have hmodinv : inverseMod E.Q b ≡ eps * L [ZMOD E.Q] :=
      (Int.modEq_iff_dvd).2 (by
        convert dvd_neg.mpr hdivinv using 1 <;> ring)
    have hmody : y * inverseMod E.Q b ≡
        y * (eps * L) [ZMOD E.Q] := hmodinv.mul_left y
    obtain ⟨q, hqodd⟩ := hQodd
    have heps_bounds : -1 ≤ eps ∧ eps ≤ 1 := by
      rcases heps with rfl | rfl <;> omega
    have ht_ltQ : L * y < E.Q := by
      nlinarith [hLy_bound, hqpos, heps_bounds.2]
    have ht_res : (L * y) % E.Q = L * y :=
      Int.emod_eq_of_lt (by omega) ht_ltQ
    by_cases hhalf : L * y ≤ E.Q / 2
    · have hdist : productShellDistance E y b = L * y := by
        dsimp [productShellDistance, cyclicDistance]
        rcases heps with rfl | rfl
        · have hres : (y * inverseMod E.Q b) % E.Q = L * y := by
            calc
              (y * inverseMod E.Q b) % E.Q =
                  (y * ((1 : ℤ) * L)) % E.Q := by simpa using hmody.eq
              _ = L * y := by
                rw [show y * (1 * L) = L * y by ring, ht_res]
          rw [hres, min_eq_left]
          omega
        · have hnot : ¬ E.Q ∣ L * y := by
            intro hdiv
            have hz := Int.emod_eq_zero_of_dvd hdiv
            rw [ht_res] at hz
            omega
          have hres : (y * inverseMod E.Q b) % E.Q = E.Q - L * y := by
            calc
              (y * inverseMod E.Q b) % E.Q =
                  (y * ((-1 : ℤ) * L)) % E.Q := by simpa using hmody.eq
              _ = (-(L * y)) % E.Q := by congr 1 <;> ring
              _ = E.Q - L * y := by
                rw [Int.neg_emod]
                simp [hnot, ht_res, Int.natAbs_of_nonneg hqpos.le]
          rw [hres]
          have hcomp : E.Q - (E.Q - L * y) = L * y := by ring
          rw [hcomp, min_eq_right]
          omega
      rw [productShellValue, hdist]
      have hcalc : b * (L * y) = y * (E.Q + eps) := by
        rw [← hL]
        ring
      have hepslow : -1 ≤ eps := by rcases heps with rfl | rfl <;> omega
      nlinarith [hcalc]
    · have hhalf' : E.Q / 2 < L * y := lt_of_not_ge hhalf
      have hhalfQ : E.Q / 2 = q := by rw [hqodd]; omega
      have hq_lt : q < L * y := by omega
      have heps1 : eps = 1 := by
        rcases heps with he | he
        · exact he
        · exfalso
          rw [he] at hLy_bound
          omega
      subst eps
      have hspecial : L * y = (E.Q + 1) / 2 := by
        rw [hqodd]
        omega
      have hdist : productShellDistance E y b = (E.Q - 1) / 2 := by
        dsimp [productShellDistance, cyclicDistance]
        have hres : (y * inverseMod E.Q b) % E.Q =
            (E.Q + 1) / 2 := by
          calc
            (y * inverseMod E.Q b) % E.Q =
                (y * (1 * L)) % E.Q := by simpa using hmody.eq
            _ = L * y := by
              rw [show y * (1 * L) = L * y by ring, ht_res]
            _ = (E.Q + 1) / 2 := hspecial
        rw [hres]
        have hcomp : E.Q - (E.Q + 1) / 2 = (E.Q - 1) / 2 := by omega
        rw [hcomp, min_eq_right]
        omega
      have hb_eq : b = 2 * y := by
        apply mul_left_cancel₀ (ne_of_gt hLpos)
        nlinarith [hL, hspecial]
      rw [productShellValue, hdist, hb_eq]
      have hhalf_mul : 2 * ((E.Q - 1) / 2) = E.Q - 1 := by
        rw [hqodd]
        omega
      have heq : y * (E.Q - 1) =
          2 * y * ((E.Q - 1) / 2) := by
        calc
          y * (E.Q - 1) = y * (2 * ((E.Q - 1) / 2)) :=
            congrArg (fun z : ℤ => y * z) hhalf_mul.symm
          _ = 2 * y * ((E.Q - 1) / 2) := by ring
      exact le_of_eq heq
  rcases hgood with hminus | hplus
  · obtain ⟨L, hL⟩ := hminus
    rw [hs] at hL
    apply hfar_case (-1) L (Or.inr rfl)
    nlinarith [hL]
  · obtain ⟨L, hL⟩ := hplus
    rw [hs] at hL
    apply hfar_case 1 L (Or.inl rfl)
    nlinarith [hL]

theorem triangularBoundScratch (A : Finset ℤ) (Q : ℤ)
    (hpos : ∀ a ∈ A, 0 < a)
    (hsum : (∑ a ∈ A, a) ≤ Q) :
    (A.card : ℤ) * ((A.card : ℤ) + 1) ≤ 2 * Q := by
  by_cases hn : A.Nonempty
  · have hcard0 : A.card ≠ 0 := Finset.card_ne_zero.mpr hn
    obtain ⟨n, hcard⟩ := Nat.exists_eq_succ_of_ne_zero hcard0
    let e : Fin (n + 1) ↪o ℤ := A.orderEmbOfFin hcard
    have he_mem (i : Fin (n + 1)) : e i ∈ A := by
      dsimp [e]
      exact Finset.orderEmbOfFin_mem A hcard i
    have he_lower : ∀ i : Fin (n + 1), (i.val : ℝ) + 1 ≤ (e i : ℝ) := by
      intro i
      induction i using Fin.induction with
      | zero =>
          exact_mod_cast hpos (e 0) (he_mem 0)
      | @succ i hi =>
          have hstepZ : e i.castSucc + 1 ≤ e i.succ := by
            have hlt := e.strictMono (Fin.castSucc_lt_succ (i := i))
            omega
          have hstep : (e i.castSucc : ℝ) + 1 ≤ (e i.succ : ℝ) := by
            exact_mod_cast hstepZ
          have hi' : (i.val : ℝ) + 1 ≤ (e i.castSucc : ℝ) := by
            simpa using hi
          have hnext : (i.val : ℝ) + 2 ≤ (e i.succ : ℝ) := by
            nlinarith [hi', hstep]
          norm_num [Fin.val_succ] at ⊢
          nlinarith [hnext]
    have hsum_image : (∑ a ∈ A, (a : ℝ)) =
        ∑ i : Fin (n + 1), (e i : ℝ) := by
      calc
        (∑ a ∈ A, (a : ℝ)) = ∑ a ∈ Finset.image e Finset.univ, (a : ℝ) := by
          rw [Finset.image_orderEmbOfFin_univ A hcard]
        _ = ∑ i ∈ (Finset.univ : Finset (Fin (n + 1))), (e i : ℝ) := by
          rw [Finset.sum_image]
          intro a ha b hb hab
          exact e.injective hab
        _ = ∑ i : Fin (n + 1), (e i : ℝ) := by simp
    have hsum_lower : (∑ i : Fin (n + 1), ((i.val : ℝ) + 1)) ≤
        ∑ i : Fin (n + 1), (e i : ℝ) := by
      exact Finset.sum_le_sum (fun i hi => he_lower i)
    rw [← hsum_image] at hsum_lower
    have hsum_index :
        (∑ i : Fin (n + 1), ((i.val : ℝ) + 1)) =
          ∑ k ∈ Finset.range (n + 1), ((k : ℝ) + 1) := by
      convert (Fin.sum_univ_eq_sum_range
        (fun k : ℕ => (k : ℝ) + 1) (n + 1)) using 1 <;> simp
    rw [hsum_index] at hsum_lower
    have hformula : ∀ r : ℕ,
        (∑ k ∈ Finset.range (r + 1), ((k : ℝ) + 1)) =
          ((r : ℝ) + 1) * ((r : ℝ) + 2) / 2 := by
      intro r
      induction r with
      | zero => norm_num
      | succ r ih =>
          rw [Finset.sum_range_succ, ih]
          push_cast
          ring
    rw [hformula n] at hsum_lower
    have hsumR : (∑ a ∈ A, (a : ℝ)) ≤ (Q : ℝ) := by
      have hcast : ((∑ a ∈ A, a : ℤ) : ℝ) = ∑ a ∈ A, (a : ℝ) := by
        norm_num
      rw [← hcast]
      exact_mod_cast hsum
    have htriR : ((n : ℝ) + 1) * ((n : ℝ) + 2) ≤ 2 * (Q : ℝ) := by
      nlinarith [hsum_lower, hsumR]
    have htriZ : ((n : ℤ) + 1) * ((n : ℤ) + 2) ≤ 2 * Q := by
      exact_mod_cast htriR
    simpa [hcard] using htriZ
  · have hzero : A = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
    simp [hzero] at hsum ⊢
    omega

theorem dyadicCloseFinalArithmeticScratch
    (m y Q p f : ℝ)
    (hm : 0 < m) (hy : 1 < y) (_hQ : 1 < Q)
    (hp : 0 ≤ p) (_hf : 0 ≤ f)
    (hs : 1 + p ≤ 2 * y / m - 1)
    (hbudget : p + f ≤ Q - y - 1) :
    1 / y + p / y + f / (y * (Q - 1)) < 2 / m := by
  have hy0 : 0 < y := lt_trans (by norm_num) hy
  have hQ0 : 0 < Q - 1 := by linarith
  have hden : 0 < y * (Q - 1) := mul_pos hy0 hQ0
  have hbudget' : f ≤ Q - y - (1 + p) := by linarith
  have hfterm : f / (y * (Q - 1)) ≤
      (Q - y - (1 + p)) / (y * (Q - 1)) := by
    exact (div_le_div_iff_of_pos_right hden).2 hbudget'
  have hphi :
      (1 + p) / y + (Q - y - (1 + p)) / (y * (Q - 1)) < 2 / m := by
    have hs' : 0 ≤ 2 * y / m - 1 - (1 + p) := by linarith
    have hnum : 0 <
        (Q - 1) * (2 * y / m - 1 - (1 + p)) + (y + (1 + p) - 1) := by
      have hysp : 0 < y + (1 + p) - 1 := by linarith
      positivity
    have hid :
        2 / m - ((1 + p) / y +
          (Q - y - (1 + p)) / (y * (Q - 1))) =
          ((Q - 1) * (2 * y / m - 1 - (1 + p)) +
            (y + (1 + p) - 1)) / (y * (Q - 1)) := by
      field_simp
      ring
    have hdiff : 0 < 2 / m - ((1 + p) / y +
        (Q - y - (1 + p)) / (y * (Q - 1))) := by
      rw [hid]
      exact div_pos hnum hden
    exact sub_pos.mp hdiff
  calc
    1 / y + p / y + f / (y * (Q - 1)) =
        (1 + p) / y + f / (y * (Q - 1)) := by ring
    _ ≤ (1 + p) / y +
        (Q - y - (1 + p)) / (y * (Q - 1)) := by linarith
    _ < 2 / m := hphi

theorem pBoundWithOneScratch
    (P PowP : Finset ℤ) (v : ℕ) (hPsub : P ⊆ PowP)
    (hone : 1 ∈ PowP) (hPone : 1 ∉ P)
    (hPowSum : (∑ a ∈ PowP, a) = (2 : ℤ) ^ (v + 1) - 1)
    (hPowPos : ∀ a ∈ PowP, 0 ≤ a) :
    1 + ∑ a ∈ P, a ≤ (2 : ℤ) ^ (v + 1) - 1 := by
  have hPoneSub : insert 1 P ⊆ PowP := by
    intro a ha
    rcases Finset.mem_insert.mp ha with rfl | ha
    · exact hone
    · exact hPsub ha
  have hsum : (∑ a ∈ insert 1 P, a) ≤ ∑ a ∈ PowP, a := by
    exact Finset.sum_le_sum_of_subset_of_nonneg hPoneSub
      (fun a ha _ => hPowPos a ha)
  rw [Finset.sum_insert hPone] at hsum
  omega

theorem pAndFBudgetScratch
    (A P F : Finset ℤ) (y Q : ℤ)
    (hy : 1 < y) (hyA : y ∈ A) (honeA : 1 ∈ A)
    (hAsum : (∑ a ∈ A, a) ≤ Q)
    (hApos : ∀ a ∈ A, 0 ≤ a)
    (hPsub : P ⊆ A.erase y) (hFsub : F ⊆ A.erase y)
    (hPone : 1 ∉ P) (hFone : 1 ∉ F)
    (hPFdisj : Disjoint P F) :
    (1 + ∑ a ∈ P, a) + ∑ a ∈ F, a ≤ Q - y := by
  have hPFsub : P ∪ F ⊆ A.erase y := by
    intro a ha
    rcases Finset.mem_union.mp ha with hpa | hfa
    · exact hPsub hpa
    · exact hFsub hfa
  have hPFone : 1 ∉ P ∪ F := by
    intro h
    rcases Finset.mem_union.mp h with h | h
    · exact hPone h
    · exact hFone h
  have hone_erase : 1 ∈ A.erase y := by
    exact Finset.mem_erase.mpr ⟨by omega, honeA⟩
  have hUsub : insert 1 (P ∪ F) ⊆ A.erase y := by
    intro a ha
    rcases Finset.mem_insert.mp ha with rfl | ha
    · exact hone_erase
    · exact hPFsub ha
  have hsumU : (∑ a ∈ insert 1 (P ∪ F), a) ≤
      ∑ a ∈ A.erase y, a := by
    exact Finset.sum_le_sum_of_subset_of_nonneg hUsub
      (fun a ha _ => hApos a (Finset.mem_erase.mp ha).2)
  have hsum_erase_eq : (∑ a ∈ A.erase y, a) + y =
      ∑ a ∈ A, a := by
    simpa using A.sum_erase_add (f := fun a : ℤ => a) hyA
  have hsum_erase : (∑ a ∈ A.erase y, a) + y ≤ Q := by
    linarith
  have hPFdisj' : Disjoint ({1} : Finset ℤ) (P ∪ F) := by
    rw [Finset.disjoint_singleton_left]
    exact hPFone
  rw [Finset.sum_insert hPFone, Finset.sum_union hPFdisj] at hsumU
  omega

end Fraenkel
